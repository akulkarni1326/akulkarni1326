package com.cleo.b2biaas.clarify;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/**
 * @author Manju Muthuraj
 * 
 */
public class UploadAttachment extends B2BAction{

	public static String attachementToken;

	public String getAttachmentToken(String fileName, String attachmentContent,
			String securityToken, String serverUrl) throws Exception {
		logInfo("Attachement Name : "+ fileName);
		//logInfo("Attachement Content : "+ attachmentContent);
		URL url = new URL(serverUrl + "?attachmentName=" + fileName);
		URLConnection urlConnection = url.openConnection();

		HttpURLConnection http = (HttpURLConnection) urlConnection;

		http.setRequestMethod(EventKeys.HTTP_POST_METHOD);
		http.setDoOutput(true);
		http.setRequestProperty(EventKeys.HEADER_KEY_CONTENT_TYPE,
				EventKeys.HEADER_VALUE_APPLICATION_OCTETSTREAM);
		http.setRequestProperty(EventKeys.HEADER_KEY_AUTHORIZATION, "Bearer "
				+ securityToken);
		http.connect();

		try (OutputStream os = http.getOutputStream()) {
			byte[] bytes = attachmentContent.getBytes();
			os.write(bytes);
		}

		int responseCode = http.getResponseCode();
		if (responseCode != 200) {
			logError("Upload Attachment Failed : HTTP error code : "
					+ http.getResponseCode() + ": Response message : "
					+ http.getResponseMessage());
			return attachementToken;
		}

		BufferedReader br = new BufferedReader(new InputStreamReader(
				http.getInputStream()));

		String output;
		while ((output = br.readLine()) != null) {
			JSONParser parse = new JSONParser();
			JSONObject jobj = (JSONObject) parse.parse(output);
			attachementToken = (String) jobj.get("token");
		}
		return attachementToken;
	}

}
