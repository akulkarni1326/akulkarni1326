/**
 * @generated
 */
package com.cleo.cic.cockpit.core.n850;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.extol.ebi.reactor.edi.lib.schema.*;

@SuppressWarnings("all")
public class n850v4010CockpitEDI_Rt implements RuntimeEdiDerivedMessageSchemaProvider {

	private RtEdiDerivedMessageSchema schema_n850v4010CockpitEDI;

	public RtEdiDerivedMessageSchema getSchema() {
		if (schema_n850v4010CockpitEDI == null) {
			DerivedMessageHelper h = new DerivedMessageHelper();
			h.message = message850();
			
			schema_n850v4010CockpitEDI = new RtEdiDerivedMessageSchema("n850v4010CockpitEDI", h);
		}

		return schema_n850v4010CockpitEDI;
	}
	
	private RtMessage message850;
	
	private RtMessage message850() {
		if (message850 == null) {
			MessageHelper h = new MessageHelper();
			h.name = "Purchase Order";
			h.functionalGroup = "PO";
			h.version = "004010";
			h.standardsClass = "X";
			h.industryGroup = "X";

			List<RtArea> areas = new ArrayList<>();
			areas.add(area1());
			areas.add(area2());
			areas.add(area3());

			message850 = new RtMessage("850", areas, h);
		}

		return message850;
	}
	
	private RtArea area1;
	
	private RtArea area1() {
		if (area1 == null) {
			Map<String, RtSegmentGroup> segmentGroups_0 = new HashMap<>();
			{
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("120", 0, 1, segmentSAC()));
				segmentFeatures.add(new RtSegmentReference("125", 0, 1, segmentCUR()));
				
				segmentGroups_0.put("SAC", new RtSegmentGroup("SAC", segmentFeatures));
			}
			{
				Map<String, RtSegmentGroup> segmentGroups_1 = new HashMap<>();
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("293", 0, 1, segmentFA1()));
					segmentFeatures.add(new RtSegmentReference("294", 1, 999999, segmentFA2()));
					
					segmentGroups_1.put("FA1", new RtSegmentGroup("FA1", segmentFeatures));
				}
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("287", 0, 1, segmentAMT()));
				segmentFeatures.add(new RtSegmentReference("289", 0, 999999, segmentREF()));
				segmentFeatures.add(new RtSegmentReference("290", 0, 1, segmentDTM()));
				segmentFeatures.add(new RtSegmentReference("292", 0, 999999, segmentPCT()));
				segmentFeatures.add(new RtSegmentGroupReference("293", 0, 999999, segmentGroups_1.get("FA1")));
				
				segmentGroups_0.put("AMT", new RtSegmentGroup("AMT", segmentFeatures, segmentGroups_1));
			}
			{
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("295", 0, 1, segmentN9()));
				segmentFeatures.add(new RtSegmentReference("297", 0, 999999, segmentDTM()));
				segmentFeatures.add(new RtSegmentReference("300", 0, 1000, segmentMSG()));
				
				segmentGroups_0.put("N9", new RtSegmentGroup("N9", segmentFeatures));
			}
			{
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("310", 0, 1, segmentN1()));
				segmentFeatures.add(new RtSegmentReference("320", 0, 2, segmentN2()));
				segmentFeatures.add(new RtSegmentReference("330", 0, 2, segmentN3()));
				segmentFeatures.add(new RtSegmentReference("340", 0, 999999, segmentN4()));
				segmentFeatures.add(new RtSegmentReference("345", 0, 999999, segmentNX2()));
				segmentFeatures.add(new RtSegmentReference("350", 0, 12, segmentREF()));
				segmentFeatures.add(new RtSegmentReference("360", 0, 999999, segmentPER()));
				segmentFeatures.add(new RtSegmentReference("365", 0, 999999, segmentSI()));
				segmentFeatures.add(new RtSegmentReference("370", 0, 1, segmentFOB()));
				segmentFeatures.add(new RtSegmentReference("380", 0, 2, segmentTD1()));
				segmentFeatures.add(new RtSegmentReference("390", 0, 12, segmentTD5()));
				segmentFeatures.add(new RtSegmentReference("400", 0, 12, segmentTD3()));
				segmentFeatures.add(new RtSegmentReference("410", 0, 5, segmentTD4()));
				segmentFeatures.add(new RtSegmentReference("420", 0, 200, segmentPKG()));
				
				segmentGroups_0.put("N1", new RtSegmentGroup("N1", segmentFeatures));
			}
			{
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("430", 0, 1, segmentLM()));
				segmentFeatures.add(new RtSegmentReference("440", 1, 999999, segmentLQ()));
				
				segmentGroups_0.put("LM", new RtSegmentGroup("LM", segmentFeatures));
			}
			{
				Map<String, RtSegmentGroup> segmentGroups_1 = new HashMap<>();
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("490", 0, 1, segmentN1()));
					segmentFeatures.add(new RtSegmentReference("500", 0, 2, segmentN2()));
					segmentFeatures.add(new RtSegmentReference("510", 0, 2, segmentN3()));
					segmentFeatures.add(new RtSegmentReference("520", 0, 1, segmentN4()));
					segmentFeatures.add(new RtSegmentReference("530", 0, 20, segmentREF()));
					segmentFeatures.add(new RtSegmentReference("540", 0, 1, segmentG61()));
					segmentFeatures.add(new RtSegmentReference("550", 0, 50, segmentMSG()));
					
					segmentGroups_1.put("N1", new RtSegmentGroup("N1", segmentFeatures));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("560", 0, 1, segmentCB1()));
					segmentFeatures.add(new RtSegmentReference("570", 0, 20, segmentREF()));
					segmentFeatures.add(new RtSegmentReference("580", 0, 5, segmentDTM()));
					segmentFeatures.add(new RtSegmentReference("590", 0, 1, segmentLDT()));
					segmentFeatures.add(new RtSegmentReference("600", 0, 50, segmentMSG()));
					
					segmentGroups_1.put("CB1", new RtSegmentGroup("CB1", segmentFeatures));
				}
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("450", 0, 1, segmentSPI()));
				segmentFeatures.add(new RtSegmentReference("460", 0, 5, segmentREF()));
				segmentFeatures.add(new RtSegmentReference("470", 0, 5, segmentDTM()));
				segmentFeatures.add(new RtSegmentReference("480", 0, 50, segmentMSG()));
				segmentFeatures.add(new RtSegmentGroupReference("490", 0, 20, segmentGroups_1.get("N1")));
				segmentFeatures.add(new RtSegmentGroupReference("560", 0, 999999, segmentGroups_1.get("CB1")));
				
				segmentGroups_0.put("SPI", new RtSegmentGroup("SPI", segmentFeatures, segmentGroups_1));
			}
			{
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("610", 0, 1, segmentADV()));
				segmentFeatures.add(new RtSegmentReference("620", 0, 999999, segmentDTM()));
				segmentFeatures.add(new RtSegmentReference("630", 0, 999999, segmentMTX()));
				
				segmentGroups_0.put("ADV", new RtSegmentGroup("ADV", segmentFeatures));
			}
			List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
			segmentFeatures.add(new RtSegmentReference("010", 1, 1, segmentST()));
			segmentFeatures.add(new RtSegmentReference("020", 1, 1, segmentBEG()));
			segmentFeatures.add(new RtSegmentReference("040", 0, 1, segmentCUR()));
			segmentFeatures.add(new RtSegmentReference("050", 0, 999999, segmentREF()));
			segmentFeatures.add(new RtSegmentReference("060", 0, 3, segmentPER()));
			segmentFeatures.add(new RtSegmentReference("070", 0, 999999, segmentTAX()));
			segmentFeatures.add(new RtSegmentReference("080", 0, 999999, segmentFOB()));
			segmentFeatures.add(new RtSegmentReference("090", 0, 999999, segmentCTP()));
			segmentFeatures.add(new RtSegmentReference("095", 0, 10, segmentPAM()));
			segmentFeatures.add(new RtSegmentReference("110", 0, 5, segmentCSH()));
			segmentFeatures.add(new RtSegmentReference("115", 0, 999999, segmentTC2()));
			segmentFeatures.add(new RtSegmentGroupReference("120", 0, 25, segmentGroups_0.get("SAC")));
			segmentFeatures.add(new RtSegmentReference("130", 0, 999999, segmentITD()));
			segmentFeatures.add(new RtSegmentReference("140", 0, 20, segmentDIS()));
			segmentFeatures.add(new RtSegmentReference("145", 0, 1, segmentINC()));
			segmentFeatures.add(new RtSegmentReference("150", 0, 10, segmentDTM()));
			segmentFeatures.add(new RtSegmentReference("160", 0, 12, segmentLDT()));
			segmentFeatures.add(new RtSegmentReference("180", 0, 5, segmentLIN()));
			segmentFeatures.add(new RtSegmentReference("185", 0, 999999, segmentSI()));
			segmentFeatures.add(new RtSegmentReference("190", 0, 200, segmentPID()));
			segmentFeatures.add(new RtSegmentReference("200", 0, 40, segmentMEA()));
			segmentFeatures.add(new RtSegmentReference("210", 0, 25, segmentPWK()));
			segmentFeatures.add(new RtSegmentReference("220", 0, 200, segmentPKG()));
			segmentFeatures.add(new RtSegmentReference("230", 0, 2, segmentTD1()));
			segmentFeatures.add(new RtSegmentReference("240", 0, 12, segmentTD5()));
			segmentFeatures.add(new RtSegmentReference("250", 0, 12, segmentTD3()));
			segmentFeatures.add(new RtSegmentReference("260", 0, 5, segmentTD4()));
			segmentFeatures.add(new RtSegmentReference("270", 0, 10, segmentMAN()));
			segmentFeatures.add(new RtSegmentReference("276", 0, 999999, segmentPCT()));
			segmentFeatures.add(new RtSegmentReference("280", 0, 5, segmentCTB()));
			segmentFeatures.add(new RtSegmentReference("285", 0, 999999, segmentTXI()));
			segmentFeatures.add(new RtSegmentGroupReference("287", 0, 999999, segmentGroups_0.get("AMT")));
			segmentFeatures.add(new RtSegmentGroupReference("295", 0, 1000, segmentGroups_0.get("N9")));
			segmentFeatures.add(new RtSegmentGroupReference("310", 0, 200, segmentGroups_0.get("N1")));
			segmentFeatures.add(new RtSegmentGroupReference("430", 0, 999999, segmentGroups_0.get("LM")));
			segmentFeatures.add(new RtSegmentGroupReference("450", 0, 999999, segmentGroups_0.get("SPI")));
			segmentFeatures.add(new RtSegmentGroupReference("610", 0, 999999, segmentGroups_0.get("ADV")));
			
			area1 = new RtArea("1", segmentFeatures, segmentGroups_0);
		}
		
		return area1;
	}
	
	private RtArea area2;
	
	private RtArea area2() {
		if (area2 == null) {
			Map<String, RtSegmentGroup> segmentGroups_0 = new HashMap<>();
			{
				Map<String, RtSegmentGroup> segmentGroups_1 = new HashMap<>();
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("040", 0, 1, segmentCTP()));
					segmentFeatures.add(new RtSegmentReference("043", 0, 1, segmentCUR()));
					
					segmentGroups_1.put("CTP", new RtSegmentGroup("CTP", segmentFeatures));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("050", 0, 1, segmentPID()));
					segmentFeatures.add(new RtSegmentReference("060", 0, 10, segmentMEA()));
					
					segmentGroups_1.put("PID", new RtSegmentGroup("PID", segmentFeatures));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("130", 0, 1, segmentSAC()));
					segmentFeatures.add(new RtSegmentReference("135", 0, 1, segmentCUR()));
					segmentFeatures.add(new RtSegmentReference("137", 0, 1, segmentCTP()));
					
					segmentGroups_1.put("SAC", new RtSegmentGroup("SAC", segmentFeatures));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("293", 0, 1, segmentQTY()));
					segmentFeatures.add(new RtSegmentReference("294", 0, 999999, segmentSI()));
					
					segmentGroups_1.put("QTY", new RtSegmentGroup("QTY", segmentFeatures));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("295", 0, 1, segmentSCH()));
					segmentFeatures.add(new RtSegmentReference("296", 0, 2, segmentTD1()));
					segmentFeatures.add(new RtSegmentReference("297", 0, 12, segmentTD5()));
					segmentFeatures.add(new RtSegmentReference("298", 0, 12, segmentTD3()));
					segmentFeatures.add(new RtSegmentReference("299", 0, 5, segmentTD4()));
					segmentFeatures.add(new RtSegmentReference("300", 0, 999999, segmentREF()));
					
					segmentGroups_1.put("SCH", new RtSegmentGroup("SCH", segmentFeatures));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("305", 0, 1, segmentPKG()));
					segmentFeatures.add(new RtSegmentReference("310", 0, 999999, segmentMEA()));
					
					segmentGroups_1.put("PKG", new RtSegmentGroup("PKG", segmentFeatures));
				}
				{
					Map<String, RtSegmentGroup> segmentGroups_2 = new HashMap<>();
					{
						List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
						segmentFeatures.add(new RtSegmentReference("325", 0, 1, segmentLM()));
						segmentFeatures.add(new RtSegmentReference("326", 1, 999999, segmentLQ()));
						
						segmentGroups_2.put("LM", new RtSegmentGroup("LM", segmentFeatures));
					}
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("321", 0, 1, segmentLDT()));
					segmentFeatures.add(new RtSegmentReference("322", 0, 999999, segmentQTY()));
					segmentFeatures.add(new RtSegmentReference("323", 0, 1, segmentMSG()));
					segmentFeatures.add(new RtSegmentReference("324", 0, 3, segmentREF()));
					segmentFeatures.add(new RtSegmentGroupReference("325", 0, 999999, segmentGroups_2.get("LM")));
					
					segmentGroups_1.put("LDT", new RtSegmentGroup("LDT", segmentFeatures, segmentGroups_2));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("330", 0, 1, segmentN9()));
					segmentFeatures.add(new RtSegmentReference("332", 0, 999999, segmentDTM()));
					segmentFeatures.add(new RtSegmentReference("335", 0, 40, segmentMEA()));
					segmentFeatures.add(new RtSegmentReference("340", 0, 1000, segmentMSG()));
					
					segmentGroups_1.put("N9", new RtSegmentGroup("N9", segmentFeatures));
				}
				{
					Map<String, RtSegmentGroup> segmentGroups_2 = new HashMap<>();
					{
						List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
						segmentFeatures.add(new RtSegmentReference("462", 0, 1, segmentLDT()));
						segmentFeatures.add(new RtSegmentReference("464", 0, 10, segmentMAN()));
						segmentFeatures.add(new RtSegmentReference("466", 0, 5, segmentQTY()));
						segmentFeatures.add(new RtSegmentReference("468", 0, 1, segmentMSG()));
						segmentFeatures.add(new RtSegmentReference("469", 0, 3, segmentREF()));
						
						segmentGroups_2.put("LDT", new RtSegmentGroup("LDT", segmentFeatures));
					}
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("350", 0, 1, segmentN1()));
					segmentFeatures.add(new RtSegmentReference("360", 0, 2, segmentN2()));
					segmentFeatures.add(new RtSegmentReference("370", 0, 2, segmentN3()));
					segmentFeatures.add(new RtSegmentReference("380", 0, 1, segmentN4()));
					segmentFeatures.add(new RtSegmentReference("383", 0, 999999, segmentQTY()));
					segmentFeatures.add(new RtSegmentReference("385", 0, 999999, segmentNX2()));
					segmentFeatures.add(new RtSegmentReference("390", 0, 12, segmentREF()));
					segmentFeatures.add(new RtSegmentReference("400", 0, 3, segmentPER()));
					segmentFeatures.add(new RtSegmentReference("405", 0, 999999, segmentSI()));
					segmentFeatures.add(new RtSegmentReference("406", 0, 1, segmentDTM()));
					segmentFeatures.add(new RtSegmentReference("410", 0, 1, segmentFOB()));
					segmentFeatures.add(new RtSegmentReference("415", 0, 200, segmentSCH()));
					segmentFeatures.add(new RtSegmentReference("420", 0, 2, segmentTD1()));
					segmentFeatures.add(new RtSegmentReference("430", 0, 12, segmentTD5()));
					segmentFeatures.add(new RtSegmentReference("440", 0, 12, segmentTD3()));
					segmentFeatures.add(new RtSegmentReference("450", 0, 5, segmentTD4()));
					segmentFeatures.add(new RtSegmentReference("460", 0, 200, segmentPKG()));
					segmentFeatures.add(new RtSegmentGroupReference("462", 0, 999999, segmentGroups_2.get("LDT")));
					
					segmentGroups_1.put("N1", new RtSegmentGroup("N1", segmentFeatures, segmentGroups_2));
				}
				{
					Map<String, RtSegmentGroup> segmentGroups_2 = new HashMap<>();
					{
						List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
						segmentFeatures.add(new RtSegmentReference("523", 0, 1, segmentN9()));
						segmentFeatures.add(new RtSegmentReference("524", 0, 999999, segmentDTM()));
						segmentFeatures.add(new RtSegmentReference("525", 0, 999999, segmentMSG()));
						
						segmentGroups_2.put("N9", new RtSegmentGroup("N9", segmentFeatures));
					}
					{
						List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
						segmentFeatures.add(new RtSegmentReference("526", 0, 1, segmentSAC()));
						segmentFeatures.add(new RtSegmentReference("527", 0, 1, segmentCUR()));
						segmentFeatures.add(new RtSegmentReference("528", 0, 1, segmentCTP()));
						
						segmentGroups_2.put("SAC", new RtSegmentGroup("SAC", segmentFeatures));
					}
					{
						List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
						segmentFeatures.add(new RtSegmentReference("529", 0, 1, segmentQTY()));
						segmentFeatures.add(new RtSegmentReference("530", 0, 999999, segmentSI()));
						
						segmentGroups_2.put("QTY", new RtSegmentGroup("QTY", segmentFeatures));
					}
					{
						List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
						segmentFeatures.add(new RtSegmentReference("535", 0, 1, segmentN1()));
						segmentFeatures.add(new RtSegmentReference("540", 0, 2, segmentN2()));
						segmentFeatures.add(new RtSegmentReference("550", 0, 2, segmentN3()));
						segmentFeatures.add(new RtSegmentReference("560", 0, 1, segmentN4()));
						segmentFeatures.add(new RtSegmentReference("570", 0, 999999, segmentNX2()));
						segmentFeatures.add(new RtSegmentReference("580", 0, 12, segmentREF()));
						segmentFeatures.add(new RtSegmentReference("590", 0, 3, segmentPER()));
						segmentFeatures.add(new RtSegmentReference("595", 0, 999999, segmentSI()));
						
						segmentGroups_2.put("N1", new RtSegmentGroup("N1", segmentFeatures));
					}
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("470", 0, 1, segmentSLN()));
					segmentFeatures.add(new RtSegmentReference("475", 0, 999999, segmentMSG()));
					segmentFeatures.add(new RtSegmentReference("480", 0, 999999, segmentSI()));
					segmentFeatures.add(new RtSegmentReference("490", 0, 1000, segmentPID()));
					segmentFeatures.add(new RtSegmentReference("500", 0, 104, segmentPO3()));
					segmentFeatures.add(new RtSegmentReference("505", 0, 999999, segmentTC2()));
					segmentFeatures.add(new RtSegmentReference("513", 0, 999999, segmentADV()));
					segmentFeatures.add(new RtSegmentReference("515", 0, 10, segmentDTM()));
					segmentFeatures.add(new RtSegmentReference("516", 0, 25, segmentCTP()));
					segmentFeatures.add(new RtSegmentReference("517", 0, 10, segmentPAM()));
					segmentFeatures.add(new RtSegmentReference("518", 0, 1, segmentPO4()));
					segmentFeatures.add(new RtSegmentReference("519", 0, 3, segmentTAX()));
					segmentFeatures.add(new RtSegmentGroupReference("523", 0, 999999, segmentGroups_2.get("N9")));
					segmentFeatures.add(new RtSegmentGroupReference("526", 0, 25, segmentGroups_2.get("SAC")));
					segmentFeatures.add(new RtSegmentGroupReference("529", 0, 999999, segmentGroups_2.get("QTY")));
					segmentFeatures.add(new RtSegmentGroupReference("535", 0, 10, segmentGroups_2.get("N1")));
					
					segmentGroups_1.put("SLN", new RtSegmentGroup("SLN", segmentFeatures, segmentGroups_2));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("600", 0, 1, segmentAMT()));
					segmentFeatures.add(new RtSegmentReference("610", 0, 1, segmentREF()));
					segmentFeatures.add(new RtSegmentReference("612", 0, 999999, segmentPCT()));
					
					segmentGroups_1.put("AMT", new RtSegmentGroup("AMT", segmentFeatures));
				}
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("620", 0, 1, segmentLM()));
					segmentFeatures.add(new RtSegmentReference("630", 1, 999999, segmentLQ()));
					
					segmentGroups_1.put("LM", new RtSegmentGroup("LM", segmentFeatures));
				}
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("010", 1, 1, segmentPO1()));
				segmentFeatures.add(new RtSegmentReference("015", 0, 999999, segmentLIN()));
				segmentFeatures.add(new RtSegmentReference("018", 0, 999999, segmentSI()));
				segmentFeatures.add(new RtSegmentReference("020", 0, 1, segmentCUR()));
				segmentFeatures.add(new RtSegmentReference("025", 0, 1, segmentCN1()));
				segmentFeatures.add(new RtSegmentReference("030", 0, 25, segmentPO3()));
				segmentFeatures.add(new RtSegmentGroupReference("040", 0, 999999, segmentGroups_1.get("CTP")));
				segmentFeatures.add(new RtSegmentReference("045", 0, 10, segmentPAM()));
				segmentFeatures.add(new RtSegmentReference("049", 0, 40, segmentMEA()));
				segmentFeatures.add(new RtSegmentGroupReference("050", 0, 1000, segmentGroups_1.get("PID")));
				segmentFeatures.add(new RtSegmentReference("070", 0, 25, segmentPWK()));
				segmentFeatures.add(new RtSegmentReference("090", 0, 999999, segmentPO4()));
				segmentFeatures.add(new RtSegmentReference("100", 0, 999999, segmentREF()));
				segmentFeatures.add(new RtSegmentReference("110", 0, 3, segmentPER()));
				segmentFeatures.add(new RtSegmentGroupReference("130", 0, 25, segmentGroups_1.get("SAC")));
				segmentFeatures.add(new RtSegmentReference("140", 0, 1, segmentIT8()));
				segmentFeatures.add(new RtSegmentReference("142", 0, 999999, segmentCSH()));
				segmentFeatures.add(new RtSegmentReference("150", 0, 2, segmentITD()));
				segmentFeatures.add(new RtSegmentReference("160", 0, 20, segmentDIS()));
				segmentFeatures.add(new RtSegmentReference("165", 0, 1, segmentINC()));
				segmentFeatures.add(new RtSegmentReference("170", 0, 999999, segmentTAX()));
				segmentFeatures.add(new RtSegmentReference("180", 0, 999999, segmentFOB()));
				segmentFeatures.add(new RtSegmentReference("190", 0, 500, segmentSDQ()));
				segmentFeatures.add(new RtSegmentReference("200", 0, 5, segmentIT3()));
				segmentFeatures.add(new RtSegmentReference("210", 0, 10, segmentDTM()));
				segmentFeatures.add(new RtSegmentReference("235", 0, 999999, segmentTC2()));
				segmentFeatures.add(new RtSegmentReference("240", 0, 1, segmentTD1()));
				segmentFeatures.add(new RtSegmentReference("250", 0, 12, segmentTD5()));
				segmentFeatures.add(new RtSegmentReference("260", 0, 12, segmentTD3()));
				segmentFeatures.add(new RtSegmentReference("270", 0, 5, segmentTD4()));
				segmentFeatures.add(new RtSegmentReference("276", 0, 999999, segmentPCT()));
				segmentFeatures.add(new RtSegmentReference("280", 0, 10, segmentMAN()));
				segmentFeatures.add(new RtSegmentReference("289", 0, 999999, segmentMSG()));
				segmentFeatures.add(new RtSegmentReference("290", 0, 999999, segmentSPI()));
				segmentFeatures.add(new RtSegmentReference("291", 0, 999999, segmentTXI()));
				segmentFeatures.add(new RtSegmentReference("292", 0, 999999, segmentCTB()));
				segmentFeatures.add(new RtSegmentGroupReference("293", 0, 999999, segmentGroups_1.get("QTY")));
				segmentFeatures.add(new RtSegmentGroupReference("295", 0, 200, segmentGroups_1.get("SCH")));
				segmentFeatures.add(new RtSegmentGroupReference("305", 0, 200, segmentGroups_1.get("PKG")));
				segmentFeatures.add(new RtSegmentReference("320", 0, 1, segmentLS()));
				segmentFeatures.add(new RtSegmentGroupReference("321", 0, 999999, segmentGroups_1.get("LDT")));
				segmentFeatures.add(new RtSegmentReference("327", 0, 1, segmentLE()));
				segmentFeatures.add(new RtSegmentGroupReference("330", 0, 1000, segmentGroups_1.get("N9")));
				segmentFeatures.add(new RtSegmentGroupReference("350", 0, 200, segmentGroups_1.get("N1")));
				segmentFeatures.add(new RtSegmentGroupReference("470", 0, 1000, segmentGroups_1.get("SLN")));
				segmentFeatures.add(new RtSegmentGroupReference("600", 0, 999999, segmentGroups_1.get("AMT")));
				segmentFeatures.add(new RtSegmentGroupReference("620", 0, 999999, segmentGroups_1.get("LM")));
				
				segmentGroups_0.put("PO1", new RtSegmentGroup("PO1", segmentFeatures, segmentGroups_1));
			}
			List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
			segmentFeatures.add(new RtSegmentGroupReference("010", 1, 100000, segmentGroups_0.get("PO1")));
			
			area2 = new RtArea("2", segmentFeatures, segmentGroups_0);
		}
		
		return area2;
	}
	
	private RtArea area3;
	
	private RtArea area3() {
		if (area3 == null) {
			Map<String, RtSegmentGroup> segmentGroups_0 = new HashMap<>();
			{
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("010", 0, 1, segmentCTT()));
				segmentFeatures.add(new RtSegmentReference("020", 0, 1, segmentAMT()));
				
				segmentGroups_0.put("CTT", new RtSegmentGroup("CTT", segmentFeatures));
			}
			List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
			segmentFeatures.add(new RtSegmentGroupReference("010", 0, 1, segmentGroups_0.get("CTT")));
			segmentFeatures.add(new RtSegmentReference("030", 1, 1, segmentSE()));
			
			area3 = new RtArea("3", segmentFeatures, segmentGroups_0);
		}
		
		return area3;
	}
	
	private RtSegment segmentST;
	
	private RtSegment segmentST() {
		if (segmentST == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "ST143", simpleElement143()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "ST329", simpleElement329()));
			segmentST = new RtSegment("ST", elementReferences);
		}

		return segmentST;
	}
	
	private RtSegment segmentBEG;
	
	private RtSegment segmentBEG() {
		if (segmentBEG == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "BEG353", simpleElement353()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "BEG92", simpleElement92()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "BEG324", simpleElement324()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "BEG328", simpleElement328()));
			elementReferences.add(new RtSimpleElementReference("05", 1, 1, "BEG373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "BEG367", simpleElement367()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "BEG587", simpleElement587()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "BEG1019", simpleElement1019()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "BEG1166", simpleElement1166()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "BEG1232", simpleElement1232()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "BEG786", simpleElement786()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "BEG640", simpleElement640()));
			segmentBEG = new RtSegment("BEG", elementReferences);
		}

		return segmentBEG;
	}
	
	private RtSegment segmentCUR;
	
	private RtSegment segmentCUR() {
		if (segmentCUR == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "CUR98", simpleElement98()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "CUR100", simpleElement100()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "CUR280", simpleElement280()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "CUR98_3", simpleElement98()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "CUR100_3", simpleElement100()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "CUR669", simpleElement669()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "CUR374", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "CUR373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "CUR337", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "CUR374_3", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "CUR373_3", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "CUR337_3", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "CUR374_4", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "CUR373_4", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "CUR337_4", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "CUR374_5", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "CUR373_5", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "CUR337_5", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("19", 0, 1, "CUR374_6", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("20", 0, 1, "CUR373_6", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("21", 0, 1, "CUR337_6", simpleElement337()));
			segmentCUR = new RtSegment("CUR", elementReferences);
		}

		return segmentCUR;
	}
	
	private RtSegment segmentREF;
	
	private RtSegment segmentREF() {
		if (segmentREF == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "REF128", simpleElement128()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "REF127", simpleElement127()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "REF352", simpleElement352()));
			elementReferences.add(new RtCompositeElementReference("04", 0, 1, "REFC040", compositeElementC040()));
			segmentREF = new RtSegment("REF", elementReferences);
		}

		return segmentREF;
	}
	
	private RtSegment segmentPER;
	
	private RtSegment segmentPER() {
		if (segmentPER == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "PER366", simpleElement366()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PER93", simpleElement93()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "PER365", simpleElement365()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PER364", simpleElement364()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PER365_3", simpleElement365()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "PER364_3", simpleElement364()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "PER365_4", simpleElement365()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "PER364_4", simpleElement364()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "PER443", simpleElement443()));
			segmentPER = new RtSegment("PER", elementReferences);
		}

		return segmentPER;
	}
	
	private RtSegment segmentTAX;
	
	private RtSegment segmentTAX() {
		if (segmentTAX == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "TAX325", simpleElement325()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "TAX309", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "TAX310", simpleElement310()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "TAX309_3", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "TAX310_3", simpleElement310()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "TAX309_4", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "TAX310_4", simpleElement310()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "TAX309_5", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "TAX310_5", simpleElement310()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "TAX309_6", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "TAX310_6", simpleElement310()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "TAX441", simpleElement441()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "TAX1179", simpleElement1179()));
			segmentTAX = new RtSegment("TAX", elementReferences);
		}

		return segmentTAX;
	}
	
	private RtSegment segmentFOB;
	
	private RtSegment segmentFOB() {
		if (segmentFOB == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "FOB146", simpleElement146()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "FOB309", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "FOB352", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "FOB334", simpleElement334()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "FOB335", simpleElement335()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "FOB309_3", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "FOB352_3", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "FOB54", simpleElement54()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "FOB352_4", simpleElement352()));
			segmentFOB = new RtSegment("FOB", elementReferences);
		}

		return segmentFOB;
	}
	
	private RtSegment segmentCTP;
	
	private RtSegment segmentCTP() {
		if (segmentCTP == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "CTP687", simpleElement687()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "CTP236", simpleElement236()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "CTP212", simpleElement212()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "CTP380", simpleElement380()));
			elementReferences.add(new RtCompositeElementReference("05", 0, 1, "CTPC001", compositeElementC001()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "CTP648", simpleElement648()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "CTP649", simpleElement649()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "CTP782", simpleElement782()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "CTP639", simpleElement639()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "CTP499", simpleElement499()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "CTP289", simpleElement289()));
			segmentCTP = new RtSegment("CTP", elementReferences);
		}

		return segmentCTP;
	}
	
	private RtSegment segmentPAM;
	
	private RtSegment segmentPAM() {
		if (segmentPAM == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "PAM673", simpleElement673()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PAM380", simpleElement380()));
			elementReferences.add(new RtCompositeElementReference("03", 0, 1, "PAMC001", compositeElementC001()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PAM522", simpleElement522()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PAM782", simpleElement782()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "PAM344", simpleElement344()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "PAM374", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "PAM373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "PAM337", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "PAM374_3", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "PAM373_3", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "PAM337_3", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "PAM1004", simpleElement1004()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "PAM954", simpleElement954()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "PAM1073", simpleElement1073()));
			segmentPAM = new RtSegment("PAM", elementReferences);
		}

		return segmentPAM;
	}
	
	private RtSegment segmentCSH;
	
	private RtSegment segmentCSH() {
		if (segmentCSH == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "CSH563", simpleElement563()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "CSH306", simpleElement306()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "CSH610", simpleElement610()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "CSH508", simpleElement508()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "CSH373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "CSH559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "CSH560", simpleElement560()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "CSH566", simpleElement566()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "CSH954", simpleElement954()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "CSH1004", simpleElement1004()));
			segmentCSH = new RtSegment("CSH", elementReferences);
		}

		return segmentCSH;
	}
	
	private RtSegment segmentTC2;
	
	private RtSegment segmentTC2() {
		if (segmentTC2 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "TC223", simpleElement23()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "TC222", simpleElement22()));
			segmentTC2 = new RtSegment("TC2", elementReferences);
		}

		return segmentTC2;
	}
	
	private RtSegment segmentSAC;
	
	private RtSegment segmentSAC() {
		if (segmentSAC == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SAC248", simpleElement248()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "SAC1300", simpleElement1300()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "SAC559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "SAC1301", simpleElement1301()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "SAC610", simpleElement610()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "SAC378", simpleElement378()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "SAC332", simpleElement332()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "SAC118", simpleElement118()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "SAC355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "SAC380", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "SAC380_3", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "SAC331", simpleElement331()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "SAC127", simpleElement127()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "SAC770", simpleElement770()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "SAC352", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "SAC819", simpleElement819()));
			segmentSAC = new RtSegment("SAC", elementReferences);
		}

		return segmentSAC;
	}
	
	private RtSegment segmentITD;
	
	private RtSegment segmentITD() {
		if (segmentITD == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "ITD336", simpleElement336()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "ITD333", simpleElement333()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "ITD338", simpleElement338()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "ITD370", simpleElement370()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "ITD351", simpleElement351()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "ITD446", simpleElement446()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "ITD386", simpleElement386()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "ITD362", simpleElement362()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "ITD388", simpleElement388()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "ITD389", simpleElement389()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "ITD342", simpleElement342()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "ITD352", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "ITD765", simpleElement765()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "ITD107", simpleElement107()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "ITD954", simpleElement954()));
			segmentITD = new RtSegment("ITD", elementReferences);
		}

		return segmentITD;
	}
	
	private RtSegment segmentDIS;
	
	private RtSegment segmentDIS() {
		if (segmentDIS == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "DIS653", simpleElement653()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "DIS654", simpleElement654()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "DIS655", simpleElement655()));
			elementReferences.add(new RtSimpleElementReference("04", 1, 1, "DIS656", simpleElement656()));
			elementReferences.add(new RtSimpleElementReference("05", 1, 1, "DIS657", simpleElement657()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "DIS657_3", simpleElement657()));
			segmentDIS = new RtSegment("DIS", elementReferences);
		}

		return segmentDIS;
	}
	
	private RtSegment segmentINC;
	
	private RtSegment segmentINC() {
		if (segmentINC == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "INC336", simpleElement336()));
			elementReferences.add(new RtCompositeElementReference("02", 1, 1, "INCC001", compositeElementC001()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "INC380", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("04", 1, 1, "INC380_3", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "INC782", simpleElement782()));
			segmentINC = new RtSegment("INC", elementReferences);
		}

		return segmentINC;
	}
	
	private RtSegment segmentDTM;
	
	private RtSegment segmentDTM() {
		if (segmentDTM == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "DTM374", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "DTM373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "DTM337", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "DTM623", simpleElement623()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "DTM1250", simpleElement1250()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "DTM1251", simpleElement1251()));
			segmentDTM = new RtSegment("DTM", elementReferences);
		}

		return segmentDTM;
	}
	
	private RtSegment segmentLDT;
	
	private RtSegment segmentLDT() {
		if (segmentLDT == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "LDT345", simpleElement345()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "LDT380", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "LDT344", simpleElement344()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "LDT373", simpleElement373()));
			segmentLDT = new RtSegment("LDT", elementReferences);
		}

		return segmentLDT;
	}
	
	private RtSegment segmentLIN;
	
	private RtSegment segmentLIN() {
		if (segmentLIN == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "LIN350", simpleElement350()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "LIN235", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "LIN234", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "LIN235_3", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "LIN234_3", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "LIN235_4", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "LIN234_4", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "LIN235_5", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "LIN234_5", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "LIN235_6", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "LIN234_6", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "LIN235_7", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "LIN234_7", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "LIN235_8", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "LIN234_8", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "LIN235_9", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "LIN234_9", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "LIN235_10", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("19", 0, 1, "LIN234_10", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("20", 0, 1, "LIN235_11", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("21", 0, 1, "LIN234_11", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("22", 0, 1, "LIN235_12", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("23", 0, 1, "LIN234_12", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("24", 0, 1, "LIN235_13", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("25", 0, 1, "LIN234_13", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("26", 0, 1, "LIN235_14", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("27", 0, 1, "LIN234_14", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("28", 0, 1, "LIN235_15", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("29", 0, 1, "LIN234_15", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("30", 0, 1, "LIN235_16", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("31", 0, 1, "LIN234_16", simpleElement234()));
			segmentLIN = new RtSegment("LIN", elementReferences);
		}

		return segmentLIN;
	}
	
	private RtSegment segmentSI;
	
	private RtSegment segmentSI() {
		if (segmentSI == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SI559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "SI1000", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "SI234", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "SI1000_3", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "SI234_3", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "SI1000_4", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "SI234_4", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "SI1000_5", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "SI234_5", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "SI1000_6", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "SI234_6", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "SI1000_7", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "SI234_7", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "SI1000_8", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "SI234_8", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "SI1000_9", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "SI234_9", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "SI1000_10", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("19", 0, 1, "SI234_10", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("20", 0, 1, "SI1000_11", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("21", 0, 1, "SI234_11", simpleElement234()));
			segmentSI = new RtSegment("SI", elementReferences);
		}

		return segmentSI;
	}
	
	private RtSegment segmentPID;
	
	private RtSegment segmentPID() {
		if (segmentPID == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "PID349", simpleElement349()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PID750", simpleElement750()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "PID559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PID751", simpleElement751()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PID352", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "PID752", simpleElement752()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "PID822", simpleElement822()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "PID1073", simpleElement1073()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "PID819", simpleElement819()));
			segmentPID = new RtSegment("PID", elementReferences);
		}

		return segmentPID;
	}
	
	private RtSegment segmentMEA;
	
	private RtSegment segmentMEA() {
		if (segmentMEA == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "MEA737", simpleElement737()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "MEA738", simpleElement738()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "MEA739", simpleElement739()));
			elementReferences.add(new RtCompositeElementReference("04", 0, 1, "MEAC001", compositeElementC001()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "MEA740", simpleElement740()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "MEA741", simpleElement741()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "MEA935", simpleElement935()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "MEA936", simpleElement936()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "MEA752", simpleElement752()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "MEA1373", simpleElement1373()));
			segmentMEA = new RtSegment("MEA", elementReferences);
		}

		return segmentMEA;
	}
	
	private RtSegment segmentPWK;
	
	private RtSegment segmentPWK() {
		if (segmentPWK == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "PWK755", simpleElement755()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PWK756", simpleElement756()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "PWK757", simpleElement757()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PWK98", simpleElement98()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PWK66", simpleElement66()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "PWK67", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "PWK352", simpleElement352()));
			elementReferences.add(new RtCompositeElementReference("08", 0, 1, "PWKC002", compositeElementC002()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "PWK1525", simpleElement1525()));
			segmentPWK = new RtSegment("PWK", elementReferences);
		}

		return segmentPWK;
	}
	
	private RtSegment segmentPKG;
	
	private RtSegment segmentPKG() {
		if (segmentPKG == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "PKG349", simpleElement349()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PKG753", simpleElement753()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "PKG559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PKG754", simpleElement754()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PKG352", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "PKG400", simpleElement400()));
			segmentPKG = new RtSegment("PKG", elementReferences);
		}

		return segmentPKG;
	}
	
	private RtSegment segmentTD1;
	
	private RtSegment segmentTD1() {
		if (segmentTD1 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "TD1103", simpleElement103()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "TD180", simpleElement80()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "TD123", simpleElement23()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "TD122", simpleElement22()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "TD179", simpleElement79()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "TD1187", simpleElement187()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "TD181", simpleElement81()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "TD1355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "TD1183", simpleElement183()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "TD1355_3", simpleElement355()));
			segmentTD1 = new RtSegment("TD1", elementReferences);
		}

		return segmentTD1;
	}
	
	private RtSegment segmentTD5;
	
	private RtSegment segmentTD5() {
		if (segmentTD5 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "TD5133", simpleElement133()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "TD566", simpleElement66()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "TD567", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "TD591", simpleElement91()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "TD5387", simpleElement387()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "TD5368", simpleElement368()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "TD5309", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "TD5310", simpleElement310()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "TD5731", simpleElement731()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "TD5732", simpleElement732()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "TD5733", simpleElement733()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "TD5284", simpleElement284()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "TD5284_3", simpleElement284()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "TD5284_4", simpleElement284()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "TD526", simpleElement26()));
			segmentTD5 = new RtSegment("TD5", elementReferences);
		}

		return segmentTD5;
	}
	
	private RtSegment segmentTD3;
	
	private RtSegment segmentTD3() {
		if (segmentTD3 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "TD340", simpleElement40()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "TD3206", simpleElement206()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "TD3207", simpleElement207()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "TD3187", simpleElement187()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "TD381", simpleElement81()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "TD3355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "TD3102", simpleElement102()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "TD3407", simpleElement407()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "TD3225", simpleElement225()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "TD324", simpleElement24()));
			segmentTD3 = new RtSegment("TD3", elementReferences);
		}

		return segmentTD3;
	}
	
	private RtSegment segmentTD4;
	
	private RtSegment segmentTD4() {
		if (segmentTD4 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "TD4152", simpleElement152()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "TD4208", simpleElement208()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "TD4209", simpleElement209()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "TD4352", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "TD41073", simpleElement1073()));
			segmentTD4 = new RtSegment("TD4", elementReferences);
		}

		return segmentTD4;
	}
	
	private RtSegment segmentMAN;
	
	private RtSegment segmentMAN() {
		if (segmentMAN == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "MAN88", simpleElement88()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "MAN87", simpleElement87()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "MAN87_3", simpleElement87()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "MAN88_3", simpleElement88()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "MAN87_4", simpleElement87()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "MAN87_5", simpleElement87()));
			segmentMAN = new RtSegment("MAN", elementReferences);
		}

		return segmentMAN;
	}
	
	private RtSegment segmentPCT;
	
	private RtSegment segmentPCT() {
		if (segmentPCT == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "PCT1004", simpleElement1004()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "PCT954", simpleElement954()));
			segmentPCT = new RtSegment("PCT", elementReferences);
		}

		return segmentPCT;
	}
	
	private RtSegment segmentCTB;
	
	private RtSegment segmentCTB() {
		if (segmentCTB == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "CTB688", simpleElement688()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "CTB352", simpleElement352()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "CTB673", simpleElement673()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "CTB380", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "CTB522", simpleElement522()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "CTB610", simpleElement610()));
			segmentCTB = new RtSegment("CTB", elementReferences);
		}

		return segmentCTB;
	}
	
	private RtSegment segmentTXI;
	
	private RtSegment segmentTXI() {
		if (segmentTXI == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "TXI963", simpleElement963()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "TXI782", simpleElement782()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "TXI954", simpleElement954()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "TXI955", simpleElement955()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "TXI956", simpleElement956()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "TXI441", simpleElement441()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "TXI662", simpleElement662()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "TXI828", simpleElement828()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "TXI325", simpleElement325()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "TXI350", simpleElement350()));
			segmentTXI = new RtSegment("TXI", elementReferences);
		}

		return segmentTXI;
	}
	
	private RtSegment segmentAMT;
	
	private RtSegment segmentAMT() {
		if (segmentAMT == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "AMT522", simpleElement522()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "AMT782", simpleElement782()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "AMT478", simpleElement478()));
			segmentAMT = new RtSegment("AMT", elementReferences);
		}

		return segmentAMT;
	}
	
	private RtSegment segmentFA1;
	
	private RtSegment segmentFA1() {
		if (segmentFA1 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "FA1559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "FA11300", simpleElement1300()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "FA1248", simpleElement248()));
			segmentFA1 = new RtSegment("FA1", elementReferences);
		}

		return segmentFA1;
	}
	
	private RtSegment segmentFA2;
	
	private RtSegment segmentFA2() {
		if (segmentFA2 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "FA21196", simpleElement1196()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "FA21195", simpleElement1195()));
			segmentFA2 = new RtSegment("FA2", elementReferences);
		}

		return segmentFA2;
	}
	
	private RtSegment segmentN9;
	
	private RtSegment segmentN9() {
		if (segmentN9 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "N9128", simpleElement128()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "N9127", simpleElement127()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "N9369", simpleElement369()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "N9373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "N9337", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "N9623", simpleElement623()));
			elementReferences.add(new RtCompositeElementReference("07", 0, 1, "N9C040", compositeElementC040()));
			segmentN9 = new RtSegment("N9", elementReferences);
		}

		return segmentN9;
	}
	
	private RtSegment segmentMSG;
	
	private RtSegment segmentMSG() {
		if (segmentMSG == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "MSG933", simpleElement933()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "MSG934", simpleElement934()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "MSG1470", simpleElement1470()));
			segmentMSG = new RtSegment("MSG", elementReferences);
		}

		return segmentMSG;
	}
	
	private RtSegment segmentN1;
	
	private RtSegment segmentN1() {
		if (segmentN1 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "N198", simpleElement98()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "N193", simpleElement93()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "N166", simpleElement66()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "N167", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "N1706", simpleElement706()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "N198_3", simpleElement98()));
			segmentN1 = new RtSegment("N1", elementReferences);
		}

		return segmentN1;
	}
	
	private RtSegment segmentN2;
	
	private RtSegment segmentN2() {
		if (segmentN2 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "N293", simpleElement93()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "N293_3", simpleElement93()));
			segmentN2 = new RtSegment("N2", elementReferences);
		}

		return segmentN2;
	}
	
	private RtSegment segmentN3;
	
	private RtSegment segmentN3() {
		if (segmentN3 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "N3166", simpleElement166()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "N3166_3", simpleElement166()));
			segmentN3 = new RtSegment("N3", elementReferences);
		}

		return segmentN3;
	}
	
	private RtSegment segmentN4;
	
	private RtSegment segmentN4() {
		if (segmentN4 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "N419", simpleElement19()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "N4156", simpleElement156()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "N4116", simpleElement116()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "N426", simpleElement26()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "N4309", simpleElement309()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "N4310", simpleElement310()));
			segmentN4 = new RtSegment("N4", elementReferences);
		}

		return segmentN4;
	}
	
	private RtSegment segmentNX2;
	
	private RtSegment segmentNX2() {
		if (segmentNX2 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "NX21106", simpleElement1106()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "NX2166", simpleElement166()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "NX21096", simpleElement1096()));
			segmentNX2 = new RtSegment("NX2", elementReferences);
		}

		return segmentNX2;
	}
	
	private RtSegment segmentLM;
	
	private RtSegment segmentLM() {
		if (segmentLM == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "LM559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "LM822", simpleElement822()));
			segmentLM = new RtSegment("LM", elementReferences);
		}

		return segmentLM;
	}
	
	private RtSegment segmentLQ;
	
	private RtSegment segmentLQ() {
		if (segmentLQ == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "LQ1270", simpleElement1270()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "LQ1271", simpleElement1271()));
			segmentLQ = new RtSegment("LQ", elementReferences);
		}

		return segmentLQ;
	}
	
	private RtSegment segmentSPI;
	
	private RtSegment segmentSPI() {
		if (segmentSPI == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SPI786", simpleElement786()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "SPI128", simpleElement128()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "SPI127", simpleElement127()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "SPI790", simpleElement790()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "SPI791", simpleElement791()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "SPI792", simpleElement792()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "SPI353", simpleElement353()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "SPI755", simpleElement755()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "SPI786_3", simpleElement786()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "SPI559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "SPI822", simpleElement822()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "SPI554", simpleElement554()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "SPI1322", simpleElement1322()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "SPI1401", simpleElement1401()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "SPI1005", simpleElement1005()));
			segmentSPI = new RtSegment("SPI", elementReferences);
		}

		return segmentSPI;
	}
	
	private RtSegment segmentG61;
	
	private RtSegment segmentG61() {
		if (segmentG61 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "G61366", simpleElement366()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "G6193", simpleElement93()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "G61365", simpleElement365()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "G61364", simpleElement364()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "G61443", simpleElement443()));
			segmentG61 = new RtSegment("G61", elementReferences);
		}

		return segmentG61;
	}
	
	private RtSegment segmentCB1;
	
	private RtSegment segmentCB1() {
		if (segmentCB1 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "CB11309", simpleElement1309()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "CB11310", simpleElement1310()));
			segmentCB1 = new RtSegment("CB1", elementReferences);
		}

		return segmentCB1;
	}
	
	private RtSegment segmentADV;
	
	private RtSegment segmentADV() {
		if (segmentADV == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "ADV559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "ADV1000", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "ADV740", simpleElement740()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "ADV741", simpleElement741()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "ADV729", simpleElement729()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "ADV1000_3", simpleElement1000()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "ADV739", simpleElement739()));
			segmentADV = new RtSegment("ADV", elementReferences);
		}

		return segmentADV;
	}
	
	private RtSegment segmentMTX;
	
	private RtSegment segmentMTX() {
		if (segmentMTX == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "MTX363", simpleElement363()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "MTX1551", simpleElement1551()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "MTX1551_3", simpleElement1551()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "MTX934", simpleElement934()));
			segmentMTX = new RtSegment("MTX", elementReferences);
		}

		return segmentMTX;
	}
	
	private RtSegment segmentPO1;
	
	private RtSegment segmentPO1() {
		if (segmentPO1 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "PO1350", simpleElement350()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PO1330", simpleElement330()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "PO1355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PO1212", simpleElement212()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PO1639", simpleElement639()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "PO1235", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "PO1234", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "PO1235_3", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "PO1234_3", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "PO1235_4", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "PO1234_4", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "PO1235_5", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "PO1234_5", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "PO1235_6", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "PO1234_6", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "PO1235_7", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "PO1234_7", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "PO1235_8", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("19", 0, 1, "PO1234_8", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("20", 0, 1, "PO1235_9", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("21", 0, 1, "PO1234_9", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("22", 0, 1, "PO1235_10", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("23", 0, 1, "PO1234_10", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("24", 0, 1, "PO1235_11", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("25", 0, 1, "PO1234_11", simpleElement234()));
			segmentPO1 = new RtSegment("PO1", elementReferences);
		}

		return segmentPO1;
	}
	
	private RtSegment segmentCN1;
	
	private RtSegment segmentCN1() {
		if (segmentCN1 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "CN11166", simpleElement1166()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "CN1782", simpleElement782()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "CN1332", simpleElement332()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "CN1127", simpleElement127()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "CN1338", simpleElement338()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "CN1799", simpleElement799()));
			segmentCN1 = new RtSegment("CN1", elementReferences);
		}

		return segmentCN1;
	}
	
	private RtSegment segmentPO3;
	
	private RtSegment segmentPO3() {
		if (segmentPO3 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "PO3371", simpleElement371()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PO3373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "PO3236", simpleElement236()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PO3212", simpleElement212()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PO3639", simpleElement639()));
			elementReferences.add(new RtSimpleElementReference("06", 1, 1, "PO3380", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("07", 1, 1, "PO3355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "PO3352", simpleElement352()));
			segmentPO3 = new RtSegment("PO3", elementReferences);
		}

		return segmentPO3;
	}
	
	private RtSegment segmentPO4;
	
	private RtSegment segmentPO4() {
		if (segmentPO4 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "PO4356", simpleElement356()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "PO4357", simpleElement357()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "PO4355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "PO4103", simpleElement103()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "PO4187", simpleElement187()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "PO4384", simpleElement384()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "PO4355_3", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "PO4385", simpleElement385()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "PO4355_4", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "PO482", simpleElement82()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "PO4189", simpleElement189()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "PO465", simpleElement65()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "PO4355_5", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "PO4810", simpleElement810()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "PO4752", simpleElement752()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "PO4350", simpleElement350()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "PO4350_3", simpleElement350()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "PO41470", simpleElement1470()));
			segmentPO4 = new RtSegment("PO4", elementReferences);
		}

		return segmentPO4;
	}
	
	private RtSegment segmentIT8;
	
	private RtSegment segmentIT8() {
		if (segmentIT8 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "IT8563", simpleElement563()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "IT8306", simpleElement306()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "IT8610", simpleElement610()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "IT8508", simpleElement508()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "IT8373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "IT8559", simpleElement559()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "IT8566", simpleElement566()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "IT8235", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "IT8234", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "IT8235_3", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "IT8234_3", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "IT8235_4", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "IT8234_4", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "IT8235_5", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "IT8234_5", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "IT8235_6", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "IT8234_6", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "IT8235_7", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("19", 0, 1, "IT8234_7", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("20", 0, 1, "IT8235_8", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("21", 0, 1, "IT8234_8", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("22", 0, 1, "IT8235_9", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("23", 0, 1, "IT8234_9", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("24", 0, 1, "IT8235_10", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("25", 0, 1, "IT8234_10", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("26", 0, 1, "IT8235_11", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("27", 0, 1, "IT8234_11", simpleElement234()));
			segmentIT8 = new RtSegment("IT8", elementReferences);
		}

		return segmentIT8;
	}
	
	private RtSegment segmentSDQ;
	
	private RtSegment segmentSDQ() {
		if (segmentSDQ == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SDQ355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "SDQ66", simpleElement66()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "SDQ67", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("04", 1, 1, "SDQ380", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "SDQ67_3", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "SDQ380_3", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "SDQ67_4", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "SDQ380_4", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "SDQ67_5", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "SDQ380_5", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "SDQ67_6", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "SDQ380_6", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "SDQ67_7", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "SDQ380_7", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "SDQ67_8", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "SDQ380_8", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "SDQ67_9", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "SDQ380_9", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("19", 0, 1, "SDQ67_10", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("20", 0, 1, "SDQ380_10", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("21", 0, 1, "SDQ67_11", simpleElement67()));
			elementReferences.add(new RtSimpleElementReference("22", 0, 1, "SDQ380_11", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("23", 0, 1, "SDQ310", simpleElement310()));
			segmentSDQ = new RtSegment("SDQ", elementReferences);
		}

		return segmentSDQ;
	}
	
	private RtSegment segmentIT3;
	
	private RtSegment segmentIT3() {
		if (segmentIT3 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 0, 1, "IT3382", simpleElement382()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "IT3355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "IT3368", simpleElement368()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "IT3383", simpleElement383()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "IT3371", simpleElement371()));
			segmentIT3 = new RtSegment("IT3", elementReferences);
		}

		return segmentIT3;
	}
	
	private RtSegment segmentQTY;
	
	private RtSegment segmentQTY() {
		if (segmentQTY == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "QTY673", simpleElement673()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "QTY380", simpleElement380()));
			elementReferences.add(new RtCompositeElementReference("03", 0, 1, "QTYC001", compositeElementC001()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "QTY61", simpleElement61()));
			segmentQTY = new RtSegment("QTY", elementReferences);
		}

		return segmentQTY;
	}
	
	private RtSegment segmentSCH;
	
	private RtSegment segmentSCH() {
		if (segmentSCH == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SCH380", simpleElement380()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "SCH355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "SCH98", simpleElement98()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "SCH93", simpleElement93()));
			elementReferences.add(new RtSimpleElementReference("05", 1, 1, "SCH374", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("06", 1, 1, "SCH373", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "SCH337", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "SCH374_3", simpleElement374()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "SCH373_3", simpleElement373()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "SCH337_3", simpleElement337()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "SCH326", simpleElement326()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "SCH350", simpleElement350()));
			segmentSCH = new RtSegment("SCH", elementReferences);
		}

		return segmentSCH;
	}
	
	private RtSegment segmentLS;
	
	private RtSegment segmentLS() {
		if (segmentLS == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "LS447", simpleElement447()));
			segmentLS = new RtSegment("LS", elementReferences);
		}

		return segmentLS;
	}
	
	private RtSegment segmentLE;
	
	private RtSegment segmentLE() {
		if (segmentLE == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "LE447", simpleElement447()));
			segmentLE = new RtSegment("LE", elementReferences);
		}

		return segmentLE;
	}
	
	private RtSegment segmentSLN;
	
	private RtSegment segmentSLN() {
		if (segmentSLN == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SLN350", simpleElement350()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "SLN350_3", simpleElement350()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "SLN662", simpleElement662()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "SLN380", simpleElement380()));
			elementReferences.add(new RtCompositeElementReference("05", 0, 1, "SLNC001", compositeElementC001()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "SLN212", simpleElement212()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "SLN639", simpleElement639()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "SLN662_3", simpleElement662()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "SLN235", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "SLN234", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "SLN235_3", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "SLN234_3", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "SLN235_4", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "SLN234_4", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "SLN235_5", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("16", 0, 1, "SLN234_5", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("17", 0, 1, "SLN235_6", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("18", 0, 1, "SLN234_6", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("19", 0, 1, "SLN235_7", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("20", 0, 1, "SLN234_7", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("21", 0, 1, "SLN235_8", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("22", 0, 1, "SLN234_8", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("23", 0, 1, "SLN235_9", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("24", 0, 1, "SLN234_9", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("25", 0, 1, "SLN235_10", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("26", 0, 1, "SLN234_10", simpleElement234()));
			elementReferences.add(new RtSimpleElementReference("27", 0, 1, "SLN235_11", simpleElement235()));
			elementReferences.add(new RtSimpleElementReference("28", 0, 1, "SLN234_11", simpleElement234()));
			segmentSLN = new RtSegment("SLN", elementReferences);
		}

		return segmentSLN;
	}
	
	private RtSegment segmentCTT;
	
	private RtSegment segmentCTT() {
		if (segmentCTT == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "CTT354", simpleElement354()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "CTT347", simpleElement347()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "CTT81", simpleElement81()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "CTT355", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "CTT183", simpleElement183()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "CTT355_3", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "CTT352", simpleElement352()));
			segmentCTT = new RtSegment("CTT", elementReferences);
		}

		return segmentCTT;
	}
	
	private RtSegment segmentSE;
	
	private RtSegment segmentSE() {
		if (segmentSE == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SE96", simpleElement96()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "SE329", simpleElement329()));
			segmentSE = new RtSegment("SE", elementReferences);
		}

		return segmentSE;
	}
	
	private RtCompositeElement compositeElementC040;

	private RtCompositeElement compositeElementC040() {
		if (compositeElementC040 == null) {
			List<RtSimpleElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "C04001", simpleElement128()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "C04002", simpleElement127()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "C04003", simpleElement128()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "C04004", simpleElement127()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "C04005", simpleElement128()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "C04006", simpleElement127()));

			compositeElementC040 = new RtCompositeElement("C040", elementReferences);
		}

		return compositeElementC040;
	}
	
	private RtCompositeElement compositeElementC001;

	private RtCompositeElement compositeElementC001() {
		if (compositeElementC001 == null) {
			List<RtSimpleElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "C00101", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "C00102", simpleElement1018()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "C00103", simpleElement649()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "C00104", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "C00105", simpleElement1018()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "C00106", simpleElement649()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "C00107", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "C00108", simpleElement1018()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "C00109", simpleElement649()));
			elementReferences.add(new RtSimpleElementReference("10", 0, 1, "C00110", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("11", 0, 1, "C00111", simpleElement1018()));
			elementReferences.add(new RtSimpleElementReference("12", 0, 1, "C00112", simpleElement649()));
			elementReferences.add(new RtSimpleElementReference("13", 0, 1, "C00113", simpleElement355()));
			elementReferences.add(new RtSimpleElementReference("14", 0, 1, "C00114", simpleElement1018()));
			elementReferences.add(new RtSimpleElementReference("15", 0, 1, "C00115", simpleElement649()));

			compositeElementC001 = new RtCompositeElement("C001", elementReferences);
		}

		return compositeElementC001;
	}
	
	private RtCompositeElement compositeElementC002;

	private RtCompositeElement compositeElementC002() {
		if (compositeElementC002 == null) {
			List<RtSimpleElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "C00201", simpleElement704()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "C00202", simpleElement704()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "C00203", simpleElement704()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "C00204", simpleElement704()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "C00205", simpleElement704()));

			compositeElementC002 = new RtCompositeElement("C002", elementReferences);
		}

		return compositeElementC002;
	}
	
	private RtSimpleElement simpleElement143;
	
	private RtSimpleElement simpleElement143() {
		if (simpleElement143 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Set Identifier Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("100");
			h.addAllowedValue("101");
			h.addAllowedValue("104");
			h.addAllowedValue("105");
			h.addAllowedValue("106");
			h.addAllowedValue("107");
			h.addAllowedValue("108");
			h.addAllowedValue("109");
			h.addAllowedValue("110");
			h.addAllowedValue("112");
			h.addAllowedValue("120");
			h.addAllowedValue("121");
			h.addAllowedValue("124");
			h.addAllowedValue("125");
			h.addAllowedValue("126");
			h.addAllowedValue("127");
			h.addAllowedValue("128");
			h.addAllowedValue("129");
			h.addAllowedValue("130");
			h.addAllowedValue("131");
			h.addAllowedValue("135");
			h.addAllowedValue("138");
			h.addAllowedValue("139");
			h.addAllowedValue("140");
			h.addAllowedValue("141");
			h.addAllowedValue("142");
			h.addAllowedValue("143");
			h.addAllowedValue("144");
			h.addAllowedValue("146");
			h.addAllowedValue("147");
			h.addAllowedValue("148");
			h.addAllowedValue("149");
			h.addAllowedValue("150");
			h.addAllowedValue("151");
			h.addAllowedValue("152");
			h.addAllowedValue("153");
			h.addAllowedValue("154");
			h.addAllowedValue("155");
			h.addAllowedValue("157");
			h.addAllowedValue("159");
			h.addAllowedValue("160");
			h.addAllowedValue("161");
			h.addAllowedValue("163");
			h.addAllowedValue("170");
			h.addAllowedValue("175");
			h.addAllowedValue("176");
			h.addAllowedValue("180");
			h.addAllowedValue("185");
			h.addAllowedValue("186");
			h.addAllowedValue("188");
			h.addAllowedValue("189");
			h.addAllowedValue("190");
			h.addAllowedValue("191");
			h.addAllowedValue("194");
			h.addAllowedValue("195");
			h.addAllowedValue("196");
			h.addAllowedValue("197");
			h.addAllowedValue("198");
			h.addAllowedValue("199");
			h.addAllowedValue("200");
			h.addAllowedValue("201");
			h.addAllowedValue("202");
			h.addAllowedValue("203");
			h.addAllowedValue("204");
			h.addAllowedValue("205");
			h.addAllowedValue("206");
			h.addAllowedValue("210");
			h.addAllowedValue("211");
			h.addAllowedValue("212");
			h.addAllowedValue("213");
			h.addAllowedValue("214");
			h.addAllowedValue("215");
			h.addAllowedValue("216");
			h.addAllowedValue("217");
			h.addAllowedValue("218");
			h.addAllowedValue("219");
			h.addAllowedValue("220");
			h.addAllowedValue("222");
			h.addAllowedValue("223");
			h.addAllowedValue("224");
			h.addAllowedValue("225");
			h.addAllowedValue("242");
			h.addAllowedValue("244");
			h.addAllowedValue("248");
			h.addAllowedValue("249");
			h.addAllowedValue("250");
			h.addAllowedValue("251");
			h.addAllowedValue("252");
			h.addAllowedValue("255");
			h.addAllowedValue("256");
			h.addAllowedValue("260");
			h.addAllowedValue("261");
			h.addAllowedValue("262");
			h.addAllowedValue("263");
			h.addAllowedValue("264");
			h.addAllowedValue("265");
			h.addAllowedValue("266");
			h.addAllowedValue("267");
			h.addAllowedValue("268");
			h.addAllowedValue("270");
			h.addAllowedValue("271");
			h.addAllowedValue("272");
			h.addAllowedValue("273");
			h.addAllowedValue("275");
			h.addAllowedValue("276");
			h.addAllowedValue("277");
			h.addAllowedValue("278");
			h.addAllowedValue("280");
			h.addAllowedValue("285");
			h.addAllowedValue("286");
			h.addAllowedValue("288");
			h.addAllowedValue("290");
			h.addAllowedValue("300");
			h.addAllowedValue("301");
			h.addAllowedValue("303");
			h.addAllowedValue("304");
			h.addAllowedValue("306");
			h.addAllowedValue("309");
			h.addAllowedValue("310");
			h.addAllowedValue("311");
			h.addAllowedValue("312");
			h.addAllowedValue("313");
			h.addAllowedValue("315");
			h.addAllowedValue("317");
			h.addAllowedValue("319");
			h.addAllowedValue("321");
			h.addAllowedValue("322");
			h.addAllowedValue("323");
			h.addAllowedValue("324");
			h.addAllowedValue("325");
			h.addAllowedValue("326");
			h.addAllowedValue("350");
			h.addAllowedValue("352");
			h.addAllowedValue("353");
			h.addAllowedValue("354");
			h.addAllowedValue("355");
			h.addAllowedValue("356");
			h.addAllowedValue("357");
			h.addAllowedValue("358");
			h.addAllowedValue("361");
			h.addAllowedValue("362");
			h.addAllowedValue("404");
			h.addAllowedValue("410");
			h.addAllowedValue("411");
			h.addAllowedValue("414");
			h.addAllowedValue("417");
			h.addAllowedValue("418");
			h.addAllowedValue("419");
			h.addAllowedValue("420");
			h.addAllowedValue("421");
			h.addAllowedValue("422");
			h.addAllowedValue("423");
			h.addAllowedValue("425");
			h.addAllowedValue("426");
			h.addAllowedValue("429");
			h.addAllowedValue("431");
			h.addAllowedValue("432");
			h.addAllowedValue("433");
			h.addAllowedValue("434");
			h.addAllowedValue("435");
			h.addAllowedValue("436");
			h.addAllowedValue("437");
			h.addAllowedValue("440");
			h.addAllowedValue("451");
			h.addAllowedValue("452");
			h.addAllowedValue("453");
			h.addAllowedValue("455");
			h.addAllowedValue("456");
			h.addAllowedValue("460");
			h.addAllowedValue("463");
			h.addAllowedValue("466");
			h.addAllowedValue("468");
			h.addAllowedValue("470");
			h.addAllowedValue("475");
			h.addAllowedValue("485");
			h.addAllowedValue("486");
			h.addAllowedValue("490");
			h.addAllowedValue("492");
			h.addAllowedValue("494");
			h.addAllowedValue("500");
			h.addAllowedValue("501");
			h.addAllowedValue("503");
			h.addAllowedValue("504");
			h.addAllowedValue("511");
			h.addAllowedValue("517");
			h.addAllowedValue("521");
			h.addAllowedValue("527");
			h.addAllowedValue("536");
			h.addAllowedValue("540");
			h.addAllowedValue("561");
			h.addAllowedValue("567");
			h.addAllowedValue("568");
			h.addAllowedValue("601");
			h.addAllowedValue("602");
			h.addAllowedValue("620");
			h.addAllowedValue("622");
			h.addAllowedValue("625");
			h.addAllowedValue("650");
			h.addAllowedValue("715");
			h.addAllowedValue("805");
			h.addAllowedValue("806");
			h.addAllowedValue("810");
			h.addAllowedValue("811");
			h.addAllowedValue("812");
			h.addAllowedValue("813");
			h.addAllowedValue("814");
			h.addAllowedValue("815");
			h.addAllowedValue("816");
			h.addAllowedValue("818");
			h.addAllowedValue("819");
			h.addAllowedValue("820");
			h.addAllowedValue("821");
			h.addAllowedValue("822");
			h.addAllowedValue("823");
			h.addAllowedValue("824");
			h.addAllowedValue("826");
			h.addAllowedValue("827");
			h.addAllowedValue("828");
			h.addAllowedValue("829");
			h.addAllowedValue("830");
			h.addAllowedValue("831");
			h.addAllowedValue("832");
			h.addAllowedValue("833");
			h.addAllowedValue("834");
			h.addAllowedValue("835");
			h.addAllowedValue("836");
			h.addAllowedValue("837");
			h.addAllowedValue("838");
			h.addAllowedValue("839");
			h.addAllowedValue("840");
			h.addAllowedValue("841");
			h.addAllowedValue("842");
			h.addAllowedValue("843");
			h.addAllowedValue("844");
			h.addAllowedValue("845");
			h.addAllowedValue("846");
			h.addAllowedValue("847");
			h.addAllowedValue("848");
			h.addAllowedValue("849");
			h.addAllowedValue("850");
			h.addAllowedValue("851");
			h.addAllowedValue("852");
			h.addAllowedValue("853");
			h.addAllowedValue("854");
			h.addAllowedValue("855");
			h.addAllowedValue("856");
			h.addAllowedValue("857");
			h.addAllowedValue("858");
			h.addAllowedValue("859");
			h.addAllowedValue("860");
			h.addAllowedValue("861");
			h.addAllowedValue("862");
			h.addAllowedValue("863");
			h.addAllowedValue("864");
			h.addAllowedValue("865");
			h.addAllowedValue("866");
			h.addAllowedValue("867");
			h.addAllowedValue("868");
			h.addAllowedValue("869");
			h.addAllowedValue("870");
			h.addAllowedValue("871");
			h.addAllowedValue("872");
			h.addAllowedValue("875");
			h.addAllowedValue("876");
			h.addAllowedValue("877");
			h.addAllowedValue("878");
			h.addAllowedValue("879");
			h.addAllowedValue("880");
			h.addAllowedValue("881");
			h.addAllowedValue("882");
			h.addAllowedValue("883");
			h.addAllowedValue("884");
			h.addAllowedValue("885");
			h.addAllowedValue("886");
			h.addAllowedValue("887");
			h.addAllowedValue("888");
			h.addAllowedValue("889");
			h.addAllowedValue("891");
			h.addAllowedValue("893");
			h.addAllowedValue("894");
			h.addAllowedValue("895");
			h.addAllowedValue("896");
			h.addAllowedValue("920");
			h.addAllowedValue("924");
			h.addAllowedValue("925");
			h.addAllowedValue("926");
			h.addAllowedValue("928");
			h.addAllowedValue("940");
			h.addAllowedValue("943");
			h.addAllowedValue("944");
			h.addAllowedValue("945");
			h.addAllowedValue("947");
			h.addAllowedValue("980");
			h.addAllowedValue("990");
			h.addAllowedValue("994");
			h.addAllowedValue("996");
			h.addAllowedValue("997");
			h.addAllowedValue("998");
			simpleElement143 = new RtSimpleElement("143", "ID", h);
		}
	
		return simpleElement143;
	}
	
	private RtSimpleElement simpleElement329;
	
	private RtSimpleElement simpleElement329() {
		if (simpleElement329 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Set Control Number";
			h.minLength = 4;
			h.maxLength = 9;
			
			simpleElement329 = new RtSimpleElement("329", "AN", h);
		}
	
		return simpleElement329;
	}
	
	private RtSimpleElement simpleElement353;
	
	private RtSimpleElement simpleElement353() {
		if (simpleElement353 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Set Purpose Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("EX");
			h.addAllowedValue("GR");
			h.addAllowedValue("PR");
			h.addAllowedValue("RH");
			h.addAllowedValue("RV");
			h.addAllowedValue("SU");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("00");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5C");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("77");
			simpleElement353 = new RtSimpleElement("353", "ID", h);
		}
	
		return simpleElement353;
	}
	
	private RtSimpleElement simpleElement92;
	
	private RtSimpleElement simpleElement92() {
		if (simpleElement92 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Purchase Order Type Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AO");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BH");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BY");
			h.addAllowedValue("CA");
			h.addAllowedValue("CC");
			h.addAllowedValue("CF");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("EO");
			h.addAllowedValue("FH");
			h.addAllowedValue("IN");
			h.addAllowedValue("JL");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KG");
			h.addAllowedValue("KI");
			h.addAllowedValue("KN");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KR");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("LB");
			h.addAllowedValue("LS");
			h.addAllowedValue("NE");
			h.addAllowedValue("NO");
			h.addAllowedValue("NP");
			h.addAllowedValue("NS");
			h.addAllowedValue("OS");
			h.addAllowedValue("PR");
			h.addAllowedValue("RA");
			h.addAllowedValue("RC");
			h.addAllowedValue("RE");
			h.addAllowedValue("RL");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RR");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RW");
			h.addAllowedValue("SA");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SW");
			h.addAllowedValue("TC");
			h.addAllowedValue("TM");
			h.addAllowedValue("TR");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("US");
			h.addAllowedValue("WO");
			h.addAllowedValue("ZZ");
			simpleElement92 = new RtSimpleElement("92", "ID", h);
		}
	
		return simpleElement92;
	}
	
	private RtSimpleElement simpleElement324;
	
	private RtSimpleElement simpleElement324() {
		if (simpleElement324 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Purchase Order Number";
			h.minLength = 1;
			h.maxLength = 22;
			
			simpleElement324 = new RtSimpleElement("324", "AN", h);
		}
	
		return simpleElement324;
	}
	
	private RtSimpleElement simpleElement328;
	
	private RtSimpleElement simpleElement328() {
		if (simpleElement328 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Release Number";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement328 = new RtSimpleElement("328", "AN", h);
		}
	
		return simpleElement328;
	}
	
	private RtSimpleElement simpleElement373;
	
	private RtSimpleElement simpleElement373() {
		if (simpleElement373 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Date";
			h.minLength = 8;
			h.maxLength = 8;
			
			simpleElement373 = new RtSimpleElement("373", "DT", h);
		}
	
		return simpleElement373;
	}
	
	private RtSimpleElement simpleElement367;
	
	private RtSimpleElement simpleElement367() {
		if (simpleElement367 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Contract Number";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement367 = new RtSimpleElement("367", "AN", h);
		}
	
		return simpleElement367;
	}
	
	private RtSimpleElement simpleElement587;
	
	private RtSimpleElement simpleElement587() {
		if (simpleElement587 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Acknowledgment Type";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AH");
			h.addAllowedValue("AK");
			h.addAllowedValue("AP");
			h.addAllowedValue("AT");
			h.addAllowedValue("NA");
			h.addAllowedValue("RD");
			h.addAllowedValue("RF");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RV");
			h.addAllowedValue("ZZ");
			simpleElement587 = new RtSimpleElement("587", "ID", h);
		}
	
		return simpleElement587;
	}
	
	private RtSimpleElement simpleElement1019;
	
	private RtSimpleElement simpleElement1019() {
		if (simpleElement1019 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Invoice Type Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("IBM");
			h.addAllowedValue("IEL");
			h.addAllowedValue("INR");
			simpleElement1019 = new RtSimpleElement("1019", "ID", h);
		}
	
		return simpleElement1019;
	}
	
	private RtSimpleElement simpleElement1166;
	
	private RtSimpleElement simpleElement1166() {
		if (simpleElement1166 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Contract Type Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CH");
			h.addAllowedValue("CP");
			h.addAllowedValue("CS");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("DI");
			h.addAllowedValue("EA");
			h.addAllowedValue("ER");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FK");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FR");
			h.addAllowedValue("FX");
			h.addAllowedValue("LA");
			h.addAllowedValue("LE");
			h.addAllowedValue("LH");
			h.addAllowedValue("OC");
			h.addAllowedValue("PR");
			h.addAllowedValue("SP");
			h.addAllowedValue("TM");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("09");
			simpleElement1166 = new RtSimpleElement("1166", "ID", h);
		}
	
		return simpleElement1166;
	}
	
	private RtSimpleElement simpleElement1232;
	
	private RtSimpleElement simpleElement1232() {
		if (simpleElement1232 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Purchase Category";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AE");
			h.addAllowedValue("CN");
			h.addAllowedValue("DR");
			h.addAllowedValue("ER");
			h.addAllowedValue("HW");
			h.addAllowedValue("IR");
			h.addAllowedValue("MD");
			h.addAllowedValue("OV");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("SB");
			h.addAllowedValue("SP");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("TE");
			h.addAllowedValue("UT");
			simpleElement1232 = new RtSimpleElement("1232", "ID", h);
		}
	
		return simpleElement1232;
	}
	
	private RtSimpleElement simpleElement786;
	
	private RtSimpleElement simpleElement786() {
		if (simpleElement786 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Security Level Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("ZZ");
			h.addAllowedValue("00");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("09");
			h.addAllowedValue("11");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("90");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("99");
			simpleElement786 = new RtSimpleElement("786", "ID", h);
		}
	
		return simpleElement786;
	}
	
	private RtSimpleElement simpleElement640;
	
	private RtSimpleElement simpleElement640() {
		if (simpleElement640 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Type Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AI");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A0");
			h.addAllowedValue("A1");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BD");
			h.addAllowedValue("BF");
			h.addAllowedValue("BH");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BR");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("BU");
			h.addAllowedValue("BV");
			h.addAllowedValue("BW");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C0");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("D1");
			h.addAllowedValue("D4");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EF");
			h.addAllowedValue("EI");
			h.addAllowedValue("EM");
			h.addAllowedValue("EP");
			h.addAllowedValue("ER");
			h.addAllowedValue("EX");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FI");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FN");
			h.addAllowedValue("FP");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("GA");
			h.addAllowedValue("GI");
			h.addAllowedValue("GR");
			h.addAllowedValue("HP");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IE");
			h.addAllowedValue("IF");
			h.addAllowedValue("II");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IO");
			h.addAllowedValue("IR");
			h.addAllowedValue("IU");
			h.addAllowedValue("IW");
			h.addAllowedValue("IX");
			h.addAllowedValue("IZ");
			h.addAllowedValue("I1");
			h.addAllowedValue("JM");
			h.addAllowedValue("JO");
			h.addAllowedValue("JR");
			h.addAllowedValue("JS");
			h.addAllowedValue("JU");
			h.addAllowedValue("JX");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KN");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LF");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LP");
			h.addAllowedValue("LR");
			h.addAllowedValue("LV");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MI");
			h.addAllowedValue("ML");
			h.addAllowedValue("MM");
			h.addAllowedValue("MP");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MU");
			h.addAllowedValue("M1");
			h.addAllowedValue("NA");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NG");
			h.addAllowedValue("NH");
			h.addAllowedValue("NI");
			h.addAllowedValue("NJ");
			h.addAllowedValue("NK");
			h.addAllowedValue("NL");
			h.addAllowedValue("NM");
			h.addAllowedValue("NO");
			h.addAllowedValue("NP");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NR");
			h.addAllowedValue("NT");
			h.addAllowedValue("NU");
			h.addAllowedValue("N1");
			h.addAllowedValue("N2");
			h.addAllowedValue("N3");
			h.addAllowedValue("N4");
			h.addAllowedValue("N5");
			h.addAllowedValue("N6");
			h.addAllowedValue("N7");
			h.addAllowedValue("N8");
			h.addAllowedValue("OC");
			h.addAllowedValue("OF");
			h.addAllowedValue("OP");
			h.addAllowedValue("OR");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PI");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P1");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QF");
			h.addAllowedValue("QG");
			h.addAllowedValue("QH");
			h.addAllowedValue("QJ");
			h.addAllowedValue("QK");
			h.addAllowedValue("QL");
			h.addAllowedValue("QP");
			h.addAllowedValue("QR");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RK");
			h.addAllowedValue("RM");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RZ");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("TD");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TX");
			h.addAllowedValue("UA");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UF");
			h.addAllowedValue("UI");
			h.addAllowedValue("UM");
			h.addAllowedValue("UO");
			h.addAllowedValue("UP");
			h.addAllowedValue("UR");
			h.addAllowedValue("UT");
			h.addAllowedValue("U1");
			h.addAllowedValue("U2");
			h.addAllowedValue("U4");
			h.addAllowedValue("U5");
			h.addAllowedValue("U9");
			h.addAllowedValue("VH");
			h.addAllowedValue("VJ");
			h.addAllowedValue("VL");
			h.addAllowedValue("VM");
			h.addAllowedValue("VN");
			h.addAllowedValue("VO");
			h.addAllowedValue("VP");
			h.addAllowedValue("VQ");
			h.addAllowedValue("VR");
			h.addAllowedValue("V1");
			h.addAllowedValue("WA");
			h.addAllowedValue("WC");
			h.addAllowedValue("WD");
			h.addAllowedValue("WH");
			h.addAllowedValue("WO");
			h.addAllowedValue("WS");
			h.addAllowedValue("WT");
			h.addAllowedValue("W1");
			h.addAllowedValue("W4");
			h.addAllowedValue("W5");
			h.addAllowedValue("XA");
			h.addAllowedValue("XB");
			h.addAllowedValue("XC");
			h.addAllowedValue("XD");
			h.addAllowedValue("XX");
			h.addAllowedValue("XY");
			h.addAllowedValue("XZ");
			h.addAllowedValue("X1");
			h.addAllowedValue("YI");
			h.addAllowedValue("YR");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZD");
			h.addAllowedValue("ZE");
			h.addAllowedValue("ZF");
			h.addAllowedValue("ZG");
			h.addAllowedValue("ZH");
			h.addAllowedValue("ZI");
			h.addAllowedValue("ZJ");
			h.addAllowedValue("ZK");
			h.addAllowedValue("ZL");
			h.addAllowedValue("ZM");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZO");
			h.addAllowedValue("ZP");
			h.addAllowedValue("ZQ");
			h.addAllowedValue("ZR");
			h.addAllowedValue("ZS");
			h.addAllowedValue("ZT");
			h.addAllowedValue("ZU");
			h.addAllowedValue("ZW");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3M");
			h.addAllowedValue("30");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("6A");
			h.addAllowedValue("6C");
			h.addAllowedValue("6N");
			h.addAllowedValue("6R");
			h.addAllowedValue("6S");
			h.addAllowedValue("60");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("85");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("91");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement640 = new RtSimpleElement("640", "ID", h);
		}
	
		return simpleElement640;
	}
	
	private RtSimpleElement simpleElement98;
	
	private RtSimpleElement simpleElement98() {
		if (simpleElement98 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Entity Identifier Code";
			h.minLength = 2;
			h.maxLength = 3;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AAA");
			h.addAllowedValue("AAB");
			h.addAllowedValue("AAC");
			h.addAllowedValue("AAD");
			h.addAllowedValue("AAE");
			h.addAllowedValue("AAF");
			h.addAllowedValue("AAG");
			h.addAllowedValue("AAH");
			h.addAllowedValue("AAI");
			h.addAllowedValue("AAJ");
			h.addAllowedValue("AAK");
			h.addAllowedValue("AAL");
			h.addAllowedValue("AAM");
			h.addAllowedValue("AAN");
			h.addAllowedValue("AAO");
			h.addAllowedValue("AAP");
			h.addAllowedValue("AAQ");
			h.addAllowedValue("AAS");
			h.addAllowedValue("AAT");
			h.addAllowedValue("AAU");
			h.addAllowedValue("AAV");
			h.addAllowedValue("AB");
			h.addAllowedValue("ABB");
			h.addAllowedValue("ABC");
			h.addAllowedValue("ABD");
			h.addAllowedValue("ABE");
			h.addAllowedValue("ABF");
			h.addAllowedValue("ABG");
			h.addAllowedValue("ABH");
			h.addAllowedValue("ABI");
			h.addAllowedValue("ABJ");
			h.addAllowedValue("ABK");
			h.addAllowedValue("ABL");
			h.addAllowedValue("ABM");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("ALA");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A8");
			h.addAllowedValue("A9");
			h.addAllowedValue("BA");
			h.addAllowedValue("BAL");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BKR");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BRN");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("BU");
			h.addAllowedValue("BUS");
			h.addAllowedValue("BV");
			h.addAllowedValue("BW");
			h.addAllowedValue("BX");
			h.addAllowedValue("BY");
			h.addAllowedValue("BZ");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("B6");
			h.addAllowedValue("B7");
			h.addAllowedValue("B8");
			h.addAllowedValue("B9");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CMW");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("COL");
			h.addAllowedValue("COR");
			h.addAllowedValue("CP");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("C7");
			h.addAllowedValue("C8");
			h.addAllowedValue("C9");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DCC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DIR");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("DV");
			h.addAllowedValue("DW");
			h.addAllowedValue("DX");
			h.addAllowedValue("DY");
			h.addAllowedValue("DZ");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("D6");
			h.addAllowedValue("D7");
			h.addAllowedValue("D8");
			h.addAllowedValue("D9");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EH");
			h.addAllowedValue("EI");
			h.addAllowedValue("EJ");
			h.addAllowedValue("EK");
			h.addAllowedValue("EL");
			h.addAllowedValue("EM");
			h.addAllowedValue("EN");
			h.addAllowedValue("ENR");
			h.addAllowedValue("EO");
			h.addAllowedValue("EP");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("ET");
			h.addAllowedValue("EU");
			h.addAllowedValue("EV");
			h.addAllowedValue("EW");
			h.addAllowedValue("EX");
			h.addAllowedValue("EXS");
			h.addAllowedValue("EY");
			h.addAllowedValue("EZ");
			h.addAllowedValue("E1");
			h.addAllowedValue("E2");
			h.addAllowedValue("E3");
			h.addAllowedValue("E4");
			h.addAllowedValue("E5");
			h.addAllowedValue("E6");
			h.addAllowedValue("E7");
			h.addAllowedValue("E8");
			h.addAllowedValue("E9");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FN");
			h.addAllowedValue("FO");
			h.addAllowedValue("FP");
			h.addAllowedValue("FQ");
			h.addAllowedValue("FR");
			h.addAllowedValue("FRL");
			h.addAllowedValue("FS");
			h.addAllowedValue("FSR");
			h.addAllowedValue("FT");
			h.addAllowedValue("FU");
			h.addAllowedValue("FV");
			h.addAllowedValue("FW");
			h.addAllowedValue("FX");
			h.addAllowedValue("FY");
			h.addAllowedValue("FZ");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("F5");
			h.addAllowedValue("F6");
			h.addAllowedValue("F7");
			h.addAllowedValue("F8");
			h.addAllowedValue("F9");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GD");
			h.addAllowedValue("GE");
			h.addAllowedValue("GF");
			h.addAllowedValue("GG");
			h.addAllowedValue("GH");
			h.addAllowedValue("GI");
			h.addAllowedValue("GIR");
			h.addAllowedValue("GJ");
			h.addAllowedValue("GK");
			h.addAllowedValue("GL");
			h.addAllowedValue("GM");
			h.addAllowedValue("GN");
			h.addAllowedValue("GO");
			h.addAllowedValue("GP");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("GT");
			h.addAllowedValue("GU");
			h.addAllowedValue("GV");
			h.addAllowedValue("GW");
			h.addAllowedValue("GX");
			h.addAllowedValue("GY");
			h.addAllowedValue("GZ");
			h.addAllowedValue("G0");
			h.addAllowedValue("G1");
			h.addAllowedValue("G2");
			h.addAllowedValue("G3");
			h.addAllowedValue("G5");
			h.addAllowedValue("G6");
			h.addAllowedValue("G7");
			h.addAllowedValue("G8");
			h.addAllowedValue("G9");
			h.addAllowedValue("HA");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HD");
			h.addAllowedValue("HE");
			h.addAllowedValue("HF");
			h.addAllowedValue("HG");
			h.addAllowedValue("HH");
			h.addAllowedValue("HI");
			h.addAllowedValue("HJ");
			h.addAllowedValue("HK");
			h.addAllowedValue("HL");
			h.addAllowedValue("HM");
			h.addAllowedValue("HMI");
			h.addAllowedValue("HN");
			h.addAllowedValue("HO");
			h.addAllowedValue("HOM");
			h.addAllowedValue("HP");
			h.addAllowedValue("HQ");
			h.addAllowedValue("HR");
			h.addAllowedValue("HS");
			h.addAllowedValue("HT");
			h.addAllowedValue("HU");
			h.addAllowedValue("HV");
			h.addAllowedValue("HW");
			h.addAllowedValue("HX");
			h.addAllowedValue("HY");
			h.addAllowedValue("HZ");
			h.addAllowedValue("H1");
			h.addAllowedValue("H2");
			h.addAllowedValue("H3");
			h.addAllowedValue("H5");
			h.addAllowedValue("H6");
			h.addAllowedValue("H7");
			h.addAllowedValue("H8");
			h.addAllowedValue("H9");
			h.addAllowedValue("IA");
			h.addAllowedValue("IAA");
			h.addAllowedValue("IAC");
			h.addAllowedValue("IAD");
			h.addAllowedValue("IAE");
			h.addAllowedValue("IAF");
			h.addAllowedValue("IAG");
			h.addAllowedValue("IAH");
			h.addAllowedValue("IAI");
			h.addAllowedValue("IAK");
			h.addAllowedValue("IAL");
			h.addAllowedValue("IAM");
			h.addAllowedValue("IAN");
			h.addAllowedValue("IAO");
			h.addAllowedValue("IAP");
			h.addAllowedValue("IAQ");
			h.addAllowedValue("IAR");
			h.addAllowedValue("IAS");
			h.addAllowedValue("IAT");
			h.addAllowedValue("IAU");
			h.addAllowedValue("IAV");
			h.addAllowedValue("IAW");
			h.addAllowedValue("IAY");
			h.addAllowedValue("IAZ");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IE");
			h.addAllowedValue("IF");
			h.addAllowedValue("II");
			h.addAllowedValue("IJ");
			h.addAllowedValue("IK");
			h.addAllowedValue("IL");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("INV");
			h.addAllowedValue("IO");
			h.addAllowedValue("IP");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IR");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("IU");
			h.addAllowedValue("IV");
			h.addAllowedValue("I1");
			h.addAllowedValue("I3");
			h.addAllowedValue("I4");
			h.addAllowedValue("I9");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JC");
			h.addAllowedValue("JD");
			h.addAllowedValue("JE");
			h.addAllowedValue("JF");
			h.addAllowedValue("JG");
			h.addAllowedValue("JH");
			h.addAllowedValue("JI");
			h.addAllowedValue("JJ");
			h.addAllowedValue("JK");
			h.addAllowedValue("JL");
			h.addAllowedValue("JM");
			h.addAllowedValue("JN");
			h.addAllowedValue("JO");
			h.addAllowedValue("JP");
			h.addAllowedValue("JQ");
			h.addAllowedValue("JR");
			h.addAllowedValue("JS");
			h.addAllowedValue("JT");
			h.addAllowedValue("JU");
			h.addAllowedValue("JV");
			h.addAllowedValue("JW");
			h.addAllowedValue("JX");
			h.addAllowedValue("JY");
			h.addAllowedValue("JZ");
			h.addAllowedValue("J1");
			h.addAllowedValue("J2");
			h.addAllowedValue("J3");
			h.addAllowedValue("J4");
			h.addAllowedValue("J5");
			h.addAllowedValue("J6");
			h.addAllowedValue("J7");
			h.addAllowedValue("J8");
			h.addAllowedValue("J9");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KN");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KR");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("KU");
			h.addAllowedValue("KV");
			h.addAllowedValue("KW");
			h.addAllowedValue("KX");
			h.addAllowedValue("KY");
			h.addAllowedValue("KZ");
			h.addAllowedValue("K1");
			h.addAllowedValue("K2");
			h.addAllowedValue("K3");
			h.addAllowedValue("K4");
			h.addAllowedValue("K5");
			h.addAllowedValue("K6");
			h.addAllowedValue("K7");
			h.addAllowedValue("K8");
			h.addAllowedValue("K9");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LF");
			h.addAllowedValue("LG");
			h.addAllowedValue("LGS");
			h.addAllowedValue("LH");
			h.addAllowedValue("LI");
			h.addAllowedValue("LJ");
			h.addAllowedValue("LK");
			h.addAllowedValue("LL");
			h.addAllowedValue("LM");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LP");
			h.addAllowedValue("LQ");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LU");
			h.addAllowedValue("LV");
			h.addAllowedValue("LW");
			h.addAllowedValue("LY");
			h.addAllowedValue("LYM");
			h.addAllowedValue("LYN");
			h.addAllowedValue("LYO");
			h.addAllowedValue("LYP");
			h.addAllowedValue("LZ");
			h.addAllowedValue("L1");
			h.addAllowedValue("L2");
			h.addAllowedValue("L3");
			h.addAllowedValue("L5");
			h.addAllowedValue("L8");
			h.addAllowedValue("L9");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MP");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MSC");
			h.addAllowedValue("MT");
			h.addAllowedValue("MU");
			h.addAllowedValue("MV");
			h.addAllowedValue("MW");
			h.addAllowedValue("MX");
			h.addAllowedValue("MY");
			h.addAllowedValue("MZ");
			h.addAllowedValue("M1");
			h.addAllowedValue("M2");
			h.addAllowedValue("M3");
			h.addAllowedValue("M4");
			h.addAllowedValue("M5");
			h.addAllowedValue("M6");
			h.addAllowedValue("M7");
			h.addAllowedValue("M8");
			h.addAllowedValue("M9");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("NCT");
			h.addAllowedValue("ND");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NG");
			h.addAllowedValue("NH");
			h.addAllowedValue("NI");
			h.addAllowedValue("NJ");
			h.addAllowedValue("NK");
			h.addAllowedValue("NL");
			h.addAllowedValue("NM");
			h.addAllowedValue("NN");
			h.addAllowedValue("NP");
			h.addAllowedValue("NPC");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("NU");
			h.addAllowedValue("NV");
			h.addAllowedValue("NW");
			h.addAllowedValue("NX");
			h.addAllowedValue("NY");
			h.addAllowedValue("NZ");
			h.addAllowedValue("N1");
			h.addAllowedValue("N2");
			h.addAllowedValue("N3");
			h.addAllowedValue("N4");
			h.addAllowedValue("N5");
			h.addAllowedValue("N6");
			h.addAllowedValue("N7");
			h.addAllowedValue("N8");
			h.addAllowedValue("N9");
			h.addAllowedValue("OA");
			h.addAllowedValue("OB");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("OE");
			h.addAllowedValue("OF");
			h.addAllowedValue("OG");
			h.addAllowedValue("OH");
			h.addAllowedValue("OI");
			h.addAllowedValue("OK");
			h.addAllowedValue("OL");
			h.addAllowedValue("OM");
			h.addAllowedValue("ON");
			h.addAllowedValue("OO");
			h.addAllowedValue("OP");
			h.addAllowedValue("OR");
			h.addAllowedValue("ORI");
			h.addAllowedValue("OS");
			h.addAllowedValue("OT");
			h.addAllowedValue("OU");
			h.addAllowedValue("OV");
			h.addAllowedValue("OW");
			h.addAllowedValue("OX");
			h.addAllowedValue("OY");
			h.addAllowedValue("OZ");
			h.addAllowedValue("O1");
			h.addAllowedValue("O2");
			h.addAllowedValue("O3");
			h.addAllowedValue("O4");
			h.addAllowedValue("O5");
			h.addAllowedValue("O6");
			h.addAllowedValue("O7");
			h.addAllowedValue("O8");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PLR");
			h.addAllowedValue("PM");
			h.addAllowedValue("PMF");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PPS");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PRE");
			h.addAllowedValue("PRP");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PUR");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P0");
			h.addAllowedValue("P1");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P6");
			h.addAllowedValue("P7");
			h.addAllowedValue("P8");
			h.addAllowedValue("P9");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QF");
			h.addAllowedValue("QG");
			h.addAllowedValue("QH");
			h.addAllowedValue("QI");
			h.addAllowedValue("QJ");
			h.addAllowedValue("QK");
			h.addAllowedValue("QL");
			h.addAllowedValue("QM");
			h.addAllowedValue("QN");
			h.addAllowedValue("QO");
			h.addAllowedValue("QP");
			h.addAllowedValue("QQ");
			h.addAllowedValue("QR");
			h.addAllowedValue("QS");
			h.addAllowedValue("QT");
			h.addAllowedValue("QU");
			h.addAllowedValue("QV");
			h.addAllowedValue("QW");
			h.addAllowedValue("QX");
			h.addAllowedValue("QY");
			h.addAllowedValue("QZ");
			h.addAllowedValue("Q1");
			h.addAllowedValue("Q2");
			h.addAllowedValue("Q3");
			h.addAllowedValue("Q4");
			h.addAllowedValue("Q5");
			h.addAllowedValue("Q6");
			h.addAllowedValue("Q7");
			h.addAllowedValue("Q8");
			h.addAllowedValue("Q9");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RCR");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("REC");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RGA");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RV");
			h.addAllowedValue("RW");
			h.addAllowedValue("RX");
			h.addAllowedValue("RY");
			h.addAllowedValue("RZ");
			h.addAllowedValue("R0");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("R9");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SEP");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SY");
			h.addAllowedValue("SZ");
			h.addAllowedValue("S0");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TPM");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TSE");
			h.addAllowedValue("TSR");
			h.addAllowedValue("TT");
			h.addAllowedValue("TTP");
			h.addAllowedValue("TU");
			h.addAllowedValue("TV");
			h.addAllowedValue("TW");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("TZ");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("T4");
			h.addAllowedValue("T6");
			h.addAllowedValue("T8");
			h.addAllowedValue("T9");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("UF");
			h.addAllowedValue("UG");
			h.addAllowedValue("UH");
			h.addAllowedValue("UI");
			h.addAllowedValue("UJ");
			h.addAllowedValue("UK");
			h.addAllowedValue("UL");
			h.addAllowedValue("UM");
			h.addAllowedValue("UN");
			h.addAllowedValue("UO");
			h.addAllowedValue("UP");
			h.addAllowedValue("UQ");
			h.addAllowedValue("UR");
			h.addAllowedValue("US");
			h.addAllowedValue("UT");
			h.addAllowedValue("UU");
			h.addAllowedValue("UW");
			h.addAllowedValue("UX");
			h.addAllowedValue("UY");
			h.addAllowedValue("UZ");
			h.addAllowedValue("U1");
			h.addAllowedValue("U2");
			h.addAllowedValue("U3");
			h.addAllowedValue("U4");
			h.addAllowedValue("U5");
			h.addAllowedValue("U6");
			h.addAllowedValue("U7");
			h.addAllowedValue("U8");
			h.addAllowedValue("U9");
			h.addAllowedValue("VA");
			h.addAllowedValue("VB");
			h.addAllowedValue("VC");
			h.addAllowedValue("VD");
			h.addAllowedValue("VE");
			h.addAllowedValue("VF");
			h.addAllowedValue("VG");
			h.addAllowedValue("VH");
			h.addAllowedValue("VI");
			h.addAllowedValue("VJ");
			h.addAllowedValue("VK");
			h.addAllowedValue("VL");
			h.addAllowedValue("VM");
			h.addAllowedValue("VN");
			h.addAllowedValue("VO");
			h.addAllowedValue("VP");
			h.addAllowedValue("VQ");
			h.addAllowedValue("VR");
			h.addAllowedValue("VS");
			h.addAllowedValue("VT");
			h.addAllowedValue("VU");
			h.addAllowedValue("VV");
			h.addAllowedValue("VW");
			h.addAllowedValue("VX");
			h.addAllowedValue("VY");
			h.addAllowedValue("VZ");
			h.addAllowedValue("V1");
			h.addAllowedValue("V2");
			h.addAllowedValue("V3");
			h.addAllowedValue("V4");
			h.addAllowedValue("V5");
			h.addAllowedValue("V6");
			h.addAllowedValue("V8");
			h.addAllowedValue("V9");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WC");
			h.addAllowedValue("WD");
			h.addAllowedValue("WE");
			h.addAllowedValue("WF");
			h.addAllowedValue("WG");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WJ");
			h.addAllowedValue("WL");
			h.addAllowedValue("WN");
			h.addAllowedValue("WO");
			h.addAllowedValue("WP");
			h.addAllowedValue("WR");
			h.addAllowedValue("WS");
			h.addAllowedValue("WT");
			h.addAllowedValue("WU");
			h.addAllowedValue("WV");
			h.addAllowedValue("WW");
			h.addAllowedValue("WX");
			h.addAllowedValue("WY");
			h.addAllowedValue("WZ");
			h.addAllowedValue("W1");
			h.addAllowedValue("W2");
			h.addAllowedValue("W3");
			h.addAllowedValue("W4");
			h.addAllowedValue("W8");
			h.addAllowedValue("W9");
			h.addAllowedValue("XA");
			h.addAllowedValue("XC");
			h.addAllowedValue("XD");
			h.addAllowedValue("XE");
			h.addAllowedValue("XF");
			h.addAllowedValue("XG");
			h.addAllowedValue("XH");
			h.addAllowedValue("XI");
			h.addAllowedValue("XJ");
			h.addAllowedValue("XK");
			h.addAllowedValue("XL");
			h.addAllowedValue("XM");
			h.addAllowedValue("XN");
			h.addAllowedValue("XO");
			h.addAllowedValue("XP");
			h.addAllowedValue("XQ");
			h.addAllowedValue("XR");
			h.addAllowedValue("XS");
			h.addAllowedValue("XT");
			h.addAllowedValue("XU");
			h.addAllowedValue("XV");
			h.addAllowedValue("XW");
			h.addAllowedValue("XX");
			h.addAllowedValue("XY");
			h.addAllowedValue("XZ");
			h.addAllowedValue("X1");
			h.addAllowedValue("X2");
			h.addAllowedValue("X3");
			h.addAllowedValue("X4");
			h.addAllowedValue("X5");
			h.addAllowedValue("X6");
			h.addAllowedValue("X7");
			h.addAllowedValue("X8");
			h.addAllowedValue("YA");
			h.addAllowedValue("YB");
			h.addAllowedValue("YC");
			h.addAllowedValue("YD");
			h.addAllowedValue("YE");
			h.addAllowedValue("YF");
			h.addAllowedValue("YG");
			h.addAllowedValue("YH");
			h.addAllowedValue("YI");
			h.addAllowedValue("YJ");
			h.addAllowedValue("YK");
			h.addAllowedValue("YL");
			h.addAllowedValue("YM");
			h.addAllowedValue("YN");
			h.addAllowedValue("YO");
			h.addAllowedValue("YP");
			h.addAllowedValue("YQ");
			h.addAllowedValue("YR");
			h.addAllowedValue("YS");
			h.addAllowedValue("YT");
			h.addAllowedValue("YU");
			h.addAllowedValue("YV");
			h.addAllowedValue("YW");
			h.addAllowedValue("YX");
			h.addAllowedValue("YY");
			h.addAllowedValue("YZ");
			h.addAllowedValue("Y2");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZD");
			h.addAllowedValue("ZE");
			h.addAllowedValue("ZF");
			h.addAllowedValue("ZG");
			h.addAllowedValue("ZH");
			h.addAllowedValue("ZJ");
			h.addAllowedValue("ZK");
			h.addAllowedValue("ZL");
			h.addAllowedValue("ZM");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZO");
			h.addAllowedValue("ZP");
			h.addAllowedValue("ZQ");
			h.addAllowedValue("ZR");
			h.addAllowedValue("ZS");
			h.addAllowedValue("ZT");
			h.addAllowedValue("ZU");
			h.addAllowedValue("ZV");
			h.addAllowedValue("ZW");
			h.addAllowedValue("ZX");
			h.addAllowedValue("ZY");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("Z1");
			h.addAllowedValue("Z2");
			h.addAllowedValue("Z3");
			h.addAllowedValue("Z4");
			h.addAllowedValue("Z5");
			h.addAllowedValue("Z6");
			h.addAllowedValue("Z7");
			h.addAllowedValue("Z8");
			h.addAllowedValue("Z9");
			h.addAllowedValue("0A");
			h.addAllowedValue("0B");
			h.addAllowedValue("0D");
			h.addAllowedValue("0E");
			h.addAllowedValue("0F");
			h.addAllowedValue("0H");
			h.addAllowedValue("001");
			h.addAllowedValue("002");
			h.addAllowedValue("003");
			h.addAllowedValue("004");
			h.addAllowedValue("005");
			h.addAllowedValue("006");
			h.addAllowedValue("007");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("1A");
			h.addAllowedValue("1B");
			h.addAllowedValue("1C");
			h.addAllowedValue("1D");
			h.addAllowedValue("1E");
			h.addAllowedValue("1F");
			h.addAllowedValue("1G");
			h.addAllowedValue("1H");
			h.addAllowedValue("1I");
			h.addAllowedValue("1J");
			h.addAllowedValue("1K");
			h.addAllowedValue("1L");
			h.addAllowedValue("1M");
			h.addAllowedValue("1N");
			h.addAllowedValue("1O");
			h.addAllowedValue("1P");
			h.addAllowedValue("1Q");
			h.addAllowedValue("1R");
			h.addAllowedValue("1S");
			h.addAllowedValue("1T");
			h.addAllowedValue("1U");
			h.addAllowedValue("1V");
			h.addAllowedValue("1W");
			h.addAllowedValue("1X");
			h.addAllowedValue("1Y");
			h.addAllowedValue("1Z");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2A");
			h.addAllowedValue("2B");
			h.addAllowedValue("2C");
			h.addAllowedValue("2D");
			h.addAllowedValue("2E");
			h.addAllowedValue("2F");
			h.addAllowedValue("2G");
			h.addAllowedValue("2H");
			h.addAllowedValue("2I");
			h.addAllowedValue("2J");
			h.addAllowedValue("2K");
			h.addAllowedValue("2L");
			h.addAllowedValue("2M");
			h.addAllowedValue("2N");
			h.addAllowedValue("2O");
			h.addAllowedValue("2P");
			h.addAllowedValue("2Q");
			h.addAllowedValue("2R");
			h.addAllowedValue("2S");
			h.addAllowedValue("2T");
			h.addAllowedValue("2U");
			h.addAllowedValue("2V");
			h.addAllowedValue("2W");
			h.addAllowedValue("2X");
			h.addAllowedValue("2Y");
			h.addAllowedValue("2Z");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3A");
			h.addAllowedValue("3B");
			h.addAllowedValue("3C");
			h.addAllowedValue("3D");
			h.addAllowedValue("3E");
			h.addAllowedValue("3F");
			h.addAllowedValue("3G");
			h.addAllowedValue("3H");
			h.addAllowedValue("3I");
			h.addAllowedValue("3J");
			h.addAllowedValue("3K");
			h.addAllowedValue("3L");
			h.addAllowedValue("3M");
			h.addAllowedValue("3N");
			h.addAllowedValue("3O");
			h.addAllowedValue("3P");
			h.addAllowedValue("3Q");
			h.addAllowedValue("3R");
			h.addAllowedValue("3S");
			h.addAllowedValue("3T");
			h.addAllowedValue("3U");
			h.addAllowedValue("3V");
			h.addAllowedValue("3W");
			h.addAllowedValue("3X");
			h.addAllowedValue("3Y");
			h.addAllowedValue("3Z");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4A");
			h.addAllowedValue("4B");
			h.addAllowedValue("4C");
			h.addAllowedValue("4D");
			h.addAllowedValue("4E");
			h.addAllowedValue("4F");
			h.addAllowedValue("4G");
			h.addAllowedValue("4H");
			h.addAllowedValue("4I");
			h.addAllowedValue("4J");
			h.addAllowedValue("4K");
			h.addAllowedValue("4L");
			h.addAllowedValue("4M");
			h.addAllowedValue("4N");
			h.addAllowedValue("4O");
			h.addAllowedValue("4P");
			h.addAllowedValue("4Q");
			h.addAllowedValue("4R");
			h.addAllowedValue("4S");
			h.addAllowedValue("4T");
			h.addAllowedValue("4U");
			h.addAllowedValue("4V");
			h.addAllowedValue("4W");
			h.addAllowedValue("4X");
			h.addAllowedValue("4Y");
			h.addAllowedValue("4Z");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5A");
			h.addAllowedValue("5B");
			h.addAllowedValue("5C");
			h.addAllowedValue("5D");
			h.addAllowedValue("5E");
			h.addAllowedValue("5F");
			h.addAllowedValue("5G");
			h.addAllowedValue("5H");
			h.addAllowedValue("5I");
			h.addAllowedValue("5J");
			h.addAllowedValue("5K");
			h.addAllowedValue("5L");
			h.addAllowedValue("5M");
			h.addAllowedValue("5N");
			h.addAllowedValue("5O");
			h.addAllowedValue("5P");
			h.addAllowedValue("5Q");
			h.addAllowedValue("5R");
			h.addAllowedValue("5S");
			h.addAllowedValue("5T");
			h.addAllowedValue("5U");
			h.addAllowedValue("5V");
			h.addAllowedValue("5W");
			h.addAllowedValue("5X");
			h.addAllowedValue("5Y");
			h.addAllowedValue("5Z");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("6A");
			h.addAllowedValue("6B");
			h.addAllowedValue("6C");
			h.addAllowedValue("6D");
			h.addAllowedValue("6E");
			h.addAllowedValue("6F");
			h.addAllowedValue("6G");
			h.addAllowedValue("6H");
			h.addAllowedValue("6I");
			h.addAllowedValue("6J");
			h.addAllowedValue("6K");
			h.addAllowedValue("6L");
			h.addAllowedValue("6M");
			h.addAllowedValue("6N");
			h.addAllowedValue("6O");
			h.addAllowedValue("6P");
			h.addAllowedValue("6Q");
			h.addAllowedValue("6R");
			h.addAllowedValue("6S");
			h.addAllowedValue("6T");
			h.addAllowedValue("6U");
			h.addAllowedValue("6V");
			h.addAllowedValue("6W");
			h.addAllowedValue("6X");
			h.addAllowedValue("6Y");
			h.addAllowedValue("6Z");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("7A");
			h.addAllowedValue("7B");
			h.addAllowedValue("7C");
			h.addAllowedValue("7D");
			h.addAllowedValue("7E");
			h.addAllowedValue("7F");
			h.addAllowedValue("7G");
			h.addAllowedValue("7H");
			h.addAllowedValue("7I");
			h.addAllowedValue("7J");
			h.addAllowedValue("7K");
			h.addAllowedValue("7L");
			h.addAllowedValue("7M");
			h.addAllowedValue("7N");
			h.addAllowedValue("7O");
			h.addAllowedValue("7P");
			h.addAllowedValue("7Q");
			h.addAllowedValue("7R");
			h.addAllowedValue("7S");
			h.addAllowedValue("7T");
			h.addAllowedValue("7U");
			h.addAllowedValue("7V");
			h.addAllowedValue("7W");
			h.addAllowedValue("7X");
			h.addAllowedValue("7Y");
			h.addAllowedValue("7Z");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8A");
			h.addAllowedValue("8B");
			h.addAllowedValue("8C");
			h.addAllowedValue("8D");
			h.addAllowedValue("8E");
			h.addAllowedValue("8F");
			h.addAllowedValue("8G");
			h.addAllowedValue("8H");
			h.addAllowedValue("8I");
			h.addAllowedValue("8J");
			h.addAllowedValue("8K");
			h.addAllowedValue("8L");
			h.addAllowedValue("8M");
			h.addAllowedValue("8N");
			h.addAllowedValue("8O");
			h.addAllowedValue("8P");
			h.addAllowedValue("8Q");
			h.addAllowedValue("8R");
			h.addAllowedValue("8S");
			h.addAllowedValue("8T");
			h.addAllowedValue("8U");
			h.addAllowedValue("8V");
			h.addAllowedValue("8W");
			h.addAllowedValue("8X");
			h.addAllowedValue("8Y");
			h.addAllowedValue("8Z");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9A");
			h.addAllowedValue("9B");
			h.addAllowedValue("9C");
			h.addAllowedValue("9D");
			h.addAllowedValue("9E");
			h.addAllowedValue("9F");
			h.addAllowedValue("9G");
			h.addAllowedValue("9H");
			h.addAllowedValue("9I");
			h.addAllowedValue("9J");
			h.addAllowedValue("9K");
			h.addAllowedValue("9L");
			h.addAllowedValue("9N");
			h.addAllowedValue("9O");
			h.addAllowedValue("9P");
			h.addAllowedValue("9Q");
			h.addAllowedValue("9R");
			h.addAllowedValue("9S");
			h.addAllowedValue("9T");
			h.addAllowedValue("9U");
			h.addAllowedValue("9V");
			h.addAllowedValue("9W");
			h.addAllowedValue("9X");
			h.addAllowedValue("9Y");
			h.addAllowedValue("9Z");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement98 = new RtSimpleElement("98", "ID", h);
		}
	
		return simpleElement98;
	}
	
	private RtSimpleElement simpleElement100;
	
	private RtSimpleElement simpleElement100() {
		if (simpleElement100 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Currency Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			simpleElement100 = new RtSimpleElement("100", "ID", h);
		}
	
		return simpleElement100;
	}
	
	private RtSimpleElement simpleElement280;
	
	private RtSimpleElement simpleElement280() {
		if (simpleElement280 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Exchange Rate";
			h.minLength = 4;
			h.maxLength = 10;
			
			simpleElement280 = new RtSimpleElement("280", "R", h);
		}
	
		return simpleElement280;
	}
	
	private RtSimpleElement simpleElement669;
	
	private RtSimpleElement simpleElement669() {
		if (simpleElement669 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Currency Market/Exchange Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("IMF");
			h.addAllowedValue("LNF");
			h.addAllowedValue("LNS");
			h.addAllowedValue("NYC");
			h.addAllowedValue("PHI");
			h.addAllowedValue("ZUR");
			simpleElement669 = new RtSimpleElement("669", "ID", h);
		}
	
		return simpleElement669;
	}
	
	private RtSimpleElement simpleElement374;
	
	private RtSimpleElement simpleElement374() {
		if (simpleElement374 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Date/Time Qualifier";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("AAA");
			h.addAllowedValue("AAB");
			h.addAllowedValue("AAD");
			h.addAllowedValue("AAE");
			h.addAllowedValue("AAF");
			h.addAllowedValue("AAG");
			h.addAllowedValue("AAH");
			h.addAllowedValue("AAI");
			h.addAllowedValue("AAJ");
			h.addAllowedValue("AAK");
			h.addAllowedValue("AAL");
			h.addAllowedValue("AAM");
			h.addAllowedValue("AAN");
			h.addAllowedValue("AAO");
			h.addAllowedValue("AAP");
			h.addAllowedValue("AAQ");
			h.addAllowedValue("AAR");
			h.addAllowedValue("AAS");
			h.addAllowedValue("AAT");
			h.addAllowedValue("AAU");
			h.addAllowedValue("AAV");
			h.addAllowedValue("AAW");
			h.addAllowedValue("AAX");
			h.addAllowedValue("AAY");
			h.addAllowedValue("AAZ");
			h.addAllowedValue("AA1");
			h.addAllowedValue("AA2");
			h.addAllowedValue("AA3");
			h.addAllowedValue("AA4");
			h.addAllowedValue("AA5");
			h.addAllowedValue("AA6");
			h.addAllowedValue("AA7");
			h.addAllowedValue("AA8");
			h.addAllowedValue("AA9");
			h.addAllowedValue("ABA");
			h.addAllowedValue("ABB");
			h.addAllowedValue("ABC");
			h.addAllowedValue("ABD");
			h.addAllowedValue("ABE");
			h.addAllowedValue("ABG");
			h.addAllowedValue("ABH");
			h.addAllowedValue("ABI");
			h.addAllowedValue("ABK");
			h.addAllowedValue("ABL");
			h.addAllowedValue("ABM");
			h.addAllowedValue("ABN");
			h.addAllowedValue("ABO");
			h.addAllowedValue("ABP");
			h.addAllowedValue("ABQ");
			h.addAllowedValue("ABR");
			h.addAllowedValue("ABS");
			h.addAllowedValue("ABT");
			h.addAllowedValue("ABU");
			h.addAllowedValue("ABV");
			h.addAllowedValue("ABW");
			h.addAllowedValue("ABX");
			h.addAllowedValue("ABY");
			h.addAllowedValue("AB1");
			h.addAllowedValue("AB2");
			h.addAllowedValue("AB3");
			h.addAllowedValue("AB4");
			h.addAllowedValue("AB5");
			h.addAllowedValue("AB6");
			h.addAllowedValue("AB7");
			h.addAllowedValue("AB8");
			h.addAllowedValue("AB9");
			h.addAllowedValue("ACA");
			h.addAllowedValue("ACB");
			h.addAllowedValue("ACK");
			h.addAllowedValue("ADB");
			h.addAllowedValue("ADC");
			h.addAllowedValue("ADD");
			h.addAllowedValue("ADL");
			h.addAllowedValue("ADM");
			h.addAllowedValue("ADR");
			h.addAllowedValue("ARD");
			h.addAllowedValue("CAD");
			h.addAllowedValue("CCR");
			h.addAllowedValue("CDT");
			h.addAllowedValue("CEA");
			h.addAllowedValue("CEB");
			h.addAllowedValue("CEC");
			h.addAllowedValue("CED");
			h.addAllowedValue("CEE");
			h.addAllowedValue("CEF");
			h.addAllowedValue("CEH");
			h.addAllowedValue("CEJ");
			h.addAllowedValue("CEK");
			h.addAllowedValue("CEL");
			h.addAllowedValue("CEM");
			h.addAllowedValue("CEN");
			h.addAllowedValue("CEO");
			h.addAllowedValue("CLO");
			h.addAllowedValue("CLU");
			h.addAllowedValue("COM");
			h.addAllowedValue("CON");
			h.addAllowedValue("CUR");
			h.addAllowedValue("DDO");
			h.addAllowedValue("DEE");
			h.addAllowedValue("DET");
			h.addAllowedValue("DFF");
			h.addAllowedValue("DFS");
			h.addAllowedValue("DIS");
			h.addAllowedValue("DOI");
			h.addAllowedValue("DSP");
			h.addAllowedValue("ECD");
			h.addAllowedValue("ECF");
			h.addAllowedValue("ECS");
			h.addAllowedValue("ECT");
			h.addAllowedValue("EPP");
			h.addAllowedValue("ESC");
			h.addAllowedValue("ESF");
			h.addAllowedValue("ESS");
			h.addAllowedValue("EST");
			h.addAllowedValue("ETP");
			h.addAllowedValue("EXO");
			h.addAllowedValue("EXP");
			h.addAllowedValue("FFI");
			h.addAllowedValue("GRD");
			h.addAllowedValue("ICF");
			h.addAllowedValue("IDG");
			h.addAllowedValue("III");
			h.addAllowedValue("IMP");
			h.addAllowedValue("INC");
			h.addAllowedValue("INT");
			h.addAllowedValue("KEV");
			h.addAllowedValue("KEW");
			h.addAllowedValue("LAS");
			h.addAllowedValue("LCC");
			h.addAllowedValue("LEA");
			h.addAllowedValue("LEL");
			h.addAllowedValue("LIQ");
			h.addAllowedValue("LLP");
			h.addAllowedValue("LOG");
			h.addAllowedValue("LPC");
			h.addAllowedValue("LSC");
			h.addAllowedValue("LTP");
			h.addAllowedValue("MRR");
			h.addAllowedValue("MSD");
			h.addAllowedValue("NAM");
			h.addAllowedValue("NFD");
			h.addAllowedValue("NRG");
			h.addAllowedValue("NSD");
			h.addAllowedValue("ORG");
			h.addAllowedValue("PBC");
			h.addAllowedValue("PDV");
			h.addAllowedValue("PLS");
			h.addAllowedValue("PPP");
			h.addAllowedValue("PRD");
			h.addAllowedValue("PRR");
			h.addAllowedValue("PTD");
			h.addAllowedValue("RAP");
			h.addAllowedValue("RES");
			h.addAllowedValue("RFD");
			h.addAllowedValue("RFF");
			h.addAllowedValue("RFO");
			h.addAllowedValue("RNT");
			h.addAllowedValue("RRM");
			h.addAllowedValue("RRT");
			h.addAllowedValue("RSD");
			h.addAllowedValue("RSS");
			h.addAllowedValue("RTO");
			h.addAllowedValue("SCV");
			h.addAllowedValue("SDD");
			h.addAllowedValue("STN");
			h.addAllowedValue("TSR");
			h.addAllowedValue("TSS");
			h.addAllowedValue("TST");
			h.addAllowedValue("VAT");
			h.addAllowedValue("VLU");
			h.addAllowedValue("WAY");
			h.addAllowedValue("W01");
			h.addAllowedValue("W02");
			h.addAllowedValue("W03");
			h.addAllowedValue("W05");
			h.addAllowedValue("W06");
			h.addAllowedValue("W07");
			h.addAllowedValue("W08");
			h.addAllowedValue("W09");
			h.addAllowedValue("W10");
			h.addAllowedValue("W11");
			h.addAllowedValue("W12");
			h.addAllowedValue("W13");
			h.addAllowedValue("YXX");
			h.addAllowedValue("YXY");
			h.addAllowedValue("ZZZ");
			h.addAllowedValue("001");
			h.addAllowedValue("002");
			h.addAllowedValue("003");
			h.addAllowedValue("004");
			h.addAllowedValue("005");
			h.addAllowedValue("006");
			h.addAllowedValue("007");
			h.addAllowedValue("008");
			h.addAllowedValue("009");
			h.addAllowedValue("010");
			h.addAllowedValue("011");
			h.addAllowedValue("012");
			h.addAllowedValue("013");
			h.addAllowedValue("014");
			h.addAllowedValue("015");
			h.addAllowedValue("016");
			h.addAllowedValue("017");
			h.addAllowedValue("018");
			h.addAllowedValue("019");
			h.addAllowedValue("020");
			h.addAllowedValue("021");
			h.addAllowedValue("022");
			h.addAllowedValue("023");
			h.addAllowedValue("024");
			h.addAllowedValue("025");
			h.addAllowedValue("026");
			h.addAllowedValue("027");
			h.addAllowedValue("028");
			h.addAllowedValue("029");
			h.addAllowedValue("030");
			h.addAllowedValue("031");
			h.addAllowedValue("032");
			h.addAllowedValue("033");
			h.addAllowedValue("034");
			h.addAllowedValue("035");
			h.addAllowedValue("036");
			h.addAllowedValue("037");
			h.addAllowedValue("038");
			h.addAllowedValue("039");
			h.addAllowedValue("040");
			h.addAllowedValue("041");
			h.addAllowedValue("042");
			h.addAllowedValue("043");
			h.addAllowedValue("044");
			h.addAllowedValue("045");
			h.addAllowedValue("046");
			h.addAllowedValue("047");
			h.addAllowedValue("048");
			h.addAllowedValue("049");
			h.addAllowedValue("050");
			h.addAllowedValue("051");
			h.addAllowedValue("052");
			h.addAllowedValue("053");
			h.addAllowedValue("054");
			h.addAllowedValue("055");
			h.addAllowedValue("056");
			h.addAllowedValue("057");
			h.addAllowedValue("058");
			h.addAllowedValue("059");
			h.addAllowedValue("060");
			h.addAllowedValue("061");
			h.addAllowedValue("062");
			h.addAllowedValue("063");
			h.addAllowedValue("064");
			h.addAllowedValue("065");
			h.addAllowedValue("066");
			h.addAllowedValue("067");
			h.addAllowedValue("068");
			h.addAllowedValue("069");
			h.addAllowedValue("070");
			h.addAllowedValue("071");
			h.addAllowedValue("072");
			h.addAllowedValue("073");
			h.addAllowedValue("074");
			h.addAllowedValue("075");
			h.addAllowedValue("076");
			h.addAllowedValue("077");
			h.addAllowedValue("078");
			h.addAllowedValue("079");
			h.addAllowedValue("080");
			h.addAllowedValue("081");
			h.addAllowedValue("082");
			h.addAllowedValue("083");
			h.addAllowedValue("084");
			h.addAllowedValue("085");
			h.addAllowedValue("086");
			h.addAllowedValue("087");
			h.addAllowedValue("088");
			h.addAllowedValue("089");
			h.addAllowedValue("090");
			h.addAllowedValue("091");
			h.addAllowedValue("092");
			h.addAllowedValue("093");
			h.addAllowedValue("094");
			h.addAllowedValue("095");
			h.addAllowedValue("096");
			h.addAllowedValue("097");
			h.addAllowedValue("098");
			h.addAllowedValue("099");
			h.addAllowedValue("100");
			h.addAllowedValue("101");
			h.addAllowedValue("102");
			h.addAllowedValue("103");
			h.addAllowedValue("104");
			h.addAllowedValue("105");
			h.addAllowedValue("106");
			h.addAllowedValue("107");
			h.addAllowedValue("108");
			h.addAllowedValue("109");
			h.addAllowedValue("110");
			h.addAllowedValue("111");
			h.addAllowedValue("112");
			h.addAllowedValue("113");
			h.addAllowedValue("114");
			h.addAllowedValue("115");
			h.addAllowedValue("116");
			h.addAllowedValue("118");
			h.addAllowedValue("119");
			h.addAllowedValue("120");
			h.addAllowedValue("121");
			h.addAllowedValue("122");
			h.addAllowedValue("124");
			h.addAllowedValue("125");
			h.addAllowedValue("126");
			h.addAllowedValue("127");
			h.addAllowedValue("128");
			h.addAllowedValue("129");
			h.addAllowedValue("130");
			h.addAllowedValue("131");
			h.addAllowedValue("132");
			h.addAllowedValue("133");
			h.addAllowedValue("134");
			h.addAllowedValue("135");
			h.addAllowedValue("136");
			h.addAllowedValue("137");
			h.addAllowedValue("138");
			h.addAllowedValue("139");
			h.addAllowedValue("140");
			h.addAllowedValue("141");
			h.addAllowedValue("142");
			h.addAllowedValue("143");
			h.addAllowedValue("144");
			h.addAllowedValue("145");
			h.addAllowedValue("146");
			h.addAllowedValue("147");
			h.addAllowedValue("148");
			h.addAllowedValue("149");
			h.addAllowedValue("150");
			h.addAllowedValue("151");
			h.addAllowedValue("152");
			h.addAllowedValue("153");
			h.addAllowedValue("154");
			h.addAllowedValue("155");
			h.addAllowedValue("156");
			h.addAllowedValue("157");
			h.addAllowedValue("158");
			h.addAllowedValue("159");
			h.addAllowedValue("160");
			h.addAllowedValue("161");
			h.addAllowedValue("162");
			h.addAllowedValue("163");
			h.addAllowedValue("164");
			h.addAllowedValue("165");
			h.addAllowedValue("166");
			h.addAllowedValue("167");
			h.addAllowedValue("168");
			h.addAllowedValue("169");
			h.addAllowedValue("170");
			h.addAllowedValue("171");
			h.addAllowedValue("172");
			h.addAllowedValue("173");
			h.addAllowedValue("174");
			h.addAllowedValue("175");
			h.addAllowedValue("176");
			h.addAllowedValue("177");
			h.addAllowedValue("178");
			h.addAllowedValue("179");
			h.addAllowedValue("180");
			h.addAllowedValue("181");
			h.addAllowedValue("182");
			h.addAllowedValue("183");
			h.addAllowedValue("184");
			h.addAllowedValue("185");
			h.addAllowedValue("186");
			h.addAllowedValue("187");
			h.addAllowedValue("188");
			h.addAllowedValue("189");
			h.addAllowedValue("190");
			h.addAllowedValue("191");
			h.addAllowedValue("192");
			h.addAllowedValue("193");
			h.addAllowedValue("194");
			h.addAllowedValue("195");
			h.addAllowedValue("196");
			h.addAllowedValue("197");
			h.addAllowedValue("198");
			h.addAllowedValue("199");
			h.addAllowedValue("200");
			h.addAllowedValue("201");
			h.addAllowedValue("202");
			h.addAllowedValue("203");
			h.addAllowedValue("204");
			h.addAllowedValue("205");
			h.addAllowedValue("206");
			h.addAllowedValue("207");
			h.addAllowedValue("208");
			h.addAllowedValue("209");
			h.addAllowedValue("210");
			h.addAllowedValue("211");
			h.addAllowedValue("212");
			h.addAllowedValue("213");
			h.addAllowedValue("214");
			h.addAllowedValue("215");
			h.addAllowedValue("216");
			h.addAllowedValue("217");
			h.addAllowedValue("218");
			h.addAllowedValue("219");
			h.addAllowedValue("220");
			h.addAllowedValue("221");
			h.addAllowedValue("222");
			h.addAllowedValue("223");
			h.addAllowedValue("224");
			h.addAllowedValue("225");
			h.addAllowedValue("226");
			h.addAllowedValue("227");
			h.addAllowedValue("228");
			h.addAllowedValue("229");
			h.addAllowedValue("230");
			h.addAllowedValue("231");
			h.addAllowedValue("232");
			h.addAllowedValue("233");
			h.addAllowedValue("234");
			h.addAllowedValue("235");
			h.addAllowedValue("236");
			h.addAllowedValue("237");
			h.addAllowedValue("238");
			h.addAllowedValue("239");
			h.addAllowedValue("240");
			h.addAllowedValue("241");
			h.addAllowedValue("242");
			h.addAllowedValue("243");
			h.addAllowedValue("244");
			h.addAllowedValue("245");
			h.addAllowedValue("246");
			h.addAllowedValue("247");
			h.addAllowedValue("248");
			h.addAllowedValue("249");
			h.addAllowedValue("250");
			h.addAllowedValue("251");
			h.addAllowedValue("252");
			h.addAllowedValue("253");
			h.addAllowedValue("254");
			h.addAllowedValue("255");
			h.addAllowedValue("256");
			h.addAllowedValue("257");
			h.addAllowedValue("258");
			h.addAllowedValue("259");
			h.addAllowedValue("260");
			h.addAllowedValue("261");
			h.addAllowedValue("262");
			h.addAllowedValue("263");
			h.addAllowedValue("264");
			h.addAllowedValue("265");
			h.addAllowedValue("266");
			h.addAllowedValue("267");
			h.addAllowedValue("268");
			h.addAllowedValue("269");
			h.addAllowedValue("270");
			h.addAllowedValue("271");
			h.addAllowedValue("272");
			h.addAllowedValue("273");
			h.addAllowedValue("274");
			h.addAllowedValue("275");
			h.addAllowedValue("276");
			h.addAllowedValue("277");
			h.addAllowedValue("278");
			h.addAllowedValue("279");
			h.addAllowedValue("280");
			h.addAllowedValue("281");
			h.addAllowedValue("282");
			h.addAllowedValue("283");
			h.addAllowedValue("284");
			h.addAllowedValue("285");
			h.addAllowedValue("286");
			h.addAllowedValue("287");
			h.addAllowedValue("288");
			h.addAllowedValue("289");
			h.addAllowedValue("290");
			h.addAllowedValue("291");
			h.addAllowedValue("292");
			h.addAllowedValue("293");
			h.addAllowedValue("294");
			h.addAllowedValue("295");
			h.addAllowedValue("296");
			h.addAllowedValue("297");
			h.addAllowedValue("298");
			h.addAllowedValue("299");
			h.addAllowedValue("300");
			h.addAllowedValue("301");
			h.addAllowedValue("302");
			h.addAllowedValue("303");
			h.addAllowedValue("304");
			h.addAllowedValue("305");
			h.addAllowedValue("306");
			h.addAllowedValue("307");
			h.addAllowedValue("308");
			h.addAllowedValue("309");
			h.addAllowedValue("310");
			h.addAllowedValue("311");
			h.addAllowedValue("312");
			h.addAllowedValue("313");
			h.addAllowedValue("314");
			h.addAllowedValue("315");
			h.addAllowedValue("316");
			h.addAllowedValue("317");
			h.addAllowedValue("318");
			h.addAllowedValue("319");
			h.addAllowedValue("320");
			h.addAllowedValue("321");
			h.addAllowedValue("322");
			h.addAllowedValue("323");
			h.addAllowedValue("324");
			h.addAllowedValue("325");
			h.addAllowedValue("326");
			h.addAllowedValue("327");
			h.addAllowedValue("328");
			h.addAllowedValue("329");
			h.addAllowedValue("330");
			h.addAllowedValue("331");
			h.addAllowedValue("332");
			h.addAllowedValue("333");
			h.addAllowedValue("334");
			h.addAllowedValue("335");
			h.addAllowedValue("336");
			h.addAllowedValue("337");
			h.addAllowedValue("338");
			h.addAllowedValue("339");
			h.addAllowedValue("340");
			h.addAllowedValue("341");
			h.addAllowedValue("342");
			h.addAllowedValue("343");
			h.addAllowedValue("344");
			h.addAllowedValue("345");
			h.addAllowedValue("346");
			h.addAllowedValue("347");
			h.addAllowedValue("348");
			h.addAllowedValue("349");
			h.addAllowedValue("350");
			h.addAllowedValue("351");
			h.addAllowedValue("352");
			h.addAllowedValue("353");
			h.addAllowedValue("354");
			h.addAllowedValue("355");
			h.addAllowedValue("356");
			h.addAllowedValue("357");
			h.addAllowedValue("358");
			h.addAllowedValue("359");
			h.addAllowedValue("360");
			h.addAllowedValue("361");
			h.addAllowedValue("362");
			h.addAllowedValue("363");
			h.addAllowedValue("364");
			h.addAllowedValue("365");
			h.addAllowedValue("366");
			h.addAllowedValue("367");
			h.addAllowedValue("368");
			h.addAllowedValue("369");
			h.addAllowedValue("370");
			h.addAllowedValue("371");
			h.addAllowedValue("372");
			h.addAllowedValue("373");
			h.addAllowedValue("374");
			h.addAllowedValue("375");
			h.addAllowedValue("376");
			h.addAllowedValue("377");
			h.addAllowedValue("378");
			h.addAllowedValue("379");
			h.addAllowedValue("380");
			h.addAllowedValue("381");
			h.addAllowedValue("382");
			h.addAllowedValue("383");
			h.addAllowedValue("384");
			h.addAllowedValue("385");
			h.addAllowedValue("386");
			h.addAllowedValue("387");
			h.addAllowedValue("388");
			h.addAllowedValue("389");
			h.addAllowedValue("390");
			h.addAllowedValue("391");
			h.addAllowedValue("392");
			h.addAllowedValue("393");
			h.addAllowedValue("394");
			h.addAllowedValue("395");
			h.addAllowedValue("396");
			h.addAllowedValue("397");
			h.addAllowedValue("398");
			h.addAllowedValue("399");
			h.addAllowedValue("400");
			h.addAllowedValue("401");
			h.addAllowedValue("402");
			h.addAllowedValue("403");
			h.addAllowedValue("404");
			h.addAllowedValue("405");
			h.addAllowedValue("406");
			h.addAllowedValue("408");
			h.addAllowedValue("409");
			h.addAllowedValue("410");
			h.addAllowedValue("411");
			h.addAllowedValue("412");
			h.addAllowedValue("413");
			h.addAllowedValue("414");
			h.addAllowedValue("415");
			h.addAllowedValue("416");
			h.addAllowedValue("417");
			h.addAllowedValue("418");
			h.addAllowedValue("419");
			h.addAllowedValue("420");
			h.addAllowedValue("421");
			h.addAllowedValue("422");
			h.addAllowedValue("423");
			h.addAllowedValue("424");
			h.addAllowedValue("425");
			h.addAllowedValue("426");
			h.addAllowedValue("427");
			h.addAllowedValue("428");
			h.addAllowedValue("429");
			h.addAllowedValue("430");
			h.addAllowedValue("431");
			h.addAllowedValue("432");
			h.addAllowedValue("433");
			h.addAllowedValue("434");
			h.addAllowedValue("435");
			h.addAllowedValue("436");
			h.addAllowedValue("437");
			h.addAllowedValue("438");
			h.addAllowedValue("439");
			h.addAllowedValue("440");
			h.addAllowedValue("441");
			h.addAllowedValue("442");
			h.addAllowedValue("443");
			h.addAllowedValue("444");
			h.addAllowedValue("445");
			h.addAllowedValue("446");
			h.addAllowedValue("447");
			h.addAllowedValue("448");
			h.addAllowedValue("449");
			h.addAllowedValue("450");
			h.addAllowedValue("451");
			h.addAllowedValue("452");
			h.addAllowedValue("453");
			h.addAllowedValue("454");
			h.addAllowedValue("455");
			h.addAllowedValue("456");
			h.addAllowedValue("457");
			h.addAllowedValue("458");
			h.addAllowedValue("459");
			h.addAllowedValue("460");
			h.addAllowedValue("461");
			h.addAllowedValue("462");
			h.addAllowedValue("463");
			h.addAllowedValue("464");
			h.addAllowedValue("465");
			h.addAllowedValue("466");
			h.addAllowedValue("467");
			h.addAllowedValue("468");
			h.addAllowedValue("469");
			h.addAllowedValue("470");
			h.addAllowedValue("471");
			h.addAllowedValue("472");
			h.addAllowedValue("473");
			h.addAllowedValue("474");
			h.addAllowedValue("475");
			h.addAllowedValue("476");
			h.addAllowedValue("477");
			h.addAllowedValue("478");
			h.addAllowedValue("479");
			h.addAllowedValue("480");
			h.addAllowedValue("481");
			h.addAllowedValue("482");
			h.addAllowedValue("483");
			h.addAllowedValue("484");
			h.addAllowedValue("485");
			h.addAllowedValue("486");
			h.addAllowedValue("487");
			h.addAllowedValue("488");
			h.addAllowedValue("489");
			h.addAllowedValue("490");
			h.addAllowedValue("491");
			h.addAllowedValue("492");
			h.addAllowedValue("493");
			h.addAllowedValue("494");
			h.addAllowedValue("495");
			h.addAllowedValue("496");
			h.addAllowedValue("497");
			h.addAllowedValue("498");
			h.addAllowedValue("499");
			h.addAllowedValue("500");
			h.addAllowedValue("501");
			h.addAllowedValue("502");
			h.addAllowedValue("503");
			h.addAllowedValue("504");
			h.addAllowedValue("505");
			h.addAllowedValue("506");
			h.addAllowedValue("507");
			h.addAllowedValue("508");
			h.addAllowedValue("509");
			h.addAllowedValue("510");
			h.addAllowedValue("511");
			h.addAllowedValue("512");
			h.addAllowedValue("513");
			h.addAllowedValue("514");
			h.addAllowedValue("515");
			h.addAllowedValue("516");
			h.addAllowedValue("517");
			h.addAllowedValue("518");
			h.addAllowedValue("519");
			h.addAllowedValue("520");
			h.addAllowedValue("521");
			h.addAllowedValue("522");
			h.addAllowedValue("523");
			h.addAllowedValue("524");
			h.addAllowedValue("525");
			h.addAllowedValue("526");
			h.addAllowedValue("527");
			h.addAllowedValue("528");
			h.addAllowedValue("529");
			h.addAllowedValue("530");
			h.addAllowedValue("531");
			h.addAllowedValue("532");
			h.addAllowedValue("533");
			h.addAllowedValue("534");
			h.addAllowedValue("535");
			h.addAllowedValue("536");
			h.addAllowedValue("537");
			h.addAllowedValue("538");
			h.addAllowedValue("539");
			h.addAllowedValue("540");
			h.addAllowedValue("541");
			h.addAllowedValue("542");
			h.addAllowedValue("543");
			h.addAllowedValue("544");
			h.addAllowedValue("545");
			h.addAllowedValue("546");
			h.addAllowedValue("547");
			h.addAllowedValue("548");
			h.addAllowedValue("549");
			h.addAllowedValue("550");
			h.addAllowedValue("551");
			h.addAllowedValue("552");
			h.addAllowedValue("553");
			h.addAllowedValue("554");
			h.addAllowedValue("555");
			h.addAllowedValue("556");
			h.addAllowedValue("557");
			h.addAllowedValue("558");
			h.addAllowedValue("559");
			h.addAllowedValue("560");
			h.addAllowedValue("561");
			h.addAllowedValue("562");
			h.addAllowedValue("563");
			h.addAllowedValue("564");
			h.addAllowedValue("565");
			h.addAllowedValue("566");
			h.addAllowedValue("567");
			h.addAllowedValue("568");
			h.addAllowedValue("569");
			h.addAllowedValue("570");
			h.addAllowedValue("571");
			h.addAllowedValue("572");
			h.addAllowedValue("573");
			h.addAllowedValue("574");
			h.addAllowedValue("575");
			h.addAllowedValue("576");
			h.addAllowedValue("577");
			h.addAllowedValue("578");
			h.addAllowedValue("579");
			h.addAllowedValue("580");
			h.addAllowedValue("581");
			h.addAllowedValue("582");
			h.addAllowedValue("583");
			h.addAllowedValue("584");
			h.addAllowedValue("585");
			h.addAllowedValue("586");
			h.addAllowedValue("587");
			h.addAllowedValue("589");
			h.addAllowedValue("590");
			h.addAllowedValue("591");
			h.addAllowedValue("592");
			h.addAllowedValue("593");
			h.addAllowedValue("594");
			h.addAllowedValue("595");
			h.addAllowedValue("596");
			h.addAllowedValue("597");
			h.addAllowedValue("598");
			h.addAllowedValue("599");
			h.addAllowedValue("600");
			h.addAllowedValue("601");
			h.addAllowedValue("602");
			h.addAllowedValue("603");
			h.addAllowedValue("604");
			h.addAllowedValue("606");
			h.addAllowedValue("607");
			h.addAllowedValue("608");
			h.addAllowedValue("609");
			h.addAllowedValue("610");
			h.addAllowedValue("611");
			h.addAllowedValue("612");
			h.addAllowedValue("613");
			h.addAllowedValue("614");
			h.addAllowedValue("615");
			h.addAllowedValue("616");
			h.addAllowedValue("617");
			h.addAllowedValue("618");
			h.addAllowedValue("619");
			h.addAllowedValue("620");
			h.addAllowedValue("621");
			h.addAllowedValue("622");
			h.addAllowedValue("623");
			h.addAllowedValue("624");
			h.addAllowedValue("625");
			h.addAllowedValue("626");
			h.addAllowedValue("627");
			h.addAllowedValue("629");
			h.addAllowedValue("630");
			h.addAllowedValue("631");
			h.addAllowedValue("632");
			h.addAllowedValue("633");
			h.addAllowedValue("634");
			h.addAllowedValue("635");
			h.addAllowedValue("636");
			h.addAllowedValue("637");
			h.addAllowedValue("638");
			h.addAllowedValue("640");
			h.addAllowedValue("641");
			h.addAllowedValue("642");
			h.addAllowedValue("643");
			h.addAllowedValue("644");
			h.addAllowedValue("646");
			h.addAllowedValue("647");
			h.addAllowedValue("648");
			h.addAllowedValue("649");
			h.addAllowedValue("650");
			h.addAllowedValue("651");
			h.addAllowedValue("652");
			h.addAllowedValue("653");
			h.addAllowedValue("655");
			h.addAllowedValue("656");
			h.addAllowedValue("657");
			h.addAllowedValue("658");
			h.addAllowedValue("659");
			h.addAllowedValue("660");
			h.addAllowedValue("661");
			h.addAllowedValue("662");
			h.addAllowedValue("663");
			h.addAllowedValue("664");
			h.addAllowedValue("665");
			h.addAllowedValue("666");
			h.addAllowedValue("667");
			h.addAllowedValue("668");
			h.addAllowedValue("669");
			h.addAllowedValue("670");
			h.addAllowedValue("671");
			h.addAllowedValue("672");
			h.addAllowedValue("673");
			h.addAllowedValue("674");
			h.addAllowedValue("675");
			h.addAllowedValue("681");
			h.addAllowedValue("682");
			h.addAllowedValue("683");
			h.addAllowedValue("684");
			h.addAllowedValue("685");
			h.addAllowedValue("686");
			h.addAllowedValue("687");
			h.addAllowedValue("688");
			h.addAllowedValue("689");
			h.addAllowedValue("690");
			h.addAllowedValue("691");
			h.addAllowedValue("692");
			h.addAllowedValue("693");
			h.addAllowedValue("694");
			h.addAllowedValue("695");
			h.addAllowedValue("696");
			h.addAllowedValue("697");
			h.addAllowedValue("699");
			h.addAllowedValue("700");
			h.addAllowedValue("701");
			h.addAllowedValue("702");
			h.addAllowedValue("703");
			h.addAllowedValue("704");
			h.addAllowedValue("705");
			h.addAllowedValue("706");
			h.addAllowedValue("707");
			h.addAllowedValue("708");
			h.addAllowedValue("709");
			h.addAllowedValue("710");
			h.addAllowedValue("711");
			h.addAllowedValue("712");
			h.addAllowedValue("713");
			h.addAllowedValue("714");
			h.addAllowedValue("715");
			h.addAllowedValue("716");
			h.addAllowedValue("717");
			h.addAllowedValue("718");
			h.addAllowedValue("719");
			h.addAllowedValue("720");
			h.addAllowedValue("721");
			h.addAllowedValue("722");
			h.addAllowedValue("723");
			h.addAllowedValue("724");
			h.addAllowedValue("725");
			h.addAllowedValue("726");
			h.addAllowedValue("727");
			h.addAllowedValue("728");
			h.addAllowedValue("729");
			h.addAllowedValue("730");
			h.addAllowedValue("731");
			h.addAllowedValue("732");
			h.addAllowedValue("733");
			h.addAllowedValue("734");
			h.addAllowedValue("736");
			h.addAllowedValue("737");
			h.addAllowedValue("738");
			h.addAllowedValue("739");
			h.addAllowedValue("740");
			h.addAllowedValue("741");
			h.addAllowedValue("742");
			h.addAllowedValue("743");
			h.addAllowedValue("744");
			h.addAllowedValue("745");
			h.addAllowedValue("746");
			h.addAllowedValue("750");
			h.addAllowedValue("751");
			h.addAllowedValue("752");
			h.addAllowedValue("753");
			h.addAllowedValue("754");
			h.addAllowedValue("755");
			h.addAllowedValue("756");
			h.addAllowedValue("757");
			h.addAllowedValue("758");
			h.addAllowedValue("760");
			h.addAllowedValue("770");
			h.addAllowedValue("771");
			h.addAllowedValue("773");
			h.addAllowedValue("774");
			h.addAllowedValue("776");
			h.addAllowedValue("778");
			h.addAllowedValue("779");
			h.addAllowedValue("780");
			h.addAllowedValue("781");
			h.addAllowedValue("782");
			h.addAllowedValue("783");
			h.addAllowedValue("784");
			h.addAllowedValue("785");
			h.addAllowedValue("786");
			h.addAllowedValue("789");
			h.addAllowedValue("800");
			h.addAllowedValue("801");
			h.addAllowedValue("802");
			h.addAllowedValue("803");
			h.addAllowedValue("804");
			h.addAllowedValue("805");
			h.addAllowedValue("806");
			h.addAllowedValue("807");
			h.addAllowedValue("808");
			h.addAllowedValue("809");
			h.addAllowedValue("810");
			h.addAllowedValue("811");
			h.addAllowedValue("812");
			h.addAllowedValue("813");
			h.addAllowedValue("814");
			h.addAllowedValue("815");
			h.addAllowedValue("816");
			h.addAllowedValue("817");
			h.addAllowedValue("818");
			h.addAllowedValue("820");
			h.addAllowedValue("821");
			h.addAllowedValue("822");
			h.addAllowedValue("823");
			h.addAllowedValue("824");
			h.addAllowedValue("825");
			h.addAllowedValue("826");
			h.addAllowedValue("827");
			h.addAllowedValue("828");
			h.addAllowedValue("830");
			h.addAllowedValue("831");
			h.addAllowedValue("832");
			h.addAllowedValue("840");
			h.addAllowedValue("841");
			h.addAllowedValue("842");
			h.addAllowedValue("843");
			h.addAllowedValue("844");
			h.addAllowedValue("845");
			h.addAllowedValue("846");
			h.addAllowedValue("847");
			h.addAllowedValue("848");
			h.addAllowedValue("849");
			h.addAllowedValue("850");
			h.addAllowedValue("851");
			h.addAllowedValue("853");
			h.addAllowedValue("854");
			h.addAllowedValue("855");
			h.addAllowedValue("856");
			h.addAllowedValue("857");
			h.addAllowedValue("858");
			h.addAllowedValue("859");
			h.addAllowedValue("860");
			h.addAllowedValue("861");
			h.addAllowedValue("862");
			h.addAllowedValue("863");
			h.addAllowedValue("864");
			h.addAllowedValue("865");
			h.addAllowedValue("866");
			h.addAllowedValue("867");
			h.addAllowedValue("868");
			h.addAllowedValue("869");
			h.addAllowedValue("870");
			h.addAllowedValue("871");
			h.addAllowedValue("872");
			h.addAllowedValue("873");
			h.addAllowedValue("874");
			h.addAllowedValue("875");
			h.addAllowedValue("876");
			h.addAllowedValue("877");
			h.addAllowedValue("878");
			h.addAllowedValue("879");
			h.addAllowedValue("880");
			h.addAllowedValue("881");
			h.addAllowedValue("882");
			h.addAllowedValue("883");
			h.addAllowedValue("884");
			h.addAllowedValue("885");
			h.addAllowedValue("900");
			h.addAllowedValue("901");
			h.addAllowedValue("903");
			h.addAllowedValue("904");
			h.addAllowedValue("905");
			h.addAllowedValue("906");
			h.addAllowedValue("907");
			h.addAllowedValue("908");
			h.addAllowedValue("909");
			h.addAllowedValue("910");
			h.addAllowedValue("911");
			h.addAllowedValue("912");
			h.addAllowedValue("913");
			h.addAllowedValue("914");
			h.addAllowedValue("915");
			h.addAllowedValue("916");
			h.addAllowedValue("917");
			h.addAllowedValue("918");
			h.addAllowedValue("919");
			h.addAllowedValue("920");
			h.addAllowedValue("921");
			h.addAllowedValue("922");
			h.addAllowedValue("923");
			h.addAllowedValue("924");
			h.addAllowedValue("925");
			h.addAllowedValue("926");
			h.addAllowedValue("927");
			h.addAllowedValue("928");
			h.addAllowedValue("929");
			h.addAllowedValue("930");
			h.addAllowedValue("931");
			h.addAllowedValue("932");
			h.addAllowedValue("933");
			h.addAllowedValue("934");
			h.addAllowedValue("935");
			h.addAllowedValue("936");
			h.addAllowedValue("937");
			h.addAllowedValue("938");
			h.addAllowedValue("939");
			h.addAllowedValue("940");
			h.addAllowedValue("941");
			h.addAllowedValue("942");
			h.addAllowedValue("943");
			h.addAllowedValue("944");
			h.addAllowedValue("945");
			h.addAllowedValue("946");
			h.addAllowedValue("947");
			h.addAllowedValue("948");
			h.addAllowedValue("949");
			h.addAllowedValue("950");
			h.addAllowedValue("951");
			h.addAllowedValue("952");
			h.addAllowedValue("953");
			h.addAllowedValue("954");
			h.addAllowedValue("955");
			h.addAllowedValue("956");
			h.addAllowedValue("957");
			h.addAllowedValue("960");
			h.addAllowedValue("961");
			h.addAllowedValue("962");
			h.addAllowedValue("963");
			h.addAllowedValue("964");
			h.addAllowedValue("965");
			h.addAllowedValue("966");
			h.addAllowedValue("967");
			h.addAllowedValue("968");
			h.addAllowedValue("969");
			h.addAllowedValue("970");
			h.addAllowedValue("971");
			h.addAllowedValue("972");
			h.addAllowedValue("973");
			h.addAllowedValue("974");
			h.addAllowedValue("975");
			h.addAllowedValue("976");
			h.addAllowedValue("977");
			h.addAllowedValue("978");
			h.addAllowedValue("979");
			h.addAllowedValue("980");
			h.addAllowedValue("981");
			h.addAllowedValue("982");
			h.addAllowedValue("983");
			h.addAllowedValue("984");
			h.addAllowedValue("985");
			h.addAllowedValue("986");
			h.addAllowedValue("987");
			h.addAllowedValue("988");
			h.addAllowedValue("989");
			h.addAllowedValue("992");
			h.addAllowedValue("993");
			h.addAllowedValue("994");
			h.addAllowedValue("995");
			h.addAllowedValue("996");
			h.addAllowedValue("997");
			h.addAllowedValue("998");
			h.addAllowedValue("999");
			simpleElement374 = new RtSimpleElement("374", "ID", h);
		}
	
		return simpleElement374;
	}
	
	private RtSimpleElement simpleElement337;
	
	private RtSimpleElement simpleElement337() {
		if (simpleElement337 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Time";
			h.minLength = 4;
			h.maxLength = 8;
			
			simpleElement337 = new RtSimpleElement("337", "TM", h);
		}
	
		return simpleElement337;
	}
	
	private RtSimpleElement simpleElement128;
	
	private RtSimpleElement simpleElement128() {
		if (simpleElement128 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Reference Identification Qualifier";
			h.minLength = 2;
			h.maxLength = 3;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AAA");
			h.addAllowedValue("AAB");
			h.addAllowedValue("AAC");
			h.addAllowedValue("AAD");
			h.addAllowedValue("AAE");
			h.addAllowedValue("AAF");
			h.addAllowedValue("AAG");
			h.addAllowedValue("AAH");
			h.addAllowedValue("AAI");
			h.addAllowedValue("AAJ");
			h.addAllowedValue("AAK");
			h.addAllowedValue("AAL");
			h.addAllowedValue("AAM");
			h.addAllowedValue("AAN");
			h.addAllowedValue("AAO");
			h.addAllowedValue("AAP");
			h.addAllowedValue("AAQ");
			h.addAllowedValue("AAR");
			h.addAllowedValue("AAS");
			h.addAllowedValue("AAT");
			h.addAllowedValue("AAU");
			h.addAllowedValue("AAV");
			h.addAllowedValue("AAW");
			h.addAllowedValue("AAX");
			h.addAllowedValue("AAY");
			h.addAllowedValue("AAZ");
			h.addAllowedValue("AB");
			h.addAllowedValue("ABA");
			h.addAllowedValue("ABB");
			h.addAllowedValue("ABC");
			h.addAllowedValue("ABD");
			h.addAllowedValue("ABE");
			h.addAllowedValue("ABF");
			h.addAllowedValue("ABG");
			h.addAllowedValue("ABH");
			h.addAllowedValue("ABJ");
			h.addAllowedValue("ABK");
			h.addAllowedValue("ABL");
			h.addAllowedValue("ABM");
			h.addAllowedValue("ABN");
			h.addAllowedValue("ABO");
			h.addAllowedValue("ABP");
			h.addAllowedValue("ABQ");
			h.addAllowedValue("ABR");
			h.addAllowedValue("ABS");
			h.addAllowedValue("ABT");
			h.addAllowedValue("ABU");
			h.addAllowedValue("ABV");
			h.addAllowedValue("ABY");
			h.addAllowedValue("AC");
			h.addAllowedValue("ACA");
			h.addAllowedValue("ACB");
			h.addAllowedValue("ACC");
			h.addAllowedValue("ACD");
			h.addAllowedValue("ACE");
			h.addAllowedValue("ACF");
			h.addAllowedValue("ACG");
			h.addAllowedValue("ACH");
			h.addAllowedValue("ACI");
			h.addAllowedValue("ACJ");
			h.addAllowedValue("ACK");
			h.addAllowedValue("ACR");
			h.addAllowedValue("ACS");
			h.addAllowedValue("ACT");
			h.addAllowedValue("AD");
			h.addAllowedValue("ADA");
			h.addAllowedValue("ADB");
			h.addAllowedValue("ADC");
			h.addAllowedValue("ADD");
			h.addAllowedValue("ADE");
			h.addAllowedValue("ADF");
			h.addAllowedValue("ADG");
			h.addAllowedValue("ADH");
			h.addAllowedValue("ADI");
			h.addAllowedValue("ADM");
			h.addAllowedValue("AE");
			h.addAllowedValue("AEA");
			h.addAllowedValue("AEB");
			h.addAllowedValue("AEC");
			h.addAllowedValue("AED");
			h.addAllowedValue("AEE");
			h.addAllowedValue("AEF");
			h.addAllowedValue("AEG");
			h.addAllowedValue("AEH");
			h.addAllowedValue("AEI");
			h.addAllowedValue("AEJ");
			h.addAllowedValue("AEK");
			h.addAllowedValue("AEL");
			h.addAllowedValue("AEM");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AHC");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("ALC");
			h.addAllowedValue("ALG");
			h.addAllowedValue("ALH");
			h.addAllowedValue("ALI");
			h.addAllowedValue("ALJ");
			h.addAllowedValue("ALT");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("API");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("ASL");
			h.addAllowedValue("ASP");
			h.addAllowedValue("AST");
			h.addAllowedValue("AT");
			h.addAllowedValue("ATC");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A0");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A8");
			h.addAllowedValue("A9");
			h.addAllowedValue("BA");
			h.addAllowedValue("BAA");
			h.addAllowedValue("BAB");
			h.addAllowedValue("BAC");
			h.addAllowedValue("BAD");
			h.addAllowedValue("BAE");
			h.addAllowedValue("BAF");
			h.addAllowedValue("BAG");
			h.addAllowedValue("BAH");
			h.addAllowedValue("BAI");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BCI");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BKT");
			h.addAllowedValue("BL");
			h.addAllowedValue("BLT");
			h.addAllowedValue("BM");
			h.addAllowedValue("BMM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BOI");
			h.addAllowedValue("BP");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("BU");
			h.addAllowedValue("BV");
			h.addAllowedValue("BW");
			h.addAllowedValue("BX");
			h.addAllowedValue("BY");
			h.addAllowedValue("BZ");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("B6");
			h.addAllowedValue("B7");
			h.addAllowedValue("B8");
			h.addAllowedValue("B9");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CBG");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CDN");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CIR");
			h.addAllowedValue("CIT");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CMN");
			h.addAllowedValue("CMP");
			h.addAllowedValue("CMT");
			h.addAllowedValue("CN");
			h.addAllowedValue("CNO");
			h.addAllowedValue("CO");
			h.addAllowedValue("COL");
			h.addAllowedValue("COT");
			h.addAllowedValue("CP");
			h.addAllowedValue("CPA");
			h.addAllowedValue("CPT");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CRN");
			h.addAllowedValue("CRS");
			h.addAllowedValue("CS");
			h.addAllowedValue("CSC");
			h.addAllowedValue("CSG");
			h.addAllowedValue("CST");
			h.addAllowedValue("CT");
			h.addAllowedValue("CTS");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CYC");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C0");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("C7");
			h.addAllowedValue("C8");
			h.addAllowedValue("C9");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DHH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DIS");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DNR");
			h.addAllowedValue("DNS");
			h.addAllowedValue("DO");
			h.addAllowedValue("DOA");
			h.addAllowedValue("DOC");
			h.addAllowedValue("DOE");
			h.addAllowedValue("DOI");
			h.addAllowedValue("DOJ");
			h.addAllowedValue("DOL");
			h.addAllowedValue("DON");
			h.addAllowedValue("DOS");
			h.addAllowedValue("DOT");
			h.addAllowedValue("DP");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DRN");
			h.addAllowedValue("DS");
			h.addAllowedValue("DSC");
			h.addAllowedValue("DSI");
			h.addAllowedValue("DST");
			h.addAllowedValue("DT");
			h.addAllowedValue("DTS");
			h.addAllowedValue("DU");
			h.addAllowedValue("DUN");
			h.addAllowedValue("DV");
			h.addAllowedValue("DW");
			h.addAllowedValue("DX");
			h.addAllowedValue("DY");
			h.addAllowedValue("DZ");
			h.addAllowedValue("D0");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("D6");
			h.addAllowedValue("D7");
			h.addAllowedValue("D8");
			h.addAllowedValue("D9");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EDA");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EH");
			h.addAllowedValue("EI");
			h.addAllowedValue("EJ");
			h.addAllowedValue("EK");
			h.addAllowedValue("EL");
			h.addAllowedValue("EM");
			h.addAllowedValue("EMM");
			h.addAllowedValue("EN");
			h.addAllowedValue("END");
			h.addAllowedValue("EO");
			h.addAllowedValue("EP");
			h.addAllowedValue("EPA");
			h.addAllowedValue("EPB");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("ESN");
			h.addAllowedValue("ET");
			h.addAllowedValue("EU");
			h.addAllowedValue("EV");
			h.addAllowedValue("EW");
			h.addAllowedValue("EX");
			h.addAllowedValue("EY");
			h.addAllowedValue("EZ");
			h.addAllowedValue("E1");
			h.addAllowedValue("E2");
			h.addAllowedValue("E3");
			h.addAllowedValue("E4");
			h.addAllowedValue("E5");
			h.addAllowedValue("E6");
			h.addAllowedValue("E7");
			h.addAllowedValue("E8");
			h.addAllowedValue("E9");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FCN");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FK");
			h.addAllowedValue("FL");
			h.addAllowedValue("FLZ");
			h.addAllowedValue("FM");
			h.addAllowedValue("FMP");
			h.addAllowedValue("FN");
			h.addAllowedValue("FND");
			h.addAllowedValue("FO");
			h.addAllowedValue("FP");
			h.addAllowedValue("FQ");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FSN");
			h.addAllowedValue("FT");
			h.addAllowedValue("FTN");
			h.addAllowedValue("FU");
			h.addAllowedValue("FV");
			h.addAllowedValue("FW");
			h.addAllowedValue("FWC");
			h.addAllowedValue("FX");
			h.addAllowedValue("FY");
			h.addAllowedValue("FZ");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("F5");
			h.addAllowedValue("F6");
			h.addAllowedValue("F7");
			h.addAllowedValue("F8");
			h.addAllowedValue("F9");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GD");
			h.addAllowedValue("GE");
			h.addAllowedValue("GF");
			h.addAllowedValue("GG");
			h.addAllowedValue("GH");
			h.addAllowedValue("GI");
			h.addAllowedValue("GJ");
			h.addAllowedValue("GK");
			h.addAllowedValue("GL");
			h.addAllowedValue("GM");
			h.addAllowedValue("GN");
			h.addAllowedValue("GO");
			h.addAllowedValue("GP");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("GT");
			h.addAllowedValue("GU");
			h.addAllowedValue("GV");
			h.addAllowedValue("GW");
			h.addAllowedValue("GWS");
			h.addAllowedValue("GX");
			h.addAllowedValue("GY");
			h.addAllowedValue("GZ");
			h.addAllowedValue("G1");
			h.addAllowedValue("G2");
			h.addAllowedValue("G3");
			h.addAllowedValue("G4");
			h.addAllowedValue("G5");
			h.addAllowedValue("G6");
			h.addAllowedValue("G7");
			h.addAllowedValue("G8");
			h.addAllowedValue("G9");
			h.addAllowedValue("HA");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HD");
			h.addAllowedValue("HE");
			h.addAllowedValue("HF");
			h.addAllowedValue("HG");
			h.addAllowedValue("HH");
			h.addAllowedValue("HHT");
			h.addAllowedValue("HI");
			h.addAllowedValue("HJ");
			h.addAllowedValue("HK");
			h.addAllowedValue("HL");
			h.addAllowedValue("HM");
			h.addAllowedValue("HMB");
			h.addAllowedValue("HN");
			h.addAllowedValue("HO");
			h.addAllowedValue("HP");
			h.addAllowedValue("HPI");
			h.addAllowedValue("HQ");
			h.addAllowedValue("HR");
			h.addAllowedValue("HS");
			h.addAllowedValue("HT");
			h.addAllowedValue("HU");
			h.addAllowedValue("HUD");
			h.addAllowedValue("HV");
			h.addAllowedValue("HW");
			h.addAllowedValue("HX");
			h.addAllowedValue("HY");
			h.addAllowedValue("HZ");
			h.addAllowedValue("H1");
			h.addAllowedValue("H2");
			h.addAllowedValue("H3");
			h.addAllowedValue("H4");
			h.addAllowedValue("H5");
			h.addAllowedValue("H6");
			h.addAllowedValue("H7");
			h.addAllowedValue("H8");
			h.addAllowedValue("H9");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ICD");
			h.addAllowedValue("ID");
			h.addAllowedValue("IE");
			h.addAllowedValue("IF");
			h.addAllowedValue("IFT");
			h.addAllowedValue("IG");
			h.addAllowedValue("IH");
			h.addAllowedValue("II");
			h.addAllowedValue("IID");
			h.addAllowedValue("IJ");
			h.addAllowedValue("IK");
			h.addAllowedValue("IL");
			h.addAllowedValue("IM");
			h.addAllowedValue("IMP");
			h.addAllowedValue("IMS");
			h.addAllowedValue("IN");
			h.addAllowedValue("IND");
			h.addAllowedValue("IO");
			h.addAllowedValue("IP");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IR");
			h.addAllowedValue("IRN");
			h.addAllowedValue("IRP");
			h.addAllowedValue("IS");
			h.addAllowedValue("ISC");
			h.addAllowedValue("ISN");
			h.addAllowedValue("ISS");
			h.addAllowedValue("IT");
			h.addAllowedValue("IU");
			h.addAllowedValue("IV");
			h.addAllowedValue("IW");
			h.addAllowedValue("IX");
			h.addAllowedValue("IZ");
			h.addAllowedValue("I1");
			h.addAllowedValue("I2");
			h.addAllowedValue("I3");
			h.addAllowedValue("I4");
			h.addAllowedValue("I5");
			h.addAllowedValue("I7");
			h.addAllowedValue("I8");
			h.addAllowedValue("I9");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JC");
			h.addAllowedValue("JD");
			h.addAllowedValue("JE");
			h.addAllowedValue("JF");
			h.addAllowedValue("JH");
			h.addAllowedValue("JI");
			h.addAllowedValue("JK");
			h.addAllowedValue("JL");
			h.addAllowedValue("JM");
			h.addAllowedValue("JN");
			h.addAllowedValue("JO");
			h.addAllowedValue("JP");
			h.addAllowedValue("JQ");
			h.addAllowedValue("JR");
			h.addAllowedValue("JS");
			h.addAllowedValue("JT");
			h.addAllowedValue("JU");
			h.addAllowedValue("JV");
			h.addAllowedValue("JW");
			h.addAllowedValue("JX");
			h.addAllowedValue("JY");
			h.addAllowedValue("JZ");
			h.addAllowedValue("J0");
			h.addAllowedValue("J1");
			h.addAllowedValue("J2");
			h.addAllowedValue("J3");
			h.addAllowedValue("J4");
			h.addAllowedValue("J5");
			h.addAllowedValue("J6");
			h.addAllowedValue("J7");
			h.addAllowedValue("J8");
			h.addAllowedValue("J9");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KN");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KR");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("KU");
			h.addAllowedValue("KV");
			h.addAllowedValue("KW");
			h.addAllowedValue("KX");
			h.addAllowedValue("KY");
			h.addAllowedValue("KZ");
			h.addAllowedValue("K0");
			h.addAllowedValue("K1");
			h.addAllowedValue("K2");
			h.addAllowedValue("K3");
			h.addAllowedValue("K4");
			h.addAllowedValue("K5");
			h.addAllowedValue("K6");
			h.addAllowedValue("K7");
			h.addAllowedValue("K8");
			h.addAllowedValue("K9");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LEN");
			h.addAllowedValue("LF");
			h.addAllowedValue("LG");
			h.addAllowedValue("LH");
			h.addAllowedValue("LI");
			h.addAllowedValue("LIC");
			h.addAllowedValue("LJ");
			h.addAllowedValue("LK");
			h.addAllowedValue("LL");
			h.addAllowedValue("LM");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LOI");
			h.addAllowedValue("LP");
			h.addAllowedValue("LQ");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LSD");
			h.addAllowedValue("LT");
			h.addAllowedValue("LU");
			h.addAllowedValue("LV");
			h.addAllowedValue("LVO");
			h.addAllowedValue("LW");
			h.addAllowedValue("LX");
			h.addAllowedValue("LY");
			h.addAllowedValue("LZ");
			h.addAllowedValue("L1");
			h.addAllowedValue("L2");
			h.addAllowedValue("L3");
			h.addAllowedValue("L4");
			h.addAllowedValue("L5");
			h.addAllowedValue("L6");
			h.addAllowedValue("L7");
			h.addAllowedValue("L8");
			h.addAllowedValue("L9");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MBX");
			h.addAllowedValue("MC");
			h.addAllowedValue("MCI");
			h.addAllowedValue("MD");
			h.addAllowedValue("MDN");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MP");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MSL");
			h.addAllowedValue("MT");
			h.addAllowedValue("MU");
			h.addAllowedValue("MV");
			h.addAllowedValue("MW");
			h.addAllowedValue("MX");
			h.addAllowedValue("MY");
			h.addAllowedValue("MZ");
			h.addAllowedValue("MZO");
			h.addAllowedValue("M1");
			h.addAllowedValue("M2");
			h.addAllowedValue("M3");
			h.addAllowedValue("M5");
			h.addAllowedValue("M6");
			h.addAllowedValue("M7");
			h.addAllowedValue("M8");
			h.addAllowedValue("M9");
			h.addAllowedValue("NA");
			h.addAllowedValue("NAS");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NDA");
			h.addAllowedValue("NDB");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NFC");
			h.addAllowedValue("NFD");
			h.addAllowedValue("NFM");
			h.addAllowedValue("NFN");
			h.addAllowedValue("NFS");
			h.addAllowedValue("NG");
			h.addAllowedValue("NH");
			h.addAllowedValue("NI");
			h.addAllowedValue("NJ");
			h.addAllowedValue("NK");
			h.addAllowedValue("NL");
			h.addAllowedValue("NM");
			h.addAllowedValue("NN");
			h.addAllowedValue("NO");
			h.addAllowedValue("NP");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("NU");
			h.addAllowedValue("NW");
			h.addAllowedValue("NX");
			h.addAllowedValue("NY");
			h.addAllowedValue("NZ");
			h.addAllowedValue("N0");
			h.addAllowedValue("N1");
			h.addAllowedValue("N2");
			h.addAllowedValue("N3");
			h.addAllowedValue("N4");
			h.addAllowedValue("N5");
			h.addAllowedValue("N6");
			h.addAllowedValue("N7");
			h.addAllowedValue("N8");
			h.addAllowedValue("N9");
			h.addAllowedValue("OA");
			h.addAllowedValue("OB");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("OE");
			h.addAllowedValue("OF");
			h.addAllowedValue("OG");
			h.addAllowedValue("OH");
			h.addAllowedValue("OI");
			h.addAllowedValue("OJ");
			h.addAllowedValue("OK");
			h.addAllowedValue("OL");
			h.addAllowedValue("OM");
			h.addAllowedValue("ON");
			h.addAllowedValue("OP");
			h.addAllowedValue("OQ");
			h.addAllowedValue("OR");
			h.addAllowedValue("OS");
			h.addAllowedValue("OT");
			h.addAllowedValue("OU");
			h.addAllowedValue("OV");
			h.addAllowedValue("OW");
			h.addAllowedValue("OX");
			h.addAllowedValue("OZ");
			h.addAllowedValue("O1");
			h.addAllowedValue("O2");
			h.addAllowedValue("O5");
			h.addAllowedValue("O7");
			h.addAllowedValue("O8");
			h.addAllowedValue("O9");
			h.addAllowedValue("PA");
			h.addAllowedValue("PAC");
			h.addAllowedValue("PAN");
			h.addAllowedValue("PAP");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PCC");
			h.addAllowedValue("PCN");
			h.addAllowedValue("PD");
			h.addAllowedValue("PDL");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PGC");
			h.addAllowedValue("PGN");
			h.addAllowedValue("PGS");
			h.addAllowedValue("PH");
			h.addAllowedValue("PHC");
			h.addAllowedValue("PI");
			h.addAllowedValue("PID");
			h.addAllowedValue("PIN");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PLA");
			h.addAllowedValue("PLN");
			h.addAllowedValue("PM");
			h.addAllowedValue("PMN");
			h.addAllowedValue("PN");
			h.addAllowedValue("PNN");
			h.addAllowedValue("PO");
			h.addAllowedValue("POL");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PRS");
			h.addAllowedValue("PRT");
			h.addAllowedValue("PS");
			h.addAllowedValue("PSI");
			h.addAllowedValue("PSL");
			h.addAllowedValue("PSM");
			h.addAllowedValue("PSN");
			h.addAllowedValue("PT");
			h.addAllowedValue("PTC");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PWC");
			h.addAllowedValue("PWS");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P1");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P6");
			h.addAllowedValue("P7");
			h.addAllowedValue("P8");
			h.addAllowedValue("P9");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QF");
			h.addAllowedValue("QG");
			h.addAllowedValue("QH");
			h.addAllowedValue("QI");
			h.addAllowedValue("QJ");
			h.addAllowedValue("QK");
			h.addAllowedValue("QL");
			h.addAllowedValue("QM");
			h.addAllowedValue("QN");
			h.addAllowedValue("QO");
			h.addAllowedValue("QP");
			h.addAllowedValue("QQ");
			h.addAllowedValue("QR");
			h.addAllowedValue("QS");
			h.addAllowedValue("QT");
			h.addAllowedValue("QU");
			h.addAllowedValue("QV");
			h.addAllowedValue("QW");
			h.addAllowedValue("QX");
			h.addAllowedValue("QY");
			h.addAllowedValue("QZ");
			h.addAllowedValue("Q1");
			h.addAllowedValue("Q2");
			h.addAllowedValue("Q3");
			h.addAllowedValue("Q4");
			h.addAllowedValue("Q5");
			h.addAllowedValue("Q6");
			h.addAllowedValue("Q7");
			h.addAllowedValue("Q8");
			h.addAllowedValue("Q9");
			h.addAllowedValue("RA");
			h.addAllowedValue("RAA");
			h.addAllowedValue("RAN");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("REC");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RGI");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RIG");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RPP");
			h.addAllowedValue("RPT");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RRS");
			h.addAllowedValue("RS");
			h.addAllowedValue("RSN");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RV");
			h.addAllowedValue("RW");
			h.addAllowedValue("RX");
			h.addAllowedValue("RY");
			h.addAllowedValue("RZ");
			h.addAllowedValue("R0");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("R9");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SBN");
			h.addAllowedValue("SC");
			h.addAllowedValue("SCA");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SEK");
			h.addAllowedValue("SES");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SHL");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SNH");
			h.addAllowedValue("SNV");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SPL");
			h.addAllowedValue("SPN");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("STB");
			h.addAllowedValue("STR");
			h.addAllowedValue("SU");
			h.addAllowedValue("SUB");
			h.addAllowedValue("SUO");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SY");
			h.addAllowedValue("SZ");
			h.addAllowedValue("S0");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TDT");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TIP");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TOC");
			h.addAllowedValue("TP");
			h.addAllowedValue("TPN");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TSN");
			h.addAllowedValue("TT");
			h.addAllowedValue("TU");
			h.addAllowedValue("TV");
			h.addAllowedValue("TW");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("TZ");
			h.addAllowedValue("T0");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("T4");
			h.addAllowedValue("T5");
			h.addAllowedValue("T6");
			h.addAllowedValue("T7");
			h.addAllowedValue("T8");
			h.addAllowedValue("T9");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("UF");
			h.addAllowedValue("UG");
			h.addAllowedValue("UH");
			h.addAllowedValue("UI");
			h.addAllowedValue("UJ");
			h.addAllowedValue("UK");
			h.addAllowedValue("UL");
			h.addAllowedValue("UM");
			h.addAllowedValue("UN");
			h.addAllowedValue("UO");
			h.addAllowedValue("UP");
			h.addAllowedValue("UQ");
			h.addAllowedValue("UR");
			h.addAllowedValue("URL");
			h.addAllowedValue("US");
			h.addAllowedValue("UT");
			h.addAllowedValue("UU");
			h.addAllowedValue("UV");
			h.addAllowedValue("UW");
			h.addAllowedValue("UX");
			h.addAllowedValue("UY");
			h.addAllowedValue("UZ");
			h.addAllowedValue("U0");
			h.addAllowedValue("U1");
			h.addAllowedValue("U2");
			h.addAllowedValue("U3");
			h.addAllowedValue("U4");
			h.addAllowedValue("U5");
			h.addAllowedValue("U6");
			h.addAllowedValue("U8");
			h.addAllowedValue("U9");
			h.addAllowedValue("VA");
			h.addAllowedValue("VB");
			h.addAllowedValue("VC");
			h.addAllowedValue("VD");
			h.addAllowedValue("VE");
			h.addAllowedValue("VF");
			h.addAllowedValue("VG");
			h.addAllowedValue("VH");
			h.addAllowedValue("VI");
			h.addAllowedValue("VJ");
			h.addAllowedValue("VK");
			h.addAllowedValue("VL");
			h.addAllowedValue("VM");
			h.addAllowedValue("VN");
			h.addAllowedValue("VO");
			h.addAllowedValue("VP");
			h.addAllowedValue("VQ");
			h.addAllowedValue("VR");
			h.addAllowedValue("VS");
			h.addAllowedValue("VT");
			h.addAllowedValue("VU");
			h.addAllowedValue("VV");
			h.addAllowedValue("VW");
			h.addAllowedValue("VX");
			h.addAllowedValue("VY");
			h.addAllowedValue("VZ");
			h.addAllowedValue("V0");
			h.addAllowedValue("V1");
			h.addAllowedValue("V2");
			h.addAllowedValue("V3");
			h.addAllowedValue("V4");
			h.addAllowedValue("V5");
			h.addAllowedValue("V6");
			h.addAllowedValue("V7");
			h.addAllowedValue("V8");
			h.addAllowedValue("V9");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WC");
			h.addAllowedValue("WCS");
			h.addAllowedValue("WD");
			h.addAllowedValue("WDR");
			h.addAllowedValue("WE");
			h.addAllowedValue("WF");
			h.addAllowedValue("WG");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WJ");
			h.addAllowedValue("WK");
			h.addAllowedValue("WL");
			h.addAllowedValue("WM");
			h.addAllowedValue("WN");
			h.addAllowedValue("WO");
			h.addAllowedValue("WP");
			h.addAllowedValue("WQ");
			h.addAllowedValue("WR");
			h.addAllowedValue("WS");
			h.addAllowedValue("WT");
			h.addAllowedValue("WU");
			h.addAllowedValue("WV");
			h.addAllowedValue("WW");
			h.addAllowedValue("WX");
			h.addAllowedValue("WY");
			h.addAllowedValue("WZ");
			h.addAllowedValue("W1");
			h.addAllowedValue("W2");
			h.addAllowedValue("W3");
			h.addAllowedValue("W4");
			h.addAllowedValue("W5");
			h.addAllowedValue("W6");
			h.addAllowedValue("W7");
			h.addAllowedValue("W8");
			h.addAllowedValue("W9");
			h.addAllowedValue("XA");
			h.addAllowedValue("XB");
			h.addAllowedValue("XC");
			h.addAllowedValue("XD");
			h.addAllowedValue("XE");
			h.addAllowedValue("XF");
			h.addAllowedValue("XG");
			h.addAllowedValue("XH");
			h.addAllowedValue("XI");
			h.addAllowedValue("XJ");
			h.addAllowedValue("XK");
			h.addAllowedValue("XL");
			h.addAllowedValue("XM");
			h.addAllowedValue("XN");
			h.addAllowedValue("XO");
			h.addAllowedValue("XP");
			h.addAllowedValue("XQ");
			h.addAllowedValue("XR");
			h.addAllowedValue("XS");
			h.addAllowedValue("XT");
			h.addAllowedValue("XU");
			h.addAllowedValue("XV");
			h.addAllowedValue("XW");
			h.addAllowedValue("XX");
			h.addAllowedValue("XY");
			h.addAllowedValue("XZ");
			h.addAllowedValue("X0");
			h.addAllowedValue("X1");
			h.addAllowedValue("X2");
			h.addAllowedValue("X3");
			h.addAllowedValue("X4");
			h.addAllowedValue("X5");
			h.addAllowedValue("X6");
			h.addAllowedValue("X7");
			h.addAllowedValue("X8");
			h.addAllowedValue("X9");
			h.addAllowedValue("YA");
			h.addAllowedValue("YB");
			h.addAllowedValue("YC");
			h.addAllowedValue("YD");
			h.addAllowedValue("YE");
			h.addAllowedValue("YF");
			h.addAllowedValue("YH");
			h.addAllowedValue("YI");
			h.addAllowedValue("YJ");
			h.addAllowedValue("YK");
			h.addAllowedValue("YL");
			h.addAllowedValue("YM");
			h.addAllowedValue("YN");
			h.addAllowedValue("YO");
			h.addAllowedValue("YP");
			h.addAllowedValue("YQ");
			h.addAllowedValue("YR");
			h.addAllowedValue("YS");
			h.addAllowedValue("YT");
			h.addAllowedValue("YV");
			h.addAllowedValue("YW");
			h.addAllowedValue("YX");
			h.addAllowedValue("YY");
			h.addAllowedValue("YZ");
			h.addAllowedValue("Y0");
			h.addAllowedValue("Y1");
			h.addAllowedValue("Y2");
			h.addAllowedValue("Y3");
			h.addAllowedValue("Y4");
			h.addAllowedValue("Y5");
			h.addAllowedValue("Y6");
			h.addAllowedValue("Y7");
			h.addAllowedValue("Y8");
			h.addAllowedValue("Y9");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZD");
			h.addAllowedValue("ZE");
			h.addAllowedValue("ZF");
			h.addAllowedValue("ZG");
			h.addAllowedValue("ZH");
			h.addAllowedValue("ZI");
			h.addAllowedValue("ZJ");
			h.addAllowedValue("ZK");
			h.addAllowedValue("ZL");
			h.addAllowedValue("ZM");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZO");
			h.addAllowedValue("ZP");
			h.addAllowedValue("ZQ");
			h.addAllowedValue("ZR");
			h.addAllowedValue("ZS");
			h.addAllowedValue("ZT");
			h.addAllowedValue("ZU");
			h.addAllowedValue("ZV");
			h.addAllowedValue("ZW");
			h.addAllowedValue("ZX");
			h.addAllowedValue("ZY");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("Z1");
			h.addAllowedValue("Z2");
			h.addAllowedValue("Z3");
			h.addAllowedValue("Z4");
			h.addAllowedValue("Z5");
			h.addAllowedValue("Z6");
			h.addAllowedValue("Z7");
			h.addAllowedValue("Z8");
			h.addAllowedValue("Z9");
			h.addAllowedValue("0A");
			h.addAllowedValue("0B");
			h.addAllowedValue("0D");
			h.addAllowedValue("0E");
			h.addAllowedValue("0F");
			h.addAllowedValue("0G");
			h.addAllowedValue("0H");
			h.addAllowedValue("0I");
			h.addAllowedValue("0J");
			h.addAllowedValue("0K");
			h.addAllowedValue("0L");
			h.addAllowedValue("0M");
			h.addAllowedValue("0N");
			h.addAllowedValue("0P");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("1A");
			h.addAllowedValue("1B");
			h.addAllowedValue("1C");
			h.addAllowedValue("1D");
			h.addAllowedValue("1E");
			h.addAllowedValue("1F");
			h.addAllowedValue("1G");
			h.addAllowedValue("1H");
			h.addAllowedValue("1I");
			h.addAllowedValue("1J");
			h.addAllowedValue("1K");
			h.addAllowedValue("1L");
			h.addAllowedValue("1M");
			h.addAllowedValue("1N");
			h.addAllowedValue("1O");
			h.addAllowedValue("1P");
			h.addAllowedValue("1Q");
			h.addAllowedValue("1R");
			h.addAllowedValue("1S");
			h.addAllowedValue("1T");
			h.addAllowedValue("1U");
			h.addAllowedValue("1V");
			h.addAllowedValue("1W");
			h.addAllowedValue("1X");
			h.addAllowedValue("1Y");
			h.addAllowedValue("1Z");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2A");
			h.addAllowedValue("2B");
			h.addAllowedValue("2C");
			h.addAllowedValue("2D");
			h.addAllowedValue("2E");
			h.addAllowedValue("2F");
			h.addAllowedValue("2G");
			h.addAllowedValue("2H");
			h.addAllowedValue("2I");
			h.addAllowedValue("2J");
			h.addAllowedValue("2K");
			h.addAllowedValue("2L");
			h.addAllowedValue("2M");
			h.addAllowedValue("2N");
			h.addAllowedValue("2O");
			h.addAllowedValue("2P");
			h.addAllowedValue("2Q");
			h.addAllowedValue("2R");
			h.addAllowedValue("2S");
			h.addAllowedValue("2T");
			h.addAllowedValue("2U");
			h.addAllowedValue("2V");
			h.addAllowedValue("2W");
			h.addAllowedValue("2X");
			h.addAllowedValue("2Y");
			h.addAllowedValue("2Z");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3A");
			h.addAllowedValue("3B");
			h.addAllowedValue("3C");
			h.addAllowedValue("3D");
			h.addAllowedValue("3E");
			h.addAllowedValue("3F");
			h.addAllowedValue("3G");
			h.addAllowedValue("3H");
			h.addAllowedValue("3I");
			h.addAllowedValue("3J");
			h.addAllowedValue("3K");
			h.addAllowedValue("3L");
			h.addAllowedValue("3M");
			h.addAllowedValue("3N");
			h.addAllowedValue("3O");
			h.addAllowedValue("3P");
			h.addAllowedValue("3Q");
			h.addAllowedValue("3R");
			h.addAllowedValue("3S");
			h.addAllowedValue("3T");
			h.addAllowedValue("3U");
			h.addAllowedValue("3V");
			h.addAllowedValue("3W");
			h.addAllowedValue("3X");
			h.addAllowedValue("3Y");
			h.addAllowedValue("3Z");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4A");
			h.addAllowedValue("4B");
			h.addAllowedValue("4C");
			h.addAllowedValue("4D");
			h.addAllowedValue("4E");
			h.addAllowedValue("4F");
			h.addAllowedValue("4G");
			h.addAllowedValue("4H");
			h.addAllowedValue("4I");
			h.addAllowedValue("4J");
			h.addAllowedValue("4K");
			h.addAllowedValue("4L");
			h.addAllowedValue("4M");
			h.addAllowedValue("4N");
			h.addAllowedValue("4O");
			h.addAllowedValue("4P");
			h.addAllowedValue("4Q");
			h.addAllowedValue("4R");
			h.addAllowedValue("4S");
			h.addAllowedValue("4T");
			h.addAllowedValue("4U");
			h.addAllowedValue("4V");
			h.addAllowedValue("4W");
			h.addAllowedValue("4X");
			h.addAllowedValue("4Y");
			h.addAllowedValue("4Z");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5A");
			h.addAllowedValue("5B");
			h.addAllowedValue("5C");
			h.addAllowedValue("5D");
			h.addAllowedValue("5E");
			h.addAllowedValue("5F");
			h.addAllowedValue("5G");
			h.addAllowedValue("5H");
			h.addAllowedValue("5I");
			h.addAllowedValue("5J");
			h.addAllowedValue("5K");
			h.addAllowedValue("5L");
			h.addAllowedValue("5M");
			h.addAllowedValue("5N");
			h.addAllowedValue("5O");
			h.addAllowedValue("5P");
			h.addAllowedValue("5Q");
			h.addAllowedValue("5R");
			h.addAllowedValue("5S");
			h.addAllowedValue("5T");
			h.addAllowedValue("5U");
			h.addAllowedValue("5V");
			h.addAllowedValue("5W");
			h.addAllowedValue("5X");
			h.addAllowedValue("5Y");
			h.addAllowedValue("5Z");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("6A");
			h.addAllowedValue("6B");
			h.addAllowedValue("6C");
			h.addAllowedValue("6D");
			h.addAllowedValue("6E");
			h.addAllowedValue("6F");
			h.addAllowedValue("6G");
			h.addAllowedValue("6H");
			h.addAllowedValue("6I");
			h.addAllowedValue("6J");
			h.addAllowedValue("6K");
			h.addAllowedValue("6L");
			h.addAllowedValue("6M");
			h.addAllowedValue("6N");
			h.addAllowedValue("6O");
			h.addAllowedValue("6P");
			h.addAllowedValue("6Q");
			h.addAllowedValue("6R");
			h.addAllowedValue("6S");
			h.addAllowedValue("6T");
			h.addAllowedValue("6U");
			h.addAllowedValue("6V");
			h.addAllowedValue("6W");
			h.addAllowedValue("6X");
			h.addAllowedValue("6Y");
			h.addAllowedValue("6Z");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("7A");
			h.addAllowedValue("7B");
			h.addAllowedValue("7C");
			h.addAllowedValue("7D");
			h.addAllowedValue("7E");
			h.addAllowedValue("7F");
			h.addAllowedValue("7G");
			h.addAllowedValue("7H");
			h.addAllowedValue("7I");
			h.addAllowedValue("7J");
			h.addAllowedValue("7K");
			h.addAllowedValue("7L");
			h.addAllowedValue("7M");
			h.addAllowedValue("7N");
			h.addAllowedValue("7O");
			h.addAllowedValue("7P");
			h.addAllowedValue("7Q");
			h.addAllowedValue("7R");
			h.addAllowedValue("7S");
			h.addAllowedValue("7T");
			h.addAllowedValue("7U");
			h.addAllowedValue("7W");
			h.addAllowedValue("7X");
			h.addAllowedValue("7Y");
			h.addAllowedValue("7Z");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8A");
			h.addAllowedValue("8B");
			h.addAllowedValue("8C");
			h.addAllowedValue("8D");
			h.addAllowedValue("8E");
			h.addAllowedValue("8F");
			h.addAllowedValue("8G");
			h.addAllowedValue("8H");
			h.addAllowedValue("8I");
			h.addAllowedValue("8J");
			h.addAllowedValue("8K");
			h.addAllowedValue("8L");
			h.addAllowedValue("8M");
			h.addAllowedValue("8N");
			h.addAllowedValue("8O");
			h.addAllowedValue("8P");
			h.addAllowedValue("8Q");
			h.addAllowedValue("8R");
			h.addAllowedValue("8S");
			h.addAllowedValue("8U");
			h.addAllowedValue("8V");
			h.addAllowedValue("8W");
			h.addAllowedValue("8X");
			h.addAllowedValue("8Y");
			h.addAllowedValue("8Z");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9A");
			h.addAllowedValue("9B");
			h.addAllowedValue("9C");
			h.addAllowedValue("9D");
			h.addAllowedValue("9E");
			h.addAllowedValue("9F");
			h.addAllowedValue("9G");
			h.addAllowedValue("9H");
			h.addAllowedValue("9I");
			h.addAllowedValue("9J");
			h.addAllowedValue("9K");
			h.addAllowedValue("9L");
			h.addAllowedValue("9M");
			h.addAllowedValue("9N");
			h.addAllowedValue("9P");
			h.addAllowedValue("9Q");
			h.addAllowedValue("9R");
			h.addAllowedValue("9S");
			h.addAllowedValue("9T");
			h.addAllowedValue("9U");
			h.addAllowedValue("9V");
			h.addAllowedValue("9W");
			h.addAllowedValue("9X");
			h.addAllowedValue("9Y");
			h.addAllowedValue("9Z");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement128 = new RtSimpleElement("128", "ID", h);
		}
	
		return simpleElement128;
	}
	
	private RtSimpleElement simpleElement127;
	
	private RtSimpleElement simpleElement127() {
		if (simpleElement127 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Reference Identification";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement127 = new RtSimpleElement("127", "AN", h);
		}
	
		return simpleElement127;
	}
	
	private RtSimpleElement simpleElement352;
	
	private RtSimpleElement simpleElement352() {
		if (simpleElement352 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Description";
			h.minLength = 1;
			h.maxLength = 80;
			
			simpleElement352 = new RtSimpleElement("352", "AN", h);
		}
	
		return simpleElement352;
	}
	
	private RtSimpleElement simpleElement366;
	
	private RtSimpleElement simpleElement366() {
		if (simpleElement366 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Contact Function Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AP");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BP");
			h.addAllowedValue("BS");
			h.addAllowedValue("BU");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C2");
			h.addAllowedValue("DA");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DI");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DV");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EM");
			h.addAllowedValue("EN");
			h.addAllowedValue("EO");
			h.addAllowedValue("EP");
			h.addAllowedValue("ES");
			h.addAllowedValue("EV");
			h.addAllowedValue("EX");
			h.addAllowedValue("E1");
			h.addAllowedValue("E2");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FF");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FN");
			h.addAllowedValue("FO");
			h.addAllowedValue("FP");
			h.addAllowedValue("FQ");
			h.addAllowedValue("FR");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GE");
			h.addAllowedValue("GR");
			h.addAllowedValue("HM");
			h.addAllowedValue("HR");
			h.addAllowedValue("IC");
			h.addAllowedValue("IO");
			h.addAllowedValue("IP");
			h.addAllowedValue("IS");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KP");
			h.addAllowedValue("KT");
			h.addAllowedValue("LD");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MG");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MM");
			h.addAllowedValue("NA");
			h.addAllowedValue("NC");
			h.addAllowedValue("NP");
			h.addAllowedValue("NT");
			h.addAllowedValue("OA");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("OS");
			h.addAllowedValue("OW");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("QA");
			h.addAllowedValue("QC");
			h.addAllowedValue("QI");
			h.addAllowedValue("QM");
			h.addAllowedValue("QP");
			h.addAllowedValue("QR");
			h.addAllowedValue("QY");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RS");
			h.addAllowedValue("RZ");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SY");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TH");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TY");
			h.addAllowedValue("UG");
			h.addAllowedValue("UP");
			h.addAllowedValue("UQ");
			h.addAllowedValue("UR");
			h.addAllowedValue("VM");
			h.addAllowedValue("VP");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WR");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("1A");
			h.addAllowedValue("1B");
			h.addAllowedValue("1C");
			h.addAllowedValue("1D");
			h.addAllowedValue("1E");
			h.addAllowedValue("1F");
			h.addAllowedValue("1G");
			h.addAllowedValue("1H");
			h.addAllowedValue("3A");
			simpleElement366 = new RtSimpleElement("366", "ID", h);
		}
	
		return simpleElement366;
	}
	
	private RtSimpleElement simpleElement93;
	
	private RtSimpleElement simpleElement93() {
		if (simpleElement93 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Name";
			h.minLength = 1;
			h.maxLength = 60;
			
			simpleElement93 = new RtSimpleElement("93", "AN", h);
		}
	
		return simpleElement93;
	}
	
	private RtSimpleElement simpleElement365;
	
	private RtSimpleElement simpleElement365() {
		if (simpleElement365 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Communication Number Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AP");
			h.addAllowedValue("AS");
			h.addAllowedValue("AU");
			h.addAllowedValue("BN");
			h.addAllowedValue("BT");
			h.addAllowedValue("CA");
			h.addAllowedValue("CP");
			h.addAllowedValue("DN");
			h.addAllowedValue("ED");
			h.addAllowedValue("EM");
			h.addAllowedValue("EX");
			h.addAllowedValue("FT");
			h.addAllowedValue("FU");
			h.addAllowedValue("FX");
			h.addAllowedValue("HF");
			h.addAllowedValue("HP");
			h.addAllowedValue("IT");
			h.addAllowedValue("MN");
			h.addAllowedValue("NP");
			h.addAllowedValue("OF");
			h.addAllowedValue("OT");
			h.addAllowedValue("PA");
			h.addAllowedValue("PC");
			h.addAllowedValue("PP");
			h.addAllowedValue("PS");
			h.addAllowedValue("SP");
			h.addAllowedValue("TE");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TX");
			h.addAllowedValue("UR");
			h.addAllowedValue("VM");
			h.addAllowedValue("WC");
			h.addAllowedValue("WF");
			h.addAllowedValue("WP");
			simpleElement365 = new RtSimpleElement("365", "ID", h);
		}
	
		return simpleElement365;
	}
	
	private RtSimpleElement simpleElement364;
	
	private RtSimpleElement simpleElement364() {
		if (simpleElement364 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Communication Number";
			h.minLength = 1;
			h.maxLength = 80;
			
			simpleElement364 = new RtSimpleElement("364", "AN", h);
		}
	
		return simpleElement364;
	}
	
	private RtSimpleElement simpleElement443;
	
	private RtSimpleElement simpleElement443() {
		if (simpleElement443 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Contact Inquiry Reference";
			h.minLength = 1;
			h.maxLength = 20;
			
			simpleElement443 = new RtSimpleElement("443", "AN", h);
		}
	
		return simpleElement443;
	}
	
	private RtSimpleElement simpleElement325;
	
	private RtSimpleElement simpleElement325() {
		if (simpleElement325 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Tax Identification Number";
			h.minLength = 1;
			h.maxLength = 20;
			
			simpleElement325 = new RtSimpleElement("325", "AN", h);
		}
	
		return simpleElement325;
	}
	
	private RtSimpleElement simpleElement309;
	
	private RtSimpleElement simpleElement309() {
		if (simpleElement309 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Location Qualifier";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AA");
			h.addAllowedValue("AC");
			h.addAllowedValue("AP");
			h.addAllowedValue("AR");
			h.addAllowedValue("A1");
			h.addAllowedValue("B");
			h.addAllowedValue("BE");
			h.addAllowedValue("BL");
			h.addAllowedValue("BS");
			h.addAllowedValue("B1");
			h.addAllowedValue("C");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CI");
			h.addAllowedValue("CL");
			h.addAllowedValue("CO");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CY");
			h.addAllowedValue("C2");
			h.addAllowedValue("D");
			h.addAllowedValue("DC");
			h.addAllowedValue("DE");
			h.addAllowedValue("DL");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DR");
			h.addAllowedValue("DT");
			h.addAllowedValue("E");
			h.addAllowedValue("EA");
			h.addAllowedValue("EL");
			h.addAllowedValue("F");
			h.addAllowedValue("FA");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FI");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("FV");
			h.addAllowedValue("GL");
			h.addAllowedValue("H");
			h.addAllowedValue("I");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IM");
			h.addAllowedValue("IP");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("K");
			h.addAllowedValue("KE");
			h.addAllowedValue("KL");
			h.addAllowedValue("KP");
			h.addAllowedValue("L");
			h.addAllowedValue("LO");
			h.addAllowedValue("M");
			h.addAllowedValue("MI");
			h.addAllowedValue("MS");
			h.addAllowedValue("MZ");
			h.addAllowedValue("NS");
			h.addAllowedValue("O");
			h.addAllowedValue("OA");
			h.addAllowedValue("OF");
			h.addAllowedValue("OL");
			h.addAllowedValue("OP");
			h.addAllowedValue("OR");
			h.addAllowedValue("OV");
			h.addAllowedValue("P");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PL");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("RA");
			h.addAllowedValue("RC");
			h.addAllowedValue("RE");
			h.addAllowedValue("RG");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RL");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SL");
			h.addAllowedValue("SN");
			h.addAllowedValue("SP");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SW");
			h.addAllowedValue("TA");
			h.addAllowedValue("TC");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TX");
			h.addAllowedValue("UN");
			h.addAllowedValue("UR");
			h.addAllowedValue("UT");
			h.addAllowedValue("VA");
			h.addAllowedValue("VI");
			h.addAllowedValue("VS");
			h.addAllowedValue("W");
			h.addAllowedValue("WF");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			simpleElement309 = new RtSimpleElement("309", "ID", h);
		}
	
		return simpleElement309;
	}
	
	private RtSimpleElement simpleElement310;
	
	private RtSimpleElement simpleElement310() {
		if (simpleElement310 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Location Identifier";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement310 = new RtSimpleElement("310", "AN", h);
		}
	
		return simpleElement310;
	}
	
	private RtSimpleElement simpleElement441;
	
	private RtSimpleElement simpleElement441() {
		if (simpleElement441 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Tax Exempt Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("B");
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			h.addAllowedValue("E");
			h.addAllowedValue("F");
			h.addAllowedValue("G");
			h.addAllowedValue("H");
			h.addAllowedValue("I");
			h.addAllowedValue("J");
			h.addAllowedValue("K");
			h.addAllowedValue("L");
			h.addAllowedValue("M");
			h.addAllowedValue("N");
			h.addAllowedValue("O");
			h.addAllowedValue("P");
			h.addAllowedValue("Q");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			h.addAllowedValue("T");
			h.addAllowedValue("U");
			h.addAllowedValue("V");
			h.addAllowedValue("W");
			h.addAllowedValue("X");
			h.addAllowedValue("0");
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			h.addAllowedValue("9");
			simpleElement441 = new RtSimpleElement("441", "ID", h);
		}
	
		return simpleElement441;
	}
	
	private RtSimpleElement simpleElement1179;
	
	private RtSimpleElement simpleElement1179() {
		if (simpleElement1179 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Customs Entry Type Group Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("C");
			h.addAllowedValue("W");
			simpleElement1179 = new RtSimpleElement("1179", "ID", h);
		}
	
		return simpleElement1179;
	}
	
	private RtSimpleElement simpleElement146;
	
	private RtSimpleElement simpleElement146() {
		if (simpleElement146 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Shipment Method of Payment";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("BP");
			h.addAllowedValue("CA");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CF");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("FO");
			h.addAllowedValue("HP");
			h.addAllowedValue("MX");
			h.addAllowedValue("NC");
			h.addAllowedValue("NR");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PL");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PS");
			h.addAllowedValue("PU");
			h.addAllowedValue("RC");
			h.addAllowedValue("RF");
			h.addAllowedValue("RS");
			h.addAllowedValue("TP");
			h.addAllowedValue("WC");
			h.addAllowedValue("11");
			simpleElement146 = new RtSimpleElement("146", "ID", h);
		}
	
		return simpleElement146;
	}
	
	private RtSimpleElement simpleElement334;
	
	private RtSimpleElement simpleElement334() {
		if (simpleElement334 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transportation Terms Qualifier Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			simpleElement334 = new RtSimpleElement("334", "ID", h);
		}
	
		return simpleElement334;
	}
	
	private RtSimpleElement simpleElement335;
	
	private RtSimpleElement simpleElement335() {
		if (simpleElement335 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transportation Terms Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("CAF");
			h.addAllowedValue("CFR");
			h.addAllowedValue("CIF");
			h.addAllowedValue("CIP");
			h.addAllowedValue("CPT");
			h.addAllowedValue("DAF");
			h.addAllowedValue("DDP");
			h.addAllowedValue("DDU");
			h.addAllowedValue("DEQ");
			h.addAllowedValue("DES");
			h.addAllowedValue("DOM");
			h.addAllowedValue("DUP");
			h.addAllowedValue("EXQ");
			h.addAllowedValue("EXS");
			h.addAllowedValue("EXW");
			h.addAllowedValue("FAS");
			h.addAllowedValue("FCA");
			h.addAllowedValue("FCI");
			h.addAllowedValue("FCP");
			h.addAllowedValue("FOB");
			h.addAllowedValue("FOR");
			h.addAllowedValue("FOT");
			h.addAllowedValue("NPF");
			h.addAllowedValue("PPF");
			h.addAllowedValue("ZZZ");
			simpleElement335 = new RtSimpleElement("335", "ID", h);
		}
	
		return simpleElement335;
	}
	
	private RtSimpleElement simpleElement54;
	
	private RtSimpleElement simpleElement54() {
		if (simpleElement54 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Risk of Loss Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("BY");
			h.addAllowedValue("FE");
			h.addAllowedValue("IM");
			h.addAllowedValue("IR");
			h.addAllowedValue("LR");
			h.addAllowedValue("PP");
			h.addAllowedValue("SE");
			h.addAllowedValue("SR");
			h.addAllowedValue("ZZ");
			simpleElement54 = new RtSimpleElement("54", "ID", h);
		}
	
		return simpleElement54;
	}
	
	private RtSimpleElement simpleElement687;
	
	private RtSimpleElement simpleElement687() {
		if (simpleElement687 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Class of Trade Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AG");
			h.addAllowedValue("AI");
			h.addAllowedValue("AP");
			h.addAllowedValue("AS");
			h.addAllowedValue("BG");
			h.addAllowedValue("BR");
			h.addAllowedValue("CB");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CR");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DI");
			h.addAllowedValue("DR");
			h.addAllowedValue("EX");
			h.addAllowedValue("FS");
			h.addAllowedValue("GA");
			h.addAllowedValue("GM");
			h.addAllowedValue("GR");
			h.addAllowedValue("GV");
			h.addAllowedValue("HS");
			h.addAllowedValue("ID");
			h.addAllowedValue("IN");
			h.addAllowedValue("IR");
			h.addAllowedValue("JB");
			h.addAllowedValue("LC");
			h.addAllowedValue("MC");
			h.addAllowedValue("MF");
			h.addAllowedValue("ML");
			h.addAllowedValue("OE");
			h.addAllowedValue("OF");
			h.addAllowedValue("ON");
			h.addAllowedValue("PF");
			h.addAllowedValue("PH");
			h.addAllowedValue("PT");
			h.addAllowedValue("PY");
			h.addAllowedValue("RS");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SE");
			h.addAllowedValue("ST");
			h.addAllowedValue("TR");
			h.addAllowedValue("WA");
			h.addAllowedValue("WC");
			h.addAllowedValue("WH");
			h.addAllowedValue("WS");
			simpleElement687 = new RtSimpleElement("687", "ID", h);
		}
	
		return simpleElement687;
	}
	
	private RtSimpleElement simpleElement236;
	
	private RtSimpleElement simpleElement236() {
		if (simpleElement236 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Price Identifier Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("ACT");
			h.addAllowedValue("AGC");
			h.addAllowedValue("ALT");
			h.addAllowedValue("AWP");
			h.addAllowedValue("BBP");
			h.addAllowedValue("BCH");
			h.addAllowedValue("CAN");
			h.addAllowedValue("CAT");
			h.addAllowedValue("CDF");
			h.addAllowedValue("CDV");
			h.addAllowedValue("CHG");
			h.addAllowedValue("CON");
			h.addAllowedValue("CUP");
			h.addAllowedValue("CUS");
			h.addAllowedValue("C01");
			h.addAllowedValue("C02");
			h.addAllowedValue("C03");
			h.addAllowedValue("C04");
			h.addAllowedValue("C05");
			h.addAllowedValue("C06");
			h.addAllowedValue("C07");
			h.addAllowedValue("C08");
			h.addAllowedValue("C09");
			h.addAllowedValue("C10");
			h.addAllowedValue("C11");
			h.addAllowedValue("C12");
			h.addAllowedValue("C13");
			h.addAllowedValue("C14");
			h.addAllowedValue("C15");
			h.addAllowedValue("C16");
			h.addAllowedValue("C17");
			h.addAllowedValue("C18");
			h.addAllowedValue("C19");
			h.addAllowedValue("C20");
			h.addAllowedValue("C21");
			h.addAllowedValue("C22");
			h.addAllowedValue("C23");
			h.addAllowedValue("C24");
			h.addAllowedValue("C25");
			h.addAllowedValue("C26");
			h.addAllowedValue("C27");
			h.addAllowedValue("C28");
			h.addAllowedValue("C29");
			h.addAllowedValue("C30");
			h.addAllowedValue("DAP");
			h.addAllowedValue("DIS");
			h.addAllowedValue("DPR");
			h.addAllowedValue("DSC");
			h.addAllowedValue("DSD");
			h.addAllowedValue("DSP");
			h.addAllowedValue("D01");
			h.addAllowedValue("D02");
			h.addAllowedValue("D03");
			h.addAllowedValue("EDM");
			h.addAllowedValue("EDP");
			h.addAllowedValue("EDS");
			h.addAllowedValue("EDW");
			h.addAllowedValue("ELC");
			h.addAllowedValue("EST");
			h.addAllowedValue("EUP");
			h.addAllowedValue("FCH");
			h.addAllowedValue("FCP");
			h.addAllowedValue("FDS");
			h.addAllowedValue("FET");
			h.addAllowedValue("FGP");
			h.addAllowedValue("FSP");
			h.addAllowedValue("FUL");
			h.addAllowedValue("FUP");
			h.addAllowedValue("GAP");
			h.addAllowedValue("GDP");
			h.addAllowedValue("GOV");
			h.addAllowedValue("GSP");
			h.addAllowedValue("GTP");
			h.addAllowedValue("ICL");
			h.addAllowedValue("IND");
			h.addAllowedValue("INS");
			h.addAllowedValue("INV");
			h.addAllowedValue("LAR");
			h.addAllowedValue("LPP");
			h.addAllowedValue("LPR");
			h.addAllowedValue("MAP");
			h.addAllowedValue("MAS");
			h.addAllowedValue("MAX");
			h.addAllowedValue("MIN");
			h.addAllowedValue("MNC");
			h.addAllowedValue("MNR");
			h.addAllowedValue("MOD");
			h.addAllowedValue("MPR");
			h.addAllowedValue("MSR");
			h.addAllowedValue("MXR");
			h.addAllowedValue("NET");
			h.addAllowedValue("N01");
			h.addAllowedValue("N02");
			h.addAllowedValue("N03");
			h.addAllowedValue("N04");
			h.addAllowedValue("N05");
			h.addAllowedValue("N06");
			h.addAllowedValue("N07");
			h.addAllowedValue("N08");
			h.addAllowedValue("N09");
			h.addAllowedValue("N10");
			h.addAllowedValue("N11");
			h.addAllowedValue("N12");
			h.addAllowedValue("N13");
			h.addAllowedValue("N14");
			h.addAllowedValue("N15");
			h.addAllowedValue("N16");
			h.addAllowedValue("N17");
			h.addAllowedValue("N18");
			h.addAllowedValue("N19");
			h.addAllowedValue("N20");
			h.addAllowedValue("N21");
			h.addAllowedValue("N22");
			h.addAllowedValue("N23");
			h.addAllowedValue("N24");
			h.addAllowedValue("N25");
			h.addAllowedValue("N26");
			h.addAllowedValue("N27");
			h.addAllowedValue("N28");
			h.addAllowedValue("N29");
			h.addAllowedValue("N30");
			h.addAllowedValue("N31");
			h.addAllowedValue("OAP");
			h.addAllowedValue("OPP");
			h.addAllowedValue("PAP");
			h.addAllowedValue("PAQ");
			h.addAllowedValue("PBQ");
			h.addAllowedValue("PBR");
			h.addAllowedValue("PHS");
			h.addAllowedValue("PIE");
			h.addAllowedValue("PLT");
			h.addAllowedValue("PPA");
			h.addAllowedValue("PPD");
			h.addAllowedValue("PRF");
			h.addAllowedValue("PRO");
			h.addAllowedValue("PRP");
			h.addAllowedValue("PUR");
			h.addAllowedValue("QTE");
			h.addAllowedValue("REG");
			h.addAllowedValue("RES");
			h.addAllowedValue("RPA");
			h.addAllowedValue("RPM");
			h.addAllowedValue("RPP");
			h.addAllowedValue("RSH");
			h.addAllowedValue("RTL");
			h.addAllowedValue("SAC");
			h.addAllowedValue("SDP");
			h.addAllowedValue("SFP");
			h.addAllowedValue("SHD");
			h.addAllowedValue("SLP");
			h.addAllowedValue("SPC");
			h.addAllowedValue("SPE");
			h.addAllowedValue("STA");
			h.addAllowedValue("SUM");
			h.addAllowedValue("SWP");
			h.addAllowedValue("THP");
			h.addAllowedValue("TOT");
			h.addAllowedValue("TRF");
			h.addAllowedValue("UCP");
			h.addAllowedValue("ULC");
			h.addAllowedValue("WAR");
			h.addAllowedValue("WHL");
			h.addAllowedValue("WSP");
			h.addAllowedValue("ZNP");
			simpleElement236 = new RtSimpleElement("236", "ID", h);
		}
	
		return simpleElement236;
	}
	
	private RtSimpleElement simpleElement212;
	
	private RtSimpleElement simpleElement212() {
		if (simpleElement212 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Unit Price";
			h.minLength = 1;
			h.maxLength = 17;
			
			simpleElement212 = new RtSimpleElement("212", "R", h);
		}
	
		return simpleElement212;
	}
	
	private RtSimpleElement simpleElement380;
	
	private RtSimpleElement simpleElement380() {
		if (simpleElement380 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Quantity";
			h.minLength = 1;
			h.maxLength = 15;
			
			simpleElement380 = new RtSimpleElement("380", "R", h);
		}
	
		return simpleElement380;
	}
	
	private RtSimpleElement simpleElement355;
	
	private RtSimpleElement simpleElement355() {
		if (simpleElement355 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Unit or Basis for Measurement Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A8");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("BU");
			h.addAllowedValue("BV");
			h.addAllowedValue("BW");
			h.addAllowedValue("BX");
			h.addAllowedValue("BY");
			h.addAllowedValue("BZ");
			h.addAllowedValue("B0");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("B6");
			h.addAllowedValue("B7");
			h.addAllowedValue("B8");
			h.addAllowedValue("B9");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C0");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("C7");
			h.addAllowedValue("C8");
			h.addAllowedValue("C9");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("DW");
			h.addAllowedValue("DX");
			h.addAllowedValue("DY");
			h.addAllowedValue("DZ");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D5");
			h.addAllowedValue("D8");
			h.addAllowedValue("D9");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EH");
			h.addAllowedValue("EJ");
			h.addAllowedValue("EM");
			h.addAllowedValue("EP");
			h.addAllowedValue("EQ");
			h.addAllowedValue("EV");
			h.addAllowedValue("EX");
			h.addAllowedValue("EY");
			h.addAllowedValue("EZ");
			h.addAllowedValue("E1");
			h.addAllowedValue("E3");
			h.addAllowedValue("E4");
			h.addAllowedValue("E5");
			h.addAllowedValue("E7");
			h.addAllowedValue("E8");
			h.addAllowedValue("E9");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FK");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FO");
			h.addAllowedValue("FP");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("FZ");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("F5");
			h.addAllowedValue("F6");
			h.addAllowedValue("F9");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GD");
			h.addAllowedValue("GE");
			h.addAllowedValue("GF");
			h.addAllowedValue("GG");
			h.addAllowedValue("GH");
			h.addAllowedValue("GI");
			h.addAllowedValue("GJ");
			h.addAllowedValue("GK");
			h.addAllowedValue("GL");
			h.addAllowedValue("GM");
			h.addAllowedValue("GN");
			h.addAllowedValue("GO");
			h.addAllowedValue("GP");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("GT");
			h.addAllowedValue("GU");
			h.addAllowedValue("GV");
			h.addAllowedValue("GW");
			h.addAllowedValue("GX");
			h.addAllowedValue("GY");
			h.addAllowedValue("GZ");
			h.addAllowedValue("G2");
			h.addAllowedValue("G3");
			h.addAllowedValue("G4");
			h.addAllowedValue("G5");
			h.addAllowedValue("G7");
			h.addAllowedValue("HA");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HD");
			h.addAllowedValue("HE");
			h.addAllowedValue("HF");
			h.addAllowedValue("HG");
			h.addAllowedValue("HH");
			h.addAllowedValue("HI");
			h.addAllowedValue("HJ");
			h.addAllowedValue("HK");
			h.addAllowedValue("HL");
			h.addAllowedValue("HM");
			h.addAllowedValue("HN");
			h.addAllowedValue("HO");
			h.addAllowedValue("HP");
			h.addAllowedValue("HQ");
			h.addAllowedValue("HR");
			h.addAllowedValue("HS");
			h.addAllowedValue("HT");
			h.addAllowedValue("HU");
			h.addAllowedValue("HV");
			h.addAllowedValue("HW");
			h.addAllowedValue("HY");
			h.addAllowedValue("HZ");
			h.addAllowedValue("H1");
			h.addAllowedValue("H2");
			h.addAllowedValue("H4");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("IE");
			h.addAllowedValue("IF");
			h.addAllowedValue("IH");
			h.addAllowedValue("II");
			h.addAllowedValue("IK");
			h.addAllowedValue("IL");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IP");
			h.addAllowedValue("IT");
			h.addAllowedValue("IU");
			h.addAllowedValue("IV");
			h.addAllowedValue("IW");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JE");
			h.addAllowedValue("JG");
			h.addAllowedValue("JK");
			h.addAllowedValue("JM");
			h.addAllowedValue("JO");
			h.addAllowedValue("JR");
			h.addAllowedValue("JU");
			h.addAllowedValue("J2");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KR");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("KU");
			h.addAllowedValue("KV");
			h.addAllowedValue("KW");
			h.addAllowedValue("KX");
			h.addAllowedValue("K1");
			h.addAllowedValue("K2");
			h.addAllowedValue("K3");
			h.addAllowedValue("K4");
			h.addAllowedValue("K5");
			h.addAllowedValue("K6");
			h.addAllowedValue("K7");
			h.addAllowedValue("K9");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LE");
			h.addAllowedValue("LF");
			h.addAllowedValue("LG");
			h.addAllowedValue("LH");
			h.addAllowedValue("LI");
			h.addAllowedValue("LJ");
			h.addAllowedValue("LK");
			h.addAllowedValue("LL");
			h.addAllowedValue("LM");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LP");
			h.addAllowedValue("LQ");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LX");
			h.addAllowedValue("LY");
			h.addAllowedValue("L2");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MP");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("MU");
			h.addAllowedValue("MV");
			h.addAllowedValue("MW");
			h.addAllowedValue("MX");
			h.addAllowedValue("MY");
			h.addAllowedValue("MZ");
			h.addAllowedValue("M0");
			h.addAllowedValue("M1");
			h.addAllowedValue("M2");
			h.addAllowedValue("M3");
			h.addAllowedValue("M4");
			h.addAllowedValue("M5");
			h.addAllowedValue("M6");
			h.addAllowedValue("M7");
			h.addAllowedValue("M8");
			h.addAllowedValue("M9");
			h.addAllowedValue("NA");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NG");
			h.addAllowedValue("NH");
			h.addAllowedValue("NI");
			h.addAllowedValue("NJ");
			h.addAllowedValue("NL");
			h.addAllowedValue("NM");
			h.addAllowedValue("NN");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("NU");
			h.addAllowedValue("NV");
			h.addAllowedValue("NW");
			h.addAllowedValue("NX");
			h.addAllowedValue("NY");
			h.addAllowedValue("N1");
			h.addAllowedValue("N2");
			h.addAllowedValue("N3");
			h.addAllowedValue("N4");
			h.addAllowedValue("N6");
			h.addAllowedValue("N7");
			h.addAllowedValue("N9");
			h.addAllowedValue("OA");
			h.addAllowedValue("OC");
			h.addAllowedValue("ON");
			h.addAllowedValue("OP");
			h.addAllowedValue("OT");
			h.addAllowedValue("OZ");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P0");
			h.addAllowedValue("P1");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P6");
			h.addAllowedValue("P7");
			h.addAllowedValue("P8");
			h.addAllowedValue("P9");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QH");
			h.addAllowedValue("QK");
			h.addAllowedValue("QR");
			h.addAllowedValue("QS");
			h.addAllowedValue("QT");
			h.addAllowedValue("QU");
			h.addAllowedValue("Q1");
			h.addAllowedValue("Q2");
			h.addAllowedValue("Q3");
			h.addAllowedValue("Q4");
			h.addAllowedValue("Q5");
			h.addAllowedValue("Q6");
			h.addAllowedValue("Q7");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("R9");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SY");
			h.addAllowedValue("SZ");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TU");
			h.addAllowedValue("TV");
			h.addAllowedValue("TW");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("TZ");
			h.addAllowedValue("T0");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("T4");
			h.addAllowedValue("T5");
			h.addAllowedValue("T6");
			h.addAllowedValue("T7");
			h.addAllowedValue("T8");
			h.addAllowedValue("T9");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("UF");
			h.addAllowedValue("UH");
			h.addAllowedValue("UL");
			h.addAllowedValue("UM");
			h.addAllowedValue("UN");
			h.addAllowedValue("UP");
			h.addAllowedValue("UQ");
			h.addAllowedValue("UR");
			h.addAllowedValue("US");
			h.addAllowedValue("UT");
			h.addAllowedValue("UU");
			h.addAllowedValue("UV");
			h.addAllowedValue("UW");
			h.addAllowedValue("UX");
			h.addAllowedValue("UY");
			h.addAllowedValue("UZ");
			h.addAllowedValue("U1");
			h.addAllowedValue("U2");
			h.addAllowedValue("U3");
			h.addAllowedValue("U5");
			h.addAllowedValue("VA");
			h.addAllowedValue("VC");
			h.addAllowedValue("VI");
			h.addAllowedValue("VP");
			h.addAllowedValue("VR");
			h.addAllowedValue("VS");
			h.addAllowedValue("V1");
			h.addAllowedValue("V2");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WD");
			h.addAllowedValue("WE");
			h.addAllowedValue("WG");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WK");
			h.addAllowedValue("WM");
			h.addAllowedValue("WP");
			h.addAllowedValue("WR");
			h.addAllowedValue("WW");
			h.addAllowedValue("W2");
			h.addAllowedValue("XP");
			h.addAllowedValue("X1");
			h.addAllowedValue("X2");
			h.addAllowedValue("X3");
			h.addAllowedValue("X4");
			h.addAllowedValue("X5");
			h.addAllowedValue("X6");
			h.addAllowedValue("X7");
			h.addAllowedValue("X8");
			h.addAllowedValue("X9");
			h.addAllowedValue("YD");
			h.addAllowedValue("YL");
			h.addAllowedValue("YR");
			h.addAllowedValue("YT");
			h.addAllowedValue("Y1");
			h.addAllowedValue("Y2");
			h.addAllowedValue("Y3");
			h.addAllowedValue("Y4");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZP");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("Z1");
			h.addAllowedValue("Z2");
			h.addAllowedValue("Z3");
			h.addAllowedValue("Z4");
			h.addAllowedValue("Z5");
			h.addAllowedValue("Z6");
			h.addAllowedValue("Z8");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("1A");
			h.addAllowedValue("1B");
			h.addAllowedValue("1C");
			h.addAllowedValue("1D");
			h.addAllowedValue("1E");
			h.addAllowedValue("1F");
			h.addAllowedValue("1G");
			h.addAllowedValue("1H");
			h.addAllowedValue("1I");
			h.addAllowedValue("1J");
			h.addAllowedValue("1K");
			h.addAllowedValue("1L");
			h.addAllowedValue("1M");
			h.addAllowedValue("1N");
			h.addAllowedValue("1O");
			h.addAllowedValue("1P");
			h.addAllowedValue("1Q");
			h.addAllowedValue("1R");
			h.addAllowedValue("1X");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2A");
			h.addAllowedValue("2B");
			h.addAllowedValue("2C");
			h.addAllowedValue("2F");
			h.addAllowedValue("2G");
			h.addAllowedValue("2H");
			h.addAllowedValue("2I");
			h.addAllowedValue("2J");
			h.addAllowedValue("2K");
			h.addAllowedValue("2L");
			h.addAllowedValue("2M");
			h.addAllowedValue("2N");
			h.addAllowedValue("2P");
			h.addAllowedValue("2Q");
			h.addAllowedValue("2R");
			h.addAllowedValue("2U");
			h.addAllowedValue("2V");
			h.addAllowedValue("2W");
			h.addAllowedValue("2X");
			h.addAllowedValue("2Y");
			h.addAllowedValue("2Z");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3B");
			h.addAllowedValue("3C");
			h.addAllowedValue("3E");
			h.addAllowedValue("3F");
			h.addAllowedValue("3G");
			h.addAllowedValue("3H");
			h.addAllowedValue("3I");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4A");
			h.addAllowedValue("4B");
			h.addAllowedValue("4C");
			h.addAllowedValue("4D");
			h.addAllowedValue("4E");
			h.addAllowedValue("4F");
			h.addAllowedValue("4G");
			h.addAllowedValue("4H");
			h.addAllowedValue("4I");
			h.addAllowedValue("4J");
			h.addAllowedValue("4K");
			h.addAllowedValue("4L");
			h.addAllowedValue("4M");
			h.addAllowedValue("4N");
			h.addAllowedValue("4O");
			h.addAllowedValue("4P");
			h.addAllowedValue("4Q");
			h.addAllowedValue("4R");
			h.addAllowedValue("4S");
			h.addAllowedValue("4T");
			h.addAllowedValue("4U");
			h.addAllowedValue("4V");
			h.addAllowedValue("4W");
			h.addAllowedValue("4X");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("5A");
			h.addAllowedValue("5B");
			h.addAllowedValue("5C");
			h.addAllowedValue("5E");
			h.addAllowedValue("5F");
			h.addAllowedValue("5G");
			h.addAllowedValue("5H");
			h.addAllowedValue("5I");
			h.addAllowedValue("5J");
			h.addAllowedValue("5K");
			h.addAllowedValue("5P");
			h.addAllowedValue("5Q");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8C");
			h.addAllowedValue("8D");
			h.addAllowedValue("8P");
			h.addAllowedValue("8R");
			h.addAllowedValue("8S");
			h.addAllowedValue("8U");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("89");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement355 = new RtSimpleElement("355", "ID", h);
		}
	
		return simpleElement355;
	}
	
	private RtSimpleElement simpleElement1018;
	
	private RtSimpleElement simpleElement1018() {
		if (simpleElement1018 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Exponent";
			h.minLength = 1;
			h.maxLength = 15;
			
			simpleElement1018 = new RtSimpleElement("1018", "R", h);
		}
	
		return simpleElement1018;
	}
	
	private RtSimpleElement simpleElement649;
	
	private RtSimpleElement simpleElement649() {
		if (simpleElement649 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Multiplier";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement649 = new RtSimpleElement("649", "R", h);
		}
	
		return simpleElement649;
	}
	
	private RtSimpleElement simpleElement648;
	
	private RtSimpleElement simpleElement648() {
		if (simpleElement648 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Price Multiplier Qualifier";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("CSD");
			h.addAllowedValue("CSR");
			h.addAllowedValue("DIS");
			h.addAllowedValue("ILP");
			h.addAllowedValue("PSP");
			h.addAllowedValue("SEL");
			simpleElement648 = new RtSimpleElement("648", "ID", h);
		}
	
		return simpleElement648;
	}
	
	private RtSimpleElement simpleElement782;
	
	private RtSimpleElement simpleElement782() {
		if (simpleElement782 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Monetary Amount";
			h.minLength = 1;
			h.maxLength = 18;
			
			simpleElement782 = new RtSimpleElement("782", "R", h);
		}
	
		return simpleElement782;
	}
	
	private RtSimpleElement simpleElement639;
	
	private RtSimpleElement simpleElement639() {
		if (simpleElement639 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Basis of Unit Price Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AP");
			h.addAllowedValue("AW");
			h.addAllowedValue("BD");
			h.addAllowedValue("BR");
			h.addAllowedValue("BW");
			h.addAllowedValue("CA");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CT");
			h.addAllowedValue("DI");
			h.addAllowedValue("DP");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("EC");
			h.addAllowedValue("EH");
			h.addAllowedValue("ES");
			h.addAllowedValue("FB");
			h.addAllowedValue("FO");
			h.addAllowedValue("FX");
			h.addAllowedValue("HF");
			h.addAllowedValue("HP");
			h.addAllowedValue("HT");
			h.addAllowedValue("KA");
			h.addAllowedValue("KP");
			h.addAllowedValue("KR");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LM");
			h.addAllowedValue("LR");
			h.addAllowedValue("ME");
			h.addAllowedValue("ML");
			h.addAllowedValue("NC");
			h.addAllowedValue("NE");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PY");
			h.addAllowedValue("QE");
			h.addAllowedValue("QH");
			h.addAllowedValue("QR");
			h.addAllowedValue("QS");
			h.addAllowedValue("QT");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RM");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("SA");
			h.addAllowedValue("SC");
			h.addAllowedValue("SM");
			h.addAllowedValue("SR");
			h.addAllowedValue("ST");
			h.addAllowedValue("SW");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TM");
			h.addAllowedValue("TP");
			h.addAllowedValue("TT");
			h.addAllowedValue("UM");
			h.addAllowedValue("VQ");
			h.addAllowedValue("WC");
			h.addAllowedValue("WD");
			h.addAllowedValue("WE");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WM");
			simpleElement639 = new RtSimpleElement("639", "ID", h);
		}
	
		return simpleElement639;
	}
	
	private RtSimpleElement simpleElement499;
	
	private RtSimpleElement simpleElement499() {
		if (simpleElement499 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Condition Value";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement499 = new RtSimpleElement("499", "AN", h);
		}
	
		return simpleElement499;
	}
	
	private RtSimpleElement simpleElement289;
	
	private RtSimpleElement simpleElement289() {
		if (simpleElement289 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Multiple Price Quantity";
			h.minLength = 1;
			h.maxLength = 2;
			
			simpleElement289 = new RtSimpleElement("289", "N0", h);
		}
	
		return simpleElement289;
	}
	
	private RtSimpleElement simpleElement673;
	
	private RtSimpleElement simpleElement673() {
		if (simpleElement673 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Quantity Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A8");
			h.addAllowedValue("A9");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BW");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("B6");
			h.addAllowedValue("B7");
			h.addAllowedValue("B8");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CL");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CW");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C0");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DI");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DY");
			h.addAllowedValue("D1");
			h.addAllowedValue("D3");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EM");
			h.addAllowedValue("EP");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("ET");
			h.addAllowedValue("EW");
			h.addAllowedValue("E1");
			h.addAllowedValue("E2");
			h.addAllowedValue("E3");
			h.addAllowedValue("E4");
			h.addAllowedValue("E5");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FK");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("F1");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GE");
			h.addAllowedValue("GF");
			h.addAllowedValue("GI");
			h.addAllowedValue("GL");
			h.addAllowedValue("GP");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("GT");
			h.addAllowedValue("GU");
			h.addAllowedValue("GV");
			h.addAllowedValue("GW");
			h.addAllowedValue("GX");
			h.addAllowedValue("GZ");
			h.addAllowedValue("HA");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HD");
			h.addAllowedValue("HE");
			h.addAllowedValue("HF");
			h.addAllowedValue("HG");
			h.addAllowedValue("HH");
			h.addAllowedValue("HI");
			h.addAllowedValue("HJ");
			h.addAllowedValue("HK");
			h.addAllowedValue("HL");
			h.addAllowedValue("HM");
			h.addAllowedValue("HN");
			h.addAllowedValue("HO");
			h.addAllowedValue("HP");
			h.addAllowedValue("HR");
			h.addAllowedValue("HS");
			h.addAllowedValue("II");
			h.addAllowedValue("IN");
			h.addAllowedValue("IP");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JC");
			h.addAllowedValue("JD");
			h.addAllowedValue("JE");
			h.addAllowedValue("JF");
			h.addAllowedValue("JG");
			h.addAllowedValue("JH");
			h.addAllowedValue("JI");
			h.addAllowedValue("JJ");
			h.addAllowedValue("JK");
			h.addAllowedValue("JL");
			h.addAllowedValue("JM");
			h.addAllowedValue("JN");
			h.addAllowedValue("JO");
			h.addAllowedValue("JP");
			h.addAllowedValue("JQ");
			h.addAllowedValue("JR");
			h.addAllowedValue("JS");
			h.addAllowedValue("JT");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KN");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KR");
			h.addAllowedValue("KS");
			h.addAllowedValue("KU");
			h.addAllowedValue("KV");
			h.addAllowedValue("KW");
			h.addAllowedValue("KX");
			h.addAllowedValue("KY");
			h.addAllowedValue("KZ");
			h.addAllowedValue("K6");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LE");
			h.addAllowedValue("LG");
			h.addAllowedValue("LH");
			h.addAllowedValue("LI");
			h.addAllowedValue("LK");
			h.addAllowedValue("LL");
			h.addAllowedValue("LM");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LP");
			h.addAllowedValue("LQ");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LV");
			h.addAllowedValue("LW");
			h.addAllowedValue("LX");
			h.addAllowedValue("LY");
			h.addAllowedValue("L2");
			h.addAllowedValue("L3");
			h.addAllowedValue("L4");
			h.addAllowedValue("L5");
			h.addAllowedValue("L6");
			h.addAllowedValue("L7");
			h.addAllowedValue("MA");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MI");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MX");
			h.addAllowedValue("M1");
			h.addAllowedValue("M2");
			h.addAllowedValue("NA");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NG");
			h.addAllowedValue("NL");
			h.addAllowedValue("NN");
			h.addAllowedValue("NO");
			h.addAllowedValue("NP");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("NU");
			h.addAllowedValue("NV");
			h.addAllowedValue("NW");
			h.addAllowedValue("N1");
			h.addAllowedValue("N2");
			h.addAllowedValue("N3");
			h.addAllowedValue("N4");
			h.addAllowedValue("N5");
			h.addAllowedValue("N6");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("OF");
			h.addAllowedValue("OG");
			h.addAllowedValue("OH");
			h.addAllowedValue("OI");
			h.addAllowedValue("OL");
			h.addAllowedValue("ON");
			h.addAllowedValue("OO");
			h.addAllowedValue("OR");
			h.addAllowedValue("OT");
			h.addAllowedValue("OU");
			h.addAllowedValue("OV");
			h.addAllowedValue("OW");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("P1");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P6");
			h.addAllowedValue("P7");
			h.addAllowedValue("P8");
			h.addAllowedValue("P9");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QF");
			h.addAllowedValue("QH");
			h.addAllowedValue("QI");
			h.addAllowedValue("QJ");
			h.addAllowedValue("QL");
			h.addAllowedValue("QM");
			h.addAllowedValue("QN");
			h.addAllowedValue("QO");
			h.addAllowedValue("QP");
			h.addAllowedValue("QQ");
			h.addAllowedValue("QR");
			h.addAllowedValue("QS");
			h.addAllowedValue("QU");
			h.addAllowedValue("QV");
			h.addAllowedValue("QW");
			h.addAllowedValue("QX");
			h.addAllowedValue("Q1");
			h.addAllowedValue("Q2");
			h.addAllowedValue("Q3");
			h.addAllowedValue("Q4");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RW");
			h.addAllowedValue("RY");
			h.addAllowedValue("R3");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R9");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SY");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TU");
			h.addAllowedValue("TV");
			h.addAllowedValue("TW");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("T4");
			h.addAllowedValue("T5");
			h.addAllowedValue("T6");
			h.addAllowedValue("T7");
			h.addAllowedValue("UA");
			h.addAllowedValue("UG");
			h.addAllowedValue("UL");
			h.addAllowedValue("UO");
			h.addAllowedValue("US");
			h.addAllowedValue("UU");
			h.addAllowedValue("VA");
			h.addAllowedValue("VB");
			h.addAllowedValue("VC");
			h.addAllowedValue("VD");
			h.addAllowedValue("VE");
			h.addAllowedValue("VF");
			h.addAllowedValue("VG");
			h.addAllowedValue("VH");
			h.addAllowedValue("VI");
			h.addAllowedValue("VJ");
			h.addAllowedValue("VK");
			h.addAllowedValue("VL");
			h.addAllowedValue("VM");
			h.addAllowedValue("VN");
			h.addAllowedValue("VP");
			h.addAllowedValue("VR");
			h.addAllowedValue("VS");
			h.addAllowedValue("VT");
			h.addAllowedValue("VV");
			h.addAllowedValue("VY");
			h.addAllowedValue("V1");
			h.addAllowedValue("V2");
			h.addAllowedValue("V3");
			h.addAllowedValue("V4");
			h.addAllowedValue("V5");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WC");
			h.addAllowedValue("WD");
			h.addAllowedValue("WE");
			h.addAllowedValue("WG");
			h.addAllowedValue("WL");
			h.addAllowedValue("WO");
			h.addAllowedValue("WP");
			h.addAllowedValue("WR");
			h.addAllowedValue("WT");
			h.addAllowedValue("WV");
			h.addAllowedValue("WW");
			h.addAllowedValue("WX");
			h.addAllowedValue("WY");
			h.addAllowedValue("XA");
			h.addAllowedValue("XB");
			h.addAllowedValue("XC");
			h.addAllowedValue("XD");
			h.addAllowedValue("XE");
			h.addAllowedValue("XG");
			h.addAllowedValue("XI");
			h.addAllowedValue("XJ");
			h.addAllowedValue("XL");
			h.addAllowedValue("XN");
			h.addAllowedValue("XO");
			h.addAllowedValue("XT");
			h.addAllowedValue("XU");
			h.addAllowedValue("XV");
			h.addAllowedValue("XX");
			h.addAllowedValue("XY");
			h.addAllowedValue("XZ");
			h.addAllowedValue("X1");
			h.addAllowedValue("YA");
			h.addAllowedValue("YB");
			h.addAllowedValue("YC");
			h.addAllowedValue("YD");
			h.addAllowedValue("YE");
			h.addAllowedValue("YF");
			h.addAllowedValue("YG");
			h.addAllowedValue("YH");
			h.addAllowedValue("YJ");
			h.addAllowedValue("YK");
			h.addAllowedValue("YL");
			h.addAllowedValue("YM");
			h.addAllowedValue("YN");
			h.addAllowedValue("YP");
			h.addAllowedValue("YQ");
			h.addAllowedValue("YR");
			h.addAllowedValue("YS");
			h.addAllowedValue("YT");
			h.addAllowedValue("YW");
			h.addAllowedValue("YX");
			h.addAllowedValue("YY");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZD");
			h.addAllowedValue("ZE");
			h.addAllowedValue("ZF");
			h.addAllowedValue("ZG");
			h.addAllowedValue("ZH");
			h.addAllowedValue("ZI");
			h.addAllowedValue("ZJ");
			h.addAllowedValue("ZK");
			h.addAllowedValue("ZL");
			h.addAllowedValue("ZM");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZO");
			h.addAllowedValue("ZP");
			h.addAllowedValue("ZR");
			h.addAllowedValue("ZS");
			h.addAllowedValue("Z1");
			h.addAllowedValue("Z2");
			h.addAllowedValue("Z3");
			h.addAllowedValue("Z4");
			h.addAllowedValue("Z6");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("1A");
			h.addAllowedValue("1B");
			h.addAllowedValue("1C");
			h.addAllowedValue("1D");
			h.addAllowedValue("1E");
			h.addAllowedValue("1F");
			h.addAllowedValue("1G");
			h.addAllowedValue("1H");
			h.addAllowedValue("1I");
			h.addAllowedValue("1J");
			h.addAllowedValue("1K");
			h.addAllowedValue("1L");
			h.addAllowedValue("1M");
			h.addAllowedValue("1N");
			h.addAllowedValue("1O");
			h.addAllowedValue("1P");
			h.addAllowedValue("1Q");
			h.addAllowedValue("1R");
			h.addAllowedValue("1S");
			h.addAllowedValue("1T");
			h.addAllowedValue("1U");
			h.addAllowedValue("1V");
			h.addAllowedValue("1W");
			h.addAllowedValue("1X");
			h.addAllowedValue("1Y");
			h.addAllowedValue("1Z");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2A");
			h.addAllowedValue("2B");
			h.addAllowedValue("2C");
			h.addAllowedValue("2D");
			h.addAllowedValue("2E");
			h.addAllowedValue("2F");
			h.addAllowedValue("2G");
			h.addAllowedValue("2H");
			h.addAllowedValue("2I");
			h.addAllowedValue("2J");
			h.addAllowedValue("2K");
			h.addAllowedValue("2L");
			h.addAllowedValue("2M");
			h.addAllowedValue("2N");
			h.addAllowedValue("2O");
			h.addAllowedValue("2P");
			h.addAllowedValue("2Q");
			h.addAllowedValue("2R");
			h.addAllowedValue("2S");
			h.addAllowedValue("2T");
			h.addAllowedValue("2U");
			h.addAllowedValue("2V");
			h.addAllowedValue("2W");
			h.addAllowedValue("2X");
			h.addAllowedValue("2Y");
			h.addAllowedValue("2Z");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3A");
			h.addAllowedValue("3B");
			h.addAllowedValue("3C");
			h.addAllowedValue("3D");
			h.addAllowedValue("3E");
			h.addAllowedValue("3F");
			h.addAllowedValue("3G");
			h.addAllowedValue("3H");
			h.addAllowedValue("3I");
			h.addAllowedValue("3J");
			h.addAllowedValue("3K");
			h.addAllowedValue("3L");
			h.addAllowedValue("3M");
			h.addAllowedValue("3N");
			h.addAllowedValue("3P");
			h.addAllowedValue("3Q");
			h.addAllowedValue("3R");
			h.addAllowedValue("3S");
			h.addAllowedValue("3T");
			h.addAllowedValue("3U");
			h.addAllowedValue("3V");
			h.addAllowedValue("3W");
			h.addAllowedValue("3X");
			h.addAllowedValue("3Y");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4A");
			h.addAllowedValue("4B");
			h.addAllowedValue("4C");
			h.addAllowedValue("4D");
			h.addAllowedValue("4E");
			h.addAllowedValue("4F");
			h.addAllowedValue("4G");
			h.addAllowedValue("4H");
			h.addAllowedValue("4I");
			h.addAllowedValue("4J");
			h.addAllowedValue("4K");
			h.addAllowedValue("4L");
			h.addAllowedValue("4M");
			h.addAllowedValue("4N");
			h.addAllowedValue("4O");
			h.addAllowedValue("4P");
			h.addAllowedValue("4Q");
			h.addAllowedValue("4R");
			h.addAllowedValue("4S");
			h.addAllowedValue("4T");
			h.addAllowedValue("4U");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5A");
			h.addAllowedValue("5B");
			h.addAllowedValue("5C");
			h.addAllowedValue("5D");
			h.addAllowedValue("5E");
			h.addAllowedValue("5F");
			h.addAllowedValue("5G");
			h.addAllowedValue("5H");
			h.addAllowedValue("5I");
			h.addAllowedValue("5J");
			h.addAllowedValue("5K");
			h.addAllowedValue("5L");
			h.addAllowedValue("5M");
			h.addAllowedValue("5N");
			h.addAllowedValue("5O");
			h.addAllowedValue("5P");
			h.addAllowedValue("5Q");
			h.addAllowedValue("5R");
			h.addAllowedValue("5S");
			h.addAllowedValue("5T");
			h.addAllowedValue("5U");
			h.addAllowedValue("5V");
			h.addAllowedValue("5W");
			h.addAllowedValue("5X");
			h.addAllowedValue("5Y");
			h.addAllowedValue("5Z");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("6A");
			h.addAllowedValue("6B");
			h.addAllowedValue("6C");
			h.addAllowedValue("6D");
			h.addAllowedValue("6E");
			h.addAllowedValue("6F");
			h.addAllowedValue("6G");
			h.addAllowedValue("6H");
			h.addAllowedValue("6I");
			h.addAllowedValue("6J");
			h.addAllowedValue("6K");
			h.addAllowedValue("6L");
			h.addAllowedValue("6M");
			h.addAllowedValue("6N");
			h.addAllowedValue("6O");
			h.addAllowedValue("6P");
			h.addAllowedValue("6Q");
			h.addAllowedValue("6R");
			h.addAllowedValue("6S");
			h.addAllowedValue("6T");
			h.addAllowedValue("6U");
			h.addAllowedValue("6V");
			h.addAllowedValue("6W");
			h.addAllowedValue("6X");
			h.addAllowedValue("6Z");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("7A");
			h.addAllowedValue("7B");
			h.addAllowedValue("7C");
			h.addAllowedValue("7D");
			h.addAllowedValue("7E");
			h.addAllowedValue("7F");
			h.addAllowedValue("7G");
			h.addAllowedValue("7H");
			h.addAllowedValue("7I");
			h.addAllowedValue("7J");
			h.addAllowedValue("7K");
			h.addAllowedValue("7L");
			h.addAllowedValue("7M");
			h.addAllowedValue("7N");
			h.addAllowedValue("7O");
			h.addAllowedValue("7P");
			h.addAllowedValue("7Q");
			h.addAllowedValue("7R");
			h.addAllowedValue("7S");
			h.addAllowedValue("7T");
			h.addAllowedValue("7U");
			h.addAllowedValue("7V");
			h.addAllowedValue("7W");
			h.addAllowedValue("7X");
			h.addAllowedValue("7Y");
			h.addAllowedValue("7Z");
			h.addAllowedValue("70");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8A");
			h.addAllowedValue("8B");
			h.addAllowedValue("8C");
			h.addAllowedValue("8D");
			h.addAllowedValue("8E");
			h.addAllowedValue("8F");
			h.addAllowedValue("8G");
			h.addAllowedValue("8H");
			h.addAllowedValue("8I");
			h.addAllowedValue("8J");
			h.addAllowedValue("8K");
			h.addAllowedValue("8L");
			h.addAllowedValue("8M");
			h.addAllowedValue("8N");
			h.addAllowedValue("8O");
			h.addAllowedValue("8P");
			h.addAllowedValue("8Q");
			h.addAllowedValue("8R");
			h.addAllowedValue("8S");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9A");
			h.addAllowedValue("9C");
			h.addAllowedValue("9D");
			h.addAllowedValue("9E");
			h.addAllowedValue("9F");
			h.addAllowedValue("9H");
			h.addAllowedValue("9J");
			h.addAllowedValue("9K");
			h.addAllowedValue("9L");
			h.addAllowedValue("9M");
			h.addAllowedValue("9N");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement673 = new RtSimpleElement("673", "ID", h);
		}
	
		return simpleElement673;
	}
	
	private RtSimpleElement simpleElement522;
	
	private RtSimpleElement simpleElement522() {
		if (simpleElement522 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Amount Qualifier Code";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AA");
			h.addAllowedValue("AAA");
			h.addAllowedValue("AAB");
			h.addAllowedValue("AAC");
			h.addAllowedValue("AAD");
			h.addAllowedValue("AAE");
			h.addAllowedValue("AAF");
			h.addAllowedValue("AAG");
			h.addAllowedValue("AAH");
			h.addAllowedValue("AAI");
			h.addAllowedValue("AAJ");
			h.addAllowedValue("AAK");
			h.addAllowedValue("AAL");
			h.addAllowedValue("AAM");
			h.addAllowedValue("AAN");
			h.addAllowedValue("AAO");
			h.addAllowedValue("AAP");
			h.addAllowedValue("AAQ");
			h.addAllowedValue("AAR");
			h.addAllowedValue("AAS");
			h.addAllowedValue("AAT");
			h.addAllowedValue("AAU");
			h.addAllowedValue("AAV");
			h.addAllowedValue("AAW");
			h.addAllowedValue("AAX");
			h.addAllowedValue("AAY");
			h.addAllowedValue("AAZ");
			h.addAllowedValue("AB");
			h.addAllowedValue("ABA");
			h.addAllowedValue("ABB");
			h.addAllowedValue("ABC");
			h.addAllowedValue("ABD");
			h.addAllowedValue("ABE");
			h.addAllowedValue("ABF");
			h.addAllowedValue("ABG");
			h.addAllowedValue("ABH");
			h.addAllowedValue("ABI");
			h.addAllowedValue("ABJ");
			h.addAllowedValue("ABK");
			h.addAllowedValue("ABL");
			h.addAllowedValue("ABM");
			h.addAllowedValue("ABN");
			h.addAllowedValue("ABO");
			h.addAllowedValue("ABP");
			h.addAllowedValue("ABQ");
			h.addAllowedValue("ABR");
			h.addAllowedValue("ABS");
			h.addAllowedValue("ABT");
			h.addAllowedValue("ABU");
			h.addAllowedValue("ABV");
			h.addAllowedValue("ABW");
			h.addAllowedValue("ABX");
			h.addAllowedValue("ABY");
			h.addAllowedValue("ABZ");
			h.addAllowedValue("AC");
			h.addAllowedValue("ACA");
			h.addAllowedValue("ACB");
			h.addAllowedValue("ACC");
			h.addAllowedValue("ACD");
			h.addAllowedValue("ACE");
			h.addAllowedValue("ACF");
			h.addAllowedValue("ACG");
			h.addAllowedValue("ACH");
			h.addAllowedValue("ACI");
			h.addAllowedValue("ACJ");
			h.addAllowedValue("ACK");
			h.addAllowedValue("ACL");
			h.addAllowedValue("ACM");
			h.addAllowedValue("ACN");
			h.addAllowedValue("ACO");
			h.addAllowedValue("ACP");
			h.addAllowedValue("ACQ");
			h.addAllowedValue("ACR");
			h.addAllowedValue("ACS");
			h.addAllowedValue("ACT");
			h.addAllowedValue("ACU");
			h.addAllowedValue("ACV");
			h.addAllowedValue("ACW");
			h.addAllowedValue("ACX");
			h.addAllowedValue("ACY");
			h.addAllowedValue("ACZ");
			h.addAllowedValue("AD");
			h.addAllowedValue("ADA");
			h.addAllowedValue("ADB");
			h.addAllowedValue("ADC");
			h.addAllowedValue("ADD");
			h.addAllowedValue("ADE");
			h.addAllowedValue("ADF");
			h.addAllowedValue("ADG");
			h.addAllowedValue("ADH");
			h.addAllowedValue("ADI");
			h.addAllowedValue("ADJ");
			h.addAllowedValue("ADK");
			h.addAllowedValue("ADL");
			h.addAllowedValue("ADM");
			h.addAllowedValue("ADN");
			h.addAllowedValue("ADO");
			h.addAllowedValue("ADP");
			h.addAllowedValue("ADQ");
			h.addAllowedValue("ADR");
			h.addAllowedValue("ADS");
			h.addAllowedValue("ADT");
			h.addAllowedValue("ADW");
			h.addAllowedValue("ADX");
			h.addAllowedValue("ADY");
			h.addAllowedValue("ADZ");
			h.addAllowedValue("AE");
			h.addAllowedValue("AEB");
			h.addAllowedValue("AEC");
			h.addAllowedValue("AED");
			h.addAllowedValue("AEE");
			h.addAllowedValue("AEF");
			h.addAllowedValue("AEG");
			h.addAllowedValue("AEH");
			h.addAllowedValue("AEI");
			h.addAllowedValue("AEJ");
			h.addAllowedValue("AEK");
			h.addAllowedValue("AEL");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AVE");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A0");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A8");
			h.addAllowedValue("A9");
			h.addAllowedValue("B");
			h.addAllowedValue("BA");
			h.addAllowedValue("BAA");
			h.addAllowedValue("BAB");
			h.addAllowedValue("BAC");
			h.addAllowedValue("BAD");
			h.addAllowedValue("BAE");
			h.addAllowedValue("BAF");
			h.addAllowedValue("BAG");
			h.addAllowedValue("BAH");
			h.addAllowedValue("BAI");
			h.addAllowedValue("BAJ");
			h.addAllowedValue("BAK");
			h.addAllowedValue("BAL");
			h.addAllowedValue("BAM");
			h.addAllowedValue("BAN");
			h.addAllowedValue("BAO");
			h.addAllowedValue("BAP");
			h.addAllowedValue("BAQ");
			h.addAllowedValue("BAR");
			h.addAllowedValue("BAS");
			h.addAllowedValue("BAT");
			h.addAllowedValue("BAU");
			h.addAllowedValue("BAV");
			h.addAllowedValue("BAW");
			h.addAllowedValue("BAX");
			h.addAllowedValue("BAY");
			h.addAllowedValue("BAZ");
			h.addAllowedValue("BB");
			h.addAllowedValue("BBA");
			h.addAllowedValue("BBB");
			h.addAllowedValue("BBC");
			h.addAllowedValue("BBD");
			h.addAllowedValue("BBE");
			h.addAllowedValue("BBF");
			h.addAllowedValue("BBG");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("BU");
			h.addAllowedValue("BV");
			h.addAllowedValue("BW");
			h.addAllowedValue("BX");
			h.addAllowedValue("BY");
			h.addAllowedValue("BZ");
			h.addAllowedValue("B0");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("B6");
			h.addAllowedValue("B7");
			h.addAllowedValue("B8");
			h.addAllowedValue("B9");
			h.addAllowedValue("C");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C0");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("C7");
			h.addAllowedValue("C8");
			h.addAllowedValue("C9");
			h.addAllowedValue("D");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("DV");
			h.addAllowedValue("DW");
			h.addAllowedValue("DX");
			h.addAllowedValue("DY");
			h.addAllowedValue("DZ");
			h.addAllowedValue("D0");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("D6");
			h.addAllowedValue("D7");
			h.addAllowedValue("D8");
			h.addAllowedValue("D9");
			h.addAllowedValue("E");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EH");
			h.addAllowedValue("EI");
			h.addAllowedValue("EJ");
			h.addAllowedValue("EK");
			h.addAllowedValue("EL");
			h.addAllowedValue("EM");
			h.addAllowedValue("EN");
			h.addAllowedValue("EO");
			h.addAllowedValue("EP");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("ET");
			h.addAllowedValue("EU");
			h.addAllowedValue("EV");
			h.addAllowedValue("EW");
			h.addAllowedValue("EX");
			h.addAllowedValue("EY");
			h.addAllowedValue("EZ");
			h.addAllowedValue("E0");
			h.addAllowedValue("E1");
			h.addAllowedValue("E2");
			h.addAllowedValue("E3");
			h.addAllowedValue("E4");
			h.addAllowedValue("E5");
			h.addAllowedValue("E6");
			h.addAllowedValue("E7");
			h.addAllowedValue("E8");
			h.addAllowedValue("E9");
			h.addAllowedValue("F");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FBA");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FK");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FN");
			h.addAllowedValue("FO");
			h.addAllowedValue("FP");
			h.addAllowedValue("FQ");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("FU");
			h.addAllowedValue("FV");
			h.addAllowedValue("FW");
			h.addAllowedValue("FX");
			h.addAllowedValue("FY");
			h.addAllowedValue("FZ");
			h.addAllowedValue("F0");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("F5");
			h.addAllowedValue("F6");
			h.addAllowedValue("F7");
			h.addAllowedValue("F8");
			h.addAllowedValue("F9");
			h.addAllowedValue("G");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GD");
			h.addAllowedValue("GE");
			h.addAllowedValue("GF");
			h.addAllowedValue("GG");
			h.addAllowedValue("GH");
			h.addAllowedValue("GI");
			h.addAllowedValue("GJ");
			h.addAllowedValue("GK");
			h.addAllowedValue("GL");
			h.addAllowedValue("GM");
			h.addAllowedValue("GN");
			h.addAllowedValue("GO");
			h.addAllowedValue("GP");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("GT");
			h.addAllowedValue("GU");
			h.addAllowedValue("GV");
			h.addAllowedValue("GW");
			h.addAllowedValue("GX");
			h.addAllowedValue("GY");
			h.addAllowedValue("GZ");
			h.addAllowedValue("G0");
			h.addAllowedValue("G1");
			h.addAllowedValue("G2");
			h.addAllowedValue("G3");
			h.addAllowedValue("G4");
			h.addAllowedValue("G5");
			h.addAllowedValue("G6");
			h.addAllowedValue("G7");
			h.addAllowedValue("G8");
			h.addAllowedValue("G9");
			h.addAllowedValue("H");
			h.addAllowedValue("HA");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HD");
			h.addAllowedValue("HE");
			h.addAllowedValue("HF");
			h.addAllowedValue("HG");
			h.addAllowedValue("HH");
			h.addAllowedValue("HI");
			h.addAllowedValue("HJ");
			h.addAllowedValue("HK");
			h.addAllowedValue("HL");
			h.addAllowedValue("HM");
			h.addAllowedValue("HN");
			h.addAllowedValue("HO");
			h.addAllowedValue("HP");
			h.addAllowedValue("HQ");
			h.addAllowedValue("HR");
			h.addAllowedValue("HS");
			h.addAllowedValue("HT");
			h.addAllowedValue("HU");
			h.addAllowedValue("HV");
			h.addAllowedValue("HW");
			h.addAllowedValue("HX");
			h.addAllowedValue("HY");
			h.addAllowedValue("HZ");
			h.addAllowedValue("H0");
			h.addAllowedValue("H1");
			h.addAllowedValue("H2");
			h.addAllowedValue("H3");
			h.addAllowedValue("H4");
			h.addAllowedValue("H5");
			h.addAllowedValue("H6");
			h.addAllowedValue("H7");
			h.addAllowedValue("H8");
			h.addAllowedValue("H9");
			h.addAllowedValue("I");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IE");
			h.addAllowedValue("IF");
			h.addAllowedValue("IG");
			h.addAllowedValue("IH");
			h.addAllowedValue("II");
			h.addAllowedValue("IJ");
			h.addAllowedValue("IK");
			h.addAllowedValue("IL");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IO");
			h.addAllowedValue("IP");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IR");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("IU");
			h.addAllowedValue("IV");
			h.addAllowedValue("IW");
			h.addAllowedValue("IX");
			h.addAllowedValue("IY");
			h.addAllowedValue("IZ");
			h.addAllowedValue("I0");
			h.addAllowedValue("I1");
			h.addAllowedValue("I2");
			h.addAllowedValue("I3");
			h.addAllowedValue("I4");
			h.addAllowedValue("I5");
			h.addAllowedValue("I6");
			h.addAllowedValue("I7");
			h.addAllowedValue("I8");
			h.addAllowedValue("I9");
			h.addAllowedValue("J");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JC");
			h.addAllowedValue("JD");
			h.addAllowedValue("JE");
			h.addAllowedValue("JF");
			h.addAllowedValue("JG");
			h.addAllowedValue("JH");
			h.addAllowedValue("JI");
			h.addAllowedValue("JJ");
			h.addAllowedValue("JK");
			h.addAllowedValue("JL");
			h.addAllowedValue("JM");
			h.addAllowedValue("JN");
			h.addAllowedValue("JO");
			h.addAllowedValue("JP");
			h.addAllowedValue("JQ");
			h.addAllowedValue("JR");
			h.addAllowedValue("JS");
			h.addAllowedValue("JT");
			h.addAllowedValue("JU");
			h.addAllowedValue("JV");
			h.addAllowedValue("JW");
			h.addAllowedValue("JX");
			h.addAllowedValue("JY");
			h.addAllowedValue("JZ");
			h.addAllowedValue("J0");
			h.addAllowedValue("J1");
			h.addAllowedValue("J2");
			h.addAllowedValue("J3");
			h.addAllowedValue("J4");
			h.addAllowedValue("J5");
			h.addAllowedValue("J6");
			h.addAllowedValue("J7");
			h.addAllowedValue("J8");
			h.addAllowedValue("J9");
			h.addAllowedValue("K");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KN");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KR");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("KU");
			h.addAllowedValue("KV");
			h.addAllowedValue("KW");
			h.addAllowedValue("KX");
			h.addAllowedValue("KY");
			h.addAllowedValue("KZ");
			h.addAllowedValue("K0");
			h.addAllowedValue("K1");
			h.addAllowedValue("K2");
			h.addAllowedValue("K3");
			h.addAllowedValue("K4");
			h.addAllowedValue("K5");
			h.addAllowedValue("K6");
			h.addAllowedValue("K7");
			h.addAllowedValue("K8");
			h.addAllowedValue("K9");
			h.addAllowedValue("L");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LF");
			h.addAllowedValue("LG");
			h.addAllowedValue("LH");
			h.addAllowedValue("LI");
			h.addAllowedValue("LJ");
			h.addAllowedValue("LK");
			h.addAllowedValue("LL");
			h.addAllowedValue("LM");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LOW");
			h.addAllowedValue("LP");
			h.addAllowedValue("LQ");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LU");
			h.addAllowedValue("LV");
			h.addAllowedValue("LW");
			h.addAllowedValue("LX");
			h.addAllowedValue("LY");
			h.addAllowedValue("LZ");
			h.addAllowedValue("L0");
			h.addAllowedValue("L1");
			h.addAllowedValue("L2");
			h.addAllowedValue("L3");
			h.addAllowedValue("L4");
			h.addAllowedValue("L5");
			h.addAllowedValue("L6");
			h.addAllowedValue("L7");
			h.addAllowedValue("L8");
			h.addAllowedValue("L9");
			h.addAllowedValue("M");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MP");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("MU");
			h.addAllowedValue("MV");
			h.addAllowedValue("MW");
			h.addAllowedValue("MX");
			h.addAllowedValue("MY");
			h.addAllowedValue("MZ");
			h.addAllowedValue("M0");
			h.addAllowedValue("M1");
			h.addAllowedValue("M2");
			h.addAllowedValue("M3");
			h.addAllowedValue("M4");
			h.addAllowedValue("M5");
			h.addAllowedValue("M6");
			h.addAllowedValue("M7");
			h.addAllowedValue("M8");
			h.addAllowedValue("M9");
			h.addAllowedValue("N");
			h.addAllowedValue("NA");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NG");
			h.addAllowedValue("NH");
			h.addAllowedValue("NI");
			h.addAllowedValue("NJ");
			h.addAllowedValue("NK");
			h.addAllowedValue("NL");
			h.addAllowedValue("NM");
			h.addAllowedValue("NN");
			h.addAllowedValue("NO");
			h.addAllowedValue("NP");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("NU");
			h.addAllowedValue("NV");
			h.addAllowedValue("NW");
			h.addAllowedValue("NX");
			h.addAllowedValue("NY");
			h.addAllowedValue("NZ");
			h.addAllowedValue("N0");
			h.addAllowedValue("N1");
			h.addAllowedValue("N2");
			h.addAllowedValue("N3");
			h.addAllowedValue("N4");
			h.addAllowedValue("N5");
			h.addAllowedValue("N6");
			h.addAllowedValue("N7");
			h.addAllowedValue("N8");
			h.addAllowedValue("N9");
			h.addAllowedValue("O");
			h.addAllowedValue("OA");
			h.addAllowedValue("OB");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("OE");
			h.addAllowedValue("OF");
			h.addAllowedValue("OG");
			h.addAllowedValue("OH");
			h.addAllowedValue("OI");
			h.addAllowedValue("OJ");
			h.addAllowedValue("OK");
			h.addAllowedValue("OL");
			h.addAllowedValue("OM");
			h.addAllowedValue("ON");
			h.addAllowedValue("OO");
			h.addAllowedValue("OP");
			h.addAllowedValue("OQ");
			h.addAllowedValue("OR");
			h.addAllowedValue("OS");
			h.addAllowedValue("OT");
			h.addAllowedValue("OU");
			h.addAllowedValue("OV");
			h.addAllowedValue("OW");
			h.addAllowedValue("OX");
			h.addAllowedValue("OY");
			h.addAllowedValue("OZ");
			h.addAllowedValue("O0");
			h.addAllowedValue("O1");
			h.addAllowedValue("O2");
			h.addAllowedValue("O3");
			h.addAllowedValue("O4");
			h.addAllowedValue("O5");
			h.addAllowedValue("O6");
			h.addAllowedValue("O7");
			h.addAllowedValue("O8");
			h.addAllowedValue("O9");
			h.addAllowedValue("P");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PCC");
			h.addAllowedValue("PCS");
			h.addAllowedValue("PCV");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P0");
			h.addAllowedValue("P1");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P6");
			h.addAllowedValue("P7");
			h.addAllowedValue("P8");
			h.addAllowedValue("P9");
			h.addAllowedValue("Q");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QF");
			h.addAllowedValue("QG");
			h.addAllowedValue("QH");
			h.addAllowedValue("QI");
			h.addAllowedValue("QJ");
			h.addAllowedValue("QK");
			h.addAllowedValue("QL");
			h.addAllowedValue("QM");
			h.addAllowedValue("QN");
			h.addAllowedValue("QO");
			h.addAllowedValue("QP");
			h.addAllowedValue("QQ");
			h.addAllowedValue("QR");
			h.addAllowedValue("QS");
			h.addAllowedValue("QT");
			h.addAllowedValue("QU");
			h.addAllowedValue("QV");
			h.addAllowedValue("QW");
			h.addAllowedValue("QX");
			h.addAllowedValue("QY");
			h.addAllowedValue("QZ");
			h.addAllowedValue("Q0");
			h.addAllowedValue("Q1");
			h.addAllowedValue("Q2");
			h.addAllowedValue("Q3");
			h.addAllowedValue("Q4");
			h.addAllowedValue("Q5");
			h.addAllowedValue("Q6");
			h.addAllowedValue("Q7");
			h.addAllowedValue("Q8");
			h.addAllowedValue("Q9");
			h.addAllowedValue("R");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RV");
			h.addAllowedValue("RW");
			h.addAllowedValue("RX");
			h.addAllowedValue("RY");
			h.addAllowedValue("RZ");
			h.addAllowedValue("R0");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("R9");
			h.addAllowedValue("S");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SOF");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SY");
			h.addAllowedValue("SZ");
			h.addAllowedValue("S0");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("T");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TU");
			h.addAllowedValue("TW");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("TZ");
			h.addAllowedValue("T0");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("T4");
			h.addAllowedValue("T5");
			h.addAllowedValue("T6");
			h.addAllowedValue("T7");
			h.addAllowedValue("T8");
			h.addAllowedValue("T9");
			h.addAllowedValue("U");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("UF");
			h.addAllowedValue("UG");
			h.addAllowedValue("UH");
			h.addAllowedValue("UI");
			h.addAllowedValue("UJ");
			h.addAllowedValue("UK");
			h.addAllowedValue("UL");
			h.addAllowedValue("UM");
			h.addAllowedValue("UN");
			h.addAllowedValue("UO");
			h.addAllowedValue("UP");
			h.addAllowedValue("UPF");
			h.addAllowedValue("UQ");
			h.addAllowedValue("UR");
			h.addAllowedValue("US");
			h.addAllowedValue("UT");
			h.addAllowedValue("UU");
			h.addAllowedValue("UV");
			h.addAllowedValue("UW");
			h.addAllowedValue("UX");
			h.addAllowedValue("UY");
			h.addAllowedValue("UZ");
			h.addAllowedValue("U0");
			h.addAllowedValue("U1");
			h.addAllowedValue("U2");
			h.addAllowedValue("U3");
			h.addAllowedValue("U4");
			h.addAllowedValue("U5");
			h.addAllowedValue("U6");
			h.addAllowedValue("U7");
			h.addAllowedValue("U8");
			h.addAllowedValue("U9");
			h.addAllowedValue("V");
			h.addAllowedValue("VA");
			h.addAllowedValue("VB");
			h.addAllowedValue("VC");
			h.addAllowedValue("VD");
			h.addAllowedValue("VE");
			h.addAllowedValue("VES");
			h.addAllowedValue("VF");
			h.addAllowedValue("VG");
			h.addAllowedValue("VH");
			h.addAllowedValue("VI");
			h.addAllowedValue("VJ");
			h.addAllowedValue("VK");
			h.addAllowedValue("VL");
			h.addAllowedValue("VM");
			h.addAllowedValue("VN");
			h.addAllowedValue("VO");
			h.addAllowedValue("VP");
			h.addAllowedValue("VQ");
			h.addAllowedValue("VR");
			h.addAllowedValue("VS");
			h.addAllowedValue("VT");
			h.addAllowedValue("VU");
			h.addAllowedValue("VV");
			h.addAllowedValue("VW");
			h.addAllowedValue("VX");
			h.addAllowedValue("VY");
			h.addAllowedValue("VZ");
			h.addAllowedValue("V0");
			h.addAllowedValue("V1");
			h.addAllowedValue("V2");
			h.addAllowedValue("V3");
			h.addAllowedValue("V4");
			h.addAllowedValue("V5");
			h.addAllowedValue("V6");
			h.addAllowedValue("V7");
			h.addAllowedValue("V8");
			h.addAllowedValue("V9");
			h.addAllowedValue("W");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WC");
			h.addAllowedValue("WD");
			h.addAllowedValue("WE");
			h.addAllowedValue("WF");
			h.addAllowedValue("WG");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WJ");
			h.addAllowedValue("WK");
			h.addAllowedValue("WL");
			h.addAllowedValue("WM");
			h.addAllowedValue("WN");
			h.addAllowedValue("WO");
			h.addAllowedValue("WP");
			h.addAllowedValue("WQ");
			h.addAllowedValue("WR");
			h.addAllowedValue("WS");
			h.addAllowedValue("WT");
			h.addAllowedValue("WU");
			h.addAllowedValue("WV");
			h.addAllowedValue("WW");
			h.addAllowedValue("WX");
			h.addAllowedValue("WY");
			h.addAllowedValue("WZ");
			h.addAllowedValue("W0");
			h.addAllowedValue("W1");
			h.addAllowedValue("W2");
			h.addAllowedValue("W3");
			h.addAllowedValue("W4");
			h.addAllowedValue("W5");
			h.addAllowedValue("W6");
			h.addAllowedValue("W7");
			h.addAllowedValue("W8");
			h.addAllowedValue("W9");
			h.addAllowedValue("X");
			h.addAllowedValue("XA");
			h.addAllowedValue("XB");
			h.addAllowedValue("XC");
			h.addAllowedValue("XD");
			h.addAllowedValue("XE");
			h.addAllowedValue("XF");
			h.addAllowedValue("XG");
			h.addAllowedValue("XH");
			h.addAllowedValue("XI");
			h.addAllowedValue("XJ");
			h.addAllowedValue("XK");
			h.addAllowedValue("XL");
			h.addAllowedValue("XM");
			h.addAllowedValue("XN");
			h.addAllowedValue("XO");
			h.addAllowedValue("XP");
			h.addAllowedValue("XQ");
			h.addAllowedValue("XR");
			h.addAllowedValue("XS");
			h.addAllowedValue("XT");
			h.addAllowedValue("XU");
			h.addAllowedValue("XV");
			h.addAllowedValue("XW");
			h.addAllowedValue("XX");
			h.addAllowedValue("XY");
			h.addAllowedValue("XZ");
			h.addAllowedValue("X0");
			h.addAllowedValue("X1");
			h.addAllowedValue("X2");
			h.addAllowedValue("X3");
			h.addAllowedValue("X4");
			h.addAllowedValue("X5");
			h.addAllowedValue("X6");
			h.addAllowedValue("X7");
			h.addAllowedValue("X8");
			h.addAllowedValue("X9");
			h.addAllowedValue("Y");
			h.addAllowedValue("YA");
			h.addAllowedValue("YB");
			h.addAllowedValue("YC");
			h.addAllowedValue("YD");
			h.addAllowedValue("YE");
			h.addAllowedValue("YF");
			h.addAllowedValue("YG");
			h.addAllowedValue("YH");
			h.addAllowedValue("YI");
			h.addAllowedValue("YJ");
			h.addAllowedValue("YK");
			h.addAllowedValue("YL");
			h.addAllowedValue("YM");
			h.addAllowedValue("YN");
			h.addAllowedValue("YO");
			h.addAllowedValue("YQ");
			h.addAllowedValue("YR");
			h.addAllowedValue("YS");
			h.addAllowedValue("YT");
			h.addAllowedValue("YU");
			h.addAllowedValue("YV");
			h.addAllowedValue("YW");
			h.addAllowedValue("YX");
			h.addAllowedValue("YY");
			h.addAllowedValue("YZ");
			h.addAllowedValue("Y1");
			h.addAllowedValue("Y2");
			h.addAllowedValue("Y3");
			h.addAllowedValue("Y4");
			h.addAllowedValue("Y5");
			h.addAllowedValue("Y6");
			h.addAllowedValue("Y7");
			h.addAllowedValue("Y8");
			h.addAllowedValue("Y9");
			h.addAllowedValue("Z");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZD");
			h.addAllowedValue("ZE");
			h.addAllowedValue("ZF");
			h.addAllowedValue("ZG");
			h.addAllowedValue("ZH");
			h.addAllowedValue("ZI");
			h.addAllowedValue("ZJ");
			h.addAllowedValue("ZK");
			h.addAllowedValue("ZL");
			h.addAllowedValue("ZM");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZO");
			h.addAllowedValue("ZP");
			h.addAllowedValue("ZQ");
			h.addAllowedValue("ZR");
			h.addAllowedValue("ZS");
			h.addAllowedValue("ZT");
			h.addAllowedValue("ZU");
			h.addAllowedValue("ZV");
			h.addAllowedValue("ZW");
			h.addAllowedValue("ZX");
			h.addAllowedValue("ZY");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("Z0");
			h.addAllowedValue("Z1");
			h.addAllowedValue("Z2");
			h.addAllowedValue("Z3");
			h.addAllowedValue("Z4");
			h.addAllowedValue("Z5");
			h.addAllowedValue("Z6");
			h.addAllowedValue("Z7");
			h.addAllowedValue("Z8");
			h.addAllowedValue("Z9");
			h.addAllowedValue("0A");
			h.addAllowedValue("0B");
			h.addAllowedValue("0C");
			h.addAllowedValue("0D");
			h.addAllowedValue("0E");
			h.addAllowedValue("0F");
			h.addAllowedValue("0G");
			h.addAllowedValue("0H");
			h.addAllowedValue("0I");
			h.addAllowedValue("0J");
			h.addAllowedValue("0K");
			h.addAllowedValue("0L");
			h.addAllowedValue("0M");
			h.addAllowedValue("0N");
			h.addAllowedValue("0P");
			h.addAllowedValue("0Q");
			h.addAllowedValue("0R");
			h.addAllowedValue("0S");
			h.addAllowedValue("0T");
			h.addAllowedValue("0U");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("1");
			h.addAllowedValue("1A");
			h.addAllowedValue("1B");
			h.addAllowedValue("1C");
			h.addAllowedValue("1D");
			h.addAllowedValue("1E");
			h.addAllowedValue("1F");
			h.addAllowedValue("1G");
			h.addAllowedValue("1H");
			h.addAllowedValue("1J");
			h.addAllowedValue("1K");
			h.addAllowedValue("1L");
			h.addAllowedValue("1M");
			h.addAllowedValue("1N");
			h.addAllowedValue("1P");
			h.addAllowedValue("1Q");
			h.addAllowedValue("1R");
			h.addAllowedValue("1S");
			h.addAllowedValue("1T");
			h.addAllowedValue("1U");
			h.addAllowedValue("1V");
			h.addAllowedValue("1W");
			h.addAllowedValue("1X");
			h.addAllowedValue("1Y");
			h.addAllowedValue("1Z");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("2A");
			h.addAllowedValue("2B");
			h.addAllowedValue("2C");
			h.addAllowedValue("2D");
			h.addAllowedValue("2E");
			h.addAllowedValue("2F");
			h.addAllowedValue("2G");
			h.addAllowedValue("2H");
			h.addAllowedValue("2I");
			h.addAllowedValue("2J");
			h.addAllowedValue("2K");
			h.addAllowedValue("2L");
			h.addAllowedValue("2M");
			h.addAllowedValue("2N");
			h.addAllowedValue("2P");
			h.addAllowedValue("2Q");
			h.addAllowedValue("2R");
			h.addAllowedValue("2S");
			h.addAllowedValue("2T");
			h.addAllowedValue("2U");
			h.addAllowedValue("2V");
			h.addAllowedValue("2W");
			h.addAllowedValue("2X");
			h.addAllowedValue("2Y");
			h.addAllowedValue("2Z");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3");
			h.addAllowedValue("3A");
			h.addAllowedValue("3B");
			h.addAllowedValue("3C");
			h.addAllowedValue("3D");
			h.addAllowedValue("3E");
			h.addAllowedValue("3F");
			h.addAllowedValue("3G");
			h.addAllowedValue("3H");
			h.addAllowedValue("3I");
			h.addAllowedValue("3J");
			h.addAllowedValue("3K");
			h.addAllowedValue("3L");
			h.addAllowedValue("3M");
			h.addAllowedValue("3N");
			h.addAllowedValue("3O");
			h.addAllowedValue("3P");
			h.addAllowedValue("3Q");
			h.addAllowedValue("3R");
			h.addAllowedValue("3S");
			h.addAllowedValue("3T");
			h.addAllowedValue("3U");
			h.addAllowedValue("3V");
			h.addAllowedValue("3W");
			h.addAllowedValue("3X");
			h.addAllowedValue("3Y");
			h.addAllowedValue("3Z");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4");
			h.addAllowedValue("4A");
			h.addAllowedValue("4B");
			h.addAllowedValue("4C");
			h.addAllowedValue("4D");
			h.addAllowedValue("4E");
			h.addAllowedValue("4F");
			h.addAllowedValue("4G");
			h.addAllowedValue("4H");
			h.addAllowedValue("4I");
			h.addAllowedValue("4J");
			h.addAllowedValue("4K");
			h.addAllowedValue("4L");
			h.addAllowedValue("4M");
			h.addAllowedValue("4N");
			h.addAllowedValue("4O");
			h.addAllowedValue("4P");
			h.addAllowedValue("4Q");
			h.addAllowedValue("4R");
			h.addAllowedValue("4S");
			h.addAllowedValue("4T");
			h.addAllowedValue("4U");
			h.addAllowedValue("4V");
			h.addAllowedValue("4W");
			h.addAllowedValue("4X");
			h.addAllowedValue("4Y");
			h.addAllowedValue("4Z");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5");
			h.addAllowedValue("5A");
			h.addAllowedValue("5B");
			h.addAllowedValue("5C");
			h.addAllowedValue("5D");
			h.addAllowedValue("5E");
			h.addAllowedValue("5F");
			h.addAllowedValue("5G");
			h.addAllowedValue("5H");
			h.addAllowedValue("5I");
			h.addAllowedValue("5J");
			h.addAllowedValue("5K");
			h.addAllowedValue("5L");
			h.addAllowedValue("5M");
			h.addAllowedValue("5N");
			h.addAllowedValue("5O");
			h.addAllowedValue("5P");
			h.addAllowedValue("5Q");
			h.addAllowedValue("5R");
			h.addAllowedValue("5S");
			h.addAllowedValue("5T");
			h.addAllowedValue("5U");
			h.addAllowedValue("5V");
			h.addAllowedValue("5W");
			h.addAllowedValue("5X");
			h.addAllowedValue("5Y");
			h.addAllowedValue("5Z");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("6");
			h.addAllowedValue("6A");
			h.addAllowedValue("6B");
			h.addAllowedValue("6C");
			h.addAllowedValue("6D");
			h.addAllowedValue("6E");
			h.addAllowedValue("6F");
			h.addAllowedValue("6G");
			h.addAllowedValue("6H");
			h.addAllowedValue("6I");
			h.addAllowedValue("6J");
			h.addAllowedValue("6K");
			h.addAllowedValue("6L");
			h.addAllowedValue("6M");
			h.addAllowedValue("6N");
			h.addAllowedValue("6O");
			h.addAllowedValue("6P");
			h.addAllowedValue("6Q");
			h.addAllowedValue("6R");
			h.addAllowedValue("6S");
			h.addAllowedValue("6T");
			h.addAllowedValue("6U");
			h.addAllowedValue("6V");
			h.addAllowedValue("6W");
			h.addAllowedValue("6X");
			h.addAllowedValue("6Y");
			h.addAllowedValue("6Z");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("7");
			h.addAllowedValue("7A");
			h.addAllowedValue("7B");
			h.addAllowedValue("7C");
			h.addAllowedValue("7D");
			h.addAllowedValue("7E");
			h.addAllowedValue("7F");
			h.addAllowedValue("7G");
			h.addAllowedValue("7H");
			h.addAllowedValue("7I");
			h.addAllowedValue("7J");
			h.addAllowedValue("7K");
			h.addAllowedValue("7L");
			h.addAllowedValue("7M");
			h.addAllowedValue("7N");
			h.addAllowedValue("7O");
			h.addAllowedValue("7P");
			h.addAllowedValue("7Q");
			h.addAllowedValue("7R");
			h.addAllowedValue("7S");
			h.addAllowedValue("7T");
			h.addAllowedValue("7U");
			h.addAllowedValue("7V");
			h.addAllowedValue("7W");
			h.addAllowedValue("7X");
			h.addAllowedValue("7Y");
			h.addAllowedValue("7Z");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8");
			h.addAllowedValue("8A");
			h.addAllowedValue("8B");
			h.addAllowedValue("8C");
			h.addAllowedValue("8D");
			h.addAllowedValue("8E");
			h.addAllowedValue("8F");
			h.addAllowedValue("8G");
			h.addAllowedValue("8H");
			h.addAllowedValue("8I");
			h.addAllowedValue("8J");
			h.addAllowedValue("8K");
			h.addAllowedValue("8L");
			h.addAllowedValue("8M");
			h.addAllowedValue("8N");
			h.addAllowedValue("8O");
			h.addAllowedValue("8P");
			h.addAllowedValue("8Q");
			h.addAllowedValue("8R");
			h.addAllowedValue("8S");
			h.addAllowedValue("8T");
			h.addAllowedValue("8U");
			h.addAllowedValue("8V");
			h.addAllowedValue("8W");
			h.addAllowedValue("8X");
			h.addAllowedValue("8Y");
			h.addAllowedValue("8Z");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9");
			h.addAllowedValue("9A");
			h.addAllowedValue("9B");
			h.addAllowedValue("9C");
			h.addAllowedValue("9D");
			h.addAllowedValue("9E");
			h.addAllowedValue("9F");
			h.addAllowedValue("9G");
			h.addAllowedValue("9H");
			h.addAllowedValue("9I");
			h.addAllowedValue("9J");
			h.addAllowedValue("9K");
			h.addAllowedValue("9L");
			h.addAllowedValue("9M");
			h.addAllowedValue("9N");
			h.addAllowedValue("9O");
			h.addAllowedValue("9P");
			h.addAllowedValue("9Q");
			h.addAllowedValue("9R");
			h.addAllowedValue("9S");
			h.addAllowedValue("9T");
			h.addAllowedValue("9U");
			h.addAllowedValue("9V");
			h.addAllowedValue("9W");
			h.addAllowedValue("9X");
			h.addAllowedValue("9Y");
			h.addAllowedValue("9Z");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement522 = new RtSimpleElement("522", "ID", h);
		}
	
		return simpleElement522;
	}
	
	private RtSimpleElement simpleElement344;
	
	private RtSimpleElement simpleElement344() {
		if (simpleElement344 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Unit of Time Period or Interval";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AD");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AP");
			h.addAllowedValue("AY");
			h.addAllowedValue("BD");
			h.addAllowedValue("BM");
			h.addAllowedValue("BW");
			h.addAllowedValue("CC");
			h.addAllowedValue("CY");
			h.addAllowedValue("DA");
			h.addAllowedValue("DW");
			h.addAllowedValue("DY");
			h.addAllowedValue("EL");
			h.addAllowedValue("FY");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("HR");
			h.addAllowedValue("ID");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("LN");
			h.addAllowedValue("LT");
			h.addAllowedValue("MD");
			h.addAllowedValue("MI");
			h.addAllowedValue("MO");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("NX");
			h.addAllowedValue("PA");
			h.addAllowedValue("PD");
			h.addAllowedValue("PM");
			h.addAllowedValue("PR");
			h.addAllowedValue("QY");
			h.addAllowedValue("Q1");
			h.addAllowedValue("Q2");
			h.addAllowedValue("Q3");
			h.addAllowedValue("Q4");
			h.addAllowedValue("SA");
			h.addAllowedValue("SD");
			h.addAllowedValue("SH");
			h.addAllowedValue("SM");
			h.addAllowedValue("SP");
			h.addAllowedValue("TY");
			h.addAllowedValue("WK");
			h.addAllowedValue("WW");
			h.addAllowedValue("WY");
			h.addAllowedValue("YD");
			h.addAllowedValue("ZZ");
			simpleElement344 = new RtSimpleElement("344", "ID", h);
		}
	
		return simpleElement344;
	}
	
	private RtSimpleElement simpleElement1004;
	
	private RtSimpleElement simpleElement1004() {
		if (simpleElement1004 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Percent Qualifier";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AP");
			h.addAllowedValue("AR");
			h.addAllowedValue("AT");
			h.addAllowedValue("B");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BP");
			h.addAllowedValue("BS");
			h.addAllowedValue("BU");
			h.addAllowedValue("C");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CH");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CU");
			h.addAllowedValue("D");
			h.addAllowedValue("DF");
			h.addAllowedValue("DY");
			h.addAllowedValue("E");
			h.addAllowedValue("EA");
			h.addAllowedValue("EF");
			h.addAllowedValue("EP");
			h.addAllowedValue("F");
			h.addAllowedValue("FT");
			h.addAllowedValue("FV");
			h.addAllowedValue("GA");
			h.addAllowedValue("IA");
			h.addAllowedValue("IN");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("LM");
			h.addAllowedValue("M");
			h.addAllowedValue("MA");
			h.addAllowedValue("MN");
			h.addAllowedValue("MS");
			h.addAllowedValue("MX");
			h.addAllowedValue("N");
			h.addAllowedValue("NA");
			h.addAllowedValue("NH");
			h.addAllowedValue("O");
			h.addAllowedValue("OC");
			h.addAllowedValue("OF");
			h.addAllowedValue("OH");
			h.addAllowedValue("OP");
			h.addAllowedValue("P");
			h.addAllowedValue("PA");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PF");
			h.addAllowedValue("PH");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PP");
			h.addAllowedValue("PR");
			h.addAllowedValue("PT");
			h.addAllowedValue("PV");
			h.addAllowedValue("R");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RI");
			h.addAllowedValue("RL");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("S");
			h.addAllowedValue("SA");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("T");
			h.addAllowedValue("TP");
			h.addAllowedValue("W");
			h.addAllowedValue("WI");
			h.addAllowedValue("WK");
			h.addAllowedValue("X");
			h.addAllowedValue("XT");
			h.addAllowedValue("X1");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("3");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("4");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("59");
			h.addAllowedValue("6");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("7");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement1004 = new RtSimpleElement("1004", "ID", h);
		}
	
		return simpleElement1004;
	}
	
	private RtSimpleElement simpleElement954;
	
	private RtSimpleElement simpleElement954() {
		if (simpleElement954 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Percent";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement954 = new RtSimpleElement("954", "R", h);
		}
	
		return simpleElement954;
	}
	
	private RtSimpleElement simpleElement1073;
	
	private RtSimpleElement simpleElement1073() {
		if (simpleElement1073 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Yes/No Condition or Response Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("N");
			h.addAllowedValue("U");
			h.addAllowedValue("W");
			h.addAllowedValue("Y");
			simpleElement1073 = new RtSimpleElement("1073", "ID", h);
		}
	
		return simpleElement1073;
	}
	
	private RtSimpleElement simpleElement563;
	
	private RtSimpleElement simpleElement563() {
		if (simpleElement563 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Sales Requirement Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("AI");
			h.addAllowedValue("AS");
			h.addAllowedValue("B");
			h.addAllowedValue("BC");
			h.addAllowedValue("BK");
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			h.addAllowedValue("E");
			h.addAllowedValue("EI");
			h.addAllowedValue("F");
			h.addAllowedValue("FT");
			h.addAllowedValue("GS");
			h.addAllowedValue("IP");
			h.addAllowedValue("IS");
			h.addAllowedValue("K");
			h.addAllowedValue("LS");
			h.addAllowedValue("MY");
			h.addAllowedValue("N");
			h.addAllowedValue("NS");
			h.addAllowedValue("O");
			h.addAllowedValue("P");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("Q");
			h.addAllowedValue("QB");
			h.addAllowedValue("QE");
			h.addAllowedValue("QI");
			h.addAllowedValue("QM");
			h.addAllowedValue("QP");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			h.addAllowedValue("SC");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SI");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("T");
			h.addAllowedValue("UC");
			h.addAllowedValue("UL");
			h.addAllowedValue("UP");
			h.addAllowedValue("W");
			h.addAllowedValue("WY");
			h.addAllowedValue("Y");
			h.addAllowedValue("YI");
			h.addAllowedValue("Z");
			h.addAllowedValue("8A");
			simpleElement563 = new RtSimpleElement("563", "ID", h);
		}
	
		return simpleElement563;
	}
	
	private RtSimpleElement simpleElement306;
	
	private RtSimpleElement simpleElement306() {
		if (simpleElement306 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Action Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AL");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("B");
			h.addAllowedValue("BD");
			h.addAllowedValue("BI");
			h.addAllowedValue("BO");
			h.addAllowedValue("C");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CX");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("D");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DP");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DX");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("E");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EN");
			h.addAllowedValue("EP");
			h.addAllowedValue("ER");
			h.addAllowedValue("EV");
			h.addAllowedValue("EX");
			h.addAllowedValue("F");
			h.addAllowedValue("FA");
			h.addAllowedValue("FC");
			h.addAllowedValue("FI");
			h.addAllowedValue("FO");
			h.addAllowedValue("FR");
			h.addAllowedValue("F1");
			h.addAllowedValue("G");
			h.addAllowedValue("GR");
			h.addAllowedValue("H");
			h.addAllowedValue("HR");
			h.addAllowedValue("I");
			h.addAllowedValue("IA");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("I1");
			h.addAllowedValue("J");
			h.addAllowedValue("JA");
			h.addAllowedValue("JO");
			h.addAllowedValue("JU");
			h.addAllowedValue("K");
			h.addAllowedValue("KA");
			h.addAllowedValue("L");
			h.addAllowedValue("LC");
			h.addAllowedValue("LQ");
			h.addAllowedValue("M");
			h.addAllowedValue("ME");
			h.addAllowedValue("MO");
			h.addAllowedValue("N");
			h.addAllowedValue("NA");
			h.addAllowedValue("ND");
			h.addAllowedValue("NP");
			h.addAllowedValue("NS");
			h.addAllowedValue("O");
			h.addAllowedValue("OD");
			h.addAllowedValue("OP");
			h.addAllowedValue("OR");
			h.addAllowedValue("OT");
			h.addAllowedValue("P");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PF");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("P1");
			h.addAllowedValue("Q");
			h.addAllowedValue("R");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RV");
			h.addAllowedValue("RW");
			h.addAllowedValue("RX");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("R9");
			h.addAllowedValue("S");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SL");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SZ");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("T");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TG");
			h.addAllowedValue("TN");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TU");
			h.addAllowedValue("U");
			h.addAllowedValue("V");
			h.addAllowedValue("VA");
			h.addAllowedValue("W");
			h.addAllowedValue("WD");
			h.addAllowedValue("WI");
			h.addAllowedValue("WQ");
			h.addAllowedValue("WV");
			h.addAllowedValue("W1");
			h.addAllowedValue("X");
			h.addAllowedValue("Y");
			h.addAllowedValue("Z");
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("6");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("7");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9");
			h.addAllowedValue("90");
			simpleElement306 = new RtSimpleElement("306", "ID", h);
		}
	
		return simpleElement306;
	}
	
	private RtSimpleElement simpleElement610;
	
	private RtSimpleElement simpleElement610() {
		if (simpleElement610 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Amount";
			h.minLength = 1;
			h.maxLength = 15;
			
			simpleElement610 = new RtSimpleElement("610", "N2", h);
		}
	
		return simpleElement610;
	}
	
	private RtSimpleElement simpleElement508;
	
	private RtSimpleElement simpleElement508() {
		if (simpleElement508 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Account Number";
			h.minLength = 1;
			h.maxLength = 35;
			
			simpleElement508 = new RtSimpleElement("508", "AN", h);
		}
	
		return simpleElement508;
	}
	
	private RtSimpleElement simpleElement559;
	
	private RtSimpleElement simpleElement559() {
		if (simpleElement559 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Agency Qualifier Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BI");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CE");
			h.addAllowedValue("CI");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CO");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CU");
			h.addAllowedValue("CX");
			h.addAllowedValue("DA");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DI");
			h.addAllowedValue("DL");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DX");
			h.addAllowedValue("DY");
			h.addAllowedValue("DZ");
			h.addAllowedValue("EI");
			h.addAllowedValue("EP");
			h.addAllowedValue("ES");
			h.addAllowedValue("ET");
			h.addAllowedValue("EU");
			h.addAllowedValue("EX");
			h.addAllowedValue("FA");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("GC");
			h.addAllowedValue("GS");
			h.addAllowedValue("GU");
			h.addAllowedValue("HC");
			h.addAllowedValue("HI");
			h.addAllowedValue("HS");
			h.addAllowedValue("HU");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IS");
			h.addAllowedValue("JA");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LI");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("ME");
			h.addAllowedValue("MI");
			h.addAllowedValue("MP");
			h.addAllowedValue("MS");
			h.addAllowedValue("MV");
			h.addAllowedValue("NA");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NG");
			h.addAllowedValue("NI");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("NU");
			h.addAllowedValue("NW");
			h.addAllowedValue("OI");
			h.addAllowedValue("OP");
			h.addAllowedValue("OS");
			h.addAllowedValue("PA");
			h.addAllowedValue("PC");
			h.addAllowedValue("SA");
			h.addAllowedValue("SE");
			h.addAllowedValue("SL");
			h.addAllowedValue("SP");
			h.addAllowedValue("ST");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TI");
			h.addAllowedValue("TM");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TX");
			h.addAllowedValue("UC");
			h.addAllowedValue("UN");
			h.addAllowedValue("VI");
			h.addAllowedValue("WH");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			simpleElement559 = new RtSimpleElement("559", "ID", h);
		}
	
		return simpleElement559;
	}
	
	private RtSimpleElement simpleElement560;
	
	private RtSimpleElement simpleElement560() {
		if (simpleElement560 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Special Services Code";
			h.minLength = 2;
			h.maxLength = 10;
			
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AM");
			h.addAllowedValue("AO");
			h.addAllowedValue("A0010");
			h.addAllowedValue("A0020");
			h.addAllowedValue("A0030");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BOP");
			h.addAllowedValue("B0020");
			h.addAllowedValue("B0040");
			h.addAllowedValue("CA");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C0012");
			h.addAllowedValue("C0032");
			h.addAllowedValue("C0036");
			h.addAllowedValue("C0038");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("DA");
			h.addAllowedValue("DE");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DL");
			h.addAllowedValue("DS");
			h.addAllowedValue("DV");
			h.addAllowedValue("D0020");
			h.addAllowedValue("D0024");
			h.addAllowedValue("D0031");
			h.addAllowedValue("D0032");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("EG");
			h.addAllowedValue("EM");
			h.addAllowedValue("EN");
			h.addAllowedValue("ER");
			h.addAllowedValue("EU");
			h.addAllowedValue("EX");
			h.addAllowedValue("E0030");
			h.addAllowedValue("FG");
			h.addAllowedValue("FS");
			h.addAllowedValue("F1");
			h.addAllowedValue("GI");
			h.addAllowedValue("GP");
			h.addAllowedValue("GU");
			h.addAllowedValue("G0010");
			h.addAllowedValue("G0052");
			h.addAllowedValue("HC");
			h.addAllowedValue("HH");
			h.addAllowedValue("HS");
			h.addAllowedValue("H1");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IG");
			h.addAllowedValue("IK");
			h.addAllowedValue("IL");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IO");
			h.addAllowedValue("IP");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IR");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("I0012");
			h.addAllowedValue("I0013");
			h.addAllowedValue("I0021");
			h.addAllowedValue("I0022");
			h.addAllowedValue("KO");
			h.addAllowedValue("LA");
			h.addAllowedValue("LL");
			h.addAllowedValue("LS");
			h.addAllowedValue("L1");
			h.addAllowedValue("MI");
			h.addAllowedValue("ML");
			h.addAllowedValue("MNTAN");
			h.addAllowedValue("MNTMN");
			h.addAllowedValue("MNTON");
			h.addAllowedValue("M0010");
			h.addAllowedValue("M0042");
			h.addAllowedValue("NC");
			h.addAllowedValue("N0020");
			h.addAllowedValue("N0021");
			h.addAllowedValue("N0032");
			h.addAllowedValue("OA");
			h.addAllowedValue("ON");
			h.addAllowedValue("OP");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PL");
			h.addAllowedValue("PLI");
			h.addAllowedValue("PM");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PSF");
			h.addAllowedValue("P0012");
			h.addAllowedValue("P0014");
			h.addAllowedValue("P0016");
			h.addAllowedValue("P0018");
			h.addAllowedValue("P0022");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RM");
			h.addAllowedValue("RP");
			h.addAllowedValue("R0072");
			h.addAllowedValue("R0076");
			h.addAllowedValue("R0077");
			h.addAllowedValue("R0110");
			h.addAllowedValue("SD");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SLP");
			h.addAllowedValue("SPI");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("S0014");
			h.addAllowedValue("S0016");
			h.addAllowedValue("S0022");
			h.addAllowedValue("S0024");
			h.addAllowedValue("S0050");
			h.addAllowedValue("S0052");
			h.addAllowedValue("S0054");
			h.addAllowedValue("S0056");
			h.addAllowedValue("S0080");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("TC");
			h.addAllowedValue("TE");
			h.addAllowedValue("TH");
			h.addAllowedValue("TM");
			h.addAllowedValue("TO");
			h.addAllowedValue("T0070");
			h.addAllowedValue("T1");
			h.addAllowedValue("UN");
			h.addAllowedValue("US");
			h.addAllowedValue("V1");
			h.addAllowedValue("V2");
			h.addAllowedValue("WC");
			h.addAllowedValue("WH");
			h.addAllowedValue("W0010");
			h.addAllowedValue("XP");
			h.addAllowedValue("XX");
			h.addAllowedValue("X0010");
			h.addAllowedValue("YY");
			h.addAllowedValue("ZZ");
			simpleElement560 = new RtSimpleElement("560", "ID", h);
		}
	
		return simpleElement560;
	}
	
	private RtSimpleElement simpleElement566;
	
	private RtSimpleElement simpleElement566() {
		if (simpleElement566 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Product/Service Substitution Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("B0");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("X");
			h.addAllowedValue("Y");
			h.addAllowedValue("ZZ");
			simpleElement566 = new RtSimpleElement("566", "ID", h);
		}
	
		return simpleElement566;
	}
	
	private RtSimpleElement simpleElement23;
	
	private RtSimpleElement simpleElement23() {
		if (simpleElement23 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Commodity Code Qualifier";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("B");
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			h.addAllowedValue("E");
			h.addAllowedValue("F");
			h.addAllowedValue("G");
			h.addAllowedValue("H");
			h.addAllowedValue("I");
			h.addAllowedValue("J");
			h.addAllowedValue("K");
			h.addAllowedValue("L");
			h.addAllowedValue("M");
			h.addAllowedValue("N");
			h.addAllowedValue("P");
			h.addAllowedValue("Q");
			h.addAllowedValue("S");
			h.addAllowedValue("T");
			h.addAllowedValue("U");
			h.addAllowedValue("V");
			h.addAllowedValue("Z");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			simpleElement23 = new RtSimpleElement("23", "ID", h);
		}
	
		return simpleElement23;
	}
	
	private RtSimpleElement simpleElement22;
	
	private RtSimpleElement simpleElement22() {
		if (simpleElement22 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Commodity Code";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement22 = new RtSimpleElement("22", "AN", h);
		}
	
		return simpleElement22;
	}
	
	private RtSimpleElement simpleElement248;
	
	private RtSimpleElement simpleElement248() {
		if (simpleElement248 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Allowance or Charge Indicator";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("C");
			h.addAllowedValue("N");
			h.addAllowedValue("P");
			h.addAllowedValue("Q");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			simpleElement248 = new RtSimpleElement("248", "ID", h);
		}
	
		return simpleElement248;
	}
	
	private RtSimpleElement simpleElement1300;
	
	private RtSimpleElement simpleElement1300() {
		if (simpleElement1300 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Service, Promotion, Allowance, or Charge Code";
			h.minLength = 4;
			h.maxLength = 4;
			
			h.addAllowedValue("ADOW");
			h.addAllowedValue("ADRW");
			h.addAllowedValue("AFEE");
			h.addAllowedValue("ALPT");
			h.addAllowedValue("A010");
			h.addAllowedValue("A020");
			h.addAllowedValue("A030");
			h.addAllowedValue("A040");
			h.addAllowedValue("A050");
			h.addAllowedValue("A060");
			h.addAllowedValue("A070");
			h.addAllowedValue("A080");
			h.addAllowedValue("A090");
			h.addAllowedValue("A100");
			h.addAllowedValue("A110");
			h.addAllowedValue("A112");
			h.addAllowedValue("A120");
			h.addAllowedValue("A121");
			h.addAllowedValue("A122");
			h.addAllowedValue("A130");
			h.addAllowedValue("A140");
			h.addAllowedValue("A150");
			h.addAllowedValue("A160");
			h.addAllowedValue("A170");
			h.addAllowedValue("A172");
			h.addAllowedValue("A180");
			h.addAllowedValue("A190");
			h.addAllowedValue("A200");
			h.addAllowedValue("A210");
			h.addAllowedValue("A220");
			h.addAllowedValue("A230");
			h.addAllowedValue("A240");
			h.addAllowedValue("A250");
			h.addAllowedValue("A260");
			h.addAllowedValue("A270");
			h.addAllowedValue("A280");
			h.addAllowedValue("A290");
			h.addAllowedValue("A300");
			h.addAllowedValue("A310");
			h.addAllowedValue("A320");
			h.addAllowedValue("A330");
			h.addAllowedValue("A340");
			h.addAllowedValue("A350");
			h.addAllowedValue("A360");
			h.addAllowedValue("A370");
			h.addAllowedValue("A380");
			h.addAllowedValue("A390");
			h.addAllowedValue("A400");
			h.addAllowedValue("A410");
			h.addAllowedValue("A420");
			h.addAllowedValue("A430");
			h.addAllowedValue("A440");
			h.addAllowedValue("A445");
			h.addAllowedValue("A450");
			h.addAllowedValue("A460");
			h.addAllowedValue("A470");
			h.addAllowedValue("A480");
			h.addAllowedValue("A485");
			h.addAllowedValue("A490");
			h.addAllowedValue("A500");
			h.addAllowedValue("A510");
			h.addAllowedValue("A520");
			h.addAllowedValue("A530");
			h.addAllowedValue("A540");
			h.addAllowedValue("A550");
			h.addAllowedValue("A555");
			h.addAllowedValue("A560");
			h.addAllowedValue("A570");
			h.addAllowedValue("A580");
			h.addAllowedValue("A590");
			h.addAllowedValue("A600");
			h.addAllowedValue("A610");
			h.addAllowedValue("A620");
			h.addAllowedValue("A630");
			h.addAllowedValue("A640");
			h.addAllowedValue("A650");
			h.addAllowedValue("A658");
			h.addAllowedValue("A660");
			h.addAllowedValue("A670");
			h.addAllowedValue("A680");
			h.addAllowedValue("A690");
			h.addAllowedValue("A691");
			h.addAllowedValue("A700");
			h.addAllowedValue("A710");
			h.addAllowedValue("A720");
			h.addAllowedValue("A721");
			h.addAllowedValue("A730");
			h.addAllowedValue("A740");
			h.addAllowedValue("A750");
			h.addAllowedValue("A760");
			h.addAllowedValue("A770");
			h.addAllowedValue("A780");
			h.addAllowedValue("A790");
			h.addAllowedValue("A800");
			h.addAllowedValue("A810");
			h.addAllowedValue("A820");
			h.addAllowedValue("A830");
			h.addAllowedValue("A840");
			h.addAllowedValue("A850");
			h.addAllowedValue("A860");
			h.addAllowedValue("A870");
			h.addAllowedValue("A880");
			h.addAllowedValue("A890");
			h.addAllowedValue("A900");
			h.addAllowedValue("A910");
			h.addAllowedValue("A920");
			h.addAllowedValue("A930");
			h.addAllowedValue("A940");
			h.addAllowedValue("A950");
			h.addAllowedValue("A960");
			h.addAllowedValue("A970");
			h.addAllowedValue("A980");
			h.addAllowedValue("A990");
			h.addAllowedValue("BUAT");
			h.addAllowedValue("BURD");
			h.addAllowedValue("BU2T");
			h.addAllowedValue("BU4T");
			h.addAllowedValue("B000");
			h.addAllowedValue("B010");
			h.addAllowedValue("B015");
			h.addAllowedValue("B020");
			h.addAllowedValue("B030");
			h.addAllowedValue("B040");
			h.addAllowedValue("B050");
			h.addAllowedValue("B060");
			h.addAllowedValue("B070");
			h.addAllowedValue("B080");
			h.addAllowedValue("B090");
			h.addAllowedValue("B091");
			h.addAllowedValue("B100");
			h.addAllowedValue("B110");
			h.addAllowedValue("B120");
			h.addAllowedValue("B130");
			h.addAllowedValue("B140");
			h.addAllowedValue("B150");
			h.addAllowedValue("B160");
			h.addAllowedValue("B170");
			h.addAllowedValue("B180");
			h.addAllowedValue("B190");
			h.addAllowedValue("B200");
			h.addAllowedValue("B210");
			h.addAllowedValue("B220");
			h.addAllowedValue("B230");
			h.addAllowedValue("B240");
			h.addAllowedValue("B250");
			h.addAllowedValue("B260");
			h.addAllowedValue("B270");
			h.addAllowedValue("B280");
			h.addAllowedValue("B290");
			h.addAllowedValue("B300");
			h.addAllowedValue("B310");
			h.addAllowedValue("B320");
			h.addAllowedValue("B330");
			h.addAllowedValue("B340");
			h.addAllowedValue("B350");
			h.addAllowedValue("B360");
			h.addAllowedValue("B370");
			h.addAllowedValue("B380");
			h.addAllowedValue("B390");
			h.addAllowedValue("B400");
			h.addAllowedValue("B500");
			h.addAllowedValue("B510");
			h.addAllowedValue("B520");
			h.addAllowedValue("B530");
			h.addAllowedValue("B540");
			h.addAllowedValue("B550");
			h.addAllowedValue("B551");
			h.addAllowedValue("B560");
			h.addAllowedValue("B570");
			h.addAllowedValue("B580");
			h.addAllowedValue("B581");
			h.addAllowedValue("B590");
			h.addAllowedValue("B600");
			h.addAllowedValue("B610");
			h.addAllowedValue("B620");
			h.addAllowedValue("B630");
			h.addAllowedValue("B650");
			h.addAllowedValue("B660");
			h.addAllowedValue("B670");
			h.addAllowedValue("B680");
			h.addAllowedValue("B690");
			h.addAllowedValue("B700");
			h.addAllowedValue("B720");
			h.addAllowedValue("B730");
			h.addAllowedValue("B740");
			h.addAllowedValue("B742");
			h.addAllowedValue("B750");
			h.addAllowedValue("B760");
			h.addAllowedValue("B770");
			h.addAllowedValue("B775");
			h.addAllowedValue("B780");
			h.addAllowedValue("B785");
			h.addAllowedValue("B787");
			h.addAllowedValue("B790");
			h.addAllowedValue("B791");
			h.addAllowedValue("B800");
			h.addAllowedValue("B810");
			h.addAllowedValue("B820");
			h.addAllowedValue("B830");
			h.addAllowedValue("B840");
			h.addAllowedValue("B850");
			h.addAllowedValue("B860");
			h.addAllowedValue("B870");
			h.addAllowedValue("B872");
			h.addAllowedValue("B880");
			h.addAllowedValue("B881");
			h.addAllowedValue("B890");
			h.addAllowedValue("B900");
			h.addAllowedValue("B910");
			h.addAllowedValue("B911");
			h.addAllowedValue("B920");
			h.addAllowedValue("B930");
			h.addAllowedValue("B940");
			h.addAllowedValue("B950");
			h.addAllowedValue("B960");
			h.addAllowedValue("B970");
			h.addAllowedValue("B980");
			h.addAllowedValue("B990");
			h.addAllowedValue("B992");
			h.addAllowedValue("B994");
			h.addAllowedValue("B996");
			h.addAllowedValue("B998");
			h.addAllowedValue("CA2T");
			h.addAllowedValue("CA4T");
			h.addAllowedValue("CFCT");
			h.addAllowedValue("CFLT");
			h.addAllowedValue("CGTT");
			h.addAllowedValue("CLDT");
			h.addAllowedValue("COMM");
			h.addAllowedValue("CRLT");
			h.addAllowedValue("CTLT");
			h.addAllowedValue("CUFT");
			h.addAllowedValue("C000");
			h.addAllowedValue("C010");
			h.addAllowedValue("C020");
			h.addAllowedValue("C030");
			h.addAllowedValue("C040");
			h.addAllowedValue("C050");
			h.addAllowedValue("C060");
			h.addAllowedValue("C070");
			h.addAllowedValue("C080");
			h.addAllowedValue("C090");
			h.addAllowedValue("C100");
			h.addAllowedValue("C110");
			h.addAllowedValue("C120");
			h.addAllowedValue("C130");
			h.addAllowedValue("C140");
			h.addAllowedValue("C150");
			h.addAllowedValue("C160");
			h.addAllowedValue("C170");
			h.addAllowedValue("C180");
			h.addAllowedValue("C190");
			h.addAllowedValue("C200");
			h.addAllowedValue("C210");
			h.addAllowedValue("C220");
			h.addAllowedValue("C230");
			h.addAllowedValue("C231");
			h.addAllowedValue("C240");
			h.addAllowedValue("C250");
			h.addAllowedValue("C260");
			h.addAllowedValue("C270");
			h.addAllowedValue("C280");
			h.addAllowedValue("C290");
			h.addAllowedValue("C300");
			h.addAllowedValue("C310");
			h.addAllowedValue("C320");
			h.addAllowedValue("C330");
			h.addAllowedValue("C340");
			h.addAllowedValue("C350");
			h.addAllowedValue("C360");
			h.addAllowedValue("C370");
			h.addAllowedValue("C380");
			h.addAllowedValue("C390");
			h.addAllowedValue("C400");
			h.addAllowedValue("C401");
			h.addAllowedValue("C402");
			h.addAllowedValue("C410");
			h.addAllowedValue("C420");
			h.addAllowedValue("C430");
			h.addAllowedValue("C440");
			h.addAllowedValue("C450");
			h.addAllowedValue("C460");
			h.addAllowedValue("C470");
			h.addAllowedValue("C480");
			h.addAllowedValue("C490");
			h.addAllowedValue("C500");
			h.addAllowedValue("C510");
			h.addAllowedValue("C520");
			h.addAllowedValue("C530");
			h.addAllowedValue("C531");
			h.addAllowedValue("C540");
			h.addAllowedValue("C550");
			h.addAllowedValue("C560");
			h.addAllowedValue("C570");
			h.addAllowedValue("C580");
			h.addAllowedValue("C590");
			h.addAllowedValue("C600");
			h.addAllowedValue("C610");
			h.addAllowedValue("C630");
			h.addAllowedValue("C640");
			h.addAllowedValue("C650");
			h.addAllowedValue("C660");
			h.addAllowedValue("C670");
			h.addAllowedValue("C675");
			h.addAllowedValue("C680");
			h.addAllowedValue("C690");
			h.addAllowedValue("C700");
			h.addAllowedValue("C710");
			h.addAllowedValue("C720");
			h.addAllowedValue("C730");
			h.addAllowedValue("C740");
			h.addAllowedValue("C750");
			h.addAllowedValue("C760");
			h.addAllowedValue("C770");
			h.addAllowedValue("C780");
			h.addAllowedValue("C790");
			h.addAllowedValue("C800");
			h.addAllowedValue("C810");
			h.addAllowedValue("C820");
			h.addAllowedValue("C830");
			h.addAllowedValue("C840");
			h.addAllowedValue("C850");
			h.addAllowedValue("C860");
			h.addAllowedValue("C870");
			h.addAllowedValue("C880");
			h.addAllowedValue("C890");
			h.addAllowedValue("C900");
			h.addAllowedValue("C910");
			h.addAllowedValue("C920");
			h.addAllowedValue("C930");
			h.addAllowedValue("C940");
			h.addAllowedValue("C950");
			h.addAllowedValue("C960");
			h.addAllowedValue("C970");
			h.addAllowedValue("C980");
			h.addAllowedValue("C990");
			h.addAllowedValue("DCET");
			h.addAllowedValue("DCVT");
			h.addAllowedValue("DDZT");
			h.addAllowedValue("DEZT");
			h.addAllowedValue("DFDT");
			h.addAllowedValue("DGET");
			h.addAllowedValue("DOVT");
			h.addAllowedValue("DPDT");
			h.addAllowedValue("DPET");
			h.addAllowedValue("D000");
			h.addAllowedValue("D010");
			h.addAllowedValue("D015");
			h.addAllowedValue("D020");
			h.addAllowedValue("D025");
			h.addAllowedValue("D030");
			h.addAllowedValue("D040");
			h.addAllowedValue("D050");
			h.addAllowedValue("D060");
			h.addAllowedValue("D070");
			h.addAllowedValue("D080");
			h.addAllowedValue("D100");
			h.addAllowedValue("D101");
			h.addAllowedValue("D103");
			h.addAllowedValue("D110");
			h.addAllowedValue("D120");
			h.addAllowedValue("D130");
			h.addAllowedValue("D140");
			h.addAllowedValue("D141");
			h.addAllowedValue("D142");
			h.addAllowedValue("D143");
			h.addAllowedValue("D144");
			h.addAllowedValue("D150");
			h.addAllowedValue("D160");
			h.addAllowedValue("D170");
			h.addAllowedValue("D180");
			h.addAllowedValue("D190");
			h.addAllowedValue("D200");
			h.addAllowedValue("D210");
			h.addAllowedValue("D220");
			h.addAllowedValue("D230");
			h.addAllowedValue("D240");
			h.addAllowedValue("D242");
			h.addAllowedValue("D244");
			h.addAllowedValue("D246");
			h.addAllowedValue("D250");
			h.addAllowedValue("D260");
			h.addAllowedValue("D270");
			h.addAllowedValue("D280");
			h.addAllowedValue("D290");
			h.addAllowedValue("D292");
			h.addAllowedValue("D300");
			h.addAllowedValue("D301");
			h.addAllowedValue("D310");
			h.addAllowedValue("D320");
			h.addAllowedValue("D330");
			h.addAllowedValue("D340");
			h.addAllowedValue("D350");
			h.addAllowedValue("D360");
			h.addAllowedValue("D370");
			h.addAllowedValue("D380");
			h.addAllowedValue("D390");
			h.addAllowedValue("D400");
			h.addAllowedValue("D410");
			h.addAllowedValue("D420");
			h.addAllowedValue("D430");
			h.addAllowedValue("D440");
			h.addAllowedValue("D450");
			h.addAllowedValue("D460");
			h.addAllowedValue("D470");
			h.addAllowedValue("D480");
			h.addAllowedValue("D490");
			h.addAllowedValue("D500");
			h.addAllowedValue("D501");
			h.addAllowedValue("D502");
			h.addAllowedValue("D510");
			h.addAllowedValue("D520");
			h.addAllowedValue("D530");
			h.addAllowedValue("D540");
			h.addAllowedValue("D550");
			h.addAllowedValue("D560");
			h.addAllowedValue("D570");
			h.addAllowedValue("D580");
			h.addAllowedValue("D590");
			h.addAllowedValue("D600");
			h.addAllowedValue("D610");
			h.addAllowedValue("D620");
			h.addAllowedValue("D630");
			h.addAllowedValue("D640");
			h.addAllowedValue("D650");
			h.addAllowedValue("D655");
			h.addAllowedValue("D660");
			h.addAllowedValue("D670");
			h.addAllowedValue("D680");
			h.addAllowedValue("D690");
			h.addAllowedValue("D700");
			h.addAllowedValue("D701");
			h.addAllowedValue("D710");
			h.addAllowedValue("D711");
			h.addAllowedValue("D720");
			h.addAllowedValue("D730");
			h.addAllowedValue("D740");
			h.addAllowedValue("D750");
			h.addAllowedValue("D760");
			h.addAllowedValue("D770");
			h.addAllowedValue("D780");
			h.addAllowedValue("D790");
			h.addAllowedValue("D800");
			h.addAllowedValue("D810");
			h.addAllowedValue("D820");
			h.addAllowedValue("D830");
			h.addAllowedValue("D840");
			h.addAllowedValue("D850");
			h.addAllowedValue("D860");
			h.addAllowedValue("D870");
			h.addAllowedValue("D880");
			h.addAllowedValue("D890");
			h.addAllowedValue("D900");
			h.addAllowedValue("D910");
			h.addAllowedValue("D920");
			h.addAllowedValue("D930");
			h.addAllowedValue("D940");
			h.addAllowedValue("D950");
			h.addAllowedValue("D960");
			h.addAllowedValue("D970");
			h.addAllowedValue("D980");
			h.addAllowedValue("D990");
			h.addAllowedValue("D995");
			h.addAllowedValue("ENGA");
			h.addAllowedValue("EXLT");
			h.addAllowedValue("E000");
			h.addAllowedValue("E010");
			h.addAllowedValue("E020");
			h.addAllowedValue("E022");
			h.addAllowedValue("E030");
			h.addAllowedValue("E040");
			h.addAllowedValue("E050");
			h.addAllowedValue("E060");
			h.addAllowedValue("E063");
			h.addAllowedValue("E065");
			h.addAllowedValue("E067");
			h.addAllowedValue("E068");
			h.addAllowedValue("E069");
			h.addAllowedValue("E070");
			h.addAllowedValue("E080");
			h.addAllowedValue("E090");
			h.addAllowedValue("E100");
			h.addAllowedValue("E110");
			h.addAllowedValue("E120");
			h.addAllowedValue("E130");
			h.addAllowedValue("E140");
			h.addAllowedValue("E150");
			h.addAllowedValue("E160");
			h.addAllowedValue("E170");
			h.addAllowedValue("E180");
			h.addAllowedValue("E190");
			h.addAllowedValue("E191");
			h.addAllowedValue("E192");
			h.addAllowedValue("E193");
			h.addAllowedValue("E200");
			h.addAllowedValue("E210");
			h.addAllowedValue("E220");
			h.addAllowedValue("E230");
			h.addAllowedValue("E240");
			h.addAllowedValue("E250");
			h.addAllowedValue("E260");
			h.addAllowedValue("E270");
			h.addAllowedValue("E280");
			h.addAllowedValue("E290");
			h.addAllowedValue("E300");
			h.addAllowedValue("E310");
			h.addAllowedValue("E320");
			h.addAllowedValue("E330");
			h.addAllowedValue("E340");
			h.addAllowedValue("E350");
			h.addAllowedValue("E360");
			h.addAllowedValue("E370");
			h.addAllowedValue("E380");
			h.addAllowedValue("E381");
			h.addAllowedValue("E382");
			h.addAllowedValue("E384");
			h.addAllowedValue("E386");
			h.addAllowedValue("E388");
			h.addAllowedValue("E389");
			h.addAllowedValue("E390");
			h.addAllowedValue("E400");
			h.addAllowedValue("E410");
			h.addAllowedValue("E420");
			h.addAllowedValue("E430");
			h.addAllowedValue("E440");
			h.addAllowedValue("E450");
			h.addAllowedValue("E460");
			h.addAllowedValue("E470");
			h.addAllowedValue("E480");
			h.addAllowedValue("E485");
			h.addAllowedValue("E490");
			h.addAllowedValue("E500");
			h.addAllowedValue("E510");
			h.addAllowedValue("E520");
			h.addAllowedValue("E530");
			h.addAllowedValue("E540");
			h.addAllowedValue("E550");
			h.addAllowedValue("E560");
			h.addAllowedValue("E570");
			h.addAllowedValue("E580");
			h.addAllowedValue("E585");
			h.addAllowedValue("E590");
			h.addAllowedValue("E600");
			h.addAllowedValue("E610");
			h.addAllowedValue("E620");
			h.addAllowedValue("E630");
			h.addAllowedValue("E640");
			h.addAllowedValue("E650");
			h.addAllowedValue("E660");
			h.addAllowedValue("E670");
			h.addAllowedValue("E680");
			h.addAllowedValue("E690");
			h.addAllowedValue("E695");
			h.addAllowedValue("E700");
			h.addAllowedValue("E710");
			h.addAllowedValue("E720");
			h.addAllowedValue("E730");
			h.addAllowedValue("E740");
			h.addAllowedValue("E750");
			h.addAllowedValue("E760");
			h.addAllowedValue("E770");
			h.addAllowedValue("E780");
			h.addAllowedValue("E790");
			h.addAllowedValue("E800");
			h.addAllowedValue("E805");
			h.addAllowedValue("E810");
			h.addAllowedValue("E820");
			h.addAllowedValue("E830");
			h.addAllowedValue("E840");
			h.addAllowedValue("E850");
			h.addAllowedValue("E860");
			h.addAllowedValue("E870");
			h.addAllowedValue("E880");
			h.addAllowedValue("E890");
			h.addAllowedValue("E900");
			h.addAllowedValue("E910");
			h.addAllowedValue("E920");
			h.addAllowedValue("E930");
			h.addAllowedValue("E940");
			h.addAllowedValue("E950");
			h.addAllowedValue("E960");
			h.addAllowedValue("E970");
			h.addAllowedValue("E980");
			h.addAllowedValue("E990");
			h.addAllowedValue("FAKT");
			h.addAllowedValue("FLST");
			h.addAllowedValue("F000");
			h.addAllowedValue("F010");
			h.addAllowedValue("F020");
			h.addAllowedValue("F030");
			h.addAllowedValue("F040");
			h.addAllowedValue("F050");
			h.addAllowedValue("F060");
			h.addAllowedValue("F061");
			h.addAllowedValue("F062");
			h.addAllowedValue("F063");
			h.addAllowedValue("F065");
			h.addAllowedValue("F067");
			h.addAllowedValue("F070");
			h.addAllowedValue("F080");
			h.addAllowedValue("F090");
			h.addAllowedValue("F100");
			h.addAllowedValue("F110");
			h.addAllowedValue("F120");
			h.addAllowedValue("F130");
			h.addAllowedValue("F140");
			h.addAllowedValue("F150");
			h.addAllowedValue("F155");
			h.addAllowedValue("F160");
			h.addAllowedValue("F170");
			h.addAllowedValue("F180");
			h.addAllowedValue("F190");
			h.addAllowedValue("F200");
			h.addAllowedValue("F210");
			h.addAllowedValue("F220");
			h.addAllowedValue("F225");
			h.addAllowedValue("F230");
			h.addAllowedValue("F240");
			h.addAllowedValue("F250");
			h.addAllowedValue("F260");
			h.addAllowedValue("F270");
			h.addAllowedValue("F271");
			h.addAllowedValue("F272");
			h.addAllowedValue("F280");
			h.addAllowedValue("F290");
			h.addAllowedValue("F300");
			h.addAllowedValue("F310");
			h.addAllowedValue("F320");
			h.addAllowedValue("F330");
			h.addAllowedValue("F340");
			h.addAllowedValue("F350");
			h.addAllowedValue("F360");
			h.addAllowedValue("F370");
			h.addAllowedValue("F380");
			h.addAllowedValue("F390");
			h.addAllowedValue("F400");
			h.addAllowedValue("F401");
			h.addAllowedValue("F410");
			h.addAllowedValue("F420");
			h.addAllowedValue("F430");
			h.addAllowedValue("F440");
			h.addAllowedValue("F445");
			h.addAllowedValue("F450");
			h.addAllowedValue("F460");
			h.addAllowedValue("F465");
			h.addAllowedValue("F470");
			h.addAllowedValue("F480");
			h.addAllowedValue("F490");
			h.addAllowedValue("F500");
			h.addAllowedValue("F510");
			h.addAllowedValue("F520");
			h.addAllowedValue("F530");
			h.addAllowedValue("F540");
			h.addAllowedValue("F550");
			h.addAllowedValue("F560");
			h.addAllowedValue("F570");
			h.addAllowedValue("F580");
			h.addAllowedValue("F590");
			h.addAllowedValue("F600");
			h.addAllowedValue("F610");
			h.addAllowedValue("F620");
			h.addAllowedValue("F630");
			h.addAllowedValue("F640");
			h.addAllowedValue("F650");
			h.addAllowedValue("F660");
			h.addAllowedValue("F670");
			h.addAllowedValue("F680");
			h.addAllowedValue("F690");
			h.addAllowedValue("F700");
			h.addAllowedValue("F710");
			h.addAllowedValue("F720");
			h.addAllowedValue("F730");
			h.addAllowedValue("F740");
			h.addAllowedValue("F750");
			h.addAllowedValue("F760");
			h.addAllowedValue("F770");
			h.addAllowedValue("F780");
			h.addAllowedValue("F790");
			h.addAllowedValue("F800");
			h.addAllowedValue("F810");
			h.addAllowedValue("F820");
			h.addAllowedValue("F830");
			h.addAllowedValue("F840");
			h.addAllowedValue("F850");
			h.addAllowedValue("F860");
			h.addAllowedValue("F870");
			h.addAllowedValue("F880");
			h.addAllowedValue("F890");
			h.addAllowedValue("F900");
			h.addAllowedValue("F910");
			h.addAllowedValue("F920");
			h.addAllowedValue("F930");
			h.addAllowedValue("F940");
			h.addAllowedValue("F950");
			h.addAllowedValue("F960");
			h.addAllowedValue("F970");
			h.addAllowedValue("F980");
			h.addAllowedValue("F990");
			h.addAllowedValue("F991");
			h.addAllowedValue("GMST");
			h.addAllowedValue("G000");
			h.addAllowedValue("G010");
			h.addAllowedValue("G020");
			h.addAllowedValue("G025");
			h.addAllowedValue("G030");
			h.addAllowedValue("G040");
			h.addAllowedValue("G050");
			h.addAllowedValue("G060");
			h.addAllowedValue("G070");
			h.addAllowedValue("G080");
			h.addAllowedValue("G090");
			h.addAllowedValue("G100");
			h.addAllowedValue("G110");
			h.addAllowedValue("G120");
			h.addAllowedValue("G130");
			h.addAllowedValue("G140");
			h.addAllowedValue("G150");
			h.addAllowedValue("G160");
			h.addAllowedValue("G170");
			h.addAllowedValue("G180");
			h.addAllowedValue("G190");
			h.addAllowedValue("G200");
			h.addAllowedValue("G210");
			h.addAllowedValue("G220");
			h.addAllowedValue("G230");
			h.addAllowedValue("G240");
			h.addAllowedValue("G250");
			h.addAllowedValue("G260");
			h.addAllowedValue("G270");
			h.addAllowedValue("G280");
			h.addAllowedValue("G290");
			h.addAllowedValue("G300");
			h.addAllowedValue("G310");
			h.addAllowedValue("G320");
			h.addAllowedValue("G322");
			h.addAllowedValue("G324");
			h.addAllowedValue("G326");
			h.addAllowedValue("G328");
			h.addAllowedValue("G329");
			h.addAllowedValue("G330");
			h.addAllowedValue("G340");
			h.addAllowedValue("G350");
			h.addAllowedValue("G360");
			h.addAllowedValue("G370");
			h.addAllowedValue("G380");
			h.addAllowedValue("G390");
			h.addAllowedValue("G400");
			h.addAllowedValue("G410");
			h.addAllowedValue("G420");
			h.addAllowedValue("G430");
			h.addAllowedValue("G440");
			h.addAllowedValue("G450");
			h.addAllowedValue("G460");
			h.addAllowedValue("G470");
			h.addAllowedValue("G480");
			h.addAllowedValue("G490");
			h.addAllowedValue("G500");
			h.addAllowedValue("G510");
			h.addAllowedValue("G520");
			h.addAllowedValue("G530");
			h.addAllowedValue("G540");
			h.addAllowedValue("G550");
			h.addAllowedValue("G560");
			h.addAllowedValue("G570");
			h.addAllowedValue("G580");
			h.addAllowedValue("G590");
			h.addAllowedValue("G600");
			h.addAllowedValue("G610");
			h.addAllowedValue("G620");
			h.addAllowedValue("G630");
			h.addAllowedValue("G640");
			h.addAllowedValue("G650");
			h.addAllowedValue("G660");
			h.addAllowedValue("G670");
			h.addAllowedValue("G680");
			h.addAllowedValue("G690");
			h.addAllowedValue("G700");
			h.addAllowedValue("G710");
			h.addAllowedValue("G720");
			h.addAllowedValue("G730");
			h.addAllowedValue("G740");
			h.addAllowedValue("G750");
			h.addAllowedValue("G760");
			h.addAllowedValue("G770");
			h.addAllowedValue("G775");
			h.addAllowedValue("G780");
			h.addAllowedValue("G790");
			h.addAllowedValue("G800");
			h.addAllowedValue("G810");
			h.addAllowedValue("G820");
			h.addAllowedValue("G821");
			h.addAllowedValue("G830");
			h.addAllowedValue("G840");
			h.addAllowedValue("G850");
			h.addAllowedValue("G860");
			h.addAllowedValue("G870");
			h.addAllowedValue("G880");
			h.addAllowedValue("G890");
			h.addAllowedValue("G900");
			h.addAllowedValue("G910");
			h.addAllowedValue("G920");
			h.addAllowedValue("G930");
			h.addAllowedValue("G940");
			h.addAllowedValue("G950");
			h.addAllowedValue("G960");
			h.addAllowedValue("G970");
			h.addAllowedValue("G980");
			h.addAllowedValue("G990");
			h.addAllowedValue("HZDT");
			h.addAllowedValue("H000");
			h.addAllowedValue("H010");
			h.addAllowedValue("H020");
			h.addAllowedValue("H030");
			h.addAllowedValue("H040");
			h.addAllowedValue("H050");
			h.addAllowedValue("H060");
			h.addAllowedValue("H070");
			h.addAllowedValue("H080");
			h.addAllowedValue("H090");
			h.addAllowedValue("H100");
			h.addAllowedValue("H110");
			h.addAllowedValue("H120");
			h.addAllowedValue("H130");
			h.addAllowedValue("H140");
			h.addAllowedValue("H150");
			h.addAllowedValue("H151");
			h.addAllowedValue("H160");
			h.addAllowedValue("H170");
			h.addAllowedValue("H180");
			h.addAllowedValue("H190");
			h.addAllowedValue("H200");
			h.addAllowedValue("H210");
			h.addAllowedValue("H215");
			h.addAllowedValue("H220");
			h.addAllowedValue("H230");
			h.addAllowedValue("H240");
			h.addAllowedValue("H250");
			h.addAllowedValue("H260");
			h.addAllowedValue("H270");
			h.addAllowedValue("H280");
			h.addAllowedValue("H290");
			h.addAllowedValue("H300");
			h.addAllowedValue("H310");
			h.addAllowedValue("H320");
			h.addAllowedValue("H330");
			h.addAllowedValue("H340");
			h.addAllowedValue("H350");
			h.addAllowedValue("H360");
			h.addAllowedValue("H370");
			h.addAllowedValue("H380");
			h.addAllowedValue("H390");
			h.addAllowedValue("H400");
			h.addAllowedValue("H410");
			h.addAllowedValue("H420");
			h.addAllowedValue("H430");
			h.addAllowedValue("H440");
			h.addAllowedValue("H450");
			h.addAllowedValue("H460");
			h.addAllowedValue("H470");
			h.addAllowedValue("H480");
			h.addAllowedValue("H490");
			h.addAllowedValue("H500");
			h.addAllowedValue("H505");
			h.addAllowedValue("H507");
			h.addAllowedValue("H510");
			h.addAllowedValue("H520");
			h.addAllowedValue("H530");
			h.addAllowedValue("H535");
			h.addAllowedValue("H540");
			h.addAllowedValue("H550");
			h.addAllowedValue("H551");
			h.addAllowedValue("H560");
			h.addAllowedValue("H570");
			h.addAllowedValue("H580");
			h.addAllowedValue("H590");
			h.addAllowedValue("H600");
			h.addAllowedValue("H605");
			h.addAllowedValue("H610");
			h.addAllowedValue("H620");
			h.addAllowedValue("H625");
			h.addAllowedValue("H630");
			h.addAllowedValue("H640");
			h.addAllowedValue("H650");
			h.addAllowedValue("H660");
			h.addAllowedValue("H670");
			h.addAllowedValue("H680");
			h.addAllowedValue("H690");
			h.addAllowedValue("H700");
			h.addAllowedValue("H710");
			h.addAllowedValue("H720");
			h.addAllowedValue("H730");
			h.addAllowedValue("H740");
			h.addAllowedValue("H750");
			h.addAllowedValue("H760");
			h.addAllowedValue("H770");
			h.addAllowedValue("H780");
			h.addAllowedValue("H790");
			h.addAllowedValue("H800");
			h.addAllowedValue("H806");
			h.addAllowedValue("H810");
			h.addAllowedValue("H820");
			h.addAllowedValue("H830");
			h.addAllowedValue("H840");
			h.addAllowedValue("H850");
			h.addAllowedValue("H855");
			h.addAllowedValue("H860");
			h.addAllowedValue("H870");
			h.addAllowedValue("H880");
			h.addAllowedValue("H890");
			h.addAllowedValue("H900");
			h.addAllowedValue("H910");
			h.addAllowedValue("H920");
			h.addAllowedValue("H930");
			h.addAllowedValue("H935");
			h.addAllowedValue("H940");
			h.addAllowedValue("H950");
			h.addAllowedValue("H960");
			h.addAllowedValue("H970");
			h.addAllowedValue("H980");
			h.addAllowedValue("H990");
			h.addAllowedValue("IDCT");
			h.addAllowedValue("I000");
			h.addAllowedValue("I010");
			h.addAllowedValue("I020");
			h.addAllowedValue("I030");
			h.addAllowedValue("I040");
			h.addAllowedValue("I050");
			h.addAllowedValue("I060");
			h.addAllowedValue("I070");
			h.addAllowedValue("I080");
			h.addAllowedValue("I090");
			h.addAllowedValue("I100");
			h.addAllowedValue("I110");
			h.addAllowedValue("I120");
			h.addAllowedValue("I130");
			h.addAllowedValue("I131");
			h.addAllowedValue("I132");
			h.addAllowedValue("I133");
			h.addAllowedValue("I134");
			h.addAllowedValue("I136");
			h.addAllowedValue("I138");
			h.addAllowedValue("I140");
			h.addAllowedValue("I150");
			h.addAllowedValue("I160");
			h.addAllowedValue("I170");
			h.addAllowedValue("I180");
			h.addAllowedValue("I190");
			h.addAllowedValue("I200");
			h.addAllowedValue("I210");
			h.addAllowedValue("I220");
			h.addAllowedValue("I230");
			h.addAllowedValue("I240");
			h.addAllowedValue("I250");
			h.addAllowedValue("I260");
			h.addAllowedValue("I270");
			h.addAllowedValue("I280");
			h.addAllowedValue("I290");
			h.addAllowedValue("I300");
			h.addAllowedValue("I310");
			h.addAllowedValue("I320");
			h.addAllowedValue("I330");
			h.addAllowedValue("I340");
			h.addAllowedValue("I350");
			h.addAllowedValue("I360");
			h.addAllowedValue("I370");
			h.addAllowedValue("I380");
			h.addAllowedValue("I390");
			h.addAllowedValue("I400");
			h.addAllowedValue("I410");
			h.addAllowedValue("I411");
			h.addAllowedValue("I420");
			h.addAllowedValue("I430");
			h.addAllowedValue("I431");
			h.addAllowedValue("I432");
			h.addAllowedValue("I440");
			h.addAllowedValue("I450");
			h.addAllowedValue("I460");
			h.addAllowedValue("I470");
			h.addAllowedValue("I480");
			h.addAllowedValue("I490");
			h.addAllowedValue("I495");
			h.addAllowedValue("I500");
			h.addAllowedValue("I510");
			h.addAllowedValue("I520");
			h.addAllowedValue("I530");
			h.addAllowedValue("I540");
			h.addAllowedValue("I550");
			h.addAllowedValue("I560");
			h.addAllowedValue("I570");
			h.addAllowedValue("I580");
			h.addAllowedValue("I590");
			h.addAllowedValue("I595");
			h.addAllowedValue("I600");
			h.addAllowedValue("I610");
			h.addAllowedValue("I620");
			h.addAllowedValue("I630");
			h.addAllowedValue("I640");
			h.addAllowedValue("I650");
			h.addAllowedValue("I660");
			h.addAllowedValue("I670");
			h.addAllowedValue("I680");
			h.addAllowedValue("I690");
			h.addAllowedValue("I700");
			h.addAllowedValue("I710");
			h.addAllowedValue("I720");
			h.addAllowedValue("I730");
			h.addAllowedValue("I740");
			h.addAllowedValue("I750");
			h.addAllowedValue("I760");
			h.addAllowedValue("LCLT");
			h.addAllowedValue("LC2T");
			h.addAllowedValue("LC4T");
			h.addAllowedValue("LECT");
			h.addAllowedValue("LFDT");
			h.addAllowedValue("LMDT");
			h.addAllowedValue("LNDT");
			h.addAllowedValue("LPDT");
			h.addAllowedValue("LQDT");
			h.addAllowedValue("LTET");
			h.addAllowedValue("MATT");
			h.addAllowedValue("OCNT");
			h.addAllowedValue("OFFA");
			h.addAllowedValue("OODT");
			h.addAllowedValue("OTHR");
			h.addAllowedValue("OWCT");
			h.addAllowedValue("PRST");
			h.addAllowedValue("PTAX");
			h.addAllowedValue("PVPT");
			h.addAllowedValue("RDHT");
			h.addAllowedValue("RFMT");
			h.addAllowedValue("RPDT");
			h.addAllowedValue("RSTT");
			h.addAllowedValue("R020");
			h.addAllowedValue("R030");
			h.addAllowedValue("R040");
			h.addAllowedValue("R060");
			h.addAllowedValue("R080");
			h.addAllowedValue("SFBT");
			h.addAllowedValue("SFDT");
			h.addAllowedValue("SFET");
			h.addAllowedValue("SSCT");
			h.addAllowedValue("SSUT");
			h.addAllowedValue("STDT");
			h.addAllowedValue("STFT");
			h.addAllowedValue("STOT");
			h.addAllowedValue("TERT");
			h.addAllowedValue("VCLT");
			h.addAllowedValue("WBBT");
			h.addAllowedValue("WCFT");
			h.addAllowedValue("WFTT");
			h.addAllowedValue("WRBT");
			h.addAllowedValue("WRIT");
			h.addAllowedValue("ZZZZ");
			simpleElement1300 = new RtSimpleElement("1300", "ID", h);
		}
	
		return simpleElement1300;
	}
	
	private RtSimpleElement simpleElement1301;
	
	private RtSimpleElement simpleElement1301() {
		if (simpleElement1301 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Agency Service, Promotion, Allowance, or Charge Code";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement1301 = new RtSimpleElement("1301", "AN", h);
		}
	
		return simpleElement1301;
	}
	
	private RtSimpleElement simpleElement378;
	
	private RtSimpleElement simpleElement378() {
		if (simpleElement378 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Allowance/Charge Percent Qualifier";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("Z");
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			h.addAllowedValue("9");
			simpleElement378 = new RtSimpleElement("378", "ID", h);
		}
	
		return simpleElement378;
	}
	
	private RtSimpleElement simpleElement332;
	
	private RtSimpleElement simpleElement332() {
		if (simpleElement332 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Percent";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement332 = new RtSimpleElement("332", "R", h);
		}
	
		return simpleElement332;
	}
	
	private RtSimpleElement simpleElement118;
	
	private RtSimpleElement simpleElement118() {
		if (simpleElement118 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Rate";
			h.minLength = 1;
			h.maxLength = 9;
			
			simpleElement118 = new RtSimpleElement("118", "R", h);
		}
	
		return simpleElement118;
	}
	
	private RtSimpleElement simpleElement331;
	
	private RtSimpleElement simpleElement331() {
		if (simpleElement331 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Allowance or Charge Method of Handling Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("CA");
			h.addAllowedValue("CC");
			h.addAllowedValue("PP");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("15");
			h.addAllowedValue("18");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("25");
			simpleElement331 = new RtSimpleElement("331", "ID", h);
		}
	
		return simpleElement331;
	}
	
	private RtSimpleElement simpleElement770;
	
	private RtSimpleElement simpleElement770() {
		if (simpleElement770 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Option Number";
			h.minLength = 1;
			h.maxLength = 20;
			
			simpleElement770 = new RtSimpleElement("770", "AN", h);
		}
	
		return simpleElement770;
	}
	
	private RtSimpleElement simpleElement819;
	
	private RtSimpleElement simpleElement819() {
		if (simpleElement819 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Language Code";
			h.minLength = 2;
			h.maxLength = 3;
			
			simpleElement819 = new RtSimpleElement("819", "ID", h);
		}
	
		return simpleElement819;
	}
	
	private RtSimpleElement simpleElement336;
	
	private RtSimpleElement simpleElement336() {
		if (simpleElement336 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Type Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("CA");
			h.addAllowedValue("CO");
			h.addAllowedValue("NC");
			h.addAllowedValue("PP");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("52");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("61");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			simpleElement336 = new RtSimpleElement("336", "ID", h);
		}
	
		return simpleElement336;
	}
	
	private RtSimpleElement simpleElement333;
	
	private RtSimpleElement simpleElement333() {
		if (simpleElement333 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Basis Date Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("ZZ");
			h.addAllowedValue("09");
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			simpleElement333 = new RtSimpleElement("333", "ID", h);
		}
	
		return simpleElement333;
	}
	
	private RtSimpleElement simpleElement338;
	
	private RtSimpleElement simpleElement338() {
		if (simpleElement338 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Discount Percent";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement338 = new RtSimpleElement("338", "R", h);
		}
	
		return simpleElement338;
	}
	
	private RtSimpleElement simpleElement370;
	
	private RtSimpleElement simpleElement370() {
		if (simpleElement370 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Discount Due Date";
			h.minLength = 8;
			h.maxLength = 8;
			
			simpleElement370 = new RtSimpleElement("370", "DT", h);
		}
	
		return simpleElement370;
	}
	
	private RtSimpleElement simpleElement351;
	
	private RtSimpleElement simpleElement351() {
		if (simpleElement351 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Discount Days Due";
			h.minLength = 1;
			h.maxLength = 3;
			
			simpleElement351 = new RtSimpleElement("351", "N0", h);
		}
	
		return simpleElement351;
	}
	
	private RtSimpleElement simpleElement446;
	
	private RtSimpleElement simpleElement446() {
		if (simpleElement446 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Net Due Date";
			h.minLength = 8;
			h.maxLength = 8;
			
			simpleElement446 = new RtSimpleElement("446", "DT", h);
		}
	
		return simpleElement446;
	}
	
	private RtSimpleElement simpleElement386;
	
	private RtSimpleElement simpleElement386() {
		if (simpleElement386 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Net Days";
			h.minLength = 1;
			h.maxLength = 3;
			
			simpleElement386 = new RtSimpleElement("386", "N0", h);
		}
	
		return simpleElement386;
	}
	
	private RtSimpleElement simpleElement362;
	
	private RtSimpleElement simpleElement362() {
		if (simpleElement362 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Discount Amount";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement362 = new RtSimpleElement("362", "N2", h);
		}
	
		return simpleElement362;
	}
	
	private RtSimpleElement simpleElement388;
	
	private RtSimpleElement simpleElement388() {
		if (simpleElement388 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Terms Deferred Due Date";
			h.minLength = 8;
			h.maxLength = 8;
			
			simpleElement388 = new RtSimpleElement("388", "DT", h);
		}
	
		return simpleElement388;
	}
	
	private RtSimpleElement simpleElement389;
	
	private RtSimpleElement simpleElement389() {
		if (simpleElement389 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Deferred Amount Due";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement389 = new RtSimpleElement("389", "N2", h);
		}
	
		return simpleElement389;
	}
	
	private RtSimpleElement simpleElement342;
	
	private RtSimpleElement simpleElement342() {
		if (simpleElement342 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Percent of Invoice Payable";
			h.minLength = 1;
			h.maxLength = 5;
			
			simpleElement342 = new RtSimpleElement("342", "R", h);
		}
	
		return simpleElement342;
	}
	
	private RtSimpleElement simpleElement765;
	
	private RtSimpleElement simpleElement765() {
		if (simpleElement765 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Day of Month";
			h.minLength = 1;
			h.maxLength = 2;
			
			simpleElement765 = new RtSimpleElement("765", "N0", h);
		}
	
		return simpleElement765;
	}
	
	private RtSimpleElement simpleElement107;
	
	private RtSimpleElement simpleElement107() {
		if (simpleElement107 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Payment Method Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("B");
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			h.addAllowedValue("E");
			h.addAllowedValue("F");
			h.addAllowedValue("G");
			h.addAllowedValue("H");
			h.addAllowedValue("I");
			h.addAllowedValue("J");
			h.addAllowedValue("K");
			h.addAllowedValue("L");
			h.addAllowedValue("M");
			h.addAllowedValue("N");
			h.addAllowedValue("O");
			h.addAllowedValue("P");
			h.addAllowedValue("Q");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			h.addAllowedValue("T");
			h.addAllowedValue("U");
			h.addAllowedValue("V");
			h.addAllowedValue("W");
			h.addAllowedValue("X");
			h.addAllowedValue("Y");
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("8");
			simpleElement107 = new RtSimpleElement("107", "ID", h);
		}
	
		return simpleElement107;
	}
	
	private RtSimpleElement simpleElement653;
	
	private RtSimpleElement simpleElement653() {
		if (simpleElement653 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Discount Terms Type Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("AMT");
			h.addAllowedValue("CSH");
			h.addAllowedValue("DOR");
			h.addAllowedValue("DPU");
			h.addAllowedValue("DSH");
			h.addAllowedValue("DSV");
			h.addAllowedValue("POR");
			h.addAllowedValue("PPU");
			h.addAllowedValue("PSH");
			h.addAllowedValue("PSV");
			h.addAllowedValue("UNT");
			h.addAllowedValue("ZZZ");
			simpleElement653 = new RtSimpleElement("653", "ID", h);
		}
	
		return simpleElement653;
	}
	
	private RtSimpleElement simpleElement654;
	
	private RtSimpleElement simpleElement654() {
		if (simpleElement654 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Discount Base Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("CA");
			h.addAllowedValue("PC");
			h.addAllowedValue("UN");
			h.addAllowedValue("ZZ");
			simpleElement654 = new RtSimpleElement("654", "ID", h);
		}
	
		return simpleElement654;
	}
	
	private RtSimpleElement simpleElement655;
	
	private RtSimpleElement simpleElement655() {
		if (simpleElement655 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Discount Base Value";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement655 = new RtSimpleElement("655", "R", h);
		}
	
		return simpleElement655;
	}
	
	private RtSimpleElement simpleElement656;
	
	private RtSimpleElement simpleElement656() {
		if (simpleElement656 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Discount Control Limit Qualifier";
			h.minLength = 2;
			h.maxLength = 3;
			
			h.addAllowedValue("DAT");
			h.addAllowedValue("DOF");
			simpleElement656 = new RtSimpleElement("656", "ID", h);
		}
	
		return simpleElement656;
	}
	
	private RtSimpleElement simpleElement657;
	
	private RtSimpleElement simpleElement657() {
		if (simpleElement657 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Discount Control Limit";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement657 = new RtSimpleElement("657", "N0", h);
		}
	
		return simpleElement657;
	}
	
	private RtSimpleElement simpleElement623;
	
	private RtSimpleElement simpleElement623() {
		if (simpleElement623 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Time Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AD");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("CD");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("ED");
			h.addAllowedValue("ES");
			h.addAllowedValue("ET");
			h.addAllowedValue("GM");
			h.addAllowedValue("HD");
			h.addAllowedValue("HS");
			h.addAllowedValue("HT");
			h.addAllowedValue("LT");
			h.addAllowedValue("MD");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("ND");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("PD");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("TD");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("UT");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			simpleElement623 = new RtSimpleElement("623", "ID", h);
		}
	
		return simpleElement623;
	}
	
	private RtSimpleElement simpleElement1250;
	
	private RtSimpleElement simpleElement1250() {
		if (simpleElement1250 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Date Time Period Format Qualifier";
			h.minLength = 2;
			h.maxLength = 3;
			
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CM");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CY");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DD");
			h.addAllowedValue("DT");
			h.addAllowedValue("DTS");
			h.addAllowedValue("D6");
			h.addAllowedValue("D8");
			h.addAllowedValue("EH");
			h.addAllowedValue("KA");
			h.addAllowedValue("MD");
			h.addAllowedValue("MM");
			h.addAllowedValue("RD");
			h.addAllowedValue("RDM");
			h.addAllowedValue("RDT");
			h.addAllowedValue("RD2");
			h.addAllowedValue("RD4");
			h.addAllowedValue("RD5");
			h.addAllowedValue("RD6");
			h.addAllowedValue("RD8");
			h.addAllowedValue("RMD");
			h.addAllowedValue("RMY");
			h.addAllowedValue("RTM");
			h.addAllowedValue("RTS");
			h.addAllowedValue("TC");
			h.addAllowedValue("TM");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TU");
			h.addAllowedValue("UN");
			h.addAllowedValue("YM");
			h.addAllowedValue("YMM");
			h.addAllowedValue("YY");
			simpleElement1250 = new RtSimpleElement("1250", "ID", h);
		}
	
		return simpleElement1250;
	}
	
	private RtSimpleElement simpleElement1251;
	
	private RtSimpleElement simpleElement1251() {
		if (simpleElement1251 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Date Time Period";
			h.minLength = 1;
			h.maxLength = 35;
			
			simpleElement1251 = new RtSimpleElement("1251", "AN", h);
		}
	
		return simpleElement1251;
	}
	
	private RtSimpleElement simpleElement345;
	
	private RtSimpleElement simpleElement345() {
		if (simpleElement345 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Lead Time Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AP");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			simpleElement345 = new RtSimpleElement("345", "ID", h);
		}
	
		return simpleElement345;
	}
	
	private RtSimpleElement simpleElement350;
	
	private RtSimpleElement simpleElement350() {
		if (simpleElement350 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Assigned Identification";
			h.minLength = 1;
			h.maxLength = 20;
			
			simpleElement350 = new RtSimpleElement("350", "AN", h);
		}
	
		return simpleElement350;
	}
	
	private RtSimpleElement simpleElement235;
	
	private RtSimpleElement simpleElement235() {
		if (simpleElement235 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Product/Service ID Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A8");
			h.addAllowedValue("A9");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("BU");
			h.addAllowedValue("BV");
			h.addAllowedValue("BW");
			h.addAllowedValue("BX");
			h.addAllowedValue("BY");
			h.addAllowedValue("BZ");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("B6");
			h.addAllowedValue("B7");
			h.addAllowedValue("B8");
			h.addAllowedValue("B9");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("C7");
			h.addAllowedValue("C8");
			h.addAllowedValue("C9");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DI");
			h.addAllowedValue("DL");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("DV");
			h.addAllowedValue("DW");
			h.addAllowedValue("DX");
			h.addAllowedValue("DY");
			h.addAllowedValue("DZ");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EH");
			h.addAllowedValue("EI");
			h.addAllowedValue("EJ");
			h.addAllowedValue("EK");
			h.addAllowedValue("EL");
			h.addAllowedValue("EM");
			h.addAllowedValue("EN");
			h.addAllowedValue("EP");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("EU");
			h.addAllowedValue("EX");
			h.addAllowedValue("EZ");
			h.addAllowedValue("E1");
			h.addAllowedValue("E2");
			h.addAllowedValue("E3");
			h.addAllowedValue("E4");
			h.addAllowedValue("E5");
			h.addAllowedValue("E6");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FI");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FN");
			h.addAllowedValue("FP");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("FW");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("F5");
			h.addAllowedValue("F6");
			h.addAllowedValue("F7");
			h.addAllowedValue("F8");
			h.addAllowedValue("F9");
			h.addAllowedValue("GA");
			h.addAllowedValue("GC");
			h.addAllowedValue("GD");
			h.addAllowedValue("GE");
			h.addAllowedValue("GI");
			h.addAllowedValue("GK");
			h.addAllowedValue("GN");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("GU");
			h.addAllowedValue("HC");
			h.addAllowedValue("HD");
			h.addAllowedValue("HI");
			h.addAllowedValue("HN");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IE");
			h.addAllowedValue("IF");
			h.addAllowedValue("IG");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IP");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IR");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("IV");
			h.addAllowedValue("IW");
			h.addAllowedValue("IZ");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JC");
			h.addAllowedValue("JD");
			h.addAllowedValue("JN");
			h.addAllowedValue("JP");
			h.addAllowedValue("JS");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KN");
			h.addAllowedValue("KP");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LG");
			h.addAllowedValue("LP");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LU");
			h.addAllowedValue("L1");
			h.addAllowedValue("L2");
			h.addAllowedValue("L3");
			h.addAllowedValue("L4");
			h.addAllowedValue("L5");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MP");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("MU");
			h.addAllowedValue("MV");
			h.addAllowedValue("MW");
			h.addAllowedValue("MX");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NE");
			h.addAllowedValue("NH");
			h.addAllowedValue("NM");
			h.addAllowedValue("NR");
			h.addAllowedValue("NU");
			h.addAllowedValue("NW");
			h.addAllowedValue("NZ");
			h.addAllowedValue("N1");
			h.addAllowedValue("N2");
			h.addAllowedValue("N3");
			h.addAllowedValue("N4");
			h.addAllowedValue("N5");
			h.addAllowedValue("N6");
			h.addAllowedValue("OA");
			h.addAllowedValue("OB");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("OE");
			h.addAllowedValue("OF");
			h.addAllowedValue("OG");
			h.addAllowedValue("OH");
			h.addAllowedValue("OI");
			h.addAllowedValue("OL");
			h.addAllowedValue("ON");
			h.addAllowedValue("OO");
			h.addAllowedValue("OP");
			h.addAllowedValue("OR");
			h.addAllowedValue("OT");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P1");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P7");
			h.addAllowedValue("P8");
			h.addAllowedValue("P9");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RV");
			h.addAllowedValue("RW");
			h.addAllowedValue("RY");
			h.addAllowedValue("RZ");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SY");
			h.addAllowedValue("SZ");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TU");
			h.addAllowedValue("TV");
			h.addAllowedValue("TW");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("TZ");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("UF");
			h.addAllowedValue("UG");
			h.addAllowedValue("UH");
			h.addAllowedValue("UI");
			h.addAllowedValue("UJ");
			h.addAllowedValue("UK");
			h.addAllowedValue("UL");
			h.addAllowedValue("UM");
			h.addAllowedValue("UN");
			h.addAllowedValue("UO");
			h.addAllowedValue("UP");
			h.addAllowedValue("UQ");
			h.addAllowedValue("UR");
			h.addAllowedValue("US");
			h.addAllowedValue("UT");
			h.addAllowedValue("UV");
			h.addAllowedValue("UX");
			h.addAllowedValue("U2");
			h.addAllowedValue("U3");
			h.addAllowedValue("U5");
			h.addAllowedValue("U6");
			h.addAllowedValue("VA");
			h.addAllowedValue("VB");
			h.addAllowedValue("VC");
			h.addAllowedValue("VE");
			h.addAllowedValue("VI");
			h.addAllowedValue("VM");
			h.addAllowedValue("VN");
			h.addAllowedValue("VO");
			h.addAllowedValue("VP");
			h.addAllowedValue("VS");
			h.addAllowedValue("VT");
			h.addAllowedValue("VU");
			h.addAllowedValue("VV");
			h.addAllowedValue("VX");
			h.addAllowedValue("WA");
			h.addAllowedValue("WC");
			h.addAllowedValue("WL");
			h.addAllowedValue("WR");
			h.addAllowedValue("WS");
			h.addAllowedValue("W1");
			h.addAllowedValue("W2");
			h.addAllowedValue("W5");
			h.addAllowedValue("W6");
			h.addAllowedValue("W7");
			h.addAllowedValue("XA");
			h.addAllowedValue("XC");
			h.addAllowedValue("XP");
			h.addAllowedValue("XQ");
			h.addAllowedValue("XZ");
			h.addAllowedValue("YP");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZR");
			h.addAllowedValue("ZZ");
			simpleElement235 = new RtSimpleElement("235", "ID", h);
		}
	
		return simpleElement235;
	}
	
	private RtSimpleElement simpleElement234;
	
	private RtSimpleElement simpleElement234() {
		if (simpleElement234 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Product/Service ID";
			h.minLength = 1;
			h.maxLength = 48;
			
			simpleElement234 = new RtSimpleElement("234", "AN", h);
		}
	
		return simpleElement234;
	}
	
	private RtSimpleElement simpleElement1000;
	
	private RtSimpleElement simpleElement1000() {
		if (simpleElement1000 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Service Characteristics Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			simpleElement1000 = new RtSimpleElement("1000", "AN", h);
		}
	
		return simpleElement1000;
	}
	
	private RtSimpleElement simpleElement349;
	
	private RtSimpleElement simpleElement349() {
		if (simpleElement349 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Item Description Type";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("F");
			h.addAllowedValue("S");
			h.addAllowedValue("X");
			simpleElement349 = new RtSimpleElement("349", "ID", h);
		}
	
		return simpleElement349;
	}
	
	private RtSimpleElement simpleElement750;
	
	private RtSimpleElement simpleElement750() {
		if (simpleElement750 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Product/Process Characteristic Code";
			h.minLength = 2;
			h.maxLength = 3;
			
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AGE");
			h.addAllowedValue("AT");
			h.addAllowedValue("BC");
			h.addAllowedValue("BCC");
			h.addAllowedValue("BES");
			h.addAllowedValue("BEV");
			h.addAllowedValue("BLM");
			h.addAllowedValue("BND");
			h.addAllowedValue("BPI");
			h.addAllowedValue("BRG");
			h.addAllowedValue("BW");
			h.addAllowedValue("B8");
			h.addAllowedValue("CCN");
			h.addAllowedValue("CD");
			h.addAllowedValue("CFC");
			h.addAllowedValue("CH");
			h.addAllowedValue("CHF");
			h.addAllowedValue("CL");
			h.addAllowedValue("CLT");
			h.addAllowedValue("CM");
			h.addAllowedValue("CMS");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CS");
			h.addAllowedValue("CU");
			h.addAllowedValue("CW");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("DAC");
			h.addAllowedValue("DAF");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DIR");
			h.addAllowedValue("DM");
			h.addAllowedValue("EC");
			h.addAllowedValue("EN");
			h.addAllowedValue("FA");
			h.addAllowedValue("FC");
			h.addAllowedValue("FCD");
			h.addAllowedValue("FDD");
			h.addAllowedValue("FL");
			h.addAllowedValue("FLV");
			h.addAllowedValue("FMR");
			h.addAllowedValue("FQ");
			h.addAllowedValue("GD");
			h.addAllowedValue("GEN");
			h.addAllowedValue("GM");
			h.addAllowedValue("GS");
			h.addAllowedValue("HB");
			h.addAllowedValue("HY");
			h.addAllowedValue("HZ");
			h.addAllowedValue("HZR");
			h.addAllowedValue("ING");
			h.addAllowedValue("INJ");
			h.addAllowedValue("KI");
			h.addAllowedValue("LC");
			h.addAllowedValue("LO");
			h.addAllowedValue("MA");
			h.addAllowedValue("MAC");
			h.addAllowedValue("MB");
			h.addAllowedValue("MBU");
			h.addAllowedValue("MS");
			h.addAllowedValue("MSG");
			h.addAllowedValue("NH");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("ODR");
			h.addAllowedValue("OR");
			h.addAllowedValue("OT");
			h.addAllowedValue("PD");
			h.addAllowedValue("PF");
			h.addAllowedValue("PFA");
			h.addAllowedValue("PFC");
			h.addAllowedValue("PFG");
			h.addAllowedValue("PFI");
			h.addAllowedValue("PFK");
			h.addAllowedValue("PFL");
			h.addAllowedValue("PFM");
			h.addAllowedValue("PFN");
			h.addAllowedValue("PFP");
			h.addAllowedValue("PFS");
			h.addAllowedValue("PFT");
			h.addAllowedValue("PG");
			h.addAllowedValue("PP");
			h.addAllowedValue("PR");
			h.addAllowedValue("PRI");
			h.addAllowedValue("PRO");
			h.addAllowedValue("PSC");
			h.addAllowedValue("PUB");
			h.addAllowedValue("PUR");
			h.addAllowedValue("P6");
			h.addAllowedValue("QAS");
			h.addAllowedValue("RA");
			h.addAllowedValue("RCC");
			h.addAllowedValue("RM");
			h.addAllowedValue("RR");
			h.addAllowedValue("RSD");
			h.addAllowedValue("RSE");
			h.addAllowedValue("RX");
			h.addAllowedValue("R3");
			h.addAllowedValue("SC");
			h.addAllowedValue("SE");
			h.addAllowedValue("SEC");
			h.addAllowedValue("SF");
			h.addAllowedValue("SIZ");
			h.addAllowedValue("SLM");
			h.addAllowedValue("SOL");
			h.addAllowedValue("ST");
			h.addAllowedValue("STL");
			h.addAllowedValue("SYN");
			h.addAllowedValue("TC");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("THR");
			h.addAllowedValue("TIF");
			h.addAllowedValue("TIR");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TRN");
			h.addAllowedValue("TWF");
			h.addAllowedValue("TZ");
			h.addAllowedValue("VA");
			h.addAllowedValue("VC");
			h.addAllowedValue("VI");
			h.addAllowedValue("WD");
			h.addAllowedValue("WF");
			h.addAllowedValue("WLC");
			h.addAllowedValue("WT");
			h.addAllowedValue("WTT");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("25");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9A");
			h.addAllowedValue("9B");
			h.addAllowedValue("9C");
			h.addAllowedValue("9D");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("99");
			simpleElement750 = new RtSimpleElement("750", "ID", h);
		}
	
		return simpleElement750;
	}
	
	private RtSimpleElement simpleElement751;
	
	private RtSimpleElement simpleElement751() {
		if (simpleElement751 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Product Description Code";
			h.minLength = 1;
			h.maxLength = 12;
			
			simpleElement751 = new RtSimpleElement("751", "AN", h);
		}
	
		return simpleElement751;
	}
	
	private RtSimpleElement simpleElement752;
	
	private RtSimpleElement simpleElement752() {
		if (simpleElement752 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Surface/Layer/Position Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AL");
			h.addAllowedValue("AO");
			h.addAllowedValue("AS");
			h.addAllowedValue("A1");
			h.addAllowedValue("BC");
			h.addAllowedValue("BI");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BR");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("B1");
			h.addAllowedValue("CH");
			h.addAllowedValue("CT");
			h.addAllowedValue("DO");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("EX");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("GF");
			h.addAllowedValue("IN");
			h.addAllowedValue("IT");
			h.addAllowedValue("KB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LO");
			h.addAllowedValue("LT");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("M1");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("OA");
			h.addAllowedValue("OS");
			h.addAllowedValue("OT");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RV");
			h.addAllowedValue("RW");
			h.addAllowedValue("RX");
			h.addAllowedValue("RY");
			h.addAllowedValue("RZ");
			h.addAllowedValue("R0");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("R9");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SN");
			h.addAllowedValue("SP");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("TB");
			h.addAllowedValue("TP");
			h.addAllowedValue("TS");
			h.addAllowedValue("UC");
			h.addAllowedValue("UN");
			h.addAllowedValue("UP");
			h.addAllowedValue("UT");
			h.addAllowedValue("WF");
			h.addAllowedValue("1S");
			h.addAllowedValue("2S");
			simpleElement752 = new RtSimpleElement("752", "ID", h);
		}
	
		return simpleElement752;
	}
	
	private RtSimpleElement simpleElement822;
	
	private RtSimpleElement simpleElement822() {
		if (simpleElement822 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Source Subqualifier";
			h.minLength = 1;
			h.maxLength = 15;
			
			simpleElement822 = new RtSimpleElement("822", "AN", h);
		}
	
		return simpleElement822;
	}
	
	private RtSimpleElement simpleElement737;
	
	private RtSimpleElement simpleElement737() {
		if (simpleElement737 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Measurement Reference ID Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AV");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BR");
			h.addAllowedValue("BT");
			h.addAllowedValue("BZ");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CY");
			h.addAllowedValue("C1");
			h.addAllowedValue("DE");
			h.addAllowedValue("DN");
			h.addAllowedValue("DT");
			h.addAllowedValue("EA");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EL");
			h.addAllowedValue("EN");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FH");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FV");
			h.addAllowedValue("FZ");
			h.addAllowedValue("GC");
			h.addAllowedValue("GL");
			h.addAllowedValue("GO");
			h.addAllowedValue("GP");
			h.addAllowedValue("HC");
			h.addAllowedValue("HR");
			h.addAllowedValue("ID");
			h.addAllowedValue("IN");
			h.addAllowedValue("IR");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LG");
			h.addAllowedValue("LL");
			h.addAllowedValue("LM");
			h.addAllowedValue("LP");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("MP");
			h.addAllowedValue("MR");
			h.addAllowedValue("NC");
			h.addAllowedValue("NE");
			h.addAllowedValue("NX");
			h.addAllowedValue("OD");
			h.addAllowedValue("OG");
			h.addAllowedValue("OL");
			h.addAllowedValue("OP");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PO");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PY");
			h.addAllowedValue("P1");
			h.addAllowedValue("QR");
			h.addAllowedValue("QV");
			h.addAllowedValue("RA");
			h.addAllowedValue("RG");
			h.addAllowedValue("RL");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SH");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SP");
			h.addAllowedValue("SR");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SZ");
			h.addAllowedValue("TA");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TI");
			h.addAllowedValue("TL");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("VT");
			h.addAllowedValue("WA");
			h.addAllowedValue("WR");
			h.addAllowedValue("WT");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZP");
			h.addAllowedValue("9L");
			simpleElement737 = new RtSimpleElement("737", "ID", h);
		}
	
		return simpleElement737;
	}
	
	private RtSimpleElement simpleElement738;
	
	private RtSimpleElement simpleElement738() {
		if (simpleElement738 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Measurement Qualifier";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AA");
			h.addAllowedValue("AAP");
			h.addAllowedValue("AB");
			h.addAllowedValue("ABO");
			h.addAllowedValue("ABR");
			h.addAllowedValue("ABS");
			h.addAllowedValue("AC");
			h.addAllowedValue("ACN");
			h.addAllowedValue("AD");
			h.addAllowedValue("ADH");
			h.addAllowedValue("ADM");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AGE");
			h.addAllowedValue("AGI");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("ALK");
			h.addAllowedValue("ALN");
			h.addAllowedValue("ALP");
			h.addAllowedValue("AM");
			h.addAllowedValue("AMI");
			h.addAllowedValue("AMW");
			h.addAllowedValue("AN");
			h.addAllowedValue("AOX");
			h.addAllowedValue("AP");
			h.addAllowedValue("API");
			h.addAllowedValue("APP");
			h.addAllowedValue("AS");
			h.addAllowedValue("ASH");
			h.addAllowedValue("ASY");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AVT");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A9");
			h.addAllowedValue("B");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BDP");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BHF");
			h.addAllowedValue("BHS");
			h.addAllowedValue("BIC");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BN");
			h.addAllowedValue("BND");
			h.addAllowedValue("BO");
			h.addAllowedValue("BOR");
			h.addAllowedValue("BP");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BRS");
			h.addAllowedValue("BSW");
			h.addAllowedValue("BT");
			h.addAllowedValue("BU");
			h.addAllowedValue("BUD");
			h.addAllowedValue("BW");
			h.addAllowedValue("BX");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("B6");
			h.addAllowedValue("C");
			h.addAllowedValue("CA");
			h.addAllowedValue("CAU");
			h.addAllowedValue("CC");
			h.addAllowedValue("CCF");
			h.addAllowedValue("CCG");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CGR");
			h.addAllowedValue("CH");
			h.addAllowedValue("CHA");
			h.addAllowedValue("CHC");
			h.addAllowedValue("CHG");
			h.addAllowedValue("CHL");
			h.addAllowedValue("CI");
			h.addAllowedValue("CIV");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CLA");
			h.addAllowedValue("CLB");
			h.addAllowedValue("CLN");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("COH");
			h.addAllowedValue("COL");
			h.addAllowedValue("CON");
			h.addAllowedValue("COR");
			h.addAllowedValue("COS");
			h.addAllowedValue("COT");
			h.addAllowedValue("CP");
			h.addAllowedValue("CPF");
			h.addAllowedValue("CPS");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CRF");
			h.addAllowedValue("CRL");
			h.addAllowedValue("CRN");
			h.addAllowedValue("CRT");
			h.addAllowedValue("CS");
			h.addAllowedValue("CSC");
			h.addAllowedValue("CSR");
			h.addAllowedValue("CST");
			h.addAllowedValue("CT");
			h.addAllowedValue("CTG");
			h.addAllowedValue("CTT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CUT");
			h.addAllowedValue("CW");
			h.addAllowedValue("CWT");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CYB");
			h.addAllowedValue("C0");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("D");
			h.addAllowedValue("DA");
			h.addAllowedValue("DAT");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DCT");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DEM");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DIR");
			h.addAllowedValue("DIS");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DL");
			h.addAllowedValue("DM");
			h.addAllowedValue("DME");
			h.addAllowedValue("DMF");
			h.addAllowedValue("DN");
			h.addAllowedValue("DP");
			h.addAllowedValue("DPM");
			h.addAllowedValue("DR");
			h.addAllowedValue("DRY");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("DW");
			h.addAllowedValue("DWP");
			h.addAllowedValue("DY");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("D7");
			h.addAllowedValue("E");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EH");
			h.addAllowedValue("EI");
			h.addAllowedValue("EJ");
			h.addAllowedValue("EL");
			h.addAllowedValue("ELC");
			h.addAllowedValue("ELE");
			h.addAllowedValue("ELI");
			h.addAllowedValue("ELL");
			h.addAllowedValue("ELO");
			h.addAllowedValue("ELP");
			h.addAllowedValue("ELS");
			h.addAllowedValue("ELT");
			h.addAllowedValue("ELV");
			h.addAllowedValue("ELW");
			h.addAllowedValue("ELX");
			h.addAllowedValue("EM");
			h.addAllowedValue("EN");
			h.addAllowedValue("EP");
			h.addAllowedValue("EPL");
			h.addAllowedValue("ES");
			h.addAllowedValue("EVL");
			h.addAllowedValue("EVR");
			h.addAllowedValue("EW");
			h.addAllowedValue("EX");
			h.addAllowedValue("EXH");
			h.addAllowedValue("EXT");
			h.addAllowedValue("E0");
			h.addAllowedValue("E1");
			h.addAllowedValue("F");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FBP");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FIL");
			h.addAllowedValue("FIN");
			h.addAllowedValue("FIT");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FK");
			h.addAllowedValue("FL");
			h.addAllowedValue("FLD");
			h.addAllowedValue("FLN");
			h.addAllowedValue("FLP");
			h.addAllowedValue("FLV");
			h.addAllowedValue("FML");
			h.addAllowedValue("FMZ");
			h.addAllowedValue("FN");
			h.addAllowedValue("FNL");
			h.addAllowedValue("FNS");
			h.addAllowedValue("FOA");
			h.addAllowedValue("FOH");
			h.addAllowedValue("FOI");
			h.addAllowedValue("FOR");
			h.addAllowedValue("FP");
			h.addAllowedValue("FPV");
			h.addAllowedValue("FQ");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FSI");
			h.addAllowedValue("FT");
			h.addAllowedValue("FU");
			h.addAllowedValue("FUD");
			h.addAllowedValue("FV");
			h.addAllowedValue("FW");
			h.addAllowedValue("FX");
			h.addAllowedValue("FY");
			h.addAllowedValue("FZ");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("F5");
			h.addAllowedValue("F6");
			h.addAllowedValue("F7");
			h.addAllowedValue("F8");
			h.addAllowedValue("F9");
			h.addAllowedValue("G");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GD");
			h.addAllowedValue("GE");
			h.addAllowedValue("GEL");
			h.addAllowedValue("GF");
			h.addAllowedValue("GG");
			h.addAllowedValue("GGR");
			h.addAllowedValue("GH");
			h.addAllowedValue("GI");
			h.addAllowedValue("GIR");
			h.addAllowedValue("GJ");
			h.addAllowedValue("GK");
			h.addAllowedValue("GL");
			h.addAllowedValue("GLE");
			h.addAllowedValue("GM");
			h.addAllowedValue("GN");
			h.addAllowedValue("GO");
			h.addAllowedValue("GOR");
			h.addAllowedValue("GP");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GRA");
			h.addAllowedValue("GRI");
			h.addAllowedValue("GS");
			h.addAllowedValue("GT");
			h.addAllowedValue("GW");
			h.addAllowedValue("G1");
			h.addAllowedValue("G2");
			h.addAllowedValue("G3");
			h.addAllowedValue("G4");
			h.addAllowedValue("HA");
			h.addAllowedValue("HAR");
			h.addAllowedValue("HAZ");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HCG");
			h.addAllowedValue("HD");
			h.addAllowedValue("HE");
			h.addAllowedValue("HF");
			h.addAllowedValue("HG");
			h.addAllowedValue("HH");
			h.addAllowedValue("HHW");
			h.addAllowedValue("HI");
			h.addAllowedValue("HIB");
			h.addAllowedValue("HJ");
			h.addAllowedValue("HK");
			h.addAllowedValue("HL");
			h.addAllowedValue("HM");
			h.addAllowedValue("HO");
			h.addAllowedValue("HOC");
			h.addAllowedValue("HP");
			h.addAllowedValue("HR");
			h.addAllowedValue("HT");
			h.addAllowedValue("HTE");
			h.addAllowedValue("HVM");
			h.addAllowedValue("HWS");
			h.addAllowedValue("HYD");
			h.addAllowedValue("HZ");
			h.addAllowedValue("HZC");
			h.addAllowedValue("H1");
			h.addAllowedValue("H2O");
			h.addAllowedValue("H8");
			h.addAllowedValue("H9");
			h.addAllowedValue("I");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IDE");
			h.addAllowedValue("IE");
			h.addAllowedValue("IF");
			h.addAllowedValue("IG");
			h.addAllowedValue("IGA");
			h.addAllowedValue("IGR");
			h.addAllowedValue("IH");
			h.addAllowedValue("IHV");
			h.addAllowedValue("II");
			h.addAllowedValue("IJ");
			h.addAllowedValue("IK");
			h.addAllowedValue("IL");
			h.addAllowedValue("IM");
			h.addAllowedValue("IMP");
			h.addAllowedValue("IN");
			h.addAllowedValue("IND");
			h.addAllowedValue("INS");
			h.addAllowedValue("IO");
			h.addAllowedValue("IP");
			h.addAllowedValue("IPI");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IR");
			h.addAllowedValue("IRA");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("IU");
			h.addAllowedValue("IV");
			h.addAllowedValue("IW");
			h.addAllowedValue("IX");
			h.addAllowedValue("IY");
			h.addAllowedValue("IZ");
			h.addAllowedValue("JA");
			h.addAllowedValue("JOM");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KN");
			h.addAllowedValue("L");
			h.addAllowedValue("LA");
			h.addAllowedValue("LAI");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LCG");
			h.addAllowedValue("LC5");
			h.addAllowedValue("LD");
			h.addAllowedValue("LDH");
			h.addAllowedValue("LD5");
			h.addAllowedValue("LE");
			h.addAllowedValue("LEF");
			h.addAllowedValue("LF");
			h.addAllowedValue("LG");
			h.addAllowedValue("LIR");
			h.addAllowedValue("LIV");
			h.addAllowedValue("LL");
			h.addAllowedValue("LLD");
			h.addAllowedValue("LM");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LOI");
			h.addAllowedValue("LOS");
			h.addAllowedValue("LOW");
			h.addAllowedValue("LP");
			h.addAllowedValue("LPG");
			h.addAllowedValue("LPL");
			h.addAllowedValue("LPR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LSK");
			h.addAllowedValue("LSS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LTD");
			h.addAllowedValue("LW");
			h.addAllowedValue("L0");
			h.addAllowedValue("L1");
			h.addAllowedValue("M");
			h.addAllowedValue("MA");
			h.addAllowedValue("MAT");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MCN");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MEF");
			h.addAllowedValue("MEL");
			h.addAllowedValue("MER");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MHI");
			h.addAllowedValue("MI");
			h.addAllowedValue("MIC");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MOI");
			h.addAllowedValue("MOR");
			h.addAllowedValue("MP");
			h.addAllowedValue("MPR");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("MTD");
			h.addAllowedValue("MU");
			h.addAllowedValue("MUL");
			h.addAllowedValue("MV");
			h.addAllowedValue("MW");
			h.addAllowedValue("MX");
			h.addAllowedValue("MY");
			h.addAllowedValue("M1");
			h.addAllowedValue("M2");
			h.addAllowedValue("M3");
			h.addAllowedValue("M4");
			h.addAllowedValue("M5");
			h.addAllowedValue("M6");
			h.addAllowedValue("N");
			h.addAllowedValue("NA");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NEU");
			h.addAllowedValue("NF");
			h.addAllowedValue("NG");
			h.addAllowedValue("NH");
			h.addAllowedValue("NI");
			h.addAllowedValue("NIL");
			h.addAllowedValue("NJ");
			h.addAllowedValue("NK");
			h.addAllowedValue("NL");
			h.addAllowedValue("NM");
			h.addAllowedValue("NNW");
			h.addAllowedValue("NO");
			h.addAllowedValue("NOC");
			h.addAllowedValue("NON");
			h.addAllowedValue("NOR");
			h.addAllowedValue("NOX");
			h.addAllowedValue("NP");
			h.addAllowedValue("NS");
			h.addAllowedValue("NU");
			h.addAllowedValue("NV");
			h.addAllowedValue("O");
			h.addAllowedValue("OA");
			h.addAllowedValue("OAP");
			h.addAllowedValue("OB");
			h.addAllowedValue("OBT");
			h.addAllowedValue("OC");
			h.addAllowedValue("OCG");
			h.addAllowedValue("OCR");
			h.addAllowedValue("OD");
			h.addAllowedValue("ODR");
			h.addAllowedValue("OE");
			h.addAllowedValue("OF");
			h.addAllowedValue("OG");
			h.addAllowedValue("OH");
			h.addAllowedValue("OI");
			h.addAllowedValue("OIL");
			h.addAllowedValue("OJ");
			h.addAllowedValue("OK");
			h.addAllowedValue("OL");
			h.addAllowedValue("OLE");
			h.addAllowedValue("OM");
			h.addAllowedValue("ON");
			h.addAllowedValue("OO");
			h.addAllowedValue("OP");
			h.addAllowedValue("OQ");
			h.addAllowedValue("OR");
			h.addAllowedValue("ORC");
			h.addAllowedValue("OS");
			h.addAllowedValue("OT");
			h.addAllowedValue("OTE");
			h.addAllowedValue("OTH");
			h.addAllowedValue("OTT");
			h.addAllowedValue("OV");
			h.addAllowedValue("OW");
			h.addAllowedValue("OX");
			h.addAllowedValue("OXI");
			h.addAllowedValue("OXS");
			h.addAllowedValue("OY");
			h.addAllowedValue("O1");
			h.addAllowedValue("PA");
			h.addAllowedValue("PAR");
			h.addAllowedValue("PB");
			h.addAllowedValue("PBD");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PDE");
			h.addAllowedValue("PDG");
			h.addAllowedValue("PE");
			h.addAllowedValue("PER");
			h.addAllowedValue("PF");
			h.addAllowedValue("PFO");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PHA");
			h.addAllowedValue("PHW");
			h.addAllowedValue("PI");
			h.addAllowedValue("PIC");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("POC");
			h.addAllowedValue("POD");
			h.addAllowedValue("POP");
			h.addAllowedValue("PP");
			h.addAllowedValue("PPS");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PRE");
			h.addAllowedValue("PRF");
			h.addAllowedValue("PRI");
			h.addAllowedValue("PRL");
			h.addAllowedValue("PRO");
			h.addAllowedValue("PRQ");
			h.addAllowedValue("PRY");
			h.addAllowedValue("PS");
			h.addAllowedValue("PSA");
			h.addAllowedValue("PSP");
			h.addAllowedValue("PSW");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PWA");
			h.addAllowedValue("PWE");
			h.addAllowedValue("PWF");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P1");
			h.addAllowedValue("Q");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QF");
			h.addAllowedValue("QL");
			h.addAllowedValue("QUR");
			h.addAllowedValue("R");
			h.addAllowedValue("RA");
			h.addAllowedValue("RAD");
			h.addAllowedValue("RAF");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("REA");
			h.addAllowedValue("RED");
			h.addAllowedValue("REF");
			h.addAllowedValue("REI");
			h.addAllowedValue("REL");
			h.addAllowedValue("RES");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("ROH");
			h.addAllowedValue("ROX");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RSZ");
			h.addAllowedValue("RT");
			h.addAllowedValue("RTB");
			h.addAllowedValue("RU");
			h.addAllowedValue("RUD");
			h.addAllowedValue("RV");
			h.addAllowedValue("RVP");
			h.addAllowedValue("RW");
			h.addAllowedValue("RX");
			h.addAllowedValue("RY");
			h.addAllowedValue("R1");
			h.addAllowedValue("R10");
			h.addAllowedValue("R18");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("S");
			h.addAllowedValue("SA");
			h.addAllowedValue("SAP");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SCH");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SEV");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SHA");
			h.addAllowedValue("SI");
			h.addAllowedValue("SIL");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SLD");
			h.addAllowedValue("SLI");
			h.addAllowedValue("SM");
			h.addAllowedValue("SMB");
			h.addAllowedValue("SMD");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SOD");
			h.addAllowedValue("SOF");
			h.addAllowedValue("SP");
			h.addAllowedValue("SPG");
			h.addAllowedValue("SPR");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("STA");
			h.addAllowedValue("STL");
			h.addAllowedValue("STP");
			h.addAllowedValue("SU");
			h.addAllowedValue("SUM");
			h.addAllowedValue("SUR");
			h.addAllowedValue("SUT");
			h.addAllowedValue("SV");
			h.addAllowedValue("SVL");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SXX");
			h.addAllowedValue("SY");
			h.addAllowedValue("SZ");
			h.addAllowedValue("S1");
			h.addAllowedValue("S10");
			h.addAllowedValue("S12");
			h.addAllowedValue("S18");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("T");
			h.addAllowedValue("TA");
			h.addAllowedValue("TAS");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TCL");
			h.addAllowedValue("TD");
			h.addAllowedValue("TDP");
			h.addAllowedValue("TE");
			h.addAllowedValue("TEE");
			h.addAllowedValue("TES");
			h.addAllowedValue("TEX");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TOA");
			h.addAllowedValue("TOR");
			h.addAllowedValue("TOX");
			h.addAllowedValue("TP");
			h.addAllowedValue("TPF");
			h.addAllowedValue("TPL");
			h.addAllowedValue("TPQ");
			h.addAllowedValue("TPS");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TRA");
			h.addAllowedValue("TRC");
			h.addAllowedValue("TRD");
			h.addAllowedValue("TRN");
			h.addAllowedValue("TS");
			h.addAllowedValue("TSZ");
			h.addAllowedValue("TT");
			h.addAllowedValue("TTL");
			h.addAllowedValue("TU");
			h.addAllowedValue("TUR");
			h.addAllowedValue("TV");
			h.addAllowedValue("TVD");
			h.addAllowedValue("TW");
			h.addAllowedValue("TWD");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("T4");
			h.addAllowedValue("T5");
			h.addAllowedValue("T50");
			h.addAllowedValue("T90");
			h.addAllowedValue("U");
			h.addAllowedValue("UA");
			h.addAllowedValue("UCB");
			h.addAllowedValue("UG");
			h.addAllowedValue("UNI");
			h.addAllowedValue("UNK");
			h.addAllowedValue("VAD");
			h.addAllowedValue("VAP");
			h.addAllowedValue("VCG");
			h.addAllowedValue("VH");
			h.addAllowedValue("VIN");
			h.addAllowedValue("VIS");
			h.addAllowedValue("VO");
			h.addAllowedValue("VOC");
			h.addAllowedValue("VOL");
			h.addAllowedValue("VOT");
			h.addAllowedValue("VOV");
			h.addAllowedValue("VOW");
			h.addAllowedValue("VSO");
			h.addAllowedValue("VW");
			h.addAllowedValue("VWT");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WC");
			h.addAllowedValue("WD");
			h.addAllowedValue("WDE");
			h.addAllowedValue("WE");
			h.addAllowedValue("WEL");
			h.addAllowedValue("WF");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WL");
			h.addAllowedValue("WM");
			h.addAllowedValue("WOD");
			h.addAllowedValue("WPF");
			h.addAllowedValue("WPL");
			h.addAllowedValue("WPS");
			h.addAllowedValue("WR");
			h.addAllowedValue("WRA");
			h.addAllowedValue("WSK");
			h.addAllowedValue("WT");
			h.addAllowedValue("WTB");
			h.addAllowedValue("WU");
			h.addAllowedValue("WX");
			h.addAllowedValue("X");
			h.addAllowedValue("XA");
			h.addAllowedValue("XH");
			h.addAllowedValue("XP");
			h.addAllowedValue("XQ");
			h.addAllowedValue("XZ");
			h.addAllowedValue("YA");
			h.addAllowedValue("YB");
			h.addAllowedValue("YC");
			h.addAllowedValue("YD");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZAL");
			h.addAllowedValue("ZAS");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZBI");
			h.addAllowedValue("ZBT");
			h.addAllowedValue("ZBZ");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZCA");
			h.addAllowedValue("ZCB");
			h.addAllowedValue("ZCD");
			h.addAllowedValue("ZCE");
			h.addAllowedValue("ZCO");
			h.addAllowedValue("ZCR");
			h.addAllowedValue("ZCU");
			h.addAllowedValue("ZD");
			h.addAllowedValue("ZET");
			h.addAllowedValue("ZF");
			h.addAllowedValue("ZFE");
			h.addAllowedValue("ZFL");
			h.addAllowedValue("ZFS");
			h.addAllowedValue("ZG");
			h.addAllowedValue("ZGE");
			h.addAllowedValue("ZH");
			h.addAllowedValue("ZHP");
			h.addAllowedValue("ZHS");
			h.addAllowedValue("ZHX");
			h.addAllowedValue("ZIB");
			h.addAllowedValue("ZIP");
			h.addAllowedValue("ZMG");
			h.addAllowedValue("ZMN");
			h.addAllowedValue("ZMO");
			h.addAllowedValue("ZMT");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZNB");
			h.addAllowedValue("ZNI");
			h.addAllowedValue("ZNP");
			h.addAllowedValue("ZO");
			h.addAllowedValue("ZOC");
			h.addAllowedValue("ZP");
			h.addAllowedValue("ZPB");
			h.addAllowedValue("ZPP");
			h.addAllowedValue("ZPT");
			h.addAllowedValue("ZR");
			h.addAllowedValue("ZS");
			h.addAllowedValue("ZSB");
			h.addAllowedValue("ZSE");
			h.addAllowedValue("ZSI");
			h.addAllowedValue("ZSN");
			h.addAllowedValue("ZTA");
			h.addAllowedValue("ZTB");
			h.addAllowedValue("ZTE");
			h.addAllowedValue("ZTI");
			h.addAllowedValue("ZV");
			h.addAllowedValue("ZW");
			h.addAllowedValue("ZZN");
			h.addAllowedValue("ZZR");
			h.addAllowedValue("ZZZ");
			h.addAllowedValue("1");
			h.addAllowedValue("1F");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("2F");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3");
			h.addAllowedValue("3A");
			h.addAllowedValue("3B");
			h.addAllowedValue("3C");
			h.addAllowedValue("3D");
			h.addAllowedValue("3E");
			h.addAllowedValue("3F");
			h.addAllowedValue("3G");
			h.addAllowedValue("3H");
			h.addAllowedValue("3I");
			h.addAllowedValue("3J");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4");
			h.addAllowedValue("4F");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("5");
			h.addAllowedValue("5F");
			h.addAllowedValue("6");
			h.addAllowedValue("6F");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			h.addAllowedValue("8F");
			simpleElement738 = new RtSimpleElement("738", "ID", h);
		}
	
		return simpleElement738;
	}
	
	private RtSimpleElement simpleElement739;
	
	private RtSimpleElement simpleElement739() {
		if (simpleElement739 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Measurement Value";
			h.minLength = 1;
			h.maxLength = 20;
			
			simpleElement739 = new RtSimpleElement("739", "R", h);
		}
	
		return simpleElement739;
	}
	
	private RtSimpleElement simpleElement740;
	
	private RtSimpleElement simpleElement740() {
		if (simpleElement740 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Range Minimum";
			h.minLength = 1;
			h.maxLength = 20;
			
			simpleElement740 = new RtSimpleElement("740", "R", h);
		}
	
		return simpleElement740;
	}
	
	private RtSimpleElement simpleElement741;
	
	private RtSimpleElement simpleElement741() {
		if (simpleElement741 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Range Maximum";
			h.minLength = 1;
			h.maxLength = 20;
			
			simpleElement741 = new RtSimpleElement("741", "R", h);
		}
	
		return simpleElement741;
	}
	
	private RtSimpleElement simpleElement935;
	
	private RtSimpleElement simpleElement935() {
		if (simpleElement935 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Measurement Significance Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			simpleElement935 = new RtSimpleElement("935", "ID", h);
		}
	
		return simpleElement935;
	}
	
	private RtSimpleElement simpleElement936;
	
	private RtSimpleElement simpleElement936() {
		if (simpleElement936 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Measurement Attribute Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("Q1");
			h.addAllowedValue("Q2");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			simpleElement936 = new RtSimpleElement("936", "ID", h);
		}
	
		return simpleElement936;
	}
	
	private RtSimpleElement simpleElement1373;
	
	private RtSimpleElement simpleElement1373() {
		if (simpleElement1373 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Measurement Method or Device";
			h.minLength = 2;
			h.maxLength = 4;
			
			h.addAllowedValue("BM");
			h.addAllowedValue("BO");
			h.addAllowedValue("DM");
			h.addAllowedValue("FT");
			h.addAllowedValue("MA");
			h.addAllowedValue("MM");
			h.addAllowedValue("OM");
			h.addAllowedValue("PT");
			h.addAllowedValue("TM");
			h.addAllowedValue("VA");
			h.addAllowedValue("VB");
			h.addAllowedValue("VC");
			simpleElement1373 = new RtSimpleElement("1373", "ID", h);
		}
	
		return simpleElement1373;
	}
	
	private RtSimpleElement simpleElement755;
	
	private RtSimpleElement simpleElement755() {
		if (simpleElement755 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Report Type Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("AY");
			h.addAllowedValue("AZ");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BR");
			h.addAllowedValue("BS");
			h.addAllowedValue("BT");
			h.addAllowedValue("BW");
			h.addAllowedValue("BY");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("C7");
			h.addAllowedValue("C8");
			h.addAllowedValue("C9");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("DV");
			h.addAllowedValue("DW");
			h.addAllowedValue("D2");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EL");
			h.addAllowedValue("EP");
			h.addAllowedValue("ER");
			h.addAllowedValue("EX");
			h.addAllowedValue("EY");
			h.addAllowedValue("E1");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FM");
			h.addAllowedValue("FS");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("F5");
			h.addAllowedValue("F6");
			h.addAllowedValue("F7");
			h.addAllowedValue("F8");
			h.addAllowedValue("F9");
			h.addAllowedValue("GP");
			h.addAllowedValue("GT");
			h.addAllowedValue("HC");
			h.addAllowedValue("HR");
			h.addAllowedValue("HW");
			h.addAllowedValue("IA");
			h.addAllowedValue("IC");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IP");
			h.addAllowedValue("IR");
			h.addAllowedValue("IS");
			h.addAllowedValue("IT");
			h.addAllowedValue("IU");
			h.addAllowedValue("IV");
			h.addAllowedValue("I2");
			h.addAllowedValue("I3");
			h.addAllowedValue("I4");
			h.addAllowedValue("I5");
			h.addAllowedValue("I6");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JC");
			h.addAllowedValue("JD");
			h.addAllowedValue("JE");
			h.addAllowedValue("JF");
			h.addAllowedValue("JG");
			h.addAllowedValue("JH");
			h.addAllowedValue("JI");
			h.addAllowedValue("JK");
			h.addAllowedValue("JL");
			h.addAllowedValue("JM");
			h.addAllowedValue("JN");
			h.addAllowedValue("JO");
			h.addAllowedValue("JP");
			h.addAllowedValue("JQ");
			h.addAllowedValue("JR");
			h.addAllowedValue("JS");
			h.addAllowedValue("JT");
			h.addAllowedValue("JV");
			h.addAllowedValue("JW");
			h.addAllowedValue("JX");
			h.addAllowedValue("JY");
			h.addAllowedValue("JZ");
			h.addAllowedValue("KA");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KY");
			h.addAllowedValue("KZ");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LG");
			h.addAllowedValue("LI");
			h.addAllowedValue("LO");
			h.addAllowedValue("LP");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LW");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MP");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("MV");
			h.addAllowedValue("MZ");
			h.addAllowedValue("M1");
			h.addAllowedValue("NA");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NI");
			h.addAllowedValue("NL");
			h.addAllowedValue("NM");
			h.addAllowedValue("NN");
			h.addAllowedValue("NO");
			h.addAllowedValue("NQ");
			h.addAllowedValue("NR");
			h.addAllowedValue("NT");
			h.addAllowedValue("OB");
			h.addAllowedValue("OC");
			h.addAllowedValue("OD");
			h.addAllowedValue("OE");
			h.addAllowedValue("OL");
			h.addAllowedValue("OP");
			h.addAllowedValue("OR");
			h.addAllowedValue("OS");
			h.addAllowedValue("OT");
			h.addAllowedValue("OX");
			h.addAllowedValue("OZ");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PV");
			h.addAllowedValue("PW");
			h.addAllowedValue("PX");
			h.addAllowedValue("PY");
			h.addAllowedValue("PZ");
			h.addAllowedValue("P1");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P6");
			h.addAllowedValue("P7");
			h.addAllowedValue("P8");
			h.addAllowedValue("QC");
			h.addAllowedValue("QD");
			h.addAllowedValue("QE");
			h.addAllowedValue("QM");
			h.addAllowedValue("QR");
			h.addAllowedValue("QS");
			h.addAllowedValue("QT");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RR");
			h.addAllowedValue("RT");
			h.addAllowedValue("RV");
			h.addAllowedValue("RX");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("SX");
			h.addAllowedValue("SY");
			h.addAllowedValue("S1");
			h.addAllowedValue("S2");
			h.addAllowedValue("S3");
			h.addAllowedValue("S4");
			h.addAllowedValue("S5");
			h.addAllowedValue("S6");
			h.addAllowedValue("S7");
			h.addAllowedValue("S8");
			h.addAllowedValue("S9");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TX");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("T3");
			h.addAllowedValue("T4");
			h.addAllowedValue("T5");
			h.addAllowedValue("T6");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("UF");
			h.addAllowedValue("UG");
			h.addAllowedValue("UH");
			h.addAllowedValue("UI");
			h.addAllowedValue("UJ");
			h.addAllowedValue("UK");
			h.addAllowedValue("UL");
			h.addAllowedValue("UM");
			h.addAllowedValue("UN");
			h.addAllowedValue("UO");
			h.addAllowedValue("UP");
			h.addAllowedValue("UQ");
			h.addAllowedValue("UR");
			h.addAllowedValue("US");
			h.addAllowedValue("UT");
			h.addAllowedValue("UU");
			h.addAllowedValue("UV");
			h.addAllowedValue("UX");
			h.addAllowedValue("UY");
			h.addAllowedValue("UZ");
			h.addAllowedValue("U1");
			h.addAllowedValue("VA");
			h.addAllowedValue("VC");
			h.addAllowedValue("VD");
			h.addAllowedValue("VM");
			h.addAllowedValue("V1");
			h.addAllowedValue("V2");
			h.addAllowedValue("V3");
			h.addAllowedValue("V4");
			h.addAllowedValue("V5");
			h.addAllowedValue("V6");
			h.addAllowedValue("V7");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WC");
			h.addAllowedValue("WD");
			h.addAllowedValue("WE");
			h.addAllowedValue("WF");
			h.addAllowedValue("WG");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WP");
			h.addAllowedValue("WT");
			h.addAllowedValue("W1");
			h.addAllowedValue("W2");
			h.addAllowedValue("XE");
			h.addAllowedValue("XP");
			h.addAllowedValue("X1");
			h.addAllowedValue("X2");
			h.addAllowedValue("X3");
			h.addAllowedValue("X4");
			h.addAllowedValue("X5");
			h.addAllowedValue("Y1");
			h.addAllowedValue("Y2");
			h.addAllowedValue("Y3");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			simpleElement755 = new RtSimpleElement("755", "ID", h);
		}
	
		return simpleElement755;
	}
	
	private RtSimpleElement simpleElement756;
	
	private RtSimpleElement simpleElement756() {
		if (simpleElement756 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Report Transmission Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AC");
			h.addAllowedValue("AE");
			h.addAllowedValue("AM");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("BE");
			h.addAllowedValue("BM");
			h.addAllowedValue("BW");
			h.addAllowedValue("CD");
			h.addAllowedValue("CF");
			h.addAllowedValue("CP");
			h.addAllowedValue("CT");
			h.addAllowedValue("DA");
			h.addAllowedValue("EL");
			h.addAllowedValue("EM");
			h.addAllowedValue("FT");
			h.addAllowedValue("FX");
			h.addAllowedValue("GS");
			h.addAllowedValue("HL");
			h.addAllowedValue("IA");
			h.addAllowedValue("IE");
			h.addAllowedValue("IM");
			h.addAllowedValue("MB");
			h.addAllowedValue("MD");
			h.addAllowedValue("MN");
			h.addAllowedValue("MP");
			h.addAllowedValue("MT");
			h.addAllowedValue("NS");
			h.addAllowedValue("OL");
			h.addAllowedValue("PO");
			h.addAllowedValue("SE");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SW");
			h.addAllowedValue("TA");
			h.addAllowedValue("TE");
			h.addAllowedValue("TM");
			h.addAllowedValue("TX");
			h.addAllowedValue("VO");
			h.addAllowedValue("WS");
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			h.addAllowedValue("9");
			simpleElement756 = new RtSimpleElement("756", "ID", h);
		}
	
		return simpleElement756;
	}
	
	private RtSimpleElement simpleElement757;
	
	private RtSimpleElement simpleElement757() {
		if (simpleElement757 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Report Copies Needed";
			h.minLength = 1;
			h.maxLength = 2;
			
			simpleElement757 = new RtSimpleElement("757", "N0", h);
		}
	
		return simpleElement757;
	}
	
	private RtSimpleElement simpleElement66;
	
	private RtSimpleElement simpleElement66() {
		if (simpleElement66 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Identification Code Qualifier";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AL");
			h.addAllowedValue("AP");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("BC");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BG");
			h.addAllowedValue("BP");
			h.addAllowedValue("BS");
			h.addAllowedValue("C");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CI");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C5");
			h.addAllowedValue("D");
			h.addAllowedValue("DG");
			h.addAllowedValue("DL");
			h.addAllowedValue("DN");
			h.addAllowedValue("DP");
			h.addAllowedValue("DS");
			h.addAllowedValue("E");
			h.addAllowedValue("EC");
			h.addAllowedValue("EH");
			h.addAllowedValue("EI");
			h.addAllowedValue("EP");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("F");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FI");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FN");
			h.addAllowedValue("G");
			h.addAllowedValue("GA");
			h.addAllowedValue("GC");
			h.addAllowedValue("HC");
			h.addAllowedValue("HN");
			h.addAllowedValue("I");
			h.addAllowedValue("J");
			h.addAllowedValue("K");
			h.addAllowedValue("L");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LI");
			h.addAllowedValue("LN");
			h.addAllowedValue("MA");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("MI");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MN");
			h.addAllowedValue("MP");
			h.addAllowedValue("MR");
			h.addAllowedValue("M3");
			h.addAllowedValue("M4");
			h.addAllowedValue("M5");
			h.addAllowedValue("M6");
			h.addAllowedValue("N");
			h.addAllowedValue("NA");
			h.addAllowedValue("ND");
			h.addAllowedValue("NI");
			h.addAllowedValue("NO");
			h.addAllowedValue("OC");
			h.addAllowedValue("OP");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PI");
			h.addAllowedValue("PP");
			h.addAllowedValue("PR");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RT");
			h.addAllowedValue("S");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SD");
			h.addAllowedValue("SF");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SL");
			h.addAllowedValue("SP");
			h.addAllowedValue("ST");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("TA");
			h.addAllowedValue("TC");
			h.addAllowedValue("TZ");
			h.addAllowedValue("UC");
			h.addAllowedValue("UL");
			h.addAllowedValue("UM");
			h.addAllowedValue("UP");
			h.addAllowedValue("UR");
			h.addAllowedValue("US");
			h.addAllowedValue("WR");
			h.addAllowedValue("XV");
			h.addAllowedValue("XX");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZN");
			h.addAllowedValue("ZY");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5");
			h.addAllowedValue("50");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("6");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("7");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("8");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("9");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement66 = new RtSimpleElement("66", "ID", h);
		}
	
		return simpleElement66;
	}
	
	private RtSimpleElement simpleElement67;
	
	private RtSimpleElement simpleElement67() {
		if (simpleElement67 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Identification Code";
			h.minLength = 2;
			h.maxLength = 80;
			
			simpleElement67 = new RtSimpleElement("67", "AN", h);
		}
	
		return simpleElement67;
	}
	
	private RtSimpleElement simpleElement704;
	
	private RtSimpleElement simpleElement704() {
		if (simpleElement704 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Paperwork/Report Action Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("CH");
			h.addAllowedValue("CO");
			h.addAllowedValue("DM");
			h.addAllowedValue("NT");
			h.addAllowedValue("ON");
			h.addAllowedValue("OR");
			h.addAllowedValue("PV");
			h.addAllowedValue("SG");
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			simpleElement704 = new RtSimpleElement("704", "ID", h);
		}
	
		return simpleElement704;
	}
	
	private RtSimpleElement simpleElement1525;
	
	private RtSimpleElement simpleElement1525() {
		if (simpleElement1525 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Request Category Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("AR");
			h.addAllowedValue("BA");
			h.addAllowedValue("HS");
			h.addAllowedValue("IN");
			h.addAllowedValue("PR");
			h.addAllowedValue("RE");
			h.addAllowedValue("SC");
			simpleElement1525 = new RtSimpleElement("1525", "ID", h);
		}
	
		return simpleElement1525;
	}
	
	private RtSimpleElement simpleElement753;
	
	private RtSimpleElement simpleElement753() {
		if (simpleElement753 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Packaging Characteristic Code";
			h.minLength = 1;
			h.maxLength = 5;
			
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CUD");
			h.addAllowedValue("HM");
			h.addAllowedValue("IC");
			h.addAllowedValue("IP");
			h.addAllowedValue("LP");
			h.addAllowedValue("OPI");
			h.addAllowedValue("PK");
			h.addAllowedValue("PM");
			h.addAllowedValue("PML");
			h.addAllowedValue("PN");
			h.addAllowedValue("SMK");
			h.addAllowedValue("UC");
			h.addAllowedValue("UCL");
			h.addAllowedValue("UP");
			h.addAllowedValue("WM");
			h.addAllowedValue("01");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			simpleElement753 = new RtSimpleElement("753", "ID", h);
		}
	
		return simpleElement753;
	}
	
	private RtSimpleElement simpleElement754;
	
	private RtSimpleElement simpleElement754() {
		if (simpleElement754 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Packaging Description Code";
			h.minLength = 1;
			h.maxLength = 7;
			
			simpleElement754 = new RtSimpleElement("754", "AN", h);
		}
	
		return simpleElement754;
	}
	
	private RtSimpleElement simpleElement400;
	
	private RtSimpleElement simpleElement400() {
		if (simpleElement400 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Unit Load Option Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			simpleElement400 = new RtSimpleElement("400", "ID", h);
		}
	
		return simpleElement400;
	}
	
	private RtSimpleElement simpleElement103;
	
	private RtSimpleElement simpleElement103() {
		if (simpleElement103 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Packaging Code";
			h.minLength = 3;
			h.maxLength = 5;
			
			simpleElement103 = new RtSimpleElement("103", "AN", h);
		}
	
		return simpleElement103;
	}
	
	private RtSimpleElement simpleElement80;
	
	private RtSimpleElement simpleElement80() {
		if (simpleElement80 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Lading Quantity";
			h.minLength = 1;
			h.maxLength = 7;
			
			simpleElement80 = new RtSimpleElement("80", "N0", h);
		}
	
		return simpleElement80;
	}
	
	private RtSimpleElement simpleElement79;
	
	private RtSimpleElement simpleElement79() {
		if (simpleElement79 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Lading Description";
			h.minLength = 1;
			h.maxLength = 50;
			
			simpleElement79 = new RtSimpleElement("79", "AN", h);
		}
	
		return simpleElement79;
	}
	
	private RtSimpleElement simpleElement187;
	
	private RtSimpleElement simpleElement187() {
		if (simpleElement187 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Weight Qualifier";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("B");
			h.addAllowedValue("C");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("D");
			h.addAllowedValue("DR");
			h.addAllowedValue("E");
			h.addAllowedValue("F");
			h.addAllowedValue("FR");
			h.addAllowedValue("G");
			h.addAllowedValue("H");
			h.addAllowedValue("I");
			h.addAllowedValue("J");
			h.addAllowedValue("K");
			h.addAllowedValue("L");
			h.addAllowedValue("LC");
			h.addAllowedValue("M");
			h.addAllowedValue("N");
			h.addAllowedValue("ND");
			h.addAllowedValue("NI");
			h.addAllowedValue("NR");
			h.addAllowedValue("NT");
			h.addAllowedValue("O");
			h.addAllowedValue("P");
			h.addAllowedValue("PA");
			h.addAllowedValue("Q");
			h.addAllowedValue("R");
			h.addAllowedValue("RG");
			h.addAllowedValue("RN");
			h.addAllowedValue("RT");
			h.addAllowedValue("S");
			h.addAllowedValue("SF");
			h.addAllowedValue("SI");
			h.addAllowedValue("SK");
			h.addAllowedValue("SO");
			h.addAllowedValue("T");
			h.addAllowedValue("U");
			h.addAllowedValue("V");
			h.addAllowedValue("W");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WG");
			h.addAllowedValue("WJ");
			h.addAllowedValue("X");
			h.addAllowedValue("Y");
			h.addAllowedValue("Z");
			simpleElement187 = new RtSimpleElement("187", "ID", h);
		}
	
		return simpleElement187;
	}
	
	private RtSimpleElement simpleElement81;
	
	private RtSimpleElement simpleElement81() {
		if (simpleElement81 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Weight";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement81 = new RtSimpleElement("81", "R", h);
		}
	
		return simpleElement81;
	}
	
	private RtSimpleElement simpleElement183;
	
	private RtSimpleElement simpleElement183() {
		if (simpleElement183 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Volume";
			h.minLength = 1;
			h.maxLength = 8;
			
			simpleElement183 = new RtSimpleElement("183", "R", h);
		}
	
		return simpleElement183;
	}
	
	private RtSimpleElement simpleElement133;
	
	private RtSimpleElement simpleElement133() {
		if (simpleElement133 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Routing Sequence Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("B");
			h.addAllowedValue("D");
			h.addAllowedValue("H");
			h.addAllowedValue("I");
			h.addAllowedValue("JD");
			h.addAllowedValue("JO");
			h.addAllowedValue("M");
			h.addAllowedValue("O");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			h.addAllowedValue("V");
			h.addAllowedValue("X");
			h.addAllowedValue("Z");
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			h.addAllowedValue("9");
			simpleElement133 = new RtSimpleElement("133", "ID", h);
		}
	
		return simpleElement133;
	}
	
	private RtSimpleElement simpleElement91;
	
	private RtSimpleElement simpleElement91() {
		if (simpleElement91 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transportation Method/Type Code";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AC");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AH");
			h.addAllowedValue("AR");
			h.addAllowedValue("B");
			h.addAllowedValue("BP");
			h.addAllowedValue("BU");
			h.addAllowedValue("C");
			h.addAllowedValue("CE");
			h.addAllowedValue("D");
			h.addAllowedValue("DA");
			h.addAllowedValue("DW");
			h.addAllowedValue("E");
			h.addAllowedValue("ED");
			h.addAllowedValue("F");
			h.addAllowedValue("FA");
			h.addAllowedValue("FL");
			h.addAllowedValue("GG");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("H");
			h.addAllowedValue("HH");
			h.addAllowedValue("I");
			h.addAllowedValue("J");
			h.addAllowedValue("K");
			h.addAllowedValue("L");
			h.addAllowedValue("LA");
			h.addAllowedValue("LT");
			h.addAllowedValue("M");
			h.addAllowedValue("MB");
			h.addAllowedValue("MP");
			h.addAllowedValue("N");
			h.addAllowedValue("O");
			h.addAllowedValue("P");
			h.addAllowedValue("PA");
			h.addAllowedValue("PG");
			h.addAllowedValue("PL");
			h.addAllowedValue("PP");
			h.addAllowedValue("PR");
			h.addAllowedValue("PT");
			h.addAllowedValue("Q");
			h.addAllowedValue("R");
			h.addAllowedValue("RC");
			h.addAllowedValue("RR");
			h.addAllowedValue("S");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("T");
			h.addAllowedValue("TA");
			h.addAllowedValue("TC");
			h.addAllowedValue("TT");
			h.addAllowedValue("U");
			h.addAllowedValue("VA");
			h.addAllowedValue("VE");
			h.addAllowedValue("VL");
			h.addAllowedValue("W");
			h.addAllowedValue("WP");
			h.addAllowedValue("X");
			h.addAllowedValue("Y");
			h.addAllowedValue("Y1");
			h.addAllowedValue("Y2");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			simpleElement91 = new RtSimpleElement("91", "ID", h);
		}
	
		return simpleElement91;
	}
	
	private RtSimpleElement simpleElement387;
	
	private RtSimpleElement simpleElement387() {
		if (simpleElement387 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Routing";
			h.minLength = 1;
			h.maxLength = 35;
			
			simpleElement387 = new RtSimpleElement("387", "AN", h);
		}
	
		return simpleElement387;
	}
	
	private RtSimpleElement simpleElement368;
	
	private RtSimpleElement simpleElement368() {
		if (simpleElement368 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Shipment/Order Status Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AN");
			h.addAllowedValue("AP");
			h.addAllowedValue("AS");
			h.addAllowedValue("AU");
			h.addAllowedValue("AV");
			h.addAllowedValue("BK");
			h.addAllowedValue("BM");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BT");
			h.addAllowedValue("BW");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CI");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("DA");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DI");
			h.addAllowedValue("DO");
			h.addAllowedValue("DP");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EW");
			h.addAllowedValue("EX");
			h.addAllowedValue("FS");
			h.addAllowedValue("HQ");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IN");
			h.addAllowedValue("IP");
			h.addAllowedValue("IS");
			h.addAllowedValue("LM");
			h.addAllowedValue("LS");
			h.addAllowedValue("LW");
			h.addAllowedValue("MC");
			h.addAllowedValue("NF");
			h.addAllowedValue("NN");
			h.addAllowedValue("NS");
			h.addAllowedValue("NY");
			h.addAllowedValue("OB");
			h.addAllowedValue("OF");
			h.addAllowedValue("OP");
			h.addAllowedValue("OR");
			h.addAllowedValue("PA");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PP");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("QN");
			h.addAllowedValue("QP");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RI");
			h.addAllowedValue("RT");
			h.addAllowedValue("RW");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("UB");
			h.addAllowedValue("UN");
			h.addAllowedValue("UR");
			h.addAllowedValue("WS");
			h.addAllowedValue("ZZ");
			simpleElement368 = new RtSimpleElement("368", "ID", h);
		}
	
		return simpleElement368;
	}
	
	private RtSimpleElement simpleElement731;
	
	private RtSimpleElement simpleElement731() {
		if (simpleElement731 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transit Direction Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("BS");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SF");
			h.addAllowedValue("SS");
			h.addAllowedValue("ZZ");
			simpleElement731 = new RtSimpleElement("731", "ID", h);
		}
	
		return simpleElement731;
	}
	
	private RtSimpleElement simpleElement732;
	
	private RtSimpleElement simpleElement732() {
		if (simpleElement732 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transit Time Direction Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AD");
			h.addAllowedValue("CD");
			h.addAllowedValue("CW");
			h.addAllowedValue("HO");
			h.addAllowedValue("SD");
			h.addAllowedValue("SH");
			h.addAllowedValue("WD");
			h.addAllowedValue("WW");
			h.addAllowedValue("ZZ");
			simpleElement732 = new RtSimpleElement("732", "ID", h);
		}
	
		return simpleElement732;
	}
	
	private RtSimpleElement simpleElement733;
	
	private RtSimpleElement simpleElement733() {
		if (simpleElement733 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transit Time";
			h.minLength = 1;
			h.maxLength = 4;
			
			simpleElement733 = new RtSimpleElement("733", "R", h);
		}
	
		return simpleElement733;
	}
	
	private RtSimpleElement simpleElement284;
	
	private RtSimpleElement simpleElement284() {
		if (simpleElement284 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Service Level Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AC");
			h.addAllowedValue("AE");
			h.addAllowedValue("AM");
			h.addAllowedValue("BC");
			h.addAllowedValue("CB");
			h.addAllowedValue("CE");
			h.addAllowedValue("CG");
			h.addAllowedValue("CX");
			h.addAllowedValue("DC");
			h.addAllowedValue("DF");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("ES");
			h.addAllowedValue("ET");
			h.addAllowedValue("FC");
			h.addAllowedValue("GP");
			h.addAllowedValue("GT");
			h.addAllowedValue("G2");
			h.addAllowedValue("IA");
			h.addAllowedValue("IE");
			h.addAllowedValue("IX");
			h.addAllowedValue("ME");
			h.addAllowedValue("MW");
			h.addAllowedValue("ND");
			h.addAllowedValue("NF");
			h.addAllowedValue("NH");
			h.addAllowedValue("NM");
			h.addAllowedValue("NS");
			h.addAllowedValue("ON");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PI");
			h.addAllowedValue("PM");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("RS");
			h.addAllowedValue("R1");
			h.addAllowedValue("R2");
			h.addAllowedValue("R3");
			h.addAllowedValue("R4");
			h.addAllowedValue("R5");
			h.addAllowedValue("R6");
			h.addAllowedValue("R7");
			h.addAllowedValue("R8");
			h.addAllowedValue("SA");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SM");
			h.addAllowedValue("SP");
			h.addAllowedValue("ST");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("09");
			h.addAllowedValue("3D");
			h.addAllowedValue("9A");
			simpleElement284 = new RtSimpleElement("284", "ID", h);
		}
	
		return simpleElement284;
	}
	
	private RtSimpleElement simpleElement26;
	
	private RtSimpleElement simpleElement26() {
		if (simpleElement26 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Country Code";
			h.minLength = 2;
			h.maxLength = 3;
			
			simpleElement26 = new RtSimpleElement("26", "ID", h);
		}
	
		return simpleElement26;
	}
	
	private RtSimpleElement simpleElement40;
	
	private RtSimpleElement simpleElement40() {
		if (simpleElement40 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Equipment Description Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AC");
			h.addAllowedValue("AF");
			h.addAllowedValue("AL");
			h.addAllowedValue("AP");
			h.addAllowedValue("AT");
			h.addAllowedValue("BC");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BO");
			h.addAllowedValue("BR");
			h.addAllowedValue("BX");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CP");
			h.addAllowedValue("CQ");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CZ");
			h.addAllowedValue("DD");
			h.addAllowedValue("DF");
			h.addAllowedValue("DT");
			h.addAllowedValue("DX");
			h.addAllowedValue("ET");
			h.addAllowedValue("FF");
			h.addAllowedValue("FH");
			h.addAllowedValue("FN");
			h.addAllowedValue("FP");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("FX");
			h.addAllowedValue("GS");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HO");
			h.addAllowedValue("HP");
			h.addAllowedValue("HT");
			h.addAllowedValue("HV");
			h.addAllowedValue("HY");
			h.addAllowedValue("ID");
			h.addAllowedValue("IX");
			h.addAllowedValue("LO");
			h.addAllowedValue("LS");
			h.addAllowedValue("LU");
			h.addAllowedValue("NX");
			h.addAllowedValue("OB");
			h.addAllowedValue("OT");
			h.addAllowedValue("OV");
			h.addAllowedValue("PL");
			h.addAllowedValue("PP");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("RA");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RF");
			h.addAllowedValue("RG");
			h.addAllowedValue("RI");
			h.addAllowedValue("RO");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("SA");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SK");
			h.addAllowedValue("SL");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SV");
			h.addAllowedValue("TA");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TH");
			h.addAllowedValue("TI");
			h.addAllowedValue("TJ");
			h.addAllowedValue("TK");
			h.addAllowedValue("TL");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TQ");
			h.addAllowedValue("TR");
			h.addAllowedValue("TT");
			h.addAllowedValue("TU");
			h.addAllowedValue("TV");
			h.addAllowedValue("TW");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UE");
			h.addAllowedValue("UL");
			h.addAllowedValue("UP");
			h.addAllowedValue("VA");
			h.addAllowedValue("VE");
			h.addAllowedValue("VL");
			h.addAllowedValue("VR");
			h.addAllowedValue("VS");
			h.addAllowedValue("VT");
			h.addAllowedValue("WR");
			h.addAllowedValue("WY");
			h.addAllowedValue("2B");
			h.addAllowedValue("2D");
			h.addAllowedValue("2E");
			h.addAllowedValue("2F");
			h.addAllowedValue("2G");
			h.addAllowedValue("20");
			h.addAllowedValue("4B");
			h.addAllowedValue("40");
			simpleElement40 = new RtSimpleElement("40", "ID", h);
		}
	
		return simpleElement40;
	}
	
	private RtSimpleElement simpleElement206;
	
	private RtSimpleElement simpleElement206() {
		if (simpleElement206 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Equipment Initial";
			h.minLength = 1;
			h.maxLength = 4;
			
			simpleElement206 = new RtSimpleElement("206", "AN", h);
		}
	
		return simpleElement206;
	}
	
	private RtSimpleElement simpleElement207;
	
	private RtSimpleElement simpleElement207() {
		if (simpleElement207 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Equipment Number";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement207 = new RtSimpleElement("207", "AN", h);
		}
	
		return simpleElement207;
	}
	
	private RtSimpleElement simpleElement102;
	
	private RtSimpleElement simpleElement102() {
		if (simpleElement102 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Ownership Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("L");
			h.addAllowedValue("N");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			h.addAllowedValue("T");
			simpleElement102 = new RtSimpleElement("102", "ID", h);
		}
	
		return simpleElement102;
	}
	
	private RtSimpleElement simpleElement407;
	
	private RtSimpleElement simpleElement407() {
		if (simpleElement407 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Seal Status Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			simpleElement407 = new RtSimpleElement("407", "ID", h);
		}
	
		return simpleElement407;
	}
	
	private RtSimpleElement simpleElement225;
	
	private RtSimpleElement simpleElement225() {
		if (simpleElement225 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Seal Number";
			h.minLength = 2;
			h.maxLength = 15;
			
			simpleElement225 = new RtSimpleElement("225", "AN", h);
		}
	
		return simpleElement225;
	}
	
	private RtSimpleElement simpleElement24;
	
	private RtSimpleElement simpleElement24() {
		if (simpleElement24 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Equipment Type";
			h.minLength = 4;
			h.maxLength = 4;
			
			simpleElement24 = new RtSimpleElement("24", "ID", h);
		}
	
		return simpleElement24;
	}
	
	private RtSimpleElement simpleElement152;
	
	private RtSimpleElement simpleElement152() {
		if (simpleElement152 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Special Handling Code";
			h.minLength = 2;
			h.maxLength = 3;
			
			h.addAllowedValue("AAS");
			h.addAllowedValue("AB");
			h.addAllowedValue("ADL");
			h.addAllowedValue("AFN");
			h.addAllowedValue("AGG");
			h.addAllowedValue("AGS");
			h.addAllowedValue("AIB");
			h.addAllowedValue("AK");
			h.addAllowedValue("ALP");
			h.addAllowedValue("ALT");
			h.addAllowedValue("AMM");
			h.addAllowedValue("ANC");
			h.addAllowedValue("APD");
			h.addAllowedValue("APL");
			h.addAllowedValue("ARC");
			h.addAllowedValue("ARG");
			h.addAllowedValue("ARR");
			h.addAllowedValue("ART");
			h.addAllowedValue("ASY");
			h.addAllowedValue("AT");
			h.addAllowedValue("AUX");
			h.addAllowedValue("AV");
			h.addAllowedValue("AW");
			h.addAllowedValue("A1M");
			h.addAllowedValue("A3M");
			h.addAllowedValue("A5M");
			h.addAllowedValue("BA");
			h.addAllowedValue("BCP");
			h.addAllowedValue("BKA");
			h.addAllowedValue("BL");
			h.addAllowedValue("BLK");
			h.addAllowedValue("BLS");
			h.addAllowedValue("BN");
			h.addAllowedValue("BNS");
			h.addAllowedValue("BOX");
			h.addAllowedValue("BUA");
			h.addAllowedValue("BU2");
			h.addAllowedValue("BU4");
			h.addAllowedValue("BW");
			h.addAllowedValue("CAR");
			h.addAllowedValue("CA2");
			h.addAllowedValue("CA4");
			h.addAllowedValue("CC");
			h.addAllowedValue("CCB");
			h.addAllowedValue("CCH");
			h.addAllowedValue("CCS");
			h.addAllowedValue("CD");
			h.addAllowedValue("CDD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CFC");
			h.addAllowedValue("CFL");
			h.addAllowedValue("CGC");
			h.addAllowedValue("CGR");
			h.addAllowedValue("CGT");
			h.addAllowedValue("CH");
			h.addAllowedValue("CHN");
			h.addAllowedValue("CI");
			h.addAllowedValue("CIP");
			h.addAllowedValue("CIS");
			h.addAllowedValue("CLN");
			h.addAllowedValue("CLS");
			h.addAllowedValue("CM");
			h.addAllowedValue("CMD");
			h.addAllowedValue("CNL");
			h.addAllowedValue("CNS");
			h.addAllowedValue("CO");
			h.addAllowedValue("CON");
			h.addAllowedValue("COR");
			h.addAllowedValue("COU");
			h.addAllowedValue("COV");
			h.addAllowedValue("CPC");
			h.addAllowedValue("CPM");
			h.addAllowedValue("CR");
			h.addAllowedValue("CRL");
			h.addAllowedValue("CSD");
			h.addAllowedValue("CSP");
			h.addAllowedValue("CTL");
			h.addAllowedValue("CTM");
			h.addAllowedValue("CTR");
			h.addAllowedValue("CUF");
			h.addAllowedValue("CW");
			h.addAllowedValue("CX");
			h.addAllowedValue("CY");
			h.addAllowedValue("DA");
			h.addAllowedValue("DBL");
			h.addAllowedValue("DBP");
			h.addAllowedValue("DCS");
			h.addAllowedValue("DDN");
			h.addAllowedValue("DDP");
			h.addAllowedValue("DDS");
			h.addAllowedValue("DDZ");
			h.addAllowedValue("DE");
			h.addAllowedValue("DEL");
			h.addAllowedValue("DEP");
			h.addAllowedValue("DET");
			h.addAllowedValue("DEZ");
			h.addAllowedValue("DFD");
			h.addAllowedValue("DFM");
			h.addAllowedValue("DFS");
			h.addAllowedValue("DIS");
			h.addAllowedValue("DLP");
			h.addAllowedValue("DLR");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DNC");
			h.addAllowedValue("DNF");
			h.addAllowedValue("DNT");
			h.addAllowedValue("DOC");
			h.addAllowedValue("DOV");
			h.addAllowedValue("DPB");
			h.addAllowedValue("DPD");
			h.addAllowedValue("DPE");
			h.addAllowedValue("DPL");
			h.addAllowedValue("DPT");
			h.addAllowedValue("DPU");
			h.addAllowedValue("DR");
			h.addAllowedValue("DRO");
			h.addAllowedValue("DRU");
			h.addAllowedValue("DS");
			h.addAllowedValue("DSK");
			h.addAllowedValue("DSM");
			h.addAllowedValue("DSR");
			h.addAllowedValue("DSV");
			h.addAllowedValue("DT");
			h.addAllowedValue("DTB");
			h.addAllowedValue("DTP");
			h.addAllowedValue("DTV");
			h.addAllowedValue("DU");
			h.addAllowedValue("DV");
			h.addAllowedValue("DW");
			h.addAllowedValue("DWP");
			h.addAllowedValue("EAX");
			h.addAllowedValue("ECR");
			h.addAllowedValue("ECS");
			h.addAllowedValue("ED");
			h.addAllowedValue("EDD");
			h.addAllowedValue("EDO");
			h.addAllowedValue("EE");
			h.addAllowedValue("EED");
			h.addAllowedValue("EL");
			h.addAllowedValue("ELS");
			h.addAllowedValue("EMR");
			h.addAllowedValue("EMT");
			h.addAllowedValue("END");
			h.addAllowedValue("EP");
			h.addAllowedValue("ER");
			h.addAllowedValue("ERS");
			h.addAllowedValue("ERT");
			h.addAllowedValue("EV");
			h.addAllowedValue("EW");
			h.addAllowedValue("EX");
			h.addAllowedValue("EXC");
			h.addAllowedValue("EXD");
			h.addAllowedValue("EXL");
			h.addAllowedValue("EXO");
			h.addAllowedValue("EXP");
			h.addAllowedValue("EXQ");
			h.addAllowedValue("EXT");
			h.addAllowedValue("EXU");
			h.addAllowedValue("EXZ");
			h.addAllowedValue("EZE");
			h.addAllowedValue("FA");
			h.addAllowedValue("FAK");
			h.addAllowedValue("FAS");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FCS");
			h.addAllowedValue("FD");
			h.addAllowedValue("FFC");
			h.addAllowedValue("FFS");
			h.addAllowedValue("FG");
			h.addAllowedValue("FL");
			h.addAllowedValue("FLS");
			h.addAllowedValue("FP");
			h.addAllowedValue("FPT");
			h.addAllowedValue("FR");
			h.addAllowedValue("FRZ");
			h.addAllowedValue("FS");
			h.addAllowedValue("FST");
			h.addAllowedValue("FTR");
			h.addAllowedValue("GI");
			h.addAllowedValue("GMS");
			h.addAllowedValue("GOC");
			h.addAllowedValue("GSP");
			h.addAllowedValue("GSS");
			h.addAllowedValue("HAL");
			h.addAllowedValue("HAN");
			h.addAllowedValue("HBR");
			h.addAllowedValue("HDH");
			h.addAllowedValue("HDW");
			h.addAllowedValue("HE");
			h.addAllowedValue("HEA");
			h.addAllowedValue("HES");
			h.addAllowedValue("HET");
			h.addAllowedValue("HH");
			h.addAllowedValue("HM");
			h.addAllowedValue("HMA");
			h.addAllowedValue("HMI");
			h.addAllowedValue("HO");
			h.addAllowedValue("HOL");
			h.addAllowedValue("HOR");
			h.addAllowedValue("HOS");
			h.addAllowedValue("HOX");
			h.addAllowedValue("HP");
			h.addAllowedValue("HQT");
			h.addAllowedValue("HR");
			h.addAllowedValue("HRS");
			h.addAllowedValue("HT");
			h.addAllowedValue("HTI");
			h.addAllowedValue("HV");
			h.addAllowedValue("HW");
			h.addAllowedValue("HZC");
			h.addAllowedValue("HZD");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IDC");
			h.addAllowedValue("IDL");
			h.addAllowedValue("IIH");
			h.addAllowedValue("IM");
			h.addAllowedValue("IMP");
			h.addAllowedValue("IMS");
			h.addAllowedValue("INT");
			h.addAllowedValue("IP");
			h.addAllowedValue("IPU");
			h.addAllowedValue("IR");
			h.addAllowedValue("IS");
			h.addAllowedValue("ITS");
			h.addAllowedValue("JIT");
			h.addAllowedValue("JLX");
			h.addAllowedValue("JS");
			h.addAllowedValue("KEG");
			h.addAllowedValue("KMD");
			h.addAllowedValue("LAB");
			h.addAllowedValue("LAY");
			h.addAllowedValue("LB");
			h.addAllowedValue("LBL");
			h.addAllowedValue("LBR");
			h.addAllowedValue("LBT");
			h.addAllowedValue("LC");
			h.addAllowedValue("LCL");
			h.addAllowedValue("LC2");
			h.addAllowedValue("LC4");
			h.addAllowedValue("LD");
			h.addAllowedValue("LEC");
			h.addAllowedValue("LF");
			h.addAllowedValue("LFD");
			h.addAllowedValue("LHS");
			h.addAllowedValue("LIE");
			h.addAllowedValue("LMD");
			h.addAllowedValue("LME");
			h.addAllowedValue("LN");
			h.addAllowedValue("LP");
			h.addAllowedValue("LPD");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LTE");
			h.addAllowedValue("LTT");
			h.addAllowedValue("LYC");
			h.addAllowedValue("MAT");
			h.addAllowedValue("MC");
			h.addAllowedValue("MEN");
			h.addAllowedValue("MES");
			h.addAllowedValue("MET");
			h.addAllowedValue("MF");
			h.addAllowedValue("MIN");
			h.addAllowedValue("MNS");
			h.addAllowedValue("MOT");
			h.addAllowedValue("MP");
			h.addAllowedValue("MR");
			h.addAllowedValue("MRF");
			h.addAllowedValue("MSS");
			h.addAllowedValue("MTE");
			h.addAllowedValue("MVS");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NE");
			h.addAllowedValue("NH");
			h.addAllowedValue("NHC");
			h.addAllowedValue("NHL");
			h.addAllowedValue("NI");
			h.addAllowedValue("NP");
			h.addAllowedValue("NPR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NSV");
			h.addAllowedValue("NT");
			h.addAllowedValue("NW");
			h.addAllowedValue("NX");
			h.addAllowedValue("OAH");
			h.addAllowedValue("OBL");
			h.addAllowedValue("OCA");
			h.addAllowedValue("OCL");
			h.addAllowedValue("OCN");
			h.addAllowedValue("OCS");
			h.addAllowedValue("OCV");
			h.addAllowedValue("ODI");
			h.addAllowedValue("OEH");
			h.addAllowedValue("OFH");
			h.addAllowedValue("OFU");
			h.addAllowedValue("OHC");
			h.addAllowedValue("OIL");
			h.addAllowedValue("ONC");
			h.addAllowedValue("ONS");
			h.addAllowedValue("OOB");
			h.addAllowedValue("OOD");
			h.addAllowedValue("OOL");
			h.addAllowedValue("OPR");
			h.addAllowedValue("OPT");
			h.addAllowedValue("OS");
			h.addAllowedValue("OSB");
			h.addAllowedValue("OST");
			h.addAllowedValue("OTC");
			h.addAllowedValue("OTD");
			h.addAllowedValue("OTH");
			h.addAllowedValue("OTO");
			h.addAllowedValue("OTS");
			h.addAllowedValue("OUC");
			h.addAllowedValue("OUW");
			h.addAllowedValue("OV");
			h.addAllowedValue("OVR");
			h.addAllowedValue("OWC");
			h.addAllowedValue("OWR");
			h.addAllowedValue("PAJ");
			h.addAllowedValue("PAV");
			h.addAllowedValue("PB");
			h.addAllowedValue("PD");
			h.addAllowedValue("PDS");
			h.addAllowedValue("PDY");
			h.addAllowedValue("PER");
			h.addAllowedValue("PFH");
			h.addAllowedValue("PG");
			h.addAllowedValue("PHR");
			h.addAllowedValue("PI");
			h.addAllowedValue("PIR");
			h.addAllowedValue("PMM");
			h.addAllowedValue("PMR");
			h.addAllowedValue("PMS");
			h.addAllowedValue("PMT");
			h.addAllowedValue("POC");
			h.addAllowedValue("PPD");
			h.addAllowedValue("PRL");
			h.addAllowedValue("PRT");
			h.addAllowedValue("PS");
			h.addAllowedValue("PSG");
			h.addAllowedValue("PSS");
			h.addAllowedValue("PTS");
			h.addAllowedValue("PUC");
			h.addAllowedValue("PUD");
			h.addAllowedValue("PUK");
			h.addAllowedValue("PUP");
			h.addAllowedValue("PVB");
			h.addAllowedValue("PVD");
			h.addAllowedValue("PVI");
			h.addAllowedValue("PVL");
			h.addAllowedValue("PVP");
			h.addAllowedValue("PVS");
			h.addAllowedValue("PVT");
			h.addAllowedValue("PW");
			h.addAllowedValue("PYS");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RCC");
			h.addAllowedValue("RCL");
			h.addAllowedValue("RDH");
			h.addAllowedValue("RDR");
			h.addAllowedValue("REP");
			h.addAllowedValue("RES");
			h.addAllowedValue("RFM");
			h.addAllowedValue("RIE");
			h.addAllowedValue("RLS");
			h.addAllowedValue("RM");
			h.addAllowedValue("RMC");
			h.addAllowedValue("RMP");
			h.addAllowedValue("RMS");
			h.addAllowedValue("RO");
			h.addAllowedValue("RPD");
			h.addAllowedValue("RR");
			h.addAllowedValue("RRR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RSP");
			h.addAllowedValue("RSS");
			h.addAllowedValue("RSV");
			h.addAllowedValue("RT");
			h.addAllowedValue("RWR");
			h.addAllowedValue("SAS");
			h.addAllowedValue("SAT");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SCC");
			h.addAllowedValue("SCL");
			h.addAllowedValue("SD");
			h.addAllowedValue("SDL");
			h.addAllowedValue("SDS");
			h.addAllowedValue("SE");
			h.addAllowedValue("SEC");
			h.addAllowedValue("SED");
			h.addAllowedValue("SEE");
			h.addAllowedValue("SER");
			h.addAllowedValue("SEV");
			h.addAllowedValue("SFB");
			h.addAllowedValue("SFD");
			h.addAllowedValue("SFE");
			h.addAllowedValue("SFT");
			h.addAllowedValue("SGL");
			h.addAllowedValue("SH");
			h.addAllowedValue("SHH");
			h.addAllowedValue("SHL");
			h.addAllowedValue("SHW");
			h.addAllowedValue("SI");
			h.addAllowedValue("SK");
			h.addAllowedValue("SKT");
			h.addAllowedValue("SLC");
			h.addAllowedValue("SM");
			h.addAllowedValue("SMP");
			h.addAllowedValue("SMS");
			h.addAllowedValue("SNM");
			h.addAllowedValue("SNS");
			h.addAllowedValue("SNT");
			h.addAllowedValue("SOC");
			h.addAllowedValue("SOL");
			h.addAllowedValue("SP");
			h.addAllowedValue("SPC");
			h.addAllowedValue("SPR");
			h.addAllowedValue("SPT");
			h.addAllowedValue("SPU");
			h.addAllowedValue("SR");
			h.addAllowedValue("SRG");
			h.addAllowedValue("SRS");
			h.addAllowedValue("SSC");
			h.addAllowedValue("SSN");
			h.addAllowedValue("SSU");
			h.addAllowedValue("ST");
			h.addAllowedValue("STA");
			h.addAllowedValue("STD");
			h.addAllowedValue("STO");
			h.addAllowedValue("STP");
			h.addAllowedValue("STR");
			h.addAllowedValue("SUA");
			h.addAllowedValue("SUB");
			h.addAllowedValue("SUP");
			h.addAllowedValue("SVS");
			h.addAllowedValue("SW");
			h.addAllowedValue("TA");
			h.addAllowedValue("TC");
			h.addAllowedValue("TDC");
			h.addAllowedValue("TDP");
			h.addAllowedValue("TER");
			h.addAllowedValue("TF");
			h.addAllowedValue("TLS");
			h.addAllowedValue("TMS");
			h.addAllowedValue("TMV");
			h.addAllowedValue("TN");
			h.addAllowedValue("TOF");
			h.addAllowedValue("TPS");
			h.addAllowedValue("TRA");
			h.addAllowedValue("TRK");
			h.addAllowedValue("TRL");
			h.addAllowedValue("TRM");
			h.addAllowedValue("TRN");
			h.addAllowedValue("TRP");
			h.addAllowedValue("TRS");
			h.addAllowedValue("TRT");
			h.addAllowedValue("TS");
			h.addAllowedValue("TSC");
			h.addAllowedValue("TSP");
			h.addAllowedValue("TSS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TV");
			h.addAllowedValue("UB");
			h.addAllowedValue("UFC");
			h.addAllowedValue("UI");
			h.addAllowedValue("UL");
			h.addAllowedValue("UN");
			h.addAllowedValue("UP");
			h.addAllowedValue("UPK");
			h.addAllowedValue("UR");
			h.addAllowedValue("URC");
			h.addAllowedValue("US");
			h.addAllowedValue("UTL");
			h.addAllowedValue("VAC");
			h.addAllowedValue("VAN");
			h.addAllowedValue("VCL");
			h.addAllowedValue("VFN");
			h.addAllowedValue("VIS");
			h.addAllowedValue("VN");
			h.addAllowedValue("VSO");
			h.addAllowedValue("VT");
			h.addAllowedValue("VTS");
			h.addAllowedValue("WB");
			h.addAllowedValue("WBB");
			h.addAllowedValue("WCT");
			h.addAllowedValue("WD");
			h.addAllowedValue("WDS");
			h.addAllowedValue("WE");
			h.addAllowedValue("WFG");
			h.addAllowedValue("WH");
			h.addAllowedValue("WI");
			h.addAllowedValue("WM");
			h.addAllowedValue("WO");
			h.addAllowedValue("WRB");
			h.addAllowedValue("WRI");
			h.addAllowedValue("WTV");
			h.addAllowedValue("WW");
			h.addAllowedValue("XP");
			h.addAllowedValue("XT");
			h.addAllowedValue("ZZZ");
			h.addAllowedValue("045");
			h.addAllowedValue("15");
			h.addAllowedValue("170");
			h.addAllowedValue("25");
			h.addAllowedValue("35");
			h.addAllowedValue("45");
			h.addAllowedValue("510");
			h.addAllowedValue("520");
			h.addAllowedValue("550");
			h.addAllowedValue("555");
			h.addAllowedValue("565");
			h.addAllowedValue("570");
			h.addAllowedValue("585");
			h.addAllowedValue("665");
			h.addAllowedValue("670");
			h.addAllowedValue("675");
			h.addAllowedValue("761");
			simpleElement152 = new RtSimpleElement("152", "ID", h);
		}
	
		return simpleElement152;
	}
	
	private RtSimpleElement simpleElement208;
	
	private RtSimpleElement simpleElement208() {
		if (simpleElement208 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Hazardous Material Code Qualifier";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			h.addAllowedValue("E");
			h.addAllowedValue("F");
			h.addAllowedValue("I");
			h.addAllowedValue("R");
			h.addAllowedValue("T");
			h.addAllowedValue("U");
			h.addAllowedValue("X");
			h.addAllowedValue("4");
			h.addAllowedValue("6");
			h.addAllowedValue("9");
			simpleElement208 = new RtSimpleElement("208", "ID", h);
		}
	
		return simpleElement208;
	}
	
	private RtSimpleElement simpleElement209;
	
	private RtSimpleElement simpleElement209() {
		if (simpleElement209 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Hazardous Material Class Code";
			h.minLength = 1;
			h.maxLength = 4;
			
			simpleElement209 = new RtSimpleElement("209", "AN", h);
		}
	
		return simpleElement209;
	}
	
	private RtSimpleElement simpleElement88;
	
	private RtSimpleElement simpleElement88() {
		if (simpleElement88 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Marks and Numbers Qualifier";
			h.minLength = 1;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AI");
			h.addAllowedValue("CA");
			h.addAllowedValue("CP");
			h.addAllowedValue("DZ");
			h.addAllowedValue("GM");
			h.addAllowedValue("L");
			h.addAllowedValue("MC");
			h.addAllowedValue("PB");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			h.addAllowedValue("SI");
			h.addAllowedValue("SM");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("UC");
			h.addAllowedValue("UP");
			h.addAllowedValue("W");
			h.addAllowedValue("X");
			h.addAllowedValue("ZZ");
			simpleElement88 = new RtSimpleElement("88", "ID", h);
		}
	
		return simpleElement88;
	}
	
	private RtSimpleElement simpleElement87;
	
	private RtSimpleElement simpleElement87() {
		if (simpleElement87 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Marks and Numbers";
			h.minLength = 1;
			h.maxLength = 48;
			
			simpleElement87 = new RtSimpleElement("87", "AN", h);
		}
	
		return simpleElement87;
	}
	
	private RtSimpleElement simpleElement688;
	
	private RtSimpleElement simpleElement688() {
		if (simpleElement688 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Restrictions/Conditions Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("DO");
			h.addAllowedValue("DW");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("OR");
			h.addAllowedValue("SP");
			h.addAllowedValue("SR");
			h.addAllowedValue("WO");
			simpleElement688 = new RtSimpleElement("688", "ID", h);
		}
	
		return simpleElement688;
	}
	
	private RtSimpleElement simpleElement963;
	
	private RtSimpleElement simpleElement963() {
		if (simpleElement963 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Tax Type Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AT");
			h.addAllowedValue("BP");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CG");
			h.addAllowedValue("CI");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CV");
			h.addAllowedValue("DL");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ET");
			h.addAllowedValue("EV");
			h.addAllowedValue("FD");
			h.addAllowedValue("FF");
			h.addAllowedValue("FI");
			h.addAllowedValue("FL");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("HS");
			h.addAllowedValue("HT");
			h.addAllowedValue("HZ");
			h.addAllowedValue("LB");
			h.addAllowedValue("LO");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("LU");
			h.addAllowedValue("LV");
			h.addAllowedValue("MA");
			h.addAllowedValue("MN");
			h.addAllowedValue("MP");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("OH");
			h.addAllowedValue("OT");
			h.addAllowedValue("PG");
			h.addAllowedValue("PS");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SE");
			h.addAllowedValue("SF");
			h.addAllowedValue("SL");
			h.addAllowedValue("SP");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SX");
			h.addAllowedValue("TD");
			h.addAllowedValue("TT");
			h.addAllowedValue("TX");
			h.addAllowedValue("T1");
			h.addAllowedValue("T2");
			h.addAllowedValue("UL");
			h.addAllowedValue("UT");
			h.addAllowedValue("VA");
			h.addAllowedValue("WS");
			h.addAllowedValue("ZA");
			h.addAllowedValue("ZB");
			h.addAllowedValue("ZC");
			h.addAllowedValue("ZD");
			h.addAllowedValue("ZE");
			h.addAllowedValue("ZZ");
			simpleElement963 = new RtSimpleElement("963", "ID", h);
		}
	
		return simpleElement963;
	}
	
	private RtSimpleElement simpleElement955;
	
	private RtSimpleElement simpleElement955() {
		if (simpleElement955 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Tax Jurisdiction Code Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("CD");
			h.addAllowedValue("VD");
			h.addAllowedValue("VE");
			simpleElement955 = new RtSimpleElement("955", "ID", h);
		}
	
		return simpleElement955;
	}
	
	private RtSimpleElement simpleElement956;
	
	private RtSimpleElement simpleElement956() {
		if (simpleElement956 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Tax Jurisdiction Code";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement956 = new RtSimpleElement("956", "AN", h);
		}
	
		return simpleElement956;
	}
	
	private RtSimpleElement simpleElement662;
	
	private RtSimpleElement simpleElement662() {
		if (simpleElement662 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Relationship Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("D");
			h.addAllowedValue("I");
			h.addAllowedValue("O");
			h.addAllowedValue("S");
			simpleElement662 = new RtSimpleElement("662", "ID", h);
		}
	
		return simpleElement662;
	}
	
	private RtSimpleElement simpleElement828;
	
	private RtSimpleElement simpleElement828() {
		if (simpleElement828 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Dollar Basis For Percent";
			h.minLength = 1;
			h.maxLength = 9;
			
			simpleElement828 = new RtSimpleElement("828", "R", h);
		}
	
		return simpleElement828;
	}
	
	private RtSimpleElement simpleElement478;
	
	private RtSimpleElement simpleElement478() {
		if (simpleElement478 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Credit/Debit Flag Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			simpleElement478 = new RtSimpleElement("478", "ID", h);
		}
	
		return simpleElement478;
	}
	
	private RtSimpleElement simpleElement1196;
	
	private RtSimpleElement simpleElement1196() {
		if (simpleElement1196 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Breakdown Structure Detail Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AT");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A8");
			h.addAllowedValue("A9");
			h.addAllowedValue("BL");
			h.addAllowedValue("BY");
			h.addAllowedValue("B1");
			h.addAllowedValue("B2");
			h.addAllowedValue("B3");
			h.addAllowedValue("B4");
			h.addAllowedValue("B5");
			h.addAllowedValue("CM");
			h.addAllowedValue("CY");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("D6");
			h.addAllowedValue("D7");
			h.addAllowedValue("EH");
			h.addAllowedValue("ES");
			h.addAllowedValue("EX");
			h.addAllowedValue("E1");
			h.addAllowedValue("E2");
			h.addAllowedValue("E3");
			h.addAllowedValue("E4");
			h.addAllowedValue("FE");
			h.addAllowedValue("FP");
			h.addAllowedValue("FR");
			h.addAllowedValue("F1");
			h.addAllowedValue("F2");
			h.addAllowedValue("F3");
			h.addAllowedValue("F4");
			h.addAllowedValue("G1");
			h.addAllowedValue("G2");
			h.addAllowedValue("G3");
			h.addAllowedValue("G4");
			h.addAllowedValue("G5");
			h.addAllowedValue("H1");
			h.addAllowedValue("H2");
			h.addAllowedValue("H3");
			h.addAllowedValue("H4");
			h.addAllowedValue("H5");
			h.addAllowedValue("IN");
			h.addAllowedValue("I1");
			h.addAllowedValue("J1");
			h.addAllowedValue("J2");
			h.addAllowedValue("K6");
			h.addAllowedValue("LM");
			h.addAllowedValue("L1");
			h.addAllowedValue("MD");
			h.addAllowedValue("MR");
			h.addAllowedValue("M1");
			h.addAllowedValue("NP");
			h.addAllowedValue("N1");
			h.addAllowedValue("P1");
			h.addAllowedValue("P2");
			h.addAllowedValue("P3");
			h.addAllowedValue("P4");
			h.addAllowedValue("P5");
			h.addAllowedValue("P6");
			h.addAllowedValue("RL");
			h.addAllowedValue("SC");
			h.addAllowedValue("TA");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TR");
			h.addAllowedValue("TU");
			h.addAllowedValue("UB");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			simpleElement1196 = new RtSimpleElement("1196", "ID", h);
		}
	
		return simpleElement1196;
	}
	
	private RtSimpleElement simpleElement1195;
	
	private RtSimpleElement simpleElement1195() {
		if (simpleElement1195 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Financial Information Code";
			h.minLength = 1;
			h.maxLength = 80;
			
			simpleElement1195 = new RtSimpleElement("1195", "AN", h);
		}
	
		return simpleElement1195;
	}
	
	private RtSimpleElement simpleElement369;
	
	private RtSimpleElement simpleElement369() {
		if (simpleElement369 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Free-form Description";
			h.minLength = 1;
			h.maxLength = 45;
			
			simpleElement369 = new RtSimpleElement("369", "AN", h);
		}
	
		return simpleElement369;
	}
	
	private RtSimpleElement simpleElement933;
	
	private RtSimpleElement simpleElement933() {
		if (simpleElement933 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Free-Form Message Text";
			h.minLength = 1;
			h.maxLength = 264;
			
			simpleElement933 = new RtSimpleElement("933", "AN", h);
		}
	
		return simpleElement933;
	}
	
	private RtSimpleElement simpleElement934;
	
	private RtSimpleElement simpleElement934() {
		if (simpleElement934 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Printer Carriage Control Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AT");
			h.addAllowedValue("DS");
			h.addAllowedValue("LC");
			h.addAllowedValue("NP");
			h.addAllowedValue("NS");
			h.addAllowedValue("SS");
			simpleElement934 = new RtSimpleElement("934", "ID", h);
		}
	
		return simpleElement934;
	}
	
	private RtSimpleElement simpleElement1470;
	
	private RtSimpleElement simpleElement1470() {
		if (simpleElement1470 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number";
			h.minLength = 1;
			h.maxLength = 9;
			
			simpleElement1470 = new RtSimpleElement("1470", "N0", h);
		}
	
		return simpleElement1470;
	}
	
	private RtSimpleElement simpleElement706;
	
	private RtSimpleElement simpleElement706() {
		if (simpleElement706 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Entity Relationship Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			simpleElement706 = new RtSimpleElement("706", "ID", h);
		}
	
		return simpleElement706;
	}
	
	private RtSimpleElement simpleElement166;
	
	private RtSimpleElement simpleElement166() {
		if (simpleElement166 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Address Information";
			h.minLength = 1;
			h.maxLength = 55;
			
			simpleElement166 = new RtSimpleElement("166", "AN", h);
		}
	
		return simpleElement166;
	}
	
	private RtSimpleElement simpleElement19;
	
	private RtSimpleElement simpleElement19() {
		if (simpleElement19 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "City Name";
			h.minLength = 2;
			h.maxLength = 30;
			
			simpleElement19 = new RtSimpleElement("19", "AN", h);
		}
	
		return simpleElement19;
	}
	
	private RtSimpleElement simpleElement156;
	
	private RtSimpleElement simpleElement156() {
		if (simpleElement156 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "State or Province Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			simpleElement156 = new RtSimpleElement("156", "ID", h);
		}
	
		return simpleElement156;
	}
	
	private RtSimpleElement simpleElement116;
	
	private RtSimpleElement simpleElement116() {
		if (simpleElement116 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Postal Code";
			h.minLength = 3;
			h.maxLength = 15;
			
			simpleElement116 = new RtSimpleElement("116", "ID", h);
		}
	
		return simpleElement116;
	}
	
	private RtSimpleElement simpleElement1106;
	
	private RtSimpleElement simpleElement1106() {
		if (simpleElement1106 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Address Component Qualifier";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("71");
			h.addAllowedValue("74");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			simpleElement1106 = new RtSimpleElement("1106", "ID", h);
		}
	
		return simpleElement1106;
	}
	
	private RtSimpleElement simpleElement1096;
	
	private RtSimpleElement simpleElement1096() {
		if (simpleElement1096 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "County Designator";
			h.minLength = 5;
			h.maxLength = 5;
			
			simpleElement1096 = new RtSimpleElement("1096", "ID", h);
		}
	
		return simpleElement1096;
	}
	
	private RtSimpleElement simpleElement1270;
	
	private RtSimpleElement simpleElement1270() {
		if (simpleElement1270 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Code List Qualifier Code";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("A");
			h.addAllowedValue("AA");
			h.addAllowedValue("AAA");
			h.addAllowedValue("AB");
			h.addAllowedValue("ABR");
			h.addAllowedValue("ABS");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("ALP");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			h.addAllowedValue("APE");
			h.addAllowedValue("AQ");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AU");
			h.addAllowedValue("AW");
			h.addAllowedValue("AX");
			h.addAllowedValue("A1");
			h.addAllowedValue("A2");
			h.addAllowedValue("A3");
			h.addAllowedValue("A4");
			h.addAllowedValue("A5");
			h.addAllowedValue("A6");
			h.addAllowedValue("A7");
			h.addAllowedValue("A8");
			h.addAllowedValue("A9");
			h.addAllowedValue("B");
			h.addAllowedValue("BA");
			h.addAllowedValue("BB");
			h.addAllowedValue("BC");
			h.addAllowedValue("BCC");
			h.addAllowedValue("BCR");
			h.addAllowedValue("BD");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BG");
			h.addAllowedValue("BH");
			h.addAllowedValue("BI");
			h.addAllowedValue("BJ");
			h.addAllowedValue("BK");
			h.addAllowedValue("BL");
			h.addAllowedValue("BM");
			h.addAllowedValue("BN");
			h.addAllowedValue("BO");
			h.addAllowedValue("BP");
			h.addAllowedValue("BPL");
			h.addAllowedValue("BQ");
			h.addAllowedValue("BR");
			h.addAllowedValue("BRL");
			h.addAllowedValue("BS");
			h.addAllowedValue("BSL");
			h.addAllowedValue("BU");
			h.addAllowedValue("BV");
			h.addAllowedValue("BY");
			h.addAllowedValue("BZ");
			h.addAllowedValue("C");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CL");
			h.addAllowedValue("CLP");
			h.addAllowedValue("CM");
			h.addAllowedValue("CML");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("COG");
			h.addAllowedValue("CPS");
			h.addAllowedValue("CRC");
			h.addAllowedValue("CS");
			h.addAllowedValue("CSF");
			h.addAllowedValue("CT");
			h.addAllowedValue("CU");
			h.addAllowedValue("CV");
			h.addAllowedValue("CW");
			h.addAllowedValue("CZ");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("D");
			h.addAllowedValue("DA");
			h.addAllowedValue("DB");
			h.addAllowedValue("DBS");
			h.addAllowedValue("DC");
			h.addAllowedValue("DD");
			h.addAllowedValue("DE");
			h.addAllowedValue("DF");
			h.addAllowedValue("DG");
			h.addAllowedValue("DGO");
			h.addAllowedValue("DH");
			h.addAllowedValue("DI");
			h.addAllowedValue("DJ");
			h.addAllowedValue("DK");
			h.addAllowedValue("DL");
			h.addAllowedValue("DLO");
			h.addAllowedValue("DLP");
			h.addAllowedValue("DM");
			h.addAllowedValue("DN");
			h.addAllowedValue("DO");
			h.addAllowedValue("DPE");
			h.addAllowedValue("DPL");
			h.addAllowedValue("DQ");
			h.addAllowedValue("DR");
			h.addAllowedValue("DS");
			h.addAllowedValue("DT");
			h.addAllowedValue("DU");
			h.addAllowedValue("DW");
			h.addAllowedValue("DX");
			h.addAllowedValue("DY");
			h.addAllowedValue("DZ");
			h.addAllowedValue("D1");
			h.addAllowedValue("D2");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("E");
			h.addAllowedValue("EA");
			h.addAllowedValue("EB");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EE");
			h.addAllowedValue("EF");
			h.addAllowedValue("EG");
			h.addAllowedValue("EH");
			h.addAllowedValue("EI");
			h.addAllowedValue("EJ");
			h.addAllowedValue("EK");
			h.addAllowedValue("EL");
			h.addAllowedValue("EM");
			h.addAllowedValue("EN");
			h.addAllowedValue("EO");
			h.addAllowedValue("EQ");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("ESL");
			h.addAllowedValue("ET");
			h.addAllowedValue("ETL");
			h.addAllowedValue("EU");
			h.addAllowedValue("EV");
			h.addAllowedValue("EW");
			h.addAllowedValue("EWC");
			h.addAllowedValue("EWR");
			h.addAllowedValue("EX");
			h.addAllowedValue("EY");
			h.addAllowedValue("EZ");
			h.addAllowedValue("F");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FD");
			h.addAllowedValue("FE");
			h.addAllowedValue("FF");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FI");
			h.addAllowedValue("FJ");
			h.addAllowedValue("FK");
			h.addAllowedValue("FL");
			h.addAllowedValue("FM");
			h.addAllowedValue("FN");
			h.addAllowedValue("FO");
			h.addAllowedValue("FP");
			h.addAllowedValue("FQ");
			h.addAllowedValue("FR");
			h.addAllowedValue("FS");
			h.addAllowedValue("FT");
			h.addAllowedValue("FU");
			h.addAllowedValue("FV");
			h.addAllowedValue("FW");
			h.addAllowedValue("FX");
			h.addAllowedValue("FZ");
			h.addAllowedValue("G");
			h.addAllowedValue("GA");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GD");
			h.addAllowedValue("GE");
			h.addAllowedValue("GF");
			h.addAllowedValue("GG");
			h.addAllowedValue("GI");
			h.addAllowedValue("GJ");
			h.addAllowedValue("GK");
			h.addAllowedValue("GQ");
			h.addAllowedValue("GR");
			h.addAllowedValue("GS");
			h.addAllowedValue("GT");
			h.addAllowedValue("GU");
			h.addAllowedValue("GV");
			h.addAllowedValue("GW");
			h.addAllowedValue("G1");
			h.addAllowedValue("H");
			h.addAllowedValue("HA");
			h.addAllowedValue("HB");
			h.addAllowedValue("HD");
			h.addAllowedValue("HE");
			h.addAllowedValue("HI");
			h.addAllowedValue("HRC");
			h.addAllowedValue("HS");
			h.addAllowedValue("HZR");
			h.addAllowedValue("I");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IF");
			h.addAllowedValue("IMC");
			h.addAllowedValue("IMP");
			h.addAllowedValue("IPA");
			h.addAllowedValue("IQ");
			h.addAllowedValue("IT");
			h.addAllowedValue("J");
			h.addAllowedValue("JA");
			h.addAllowedValue("JB");
			h.addAllowedValue("JC");
			h.addAllowedValue("JCL");
			h.addAllowedValue("JD");
			h.addAllowedValue("JE");
			h.addAllowedValue("JF");
			h.addAllowedValue("JG");
			h.addAllowedValue("JH");
			h.addAllowedValue("JI");
			h.addAllowedValue("JK");
			h.addAllowedValue("JL");
			h.addAllowedValue("JM");
			h.addAllowedValue("JN");
			h.addAllowedValue("JO");
			h.addAllowedValue("JOL");
			h.addAllowedValue("JP");
			h.addAllowedValue("J0");
			h.addAllowedValue("J1");
			h.addAllowedValue("J2");
			h.addAllowedValue("J3");
			h.addAllowedValue("J4");
			h.addAllowedValue("J5");
			h.addAllowedValue("J6");
			h.addAllowedValue("J7");
			h.addAllowedValue("J8");
			h.addAllowedValue("J9");
			h.addAllowedValue("K");
			h.addAllowedValue("KA");
			h.addAllowedValue("KB");
			h.addAllowedValue("KC");
			h.addAllowedValue("KD");
			h.addAllowedValue("KE");
			h.addAllowedValue("KF");
			h.addAllowedValue("KG");
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("KU");
			h.addAllowedValue("KW");
			h.addAllowedValue("KYL");
			h.addAllowedValue("KZ");
			h.addAllowedValue("L");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LC");
			h.addAllowedValue("LD");
			h.addAllowedValue("LE");
			h.addAllowedValue("LF");
			h.addAllowedValue("LG");
			h.addAllowedValue("LH");
			h.addAllowedValue("LIN");
			h.addAllowedValue("LJ");
			h.addAllowedValue("LK");
			h.addAllowedValue("LM");
			h.addAllowedValue("LN");
			h.addAllowedValue("LO");
			h.addAllowedValue("LOI");
			h.addAllowedValue("LP");
			h.addAllowedValue("LQ");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LSC");
			h.addAllowedValue("LT");
			h.addAllowedValue("LZ");
			h.addAllowedValue("M");
			h.addAllowedValue("MB");
			h.addAllowedValue("MC");
			h.addAllowedValue("MCC");
			h.addAllowedValue("MCD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("ML");
			h.addAllowedValue("MN");
			h.addAllowedValue("MOC");
			h.addAllowedValue("N");
			h.addAllowedValue("NA");
			h.addAllowedValue("NAC");
			h.addAllowedValue("NAF");
			h.addAllowedValue("NAS");
			h.addAllowedValue("NB");
			h.addAllowedValue("NC");
			h.addAllowedValue("ND");
			h.addAllowedValue("NDC");
			h.addAllowedValue("NE");
			h.addAllowedValue("NF");
			h.addAllowedValue("NH");
			h.addAllowedValue("NI");
			h.addAllowedValue("NJ");
			h.addAllowedValue("NK");
			h.addAllowedValue("NL");
			h.addAllowedValue("NP");
			h.addAllowedValue("NR");
			h.addAllowedValue("NS");
			h.addAllowedValue("NT");
			h.addAllowedValue("O");
			h.addAllowedValue("OC");
			h.addAllowedValue("O1");
			h.addAllowedValue("O2");
			h.addAllowedValue("O3");
			h.addAllowedValue("O4");
			h.addAllowedValue("P");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PGS");
			h.addAllowedValue("PI");
			h.addAllowedValue("PIT");
			h.addAllowedValue("PL");
			h.addAllowedValue("PLC");
			h.addAllowedValue("PLS");
			h.addAllowedValue("PPD");
			h.addAllowedValue("PPP");
			h.addAllowedValue("PPS");
			h.addAllowedValue("PPV");
			h.addAllowedValue("PRA");
			h.addAllowedValue("PRC");
			h.addAllowedValue("PRR");
			h.addAllowedValue("PRT");
			h.addAllowedValue("PS");
			h.addAllowedValue("PWA");
			h.addAllowedValue("PWI");
			h.addAllowedValue("PWR");
			h.addAllowedValue("PWS");
			h.addAllowedValue("PWT");
			h.addAllowedValue("Q");
			h.addAllowedValue("QA");
			h.addAllowedValue("QB");
			h.addAllowedValue("QC");
			h.addAllowedValue("QE");
			h.addAllowedValue("QF");
			h.addAllowedValue("QG");
			h.addAllowedValue("QH");
			h.addAllowedValue("QI");
			h.addAllowedValue("QJ");
			h.addAllowedValue("QK");
			h.addAllowedValue("QS");
			h.addAllowedValue("R");
			h.addAllowedValue("RA");
			h.addAllowedValue("RC");
			h.addAllowedValue("RCA");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("REN");
			h.addAllowedValue("RF");
			h.addAllowedValue("RI");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RT");
			h.addAllowedValue("RTC");
			h.addAllowedValue("RUM");
			h.addAllowedValue("RX");
			h.addAllowedValue("S");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SBA");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SEC");
			h.addAllowedValue("SF");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SHL");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SMI");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SPE");
			h.addAllowedValue("SR");
			h.addAllowedValue("SRL");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("STC");
			h.addAllowedValue("T");
			h.addAllowedValue("TB");
			h.addAllowedValue("TC");
			h.addAllowedValue("TCL");
			h.addAllowedValue("TD");
			h.addAllowedValue("TE");
			h.addAllowedValue("TF");
			h.addAllowedValue("TG");
			h.addAllowedValue("TOL");
			h.addAllowedValue("TR");
			h.addAllowedValue("TTL");
			h.addAllowedValue("TX");
			h.addAllowedValue("TY");
			h.addAllowedValue("T00");
			h.addAllowedValue("T01");
			h.addAllowedValue("T02");
			h.addAllowedValue("T03");
			h.addAllowedValue("T04");
			h.addAllowedValue("T05");
			h.addAllowedValue("T06");
			h.addAllowedValue("T07");
			h.addAllowedValue("T08");
			h.addAllowedValue("T09");
			h.addAllowedValue("T10");
			h.addAllowedValue("T11");
			h.addAllowedValue("T12");
			h.addAllowedValue("T13");
			h.addAllowedValue("T14");
			h.addAllowedValue("T15");
			h.addAllowedValue("T16");
			h.addAllowedValue("T17");
			h.addAllowedValue("T18");
			h.addAllowedValue("T19");
			h.addAllowedValue("T20");
			h.addAllowedValue("T21");
			h.addAllowedValue("U");
			h.addAllowedValue("UP");
			h.addAllowedValue("UR");
			h.addAllowedValue("US");
			h.addAllowedValue("UU");
			h.addAllowedValue("V");
			h.addAllowedValue("W");
			h.addAllowedValue("WDL");
			h.addAllowedValue("X");
			h.addAllowedValue("Y");
			h.addAllowedValue("Z");
			h.addAllowedValue("ZZ");
			h.addAllowedValue("0");
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("100");
			h.addAllowedValue("101");
			h.addAllowedValue("102");
			h.addAllowedValue("103");
			h.addAllowedValue("104");
			h.addAllowedValue("105");
			h.addAllowedValue("106");
			h.addAllowedValue("107");
			h.addAllowedValue("108");
			h.addAllowedValue("109");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("3");
			h.addAllowedValue("30");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("4");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("5");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("6");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("69");
			h.addAllowedValue("7");
			h.addAllowedValue("71");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("8");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("9");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			h.addAllowedValue("92");
			h.addAllowedValue("93");
			h.addAllowedValue("94");
			h.addAllowedValue("95");
			h.addAllowedValue("96");
			h.addAllowedValue("97");
			h.addAllowedValue("98");
			h.addAllowedValue("99");
			simpleElement1270 = new RtSimpleElement("1270", "ID", h);
		}
	
		return simpleElement1270;
	}
	
	private RtSimpleElement simpleElement1271;
	
	private RtSimpleElement simpleElement1271() {
		if (simpleElement1271 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Industry Code";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement1271 = new RtSimpleElement("1271", "AN", h);
		}
	
		return simpleElement1271;
	}
	
	private RtSimpleElement simpleElement790;
	
	private RtSimpleElement simpleElement790() {
		if (simpleElement790 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Entity Title";
			h.minLength = 1;
			h.maxLength = 132;
			
			simpleElement790 = new RtSimpleElement("790", "AN", h);
		}
	
		return simpleElement790;
	}
	
	private RtSimpleElement simpleElement791;
	
	private RtSimpleElement simpleElement791() {
		if (simpleElement791 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Entity Purpose";
			h.minLength = 1;
			h.maxLength = 80;
			
			simpleElement791 = new RtSimpleElement("791", "AN", h);
		}
	
		return simpleElement791;
	}
	
	private RtSimpleElement simpleElement792;
	
	private RtSimpleElement simpleElement792() {
		if (simpleElement792 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Entity Status Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("B");
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			h.addAllowedValue("E");
			h.addAllowedValue("F");
			h.addAllowedValue("G");
			h.addAllowedValue("H");
			h.addAllowedValue("J");
			h.addAllowedValue("K");
			h.addAllowedValue("L");
			h.addAllowedValue("M");
			h.addAllowedValue("N");
			h.addAllowedValue("P");
			h.addAllowedValue("Z");
			simpleElement792 = new RtSimpleElement("792", "ID", h);
		}
	
		return simpleElement792;
	}
	
	private RtSimpleElement simpleElement554;
	
	private RtSimpleElement simpleElement554() {
		if (simpleElement554 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Assigned Number";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement554 = new RtSimpleElement("554", "N0", h);
		}
	
		return simpleElement554;
	}
	
	private RtSimpleElement simpleElement1322;
	
	private RtSimpleElement simpleElement1322() {
		if (simpleElement1322 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Certification Type Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("B");
			h.addAllowedValue("C");
			h.addAllowedValue("D");
			h.addAllowedValue("E");
			h.addAllowedValue("I");
			h.addAllowedValue("R");
			h.addAllowedValue("S");
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			simpleElement1322 = new RtSimpleElement("1322", "ID", h);
		}
	
		return simpleElement1322;
	}
	
	private RtSimpleElement simpleElement1401;
	
	private RtSimpleElement simpleElement1401() {
		if (simpleElement1401 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Proposal Data Detail Identifier Code";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AC");
			h.addAllowedValue("AD");
			h.addAllowedValue("AE");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AJ");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AM");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AP");
			simpleElement1401 = new RtSimpleElement("1401", "ID", h);
		}
	
		return simpleElement1401;
	}
	
	private RtSimpleElement simpleElement1005;
	
	private RtSimpleElement simpleElement1005() {
		if (simpleElement1005 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Hierarchical Structure Code";
			h.minLength = 4;
			h.maxLength = 4;
			
			h.addAllowedValue("ZZZZ");
			h.addAllowedValue("0001");
			h.addAllowedValue("0002");
			h.addAllowedValue("0003");
			h.addAllowedValue("0004");
			h.addAllowedValue("0010");
			h.addAllowedValue("0011");
			h.addAllowedValue("0012");
			h.addAllowedValue("0013");
			h.addAllowedValue("0014");
			h.addAllowedValue("0015");
			h.addAllowedValue("0016");
			h.addAllowedValue("0017");
			h.addAllowedValue("0018");
			h.addAllowedValue("0019");
			h.addAllowedValue("0020");
			h.addAllowedValue("0021");
			h.addAllowedValue("0022");
			h.addAllowedValue("0023");
			h.addAllowedValue("0035");
			h.addAllowedValue("0036");
			h.addAllowedValue("0055");
			h.addAllowedValue("0056");
			h.addAllowedValue("0057");
			h.addAllowedValue("0058");
			h.addAllowedValue("0059");
			h.addAllowedValue("0060");
			h.addAllowedValue("0061");
			h.addAllowedValue("0062");
			h.addAllowedValue("0063");
			h.addAllowedValue("0064");
			h.addAllowedValue("0065");
			h.addAllowedValue("0066");
			h.addAllowedValue("0067");
			h.addAllowedValue("0068");
			h.addAllowedValue("0069");
			h.addAllowedValue("0070");
			h.addAllowedValue("0071");
			h.addAllowedValue("0072");
			h.addAllowedValue("0073");
			h.addAllowedValue("0074");
			h.addAllowedValue("0075");
			h.addAllowedValue("0076");
			h.addAllowedValue("0077");
			h.addAllowedValue("0078");
			h.addAllowedValue("0079");
			h.addAllowedValue("0080");
			h.addAllowedValue("0081");
			h.addAllowedValue("0082");
			h.addAllowedValue("0083");
			h.addAllowedValue("0200");
			h.addAllowedValue("0201");
			h.addAllowedValue("0202");
			h.addAllowedValue("0203");
			h.addAllowedValue("0204");
			h.addAllowedValue("0205");
			h.addAllowedValue("0206");
			h.addAllowedValue("0207");
			h.addAllowedValue("0208");
			h.addAllowedValue("0209");
			h.addAllowedValue("0210");
			simpleElement1005 = new RtSimpleElement("1005", "ID", h);
		}
	
		return simpleElement1005;
	}
	
	private RtSimpleElement simpleElement1309;
	
	private RtSimpleElement simpleElement1309() {
		if (simpleElement1309 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Acquisition Data Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("KH");
			h.addAllowedValue("KI");
			h.addAllowedValue("KJ");
			h.addAllowedValue("KK");
			h.addAllowedValue("KL");
			h.addAllowedValue("KM");
			h.addAllowedValue("KN");
			h.addAllowedValue("KO");
			h.addAllowedValue("KP");
			h.addAllowedValue("KQ");
			h.addAllowedValue("KR");
			h.addAllowedValue("KS");
			h.addAllowedValue("KT");
			h.addAllowedValue("KU");
			h.addAllowedValue("KV");
			h.addAllowedValue("KW");
			h.addAllowedValue("KX");
			h.addAllowedValue("KY");
			h.addAllowedValue("KZ");
			h.addAllowedValue("K1");
			h.addAllowedValue("K2");
			h.addAllowedValue("K3");
			h.addAllowedValue("K4");
			h.addAllowedValue("K5");
			h.addAllowedValue("K6");
			h.addAllowedValue("L2");
			h.addAllowedValue("01");
			h.addAllowedValue("02");
			h.addAllowedValue("03");
			h.addAllowedValue("04");
			h.addAllowedValue("05");
			h.addAllowedValue("06");
			h.addAllowedValue("07");
			h.addAllowedValue("08");
			h.addAllowedValue("09");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("28");
			h.addAllowedValue("29");
			h.addAllowedValue("30");
			h.addAllowedValue("31");
			h.addAllowedValue("32");
			h.addAllowedValue("33");
			h.addAllowedValue("34");
			h.addAllowedValue("35");
			h.addAllowedValue("36");
			h.addAllowedValue("37");
			h.addAllowedValue("38");
			h.addAllowedValue("39");
			h.addAllowedValue("40");
			h.addAllowedValue("41");
			h.addAllowedValue("42");
			h.addAllowedValue("43");
			h.addAllowedValue("44");
			h.addAllowedValue("45");
			h.addAllowedValue("46");
			h.addAllowedValue("47");
			h.addAllowedValue("48");
			h.addAllowedValue("49");
			h.addAllowedValue("50");
			h.addAllowedValue("51");
			h.addAllowedValue("52");
			h.addAllowedValue("53");
			h.addAllowedValue("54");
			h.addAllowedValue("55");
			h.addAllowedValue("56");
			h.addAllowedValue("57");
			h.addAllowedValue("58");
			h.addAllowedValue("59");
			h.addAllowedValue("60");
			h.addAllowedValue("61");
			h.addAllowedValue("62");
			h.addAllowedValue("63");
			h.addAllowedValue("64");
			h.addAllowedValue("65");
			h.addAllowedValue("66");
			h.addAllowedValue("67");
			h.addAllowedValue("68");
			h.addAllowedValue("69");
			h.addAllowedValue("70");
			h.addAllowedValue("71");
			h.addAllowedValue("72");
			h.addAllowedValue("73");
			h.addAllowedValue("74");
			h.addAllowedValue("75");
			h.addAllowedValue("76");
			h.addAllowedValue("77");
			h.addAllowedValue("78");
			h.addAllowedValue("79");
			h.addAllowedValue("80");
			h.addAllowedValue("81");
			h.addAllowedValue("82");
			h.addAllowedValue("83");
			h.addAllowedValue("84");
			h.addAllowedValue("85");
			h.addAllowedValue("86");
			h.addAllowedValue("87");
			h.addAllowedValue("88");
			h.addAllowedValue("89");
			h.addAllowedValue("90");
			h.addAllowedValue("91");
			simpleElement1309 = new RtSimpleElement("1309", "ID", h);
		}
	
		return simpleElement1309;
	}
	
	private RtSimpleElement simpleElement1310;
	
	private RtSimpleElement simpleElement1310() {
		if (simpleElement1310 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Financing Type Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("G");
			h.addAllowedValue("P");
			simpleElement1310 = new RtSimpleElement("1310", "ID", h);
		}
	
		return simpleElement1310;
	}
	
	private RtSimpleElement simpleElement729;
	
	private RtSimpleElement simpleElement729() {
		if (simpleElement729 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Category";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement729 = new RtSimpleElement("729", "AN", h);
		}
	
		return simpleElement729;
	}
	
	private RtSimpleElement simpleElement363;
	
	private RtSimpleElement simpleElement363() {
		if (simpleElement363 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Note Reference Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("AAA");
			h.addAllowedValue("AAB");
			h.addAllowedValue("AAC");
			h.addAllowedValue("AAD");
			h.addAllowedValue("AAE");
			h.addAllowedValue("AAF");
			h.addAllowedValue("ABN");
			h.addAllowedValue("ACC");
			h.addAllowedValue("ACI");
			h.addAllowedValue("ACN");
			h.addAllowedValue("ACS");
			h.addAllowedValue("ACT");
			h.addAllowedValue("ADD");
			h.addAllowedValue("AES");
			h.addAllowedValue("AET");
			h.addAllowedValue("ALG");
			h.addAllowedValue("ALL");
			h.addAllowedValue("ALT");
			h.addAllowedValue("AMN");
			h.addAllowedValue("AOO");
			h.addAllowedValue("APN");
			h.addAllowedValue("APS");
			h.addAllowedValue("BBD");
			h.addAllowedValue("BBF");
			h.addAllowedValue("BBH");
			h.addAllowedValue("BBN");
			h.addAllowedValue("BBO");
			h.addAllowedValue("BBT");
			h.addAllowedValue("BFD");
			h.addAllowedValue("BOL");
			h.addAllowedValue("BUR");
			h.addAllowedValue("CAA");
			h.addAllowedValue("CAB");
			h.addAllowedValue("CAC");
			h.addAllowedValue("CAD");
			h.addAllowedValue("CAE");
			h.addAllowedValue("CAF");
			h.addAllowedValue("CAG");
			h.addAllowedValue("CAH");
			h.addAllowedValue("CAI");
			h.addAllowedValue("CAJ");
			h.addAllowedValue("CAK");
			h.addAllowedValue("CAL");
			h.addAllowedValue("CAM");
			h.addAllowedValue("CAN");
			h.addAllowedValue("CAO");
			h.addAllowedValue("CAP");
			h.addAllowedValue("CAQ");
			h.addAllowedValue("CAR");
			h.addAllowedValue("CAS");
			h.addAllowedValue("CAT");
			h.addAllowedValue("CAU");
			h.addAllowedValue("CAV");
			h.addAllowedValue("CAW");
			h.addAllowedValue("CAX");
			h.addAllowedValue("CAZ");
			h.addAllowedValue("CBA");
			h.addAllowedValue("CBB");
			h.addAllowedValue("CBC");
			h.addAllowedValue("CBH");
			h.addAllowedValue("CBI");
			h.addAllowedValue("CCA");
			h.addAllowedValue("CCB");
			h.addAllowedValue("CCC");
			h.addAllowedValue("CCD");
			h.addAllowedValue("CCE");
			h.addAllowedValue("CCF");
			h.addAllowedValue("CCG");
			h.addAllowedValue("CCN");
			h.addAllowedValue("CDD");
			h.addAllowedValue("CER");
			h.addAllowedValue("CHG");
			h.addAllowedValue("CIG");
			h.addAllowedValue("CLN");
			h.addAllowedValue("CLR");
			h.addAllowedValue("CMP");
			h.addAllowedValue("CMT");
			h.addAllowedValue("COD");
			h.addAllowedValue("COM");
			h.addAllowedValue("CON");
			h.addAllowedValue("CRA");
			h.addAllowedValue("CRK");
			h.addAllowedValue("CRN");
			h.addAllowedValue("CUS");
			h.addAllowedValue("DCP");
			h.addAllowedValue("DEE");
			h.addAllowedValue("DEL");
			h.addAllowedValue("DEP");
			h.addAllowedValue("DFR");
			h.addAllowedValue("DFS");
			h.addAllowedValue("DGN");
			h.addAllowedValue("DME");
			h.addAllowedValue("DOD");
			h.addAllowedValue("DOI");
			h.addAllowedValue("ECD");
			h.addAllowedValue("ECM");
			h.addAllowedValue("ECN");
			h.addAllowedValue("ECT");
			h.addAllowedValue("EED");
			h.addAllowedValue("EFD");
			h.addAllowedValue("ELE");
			h.addAllowedValue("EMC");
			h.addAllowedValue("EMD");
			h.addAllowedValue("ENR");
			h.addAllowedValue("ERN");
			h.addAllowedValue("EVL");
			h.addAllowedValue("EXE");
			h.addAllowedValue("EXR");
			h.addAllowedValue("EXT");
			h.addAllowedValue("FEE");
			h.addAllowedValue("FUT");
			h.addAllowedValue("GEN");
			h.addAllowedValue("GPI");
			h.addAllowedValue("GSI");
			h.addAllowedValue("HHI");
			h.addAllowedValue("ICN");
			h.addAllowedValue("IDT");
			h.addAllowedValue("IID");
			h.addAllowedValue("IIE");
			h.addAllowedValue("IIR");
			h.addAllowedValue("IMP");
			h.addAllowedValue("INS");
			h.addAllowedValue("INT");
			h.addAllowedValue("INV");
			h.addAllowedValue("IVC");
			h.addAllowedValue("JVD");
			h.addAllowedValue("LAB");
			h.addAllowedValue("LBD");
			h.addAllowedValue("LBS");
			h.addAllowedValue("LEN");
			h.addAllowedValue("LIN");
			h.addAllowedValue("LIQ");
			h.addAllowedValue("LLA");
			h.addAllowedValue("LLB");
			h.addAllowedValue("LLC");
			h.addAllowedValue("LOC");
			h.addAllowedValue("LOI");
			h.addAllowedValue("LSD");
			h.addAllowedValue("MCD");
			h.addAllowedValue("MDO");
			h.addAllowedValue("MED");
			h.addAllowedValue("MFG");
			h.addAllowedValue("MKN");
			h.addAllowedValue("MMD");
			h.addAllowedValue("MSD");
			h.addAllowedValue("NCD");
			h.addAllowedValue("NPD");
			h.addAllowedValue("NTR");
			h.addAllowedValue("OBI");
			h.addAllowedValue("OBL");
			h.addAllowedValue("OCA");
			h.addAllowedValue("OCC");
			h.addAllowedValue("OCL");
			h.addAllowedValue("OCP");
			h.addAllowedValue("OCR");
			h.addAllowedValue("ODT");
			h.addAllowedValue("OLS");
			h.addAllowedValue("OPO");
			h.addAllowedValue("ORA");
			h.addAllowedValue("ORE");
			h.addAllowedValue("ORI");
			h.addAllowedValue("OTH");
			h.addAllowedValue("OTN");
			h.addAllowedValue("OTS");
			h.addAllowedValue("PAY");
			h.addAllowedValue("PCS");
			h.addAllowedValue("PDS");
			h.addAllowedValue("PED");
			h.addAllowedValue("PEN");
			h.addAllowedValue("PES");
			h.addAllowedValue("PID");
			h.addAllowedValue("PKG");
			h.addAllowedValue("PMT");
			h.addAllowedValue("POB");
			h.addAllowedValue("POC");
			h.addAllowedValue("POL");
			h.addAllowedValue("PPC");
			h.addAllowedValue("PRI");
			h.addAllowedValue("PRN");
			h.addAllowedValue("PRO");
			h.addAllowedValue("PRR");
			h.addAllowedValue("PSY");
			h.addAllowedValue("PUR");
			h.addAllowedValue("QUL");
			h.addAllowedValue("QUT");
			h.addAllowedValue("RDI");
			h.addAllowedValue("REC");
			h.addAllowedValue("REG");
			h.addAllowedValue("REP");
			h.addAllowedValue("REV");
			h.addAllowedValue("RFL");
			h.addAllowedValue("RHB");
			h.addAllowedValue("RLA");
			h.addAllowedValue("RLH");
			h.addAllowedValue("RNH");
			h.addAllowedValue("RNI");
			h.addAllowedValue("ROU");
			h.addAllowedValue("RPT");
			h.addAllowedValue("RST");
			h.addAllowedValue("RVC");
			h.addAllowedValue("SAN");
			h.addAllowedValue("SCN");
			h.addAllowedValue("SDD");
			h.addAllowedValue("SET");
			h.addAllowedValue("SFM");
			h.addAllowedValue("SMD");
			h.addAllowedValue("SOB");
			h.addAllowedValue("SOW");
			h.addAllowedValue("SPH");
			h.addAllowedValue("SPT");
			h.addAllowedValue("SPV");
			h.addAllowedValue("SSA");
			h.addAllowedValue("SSC");
			h.addAllowedValue("SSD");
			h.addAllowedValue("SSE");
			h.addAllowedValue("SSG");
			h.addAllowedValue("SSH");
			h.addAllowedValue("SSI");
			h.addAllowedValue("SSS");
			h.addAllowedValue("SST");
			h.addAllowedValue("TAF");
			h.addAllowedValue("TCF");
			h.addAllowedValue("TDA");
			h.addAllowedValue("TES");
			h.addAllowedValue("TIL");
			h.addAllowedValue("TLF");
			h.addAllowedValue("TLR");
			h.addAllowedValue("TPO");
			h.addAllowedValue("TRA");
			h.addAllowedValue("TRE");
			h.addAllowedValue("TRF");
			h.addAllowedValue("TRS");
			h.addAllowedValue("TSD");
			h.addAllowedValue("TSF");
			h.addAllowedValue("TST");
			h.addAllowedValue("UPI");
			h.addAllowedValue("VEC");
			h.addAllowedValue("VNN");
			h.addAllowedValue("WHI");
			h.addAllowedValue("WRP");
			h.addAllowedValue("ZZZ");
			simpleElement363 = new RtSimpleElement("363", "ID", h);
		}
	
		return simpleElement363;
	}
	
	private RtSimpleElement simpleElement1551;
	
	private RtSimpleElement simpleElement1551() {
		if (simpleElement1551 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Message Text";
			h.minLength = 1;
			h.maxLength = 4096;
			
			simpleElement1551 = new RtSimpleElement("1551", "AN", h);
		}
	
		return simpleElement1551;
	}
	
	private RtSimpleElement simpleElement330;
	
	private RtSimpleElement simpleElement330() {
		if (simpleElement330 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Quantity Ordered";
			h.minLength = 1;
			h.maxLength = 15;
			
			simpleElement330 = new RtSimpleElement("330", "R", h);
		}
	
		return simpleElement330;
	}
	
	private RtSimpleElement simpleElement799;
	
	private RtSimpleElement simpleElement799() {
		if (simpleElement799 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Version Identifier";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement799 = new RtSimpleElement("799", "AN", h);
		}
	
		return simpleElement799;
	}
	
	private RtSimpleElement simpleElement371;
	
	private RtSimpleElement simpleElement371() {
		if (simpleElement371 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Change Reason Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AQ");
			h.addAllowedValue("BB");
			h.addAllowedValue("BD");
			h.addAllowedValue("C1");
			h.addAllowedValue("C2");
			h.addAllowedValue("C3");
			h.addAllowedValue("C4");
			h.addAllowedValue("C5");
			h.addAllowedValue("C6");
			h.addAllowedValue("DC");
			h.addAllowedValue("EV");
			h.addAllowedValue("FE");
			h.addAllowedValue("GU");
			h.addAllowedValue("GW");
			h.addAllowedValue("LD");
			h.addAllowedValue("MC");
			h.addAllowedValue("MP");
			h.addAllowedValue("PC");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PS");
			h.addAllowedValue("QH");
			h.addAllowedValue("QO");
			h.addAllowedValue("QP");
			h.addAllowedValue("QT");
			h.addAllowedValue("SC");
			h.addAllowedValue("UM");
			h.addAllowedValue("UP");
			h.addAllowedValue("WD");
			h.addAllowedValue("WO");
			h.addAllowedValue("ZZ");
			simpleElement371 = new RtSimpleElement("371", "ID", h);
		}
	
		return simpleElement371;
	}
	
	private RtSimpleElement simpleElement356;
	
	private RtSimpleElement simpleElement356() {
		if (simpleElement356 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Pack";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement356 = new RtSimpleElement("356", "N0", h);
		}
	
		return simpleElement356;
	}
	
	private RtSimpleElement simpleElement357;
	
	private RtSimpleElement simpleElement357() {
		if (simpleElement357 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Size";
			h.minLength = 1;
			h.maxLength = 8;
			
			simpleElement357 = new RtSimpleElement("357", "R", h);
		}
	
		return simpleElement357;
	}
	
	private RtSimpleElement simpleElement384;
	
	private RtSimpleElement simpleElement384() {
		if (simpleElement384 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Gross Weight per Pack";
			h.minLength = 1;
			h.maxLength = 9;
			
			simpleElement384 = new RtSimpleElement("384", "R", h);
		}
	
		return simpleElement384;
	}
	
	private RtSimpleElement simpleElement385;
	
	private RtSimpleElement simpleElement385() {
		if (simpleElement385 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Gross Volume per Pack";
			h.minLength = 1;
			h.maxLength = 9;
			
			simpleElement385 = new RtSimpleElement("385", "R", h);
		}
	
		return simpleElement385;
	}
	
	private RtSimpleElement simpleElement82;
	
	private RtSimpleElement simpleElement82() {
		if (simpleElement82 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Length";
			h.minLength = 1;
			h.maxLength = 8;
			
			simpleElement82 = new RtSimpleElement("82", "R", h);
		}
	
		return simpleElement82;
	}
	
	private RtSimpleElement simpleElement189;
	
	private RtSimpleElement simpleElement189() {
		if (simpleElement189 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Width";
			h.minLength = 1;
			h.maxLength = 8;
			
			simpleElement189 = new RtSimpleElement("189", "R", h);
		}
	
		return simpleElement189;
	}
	
	private RtSimpleElement simpleElement65;
	
	private RtSimpleElement simpleElement65() {
		if (simpleElement65 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Height";
			h.minLength = 1;
			h.maxLength = 8;
			
			simpleElement65 = new RtSimpleElement("65", "R", h);
		}
	
		return simpleElement65;
	}
	
	private RtSimpleElement simpleElement810;
	
	private RtSimpleElement simpleElement810() {
		if (simpleElement810 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Inner Pack";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement810 = new RtSimpleElement("810", "N0", h);
		}
	
		return simpleElement810;
	}
	
	private RtSimpleElement simpleElement382;
	
	private RtSimpleElement simpleElement382() {
		if (simpleElement382 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number of Units Shipped";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement382 = new RtSimpleElement("382", "R", h);
		}
	
		return simpleElement382;
	}
	
	private RtSimpleElement simpleElement383;
	
	private RtSimpleElement simpleElement383() {
		if (simpleElement383 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Quantity Difference";
			h.minLength = 1;
			h.maxLength = 9;
			
			simpleElement383 = new RtSimpleElement("383", "R", h);
		}
	
		return simpleElement383;
	}
	
	private RtSimpleElement simpleElement61;
	
	private RtSimpleElement simpleElement61() {
		if (simpleElement61 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Free-Form Message";
			h.minLength = 1;
			h.maxLength = 30;
			
			simpleElement61 = new RtSimpleElement("61", "AN", h);
		}
	
		return simpleElement61;
	}
	
	private RtSimpleElement simpleElement326;
	
	private RtSimpleElement simpleElement326() {
		if (simpleElement326 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Request Reference Number";
			h.minLength = 1;
			h.maxLength = 45;
			
			simpleElement326 = new RtSimpleElement("326", "AN", h);
		}
	
		return simpleElement326;
	}
	
	private RtSimpleElement simpleElement447;
	
	private RtSimpleElement simpleElement447() {
		if (simpleElement447 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Loop Identifier Code";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement447 = new RtSimpleElement("447", "AN", h);
		}
	
		return simpleElement447;
	}
	
	private RtSimpleElement simpleElement354;
	
	private RtSimpleElement simpleElement354() {
		if (simpleElement354 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number of Line Items";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement354 = new RtSimpleElement("354", "N0", h);
		}
	
		return simpleElement354;
	}
	
	private RtSimpleElement simpleElement347;
	
	private RtSimpleElement simpleElement347() {
		if (simpleElement347 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Hash Total";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement347 = new RtSimpleElement("347", "R", h);
		}
	
		return simpleElement347;
	}
	
	private RtSimpleElement simpleElement96;
	
	private RtSimpleElement simpleElement96() {
		if (simpleElement96 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number of Included Segments";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement96 = new RtSimpleElement("96", "N0", h);
		}
	
		return simpleElement96;
	}
}
