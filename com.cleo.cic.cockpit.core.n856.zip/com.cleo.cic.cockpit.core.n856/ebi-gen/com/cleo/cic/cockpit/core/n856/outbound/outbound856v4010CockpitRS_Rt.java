/**
* @generated
*/
package com.cleo.cic.cockpit.core.n856.outbound;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class outbound856v4010CockpitRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.DateTime v_currentDateTime;
	private com.extol.ebi.ruleset.lang.core.String v_currentDTMillisString;
	private com.extol.ebi.ruleset.lang.core.Number v_currentDTMillisNumeric;
	private com.extol.ebi.ruleset.lang.core.Number v_totalLineItemCounter;
	private com.extol.ebi.ruleset.lang.core.String v_totalLineItemsString;
	private com.cleo.cic.cockpit.core.cockpitRDO glb = addToContextMap(new com.cleo.cic.cockpit.core.cockpitRDO());
	private com.extol.ebi.ruleset.lang.core.Object v_outboundMessage;
	private com.extol.ebi.ruleset.lang.core.String v_NumberOfLineItems;
	private com.extol.ebi.ruleset.lang.core.String v_ShippedDate;
	private com.extol.ebi.ruleset.lang.core.String v_ParentMessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.String v_MessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> v_SplitReprocessParms;
	private com.extol.ebi.ruleset.lang.core.String v_ReprocessKey;
	private com.extol.ebi.ruleset.lang.core.Number v_ListCount;
	private com.extol.ebi.ruleset.lang.core.String v_ListCountString;
	private com.extol.ebi.ruleset.lang.core.String v_RouteValue;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.cleo.cic.cockpit.core.n856.n856v4010CockpitEDI_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "", new Block() { public void body() {
		
		
			createCompositeRule(2, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
					createSimpleRule(3, "new GetCurrentDateTime().execute() => #[this.v_currentDateTime]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
					outbound856v4010CockpitRS_Rt.this.v_currentDateTime = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
					createSimpleRule(4, "new GetMilliseconds().execute(this.v_currentDateTime) => #[this.v_currentDTMillisNumeric]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime var0 = outbound856v4010CockpitRS_Rt.this.v_currentDateTime;
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
					outbound856v4010CockpitRS_Rt.this.v_currentDTMillisNumeric = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(5, "new Move().execute(this.v_currentDTMillisNumeric) => #[this.v_currentDTMillisString]", action);
					final SourceNode var0 = toValueNode(outbound856v4010CockpitRS_Rt.this.v_currentDTMillisNumeric);
					final SourceNode result = action.execute(var0);
					outbound856v4010CockpitRS_Rt.this.v_currentDTMillisString = extractString(result);
				}
			}}).run();
			createCompositeRule(6, "", new Block() { public void body() {
			
			
				createCompositeRule(7, "for source.Area2.sgHL", new Block() { public void body() {
					final SourceNode s0_Area2 = source.get("Area2");
					if (exists(s0_Area2)) {
					for (final SourceNode s1_cur_sgHL : s0_Area2.getIterable("sgHL")) {
				
				
					createCompositeRule(8, "for source.Area2.sgHL.current.HL", new Block() { public void body() {
						final SourceNode s2_HL = s1_cur_sgHL.get("HL");
						if (exists(s2_HL)) {
					
					
						{
							com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
							createSimpleRule(9, "new Add().execute(this.v_totalLineItemCounter, 1, 0) => #[this.v_totalLineItemCounter]", action);
							final com.extol.ebi.ruleset.lang.core.Number var0 = outbound856v4010CockpitRS_Rt.this.v_totalLineItemCounter;
							final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
							final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(0);
							final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
							outbound856v4010CockpitRS_Rt.this.v_totalLineItemCounter = result;
						}
					}}}).run();
					createCompositeRule(10, "for source.Area2.sgHL.current.PRF", new Block() { public void body() {
						final SourceNode s2_PRF = s1_cur_sgHL.get("PRF");
						if (exists(s2_PRF)) {
					
					
						{
							boolean conditionResult;
							{
								com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
								createRuleCondition(11, "new IsNotNullOrWhiteSpaces().execute(source.Area2.sgHL.current.PRF.PRF324) => #[]", condition);
								final SourceNode var0 = s2_PRF.get("PRF324");
								final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
								
								conditionResult = result.asJavaBoolean().booleanValue();
							}
							if (conditionResult) {
								com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
								createSimpleRule(11, "new Move().execute(source.Area2.sgHL.current.PRF.PRF324) => #[this.v_ParentMessageId]", action);
								final SourceNode var0 = s2_PRF.get("PRF324");
								final SourceNode result = action.execute(var0);
								outbound856v4010CockpitRS_Rt.this.v_ParentMessageId = extractString(result);
							}
						}
						{
							boolean conditionResult;
							{
								com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
								createRuleCondition(12, "new IsNotNullOrWhiteSpaces().execute(source.Area2.sgHL.current.PRF.PRF324) => #[]", condition);
								final SourceNode var0 = s2_PRF.get("PRF324");
								final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
								
								conditionResult = result.asJavaBoolean().booleanValue();
							}
							if (conditionResult) {
								com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
								createSimpleRule(12, "new Move().execute(source.Area2.sgHL.current.PRF.PRF324) => #[this.v_MessageId]", action);
								final SourceNode var0 = s2_PRF.get("PRF324");
								final SourceNode result = action.execute(var0);
								outbound856v4010CockpitRS_Rt.this.v_MessageId = extractString(result);
							}
						}
					}}}).run();
					createCompositeRule(13, "for source.Area2.sgHL.current.DTM", new Block() { public void body() {
						for (final SourceNode s2_cur_DTM : s1_cur_sgHL.getIterable("DTM")) {
					
					
						{
							boolean conditionResult;
							{
								com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized condition = new com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized();
								createRuleCondition(14, "new StringEqualsNormalized().execute(source.Area2.sgHL.current.DTM.current.DTM374, \"011\") => #[]", condition);
								final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur_DTM.get("DTM374"));
								final com.extol.ebi.ruleset.lang.core.String var1 = asString("011");
								final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
								
								conditionResult = result.asJavaBoolean().booleanValue();
							}
							if (conditionResult) {
								com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
								createSimpleRule(14, "new Move().execute(source.Area2.sgHL.current.DTM.current.DTM373) => #[this.v_ShippedDate]", action);
								final SourceNode var0 = s2_cur_DTM.get("DTM373");
								final SourceNode result = action.execute(var0);
								outbound856v4010CockpitRS_Rt.this.v_ShippedDate = extractString(result);
							}
						}
					}}}).run();
				}}}}).run();
				createCompositeRule(15, "for source.Area3.CTT", new Block() { public void body() {
					final SourceNode s0_Area3 = source.get("Area3");
					if (exists(s0_Area3)) {
					final SourceNode s1_CTT = s0_Area3.get("CTT");
					if (exists(s1_CTT)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(16, "new Move().execute(source.Area3.CTT.CTT354) => #[this.v_NumberOfLineItems]", action);
						final SourceNode var0 = s1_CTT.get("CTT354");
						final SourceNode result = action.execute(var0);
						outbound856v4010CockpitRS_Rt.this.v_NumberOfLineItems = extractString(result);
					}
				}}}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(17, "new Move().execute(this.v_totalLineItemCounter) => #[this.v_totalLineItemsString]", action);
					final SourceNode var0 = toValueNode(outbound856v4010CockpitRS_Rt.this.v_totalLineItemCounter);
					final SourceNode result = action.execute(var0);
					outbound856v4010CockpitRS_Rt.this.v_totalLineItemsString = extractString(result);
				}
			}}).run();
			createCompositeRule(18, "", new Block() { public void body() {
			
			
				{
					com.cleo.b2biaas.clarify.OutboundCreateMessageHeader action = new com.cleo.b2biaas.clarify.OutboundCreateMessageHeader();
					createSimpleRule(19, "new com.cleo.b2biaas.clarify.OutboundCreateMessageHeader().execute(this.glb.tpName, \"856\", this.v_ParentMessageId, this.v_MessageId, this.v_currentDTMillisString, \"true\", \"USD\", this.glb.logOfMsgId, this.glb.tradingPartnerId) => #[this.v_outboundMessage]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = outbound856v4010CockpitRS_Rt.this.glb.tpName;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("856");
					final com.extol.ebi.ruleset.lang.core.String var2 = outbound856v4010CockpitRS_Rt.this.v_ParentMessageId;
					final com.extol.ebi.ruleset.lang.core.String var3 = outbound856v4010CockpitRS_Rt.this.v_MessageId;
					final com.extol.ebi.ruleset.lang.core.String var4 = outbound856v4010CockpitRS_Rt.this.v_currentDTMillisString;
					final com.extol.ebi.ruleset.lang.core.String var5 = asString("true");
					final com.extol.ebi.ruleset.lang.core.String var6 = asString("USD");
					final com.extol.ebi.ruleset.lang.core.String var7 = outbound856v4010CockpitRS_Rt.this.glb.logOfMsgId;
					final com.extol.ebi.ruleset.lang.core.String var8 = outbound856v4010CockpitRS_Rt.this.glb.tradingPartnerId;
					final com.extol.ebi.ruleset.lang.core.Object result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8);
					outbound856v4010CockpitRS_Rt.this.v_outboundMessage = result;
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(20, "new IsNotNullOrWhiteSpaces().execute(source.Area2.sgHL.current.PRF.PRF324) => #[]", condition);
						final SourceNode var0 = source.get("Area2").get("sgHL").get("PRF").get("PRF324");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2();
						createSimpleRule(20, "new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2().execute(this.v_outboundMessage, \"Purchase Order Number\", \"\", source.Area2.sgHL.current.PRF.PRF324) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = outbound856v4010CockpitRS_Rt.this.v_outboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Purchase Order Number");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
						final com.extol.ebi.ruleset.lang.core.String var3 = extractString(source.get("Area2").get("sgHL").get("PRF").get("PRF324"));
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(21, "new IsNotNullOrWhiteSpaces().execute(this.v_ShippedDate) => #[]", condition);
						final SourceNode var0 = toValueNode(outbound856v4010CockpitRS_Rt.this.v_ShippedDate);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2();
						createSimpleRule(21, "new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2().execute(this.v_outboundMessage, \"Shipped Date\", \"{d}\", this.v_ShippedDate) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = outbound856v4010CockpitRS_Rt.this.v_outboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Shipped Date");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("{d}");
						final com.extol.ebi.ruleset.lang.core.String var3 = outbound856v4010CockpitRS_Rt.this.v_ShippedDate;
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(22, "new IsNotNullOrWhiteSpaces().execute(this.v_NumberOfLineItems) => #[]", condition);
						final SourceNode var0 = toValueNode(outbound856v4010CockpitRS_Rt.this.v_NumberOfLineItems);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2();
						createSimpleRule(22, "new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2().execute(this.v_outboundMessage, \"Number of Line Items\", \"\", this.v_NumberOfLineItems) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = outbound856v4010CockpitRS_Rt.this.v_outboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Number of Line Items");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
						final com.extol.ebi.ruleset.lang.core.String var3 = outbound856v4010CockpitRS_Rt.this.v_NumberOfLineItems;
						action.execute(var0, var1, var2, var3);
					}
				}
				createCompositeRule(23, "", new Block() { public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.string.Split action = new com.extol.ebi.reactor.lib.actions.string.Split();
						createSimpleRule(24, "new Split().execute(\",\", this.glb.ReprocessParms) => #[this.v_SplitReprocessParms]", action);
						final com.extol.ebi.ruleset.lang.core.String var0 = asString(",");
						final com.extol.ebi.ruleset.lang.core.String var1 = outbound856v4010CockpitRS_Rt.this.glb.ReprocessParms;
						final com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> result = action.execute(var0, var1);
						outbound856v4010CockpitRS_Rt.this.v_SplitReprocessParms = result;
					}
					createCompositeRule(25, "for this.v_SplitReprocessParms", new Block() { public void body() {
						if(outbound856v4010CockpitRS_Rt.this.v_SplitReprocessParms != null) {
						for (final com.extol.ebi.ruleset.lang.core.String cur_v_SplitReprocessParms : outbound856v4010CockpitRS_Rt.this.v_SplitReprocessParms) {
					
					
						createCompositeRule(26, "", new Block() { public void body() {
						
						
							{
								com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
								createSimpleRule(27, "new Add().execute(1, this.v_ListCount, null) => #[this.v_ListCount]", action);
								final com.extol.ebi.ruleset.lang.core.Number var0 = asNumber(1);
								final com.extol.ebi.ruleset.lang.core.Number var1 = outbound856v4010CockpitRS_Rt.this.v_ListCount;
								final com.extol.ebi.ruleset.lang.core.Number var2 = null;
								final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
								outbound856v4010CockpitRS_Rt.this.v_ListCount = result;
							}
							{
								com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
								createSimpleRule(28, "new Move().execute(this.v_ListCount) => #[this.v_ListCountString]", action);
								final SourceNode var0 = toValueNode(outbound856v4010CockpitRS_Rt.this.v_ListCount);
								final SourceNode result = action.execute(var0);
								outbound856v4010CockpitRS_Rt.this.v_ListCountString = extractString(result);
							}
							{
								com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
								createSimpleRule(29, "new Move().execute(\"RouteValue\") => #[this.v_ReprocessKey]", action);
								final SourceNode var0 = toValueNode(asString("RouteValue"));
								final SourceNode result = action.execute(var0);
								outbound856v4010CockpitRS_Rt.this.v_ReprocessKey = extractString(result);
							}
							{
								com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
								createSimpleRule(30, "new ConcatenateMany().execute(null, null, this.v_ReprocessKey, \"0\", this.v_ListCountString, null, null, null, null, null, null, null) => #[this.v_ReprocessKey]", action);
								final com.extol.ebi.ruleset.lang.core.String var0 = null;
								final com.extol.ebi.ruleset.lang.core.Boolean var1 = null;
								final SourceNode var2 = toValueNode(outbound856v4010CockpitRS_Rt.this.v_ReprocessKey);
								final SourceNode var3 = toValueNode(asString("0"));
								final SourceNode var4 = toValueNode(outbound856v4010CockpitRS_Rt.this.v_ListCountString);
								final SourceNode var5 = toNullValueNode();
								final SourceNode var6 = toNullValueNode();
								final SourceNode var7 = toNullValueNode();
								final SourceNode var8 = toNullValueNode();
								final SourceNode var9 = toNullValueNode();
								final SourceNode var10 = toNullValueNode();
								final SourceNode var11 = toNullValueNode();
								final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
								outbound856v4010CockpitRS_Rt.this.v_ReprocessKey = result;
							}
						}}).run();
						createCompositeRule(31, "", new Block() { public void body() {
						
						
							{
								com.extol.ebi.reactor.lib.actions.collection.ListGet action = new com.extol.ebi.reactor.lib.actions.collection.ListGet();
								createSimpleRule(32, "new ListGet().execute(this.v_SplitReprocessParms, this.v_ListCount) => #[this.v_RouteValue]", action);
								final com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> var0 = outbound856v4010CockpitRS_Rt.this.v_SplitReprocessParms;
								final com.extol.ebi.ruleset.lang.core.Number var1 = outbound856v4010CockpitRS_Rt.this.v_ListCount;
								final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
								outbound856v4010CockpitRS_Rt.this.v_RouteValue = result;
							}
						}}).run();
						{
							com.cleo.b2biaas.clarify.OutboundAddReprocessingString action = new com.cleo.b2biaas.clarify.OutboundAddReprocessingString();
							createSimpleRule(33, "new com.cleo.b2biaas.clarify.OutboundAddReprocessingString().execute(this.v_outboundMessage, this.v_ReprocessKey, this.v_RouteValue) => #[]", action);
							final com.extol.ebi.ruleset.lang.core.Object var0 = outbound856v4010CockpitRS_Rt.this.v_outboundMessage;
							final com.extol.ebi.ruleset.lang.core.String var1 = outbound856v4010CockpitRS_Rt.this.v_ReprocessKey;
							final com.extol.ebi.ruleset.lang.core.String var2 = outbound856v4010CockpitRS_Rt.this.v_RouteValue;
							action.execute(var0, var1, var2);
						}
					}}}}).run();
					{
						boolean conditionResult;
						{
							com.extol.ebi.reactor.lib.actions.conditions.IsNotNull condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNull();
							createRuleCondition(34, "new IsNotNull().execute(this.glb.originalLOM) => #[]", condition);
							final SourceNode var0 = toValueNode(outbound856v4010CockpitRS_Rt.this.glb.originalLOM);
							final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
							
							conditionResult = result.asJavaBoolean().booleanValue();
						}
						if (conditionResult) {
							com.cleo.b2biaas.clarify.OutboundAddReprocessingString action = new com.cleo.b2biaas.clarify.OutboundAddReprocessingString();
							createSimpleRule(34, "new com.cleo.b2biaas.clarify.OutboundAddReprocessingString().execute(this.v_outboundMessage, \"originalLOM\", this.glb.originalLOM) => #[]", action);
							final com.extol.ebi.ruleset.lang.core.Object var0 = outbound856v4010CockpitRS_Rt.this.v_outboundMessage;
							final com.extol.ebi.ruleset.lang.core.String var1 = asString("originalLOM");
							final com.extol.ebi.ruleset.lang.core.String var2 = outbound856v4010CockpitRS_Rt.this.glb.originalLOM;
							action.execute(var0, var1, var2);
						}
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(35, "new Move().execute(\"SplitCode\") => #[this.env.User_Reference_1]", action);
						final SourceNode var0 = toValueNode(asString("SplitCode"));
						final SourceNode result = action.execute(var0);
						outbound856v4010CockpitRS_Rt.this.env.User_Reference_1 = extractString(result);
					}
				}}).run();
				{
					com.cleo.b2biaas.clarify.OutboundCloseMessage action = new com.cleo.b2biaas.clarify.OutboundCloseMessage();
					createSimpleRule(36, "new com.cleo.b2biaas.clarify.OutboundCloseMessage().execute(this.v_outboundMessage) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = outbound856v4010CockpitRS_Rt.this.v_outboundMessage;
					action.execute(var0);
				}
			}}).run();
		}}).run();
	}

}
