package com.cleo.b2biaas.clarify;

import com.cleo.cloud.ICloudConfig;
import com.extol.ebi.factory.EBIFactoryManager;

public class CloudConfig {

	static ICloudConfig config = EBIFactoryManager.getFactory()
			.getCloudConfig();

	public static boolean isConfigured() {
		return config.isConfigured();
	}

	public static String getServerUrl() {
		return config.getServerUrl();
	}

	public static String getTenantId() {
		return config.getTenantId();
	}

	public static String getSecurityToken() {
		return config.getSecurityToken();
	}

}
