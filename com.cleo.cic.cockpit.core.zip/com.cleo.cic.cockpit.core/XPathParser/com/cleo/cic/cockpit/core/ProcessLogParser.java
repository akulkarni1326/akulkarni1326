package com.cleo.cic.cockpit.core;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.extol.base.util.uuid.IUUID;
import com.extol.ebi.factory.EBIFactoryManager;
import com.extol.ebi.factory.IEBIFactory;
import com.extol.storage.IStorageBrokerAdapter;
import com.extol.storage.IStorageID;
import com.extol.storage.exceptions.StorageException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ProcessLogParser {

	private IEBIFactory factory = EBIFactoryManager.getFactory();
	private IStorageBrokerAdapter storageBroker = factory.createStorageBroker();
	Integer stepNumber;
	String stepName;
	String processNumber;
	String errorDescription;
	String tempProcessNumber ;

	public IStorageID getErrorLogs(String processLog) {
		try {
			if (!processLog.substring(processLog.length() - 13).equalsIgnoreCase("</ProcessLog>")) {
				processLog += "</Step></ProcessLog>";
			}
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder;
			dBuilder = dbFactory.newDocumentBuilder();

			Document doc;
			doc = dBuilder.parse(new ByteArrayInputStream(processLog.getBytes(StandardCharsets.UTF_8)));

			doc.getDocumentElement().normalize();

			XPath xPath = XPathFactory.newInstance().newXPath();

			String expression = "ProcessLog";
			NodeList parentNodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);

			for (int i = 0; i < parentNodeList.getLength(); i++) {
				Node nNode = parentNodeList.item(i);
				Element eElement = (Element) nNode;
				tempProcessNumber = eElement.getAttributeNode("userProcessNumber").getTextContent();
				NodeList stepList = eElement.getElementsByTagName("Step");
				processLastFailureStep(stepList);
			}

		} catch (XPathExpressionException | SAXException | IOException | ParserConfigurationException e) {
			factory.log("Unable to parse processLog file.");
		}
		return BuildJsonError();
	}

	public IStorageID BuildJsonError() {
		IUUID storageID = null;
		Map<String, Object> errorLogMap = new HashMap<>();
		try {
			if(processNumber!=null) errorLogMap.put("processNumber", processNumber);
			if(stepNumber != null)  errorLogMap.put("stepNumber", stepNumber);
			if(stepName != null) errorLogMap.put("stepName", stepName);
			if(errorDescription != null) errorLogMap.put("error_desciption", errorDescription.replaceAll("&quot;", "\'").replaceAll("&apos;", "\'").replaceAll("&gt;", ">").replaceAll("&lt;", "<"));
			storageID = storageBroker.createPersistentStorageLocation();
			storageBroker.writeBytes(storageID, errorLogMap.isEmpty()? new String().getBytes() :new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsBytes(errorLogMap));

		} catch (IOException | StorageException e) {
			factory.log("Unable to return error logs, Please refer to Clarify Studio Auditor for logs.");
		}
		return factory.createStorageID(storageID);
	}

	public void processLastFailureStep(NodeList stepList) {
		for (int i = 0; i < stepList.getLength(); i++) {
			Node step = stepList.item(i);
			NodeList stepNodes = step.getChildNodes();
			StringBuilder errorLog = new StringBuilder();
			for (int j = 0; j < stepNodes.getLength(); j++) {
				Node st = stepNodes.item(j);

				if (st.getNodeName().equalsIgnoreCase("Log4j")) {
					errorLog.append(st.getTextContent());
				}
				if (st.getNodeName().equalsIgnoreCase("Task")) {
					NodeList taskInsideStep = st.getChildNodes();
					for (int m = 0; m < taskInsideStep.getLength(); m++) {
						if (taskInsideStep.item(m).getNodeName().equalsIgnoreCase("Log4j")) {
							errorLog.append(taskInsideStep.item(m).getTextContent());
						}
					}
				}
				if (st.getNodeName().equalsIgnoreCase("Exit")) {
					if (st.getAttributes().getNamedItem("status").getTextContent().equalsIgnoreCase("FAILED")) {
						processNumber= tempProcessNumber;
						stepNumber = ++i;
						stepName = step.getAttributes().getNamedItem("name").getTextContent();
						errorDescription = truncateStackTrace(errorLog.toString());
					}
				}
			}
		}
	}

	public String truncateStackTrace(String trace) {
		StringBuilder stackTrace = new StringBuilder();
		trace = trace.replaceAll("\t", "");
		for (String str : trace.split("[\\r\\n]+")) {
			if (!str.startsWith("at")) {
				stackTrace.append(str);
			}
		}
		return stackTrace.toString();
	}
}
