package com.cleo.b2bcloud.core.actions;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.codetable.lib.BehaviorValueSpec;
import com.extol.ebi.codetable.lib.SingleInputCodeTable;
import com.extol.ebi.lang.CodeTable;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.reactor.lib.AbstractAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class ForcedErrorReasonCT implements CodeTable {
  public static class BpsTask implements BpsCallable {
    @OverrideOpName(value = "bps1://CodeTable")
    public boolean execute(final com.extol.ebi.bps.lang.String Key1, final com.extol.ebi.bps.lang.String Value) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
  }
  
  public static class RulesetAction extends AbstractAction implements RulesetCallable {
    public com.extol.ebi.ruleset.lang.core.String execute(final com.extol.ebi.ruleset.lang.core.String Key1) {
      String result = INSTANCE.get(asJavaString(Key1));
      return result == null ? null : asString(result);
    }
  }
  
  private static final SingleInputCodeTable INSTANCE = init();
  
  private static SingleInputCodeTable init() {
    SingleInputCodeTable ct = new SingleInputCodeTable(true, BehaviorValueSpec.ReturnKey1);
    ct.addEntry("SERVICE", "***There was a Service charge within this Invoice. ***");
    ct.addEntry("NOUPC", "***UPC Not Found***");
    return ct;
  }
}
