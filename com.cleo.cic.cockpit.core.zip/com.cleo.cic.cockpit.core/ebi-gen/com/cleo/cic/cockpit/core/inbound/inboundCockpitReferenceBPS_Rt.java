/**
* @generated
*/
package com.cleo.cic.cockpit.core.inbound;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.CompareValues;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.string.ReplaceString;
import com.extol.ebi.bps.lib.tasks.transformation.ExecuteTransformation;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps.lib.tasks.transformation.SetContextPointValue;
import com.extol.ebi.bps.lib.types.CompareType;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class inboundCockpitReferenceBPS_Rt extends AbstractCatalyst {
	
	public inboundCockpitReferenceBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_sourceData, @ParameterType(StorageNode.class) Variable<StorageNode> p_contextSource, @ParameterType(Ruleset.class) Variable<Ruleset> p_transformationRuleset, @ParameterType(String.class) Variable<String> p_documentType, @ParameterType(String.class) Variable<String> p_partnerName, @ParameterType(StorageNode.class) Variable<StorageNode> p_contextTarget) {
		final Variable<StorageNode> v_targetContext = variable(StorageNode.class, null);
		final Variable<String> v_v_tpId = variable(String.class, null);
		final Variable<String> v_cNULL = variable(String.class, null);
		final Variable<String> v_v_OwnerId = variable(String.class, null);
		final Variable<String> v_UserRef1 = variable(String.class, null);
		final Variable<String> v_UserRef2 = variable(String.class, null);
		final Variable<String> v_UserRef3 = variable(String.class, null);
		final Variable<String> v_UserRef4 = variable(String.class, null);
		final Variable<String> v_UserRef5 = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "env.var.Sender_Id"), new ContextPointVar(v_v_tpId));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "env.var.Receiver_Id"), new ContextPointVar(v_v_OwnerId));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_contextTarget, variable(String.class, "env.var.User_Reference_1"), new ContextPointVar(v_UserRef1));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_contextTarget, variable(String.class, "env.var.User_Reference_2"), new ContextPointVar(v_UserRef2));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_contextTarget, variable(String.class, "env.var.User_Reference_3"), new ContextPointVar(v_UserRef3));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_contextTarget, variable(String.class, "env.var.User_Reference_4"), new ContextPointVar(v_UserRef4));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_contextTarget, variable(String.class, "env.var.User_Reference_5"), new ContextPointVar(v_UserRef5));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_v_OwnerId, v_v_OwnerId, variable(String.class, " "), v_cNULL);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_v_tpId, v_v_tpId, variable(String.class, " "), v_cNULL);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.tradingPartnerId"), new ContextPointVar(v_v_tpId));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.tpName"), new ContextPointVar(p_partnerName));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.docType"), new ContextPointVar(p_documentType));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.ownerId"), new ContextPointVar(v_v_OwnerId));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_UserRef1, v_cNULL, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "UserRef1", "next");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.User_Reference_1"), new ContextPointVar(v_UserRef1));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("UserRef1", "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_UserRef2, v_cNULL, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "UserRef2", "next");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.User_Reference_2"), new ContextPointVar(v_UserRef2));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("UserRef2", "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_UserRef3, v_cNULL, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "UserRef3", "next");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.User_Reference_3"), new ContextPointVar(v_UserRef3));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("UserRef3", "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_UserRef4, v_cNULL, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "UserRef4", "next");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.User_Reference_4"), new ContextPointVar(v_UserRef4));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("UserRef4", "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_UserRef5, v_cNULL, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "UserRef5", "next");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_contextSource, variable(String.class, "glb.var.User_Reference_5"), new ContextPointVar(v_UserRef5));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("UserRef5", "Execute Transformation - Single Output", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Execute Transformation - Single Output");
					ExecuteTransformation task = new ExecuteTransformation();
					setupTask(task);
					return task.execute(p_sourceData, null, literalTypeFromString(TransformationSettings.class, "com.cleo.cic.cockpit.core.defaultTS"), p_transformationRuleset, null, p_contextSource, v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
