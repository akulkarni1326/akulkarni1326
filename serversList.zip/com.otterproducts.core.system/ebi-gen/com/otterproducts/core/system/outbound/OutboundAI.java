package com.otterproducts.core.system.outbound;

import com.extol.ebi.lang.ApplicationInterface;
import com.extol.ebi.lang.annotations.MatchAttribute;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.reactor.server.actions.AbstractApplicationInterfaceAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;
import java.util.List;

@SuppressWarnings("all")
public interface OutboundAI extends ApplicationInterface {
  @MatchAttribute(index = 1, orderIndex = 1)
  public abstract com.extol.ebi.ruleset.lang.core.String Doctype();
  
  @MatchAttribute(index = 2, orderIndex = 2)
  public abstract com.extol.ebi.ruleset.lang.core.String PartnerName();
  
  public class GetRoutes extends AbstractApplicationInterfaceAction implements RulesetCallable {
    protected List<String> attributeNames() {
      return java.util.Arrays.asList("Doctype", "PartnerName");
    }
    
    public com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> execute(final com.extol.ebi.ruleset.lang.core.String Doctype, final com.extol.ebi.ruleset.lang.core.String PartnerName) {
      return findApplicationRoutes(asString("com.otterproducts.core.system.outbound.OutboundAI"), Doctype, PartnerName);
    }
  }
  
  public class ExecuteContentRouter extends AbstractApplicationInterfaceAction implements RulesetCallable {
    protected List<String> attributeNames() {
      return java.util.Arrays.asList("Doctype", "PartnerName");
    }
    
    public com.extol.ebi.ruleset.lang.core.Boolean execute(final com.extol.ebi.ruleset.lang.core.String Doctype, final com.extol.ebi.ruleset.lang.core.String PartnerName, final StorageNode sourceContext, final StorageNode sourceInputDataFragment) {
      return findRoutesAndLaunchThem(sourceContext, sourceInputDataFragment, asString("com.otterproducts.core.system.outbound.OutboundAI"), Doctype, PartnerName);
    }
  }
}
