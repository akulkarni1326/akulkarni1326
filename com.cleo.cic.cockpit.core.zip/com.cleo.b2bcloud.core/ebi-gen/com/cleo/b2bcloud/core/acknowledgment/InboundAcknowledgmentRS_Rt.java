/**
* @generated
*/
package com.cleo.b2bcloud.core.acknowledgment;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.flatfile.lib.connectors.*;
import com.extol.ebi.reactor.flatfile.lib.schema.*;

@SuppressWarnings("all")
public class InboundAcknowledgmentRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,RtFlatFileSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String vGroupCntlNo;
	private com.extol.ebi.ruleset.lang.core.String vRefference;
	private com.extol.ebi.ruleset.lang.core.String vDocType;
	private com.extol.ebi.ruleset.lang.core.String vTPName;
	private com.extol.ebi.ruleset.lang.core.String vTPID;
	private com.extol.ebi.ruleset.lang.core.String vSegment;
	private com.extol.ebi.ruleset.lang.core.String vError;
	private com.extol.ebi.ruleset.lang.core.String message = asString(" ");
	private com.extol.ebi.ruleset.lang.core.String vPosition;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgment997_Rt();
	}
	
	public SchemaProvider<RtFlatFileSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "for source.Area1.AK1", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			final SourceNode s1_AK1 = s0_Area1.get("AK1");
			if (exists(s1_AK1)) {
		
		
			createCompositeRule(2, "for source.Area1.sgAK2", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(2, "new StringEquals().execute(source.Area1.sgAK2.current.AK5.AK5717, \"R\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s0_Area1.get("sgAK2").get("AK5").get("AK5717"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("R");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
				for (final SourceNode s1_cur_sgAK2 : s0_Area1.getIterable("sgAK2")) {
			
			
				createCompositeRule(3, "", new Block() { public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(4, "new Move().execute(source.Area1.AK1.AK128) => #[this.vGroupCntlNo]", action);
						final SourceNode var0 = s1_AK1.get("AK128");
						final SourceNode result = action.execute(var0);
						InboundAcknowledgmentRS_Rt.this.vGroupCntlNo = extractString(result);
					}
					{
						com.cleo.b2bcloud.core.acknowledgment.DocCT.RulesetAction action = new com.cleo.b2bcloud.core.acknowledgment.DocCT.RulesetAction();
						createSimpleRule(5, "new com.cleo.b2bcloud.core.acknowledgment.DocCT$RulesetAction().execute(source.Area1.sgAK2.current.AK2.AK2143) => #[this.vDocType]", action);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_sgAK2.get("AK2").get("AK2143"));
						final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
						InboundAcknowledgmentRS_Rt.this.vDocType = result;
					}
					{
						com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2();
						createSimpleRule(6, "new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL$RulesetActionV2().execute(this.env.User_Reference_2, this.vGroupCntlNo, source.Area1.sgAK2.current.AK2.AK2329) => ##[#[this.vRefference, this.env.User_Reference_3], #[this.vTPID], #[this.env.Message_Id]]", action);
						final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgmentRS_Rt.this.env.User_Reference_2;
						final com.extol.ebi.ruleset.lang.core.String var1 = InboundAcknowledgmentRS_Rt.this.vGroupCntlNo;
						final com.extol.ebi.ruleset.lang.core.String var2 = extractString(s1_cur_sgAK2.get("AK2").get("AK2329"));
						final com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2.ResultTuple result = action.execute(var0, var1, var2);
						InboundAcknowledgmentRS_Rt.this.vRefference = result.RefferenceNo;
						InboundAcknowledgmentRS_Rt.this.env.User_Reference_3 = result.RefferenceNo;
						InboundAcknowledgmentRS_Rt.this.vTPID = result.TRADING_PARTNER_ID;
						InboundAcknowledgmentRS_Rt.this.env.Message_Id = result.UUID;
					}
					{
						com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2();
						createSimpleRule(7, "new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL$RulesetActionV2().execute(this.vTPID) => #[this.vTPName, this.env.User_Reference_4]", action);
						final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgmentRS_Rt.this.vTPID;
						final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
						InboundAcknowledgmentRS_Rt.this.vTPName = result;
						InboundAcknowledgmentRS_Rt.this.env.User_Reference_4 = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(8, "new Move().execute(source.Area1.sgAK2.current.AK2.AK2143) => #[this.env.Process_Id]", action);
						final SourceNode var0 = s1_cur_sgAK2.get("AK2").get("AK2143");
						final SourceNode result = action.execute(var0);
						InboundAcknowledgmentRS_Rt.this.env.Process_Id = extractString(result);
					}
				}}).run();
				createCompositeRule(9, "for source.Area1.sgAK2.current.sgAK3", new Block() { public void body() {
					for (final SourceNode s2_cur_sgAK3 : s1_cur_sgAK2.getIterable("sgAK3")) {
				
				
					createCompositeRule(10, "for source.Area1.sgAK2.current.sgAK3.current.AK4", new Block() { public void body() {
						for (final SourceNode s3_cur_AK4 : s2_cur_sgAK3.getIterable("AK4")) {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(11, "new Move().execute(source.Area1.sgAK2.current.sgAK3.current.AK4.current.AK4C030.C03001) => #[this.vPosition]", action);
							final SourceNode var0 = s3_cur_AK4.get("AK4C030").get("C03001");
							final SourceNode result = action.execute(var0);
							InboundAcknowledgmentRS_Rt.this.vPosition = extractString(result);
						}
						{
							com.cleo.b2bcloud.core.acknowledgment.ErrorCT.RulesetAction action = new com.cleo.b2bcloud.core.acknowledgment.ErrorCT.RulesetAction();
							createSimpleRule(12, "new com.cleo.b2bcloud.core.acknowledgment.ErrorCT$RulesetAction().execute(source.Area1.sgAK2.current.sgAK3.current.AK4.current.AK4723) => #[this.vSegment]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_AK4.get("AK4723"));
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
							InboundAcknowledgmentRS_Rt.this.vSegment = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(13, "new ConcatenateMany().execute(\" \", true, \"The\", this.vDocType, \"with Group Control number\", this.vGroupCntlNo, \"and \", this.vDocType, \"Number -\", this.vRefference, \"was rejected by Trading Partner\", this.vTPName) => #[this.message]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
							final SourceNode var2 = toValueNode(asString("The"));
							final SourceNode var3 = toValueNode(InboundAcknowledgmentRS_Rt.this.vDocType);
							final SourceNode var4 = toValueNode(asString("with Group Control number"));
							final SourceNode var5 = toValueNode(InboundAcknowledgmentRS_Rt.this.vGroupCntlNo);
							final SourceNode var6 = toValueNode(asString("and "));
							final SourceNode var7 = toValueNode(InboundAcknowledgmentRS_Rt.this.vDocType);
							final SourceNode var8 = toValueNode(asString("Number -"));
							final SourceNode var9 = toValueNode(InboundAcknowledgmentRS_Rt.this.vRefference);
							final SourceNode var10 = toValueNode(asString("was rejected by Trading Partner"));
							final SourceNode var11 = toValueNode(InboundAcknowledgmentRS_Rt.this.vTPName);
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							InboundAcknowledgmentRS_Rt.this.message = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(14, "new ConcatenateMany().execute(\" \", true, this.message, \"due to error -\", this.vError, \"in segment\", source.Area1.sgAK2.current.sgAK3.current.AK3.AK3721, \"at position\", this.vPosition, \"(\", this.vSegment, \"). Please correct the data and resend.\") => #[this.message]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
							final SourceNode var2 = toValueNode(InboundAcknowledgmentRS_Rt.this.message);
							final SourceNode var3 = toValueNode(asString("due to error -"));
							final SourceNode var4 = toValueNode(InboundAcknowledgmentRS_Rt.this.vError);
							final SourceNode var5 = toValueNode(asString("in segment"));
							final SourceNode var6 = s2_cur_sgAK3.get("AK3").get("AK3721");
							final SourceNode var7 = toValueNode(asString("at position"));
							final SourceNode var8 = toValueNode(InboundAcknowledgmentRS_Rt.this.vPosition);
							final SourceNode var9 = toValueNode(asString("("));
							final SourceNode var10 = toValueNode(InboundAcknowledgmentRS_Rt.this.vSegment);
							final SourceNode var11 = toValueNode(asString("). Please correct the data and resend."));
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							InboundAcknowledgmentRS_Rt.this.message = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(15, "new Move().execute(1) => #[this.env.User_Reference_5]", action);
							final SourceNode var0 = toValueNode(asNumber(1));
							final SourceNode result = action.execute(var0);
							InboundAcknowledgmentRS_Rt.this.env.User_Reference_5 = extractString(result);
						}
					}}}).run();
				}}}).run();
				createCompositeRule(16, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(16, "new StringEquals().execute(this.message, \" \") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgmentRS_Rt.this.message;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString(" ");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
						createSimpleRule(17, "new ConcatenateMany().execute(\" \", true, \"We have not Received AK3/AK4 Segment in 997 for rejected\", this.vDocType, \"Number\", this.vRefference, \"with Group Control Number\", this.vGroupCntlNo, \". Please let us know\", \"the reason\", \"for\", \"rejection.\") => #[this.message]", action);
						final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
						final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
						final SourceNode var2 = toValueNode(asString("We have not Received AK3/AK4 Segment in 997 for rejected"));
						final SourceNode var3 = toValueNode(InboundAcknowledgmentRS_Rt.this.vDocType);
						final SourceNode var4 = toValueNode(asString("Number"));
						final SourceNode var5 = toValueNode(InboundAcknowledgmentRS_Rt.this.vRefference);
						final SourceNode var6 = toValueNode(asString("with Group Control Number"));
						final SourceNode var7 = toValueNode(InboundAcknowledgmentRS_Rt.this.vGroupCntlNo);
						final SourceNode var8 = toValueNode(asString(". Please let us know"));
						final SourceNode var9 = toValueNode(asString("the reason"));
						final SourceNode var10 = toValueNode(asString("for"));
						final SourceNode var11 = toValueNode(asString("rejection."));
						final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
						InboundAcknowledgmentRS_Rt.this.message = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(18, "new Move().execute(0) => #[this.env.User_Reference_5]", action);
						final SourceNode var0 = toValueNode(asNumber(0));
						final SourceNode result = action.execute(var0);
						InboundAcknowledgmentRS_Rt.this.env.User_Reference_5 = extractString(result);
					}
				}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(19, "new Move().execute(this.message) => #[this.env.User_Reference_1]", action);
					final SourceNode var0 = toValueNode(InboundAcknowledgmentRS_Rt.this.message);
					final SourceNode result = action.execute(var0);
					InboundAcknowledgmentRS_Rt.this.env.User_Reference_1 = extractString(result);
				}
			}}}).run();
		}}}}).run();
		createCompositeRule(20, "", new ConditionedBlock() {
		public boolean condition() {
			com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces();
			createRuleCondition(20, "new IsNullOrWhiteSpaces().execute(source.Area1.sgAK2.current.AK2.AK2143) => #[]", condition);
			final SourceNode var0 = source.get("Area1").get("sgAK2").get("AK2").get("AK2143");
			final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
			
			return result.asJavaBoolean().booleanValue();
		}
		public void body() {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(21, "new Move().execute(source.Area1.AK1.AK128) => #[this.vGroupCntlNo]", action);
				final SourceNode var0 = source.get("Area1").get("AK1").get("AK128");
				final SourceNode result = action.execute(var0);
				InboundAcknowledgmentRS_Rt.this.vGroupCntlNo = extractString(result);
			}
			{
				com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2();
				createSimpleRule(22, "new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL$RulesetActionV2().execute(this.env.User_Reference_2, this.vGroupCntlNo, \"0001\") => ##[#[this.vRefference, this.env.User_Reference_3], #[this.vTPID], #[this.env.Message_Id]]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgmentRS_Rt.this.env.User_Reference_2;
				final com.extol.ebi.ruleset.lang.core.String var1 = InboundAcknowledgmentRS_Rt.this.vGroupCntlNo;
				final com.extol.ebi.ruleset.lang.core.String var2 = asString("0001");
				final com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2.ResultTuple result = action.execute(var0, var1, var2);
				InboundAcknowledgmentRS_Rt.this.vRefference = result.RefferenceNo;
				InboundAcknowledgmentRS_Rt.this.env.User_Reference_3 = result.RefferenceNo;
				InboundAcknowledgmentRS_Rt.this.vTPID = result.TRADING_PARTNER_ID;
				InboundAcknowledgmentRS_Rt.this.env.Message_Id = result.UUID;
			}
			{
				com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2();
				createSimpleRule(23, "new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL$RulesetActionV2().execute(this.vTPID) => #[this.vTPName, this.env.User_Reference_4]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgmentRS_Rt.this.vTPID;
				final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
				InboundAcknowledgmentRS_Rt.this.vTPName = result;
				InboundAcknowledgmentRS_Rt.this.env.User_Reference_4 = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
				createSimpleRule(24, "new ConcatenateMany().execute(\" \", true, \"We have not Received AK2/AK3/AK4 Segment in 997 for reject, Since AK2 is not present so we can not pinpoint the exact transaction which was rejected.\", this.vDocType, \"Number\", this.vRefference, \"with Group Control Number\", this.vGroupCntlNo, \". Please let us know\", \"the reason\", \"for\", \"rejection.\") => #[this.message]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
				final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
				final SourceNode var2 = toValueNode(asString("We have not Received AK2/AK3/AK4 Segment in 997 for reject, Since AK2 is not present so we can not pinpoint the exact transaction which was rejected."));
				final SourceNode var3 = toValueNode(InboundAcknowledgmentRS_Rt.this.vDocType);
				final SourceNode var4 = toValueNode(asString("Number"));
				final SourceNode var5 = toValueNode(InboundAcknowledgmentRS_Rt.this.vRefference);
				final SourceNode var6 = toValueNode(asString("with Group Control Number"));
				final SourceNode var7 = toValueNode(InboundAcknowledgmentRS_Rt.this.vGroupCntlNo);
				final SourceNode var8 = toValueNode(asString(". Please let us know"));
				final SourceNode var9 = toValueNode(asString("the reason"));
				final SourceNode var10 = toValueNode(asString("for"));
				final SourceNode var11 = toValueNode(asString("rejection."));
				final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
				InboundAcknowledgmentRS_Rt.this.message = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(25, "new Move().execute(0) => #[this.env.User_Reference_5]", action);
				final SourceNode var0 = toValueNode(asNumber(0));
				final SourceNode result = action.execute(var0);
				InboundAcknowledgmentRS_Rt.this.env.User_Reference_5 = extractString(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(26, "new Move().execute(this.message) => #[this.env.User_Reference_1]", action);
				final SourceNode var0 = toValueNode(InboundAcknowledgmentRS_Rt.this.message);
				final SourceNode result = action.execute(var0);
				InboundAcknowledgmentRS_Rt.this.env.User_Reference_1 = extractString(result);
			}
		}}).run();
	}

}
