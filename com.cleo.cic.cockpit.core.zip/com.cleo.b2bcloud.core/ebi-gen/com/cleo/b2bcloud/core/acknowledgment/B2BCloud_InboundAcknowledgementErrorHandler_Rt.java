/**
* @generated
*/
package com.cleo.b2bcloud.core.acknowledgment;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.exitpoint.ExtractEdiAcknowledgementErrorData;
import com.extol.ebi.bps.lib.tasks.exitpoint.ExtractEdiInterchangeData;
import com.extol.ebi.bps.lib.tasks.misc.CompareValues;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStorageNodeToString;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStringToStorageNode;
import com.extol.ebi.bps.lib.tasks.misc.GetStorageNodeFromUuid;
import com.extol.ebi.bps.lib.tasks.misc.SendEmail;
import com.extol.ebi.bps.lib.tasks.string.AppendString;
import com.extol.ebi.bps.lib.tasks.string.ReplaceString;
import com.extol.ebi.bps.lib.tasks.string.ResolveGlobalVariables;
import com.extol.ebi.bps.lib.tasks.transformation.CreateContextPoint;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps.lib.tasks.transformation.SetContextPointValue;
import com.extol.ebi.bps.lib.types.CompareType;
import com.extol.ebi.bps.lib.types.EdiDataMap;
import com.extol.ebi.bps.lib.types.unions.Attachment;
import com.extol.ebi.bps.lib.types.unions.Message;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class B2BCloud_InboundAcknowledgementErrorHandler_Rt extends AbstractCatalyst {
	
	public B2BCloud_InboundAcknowledgementErrorHandler_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_storageId, @ParameterType(EdiDataMap.class) Variable<EdiDataMap> p_interchangeProperties, @ParameterType(EdiDataMap.class) Variable<EdiDataMap> p_acknowledgementErrorProperties) {
		final Variable<String> v_intCtlNbr = variable(String.class, null);
		final Variable<String> v_message = variable(String.class, null);
		final Variable<String> v_origGrpNo = variable(String.class, null);
		final Variable<String> v_syntaxError = variable(String.class, null);
		final Variable<String> v_actCode = variable(String.class, null);
		final Variable<String> v_subject = variable(String.class, "Inbound Acknowledgement Error Event");
		final Variable<String> v_label1 = variable(String.class, "\n\nFA Interchange Control#: ");
		final Variable<String> v_label2 = variable(String.class, "\n Original Group Control#:  ");
		final Variable<String> v_label4 = variable(String.class, "");
		final Variable<String> v_label3 = variable(String.class, "\nAck Code:  ");
		final Variable<String> v_label5 = variable(String.class, "\nDocument Type: ");
		final Variable<String> v_v_Document = variable(String.class, null);
		final Variable<StorageNode> v_tgtContext = variable(StorageNode.class, null);
		final Variable<String> v_body = variable(String.class, null);
		final Variable<String> v_storagenodestring = variable(String.class, null);
		final Variable<String> v_vNull = variable(String.class, null);
		final Variable<StorageNode> v_srcContext = variable(StorageNode.class, null);
		final Variable<String> v_senderID = variable(String.class, null);
		final Variable<StorageNode> v_inputfragment = variable(StorageNode.class, null);
		final Variable<String> v_v_TPName = variable(String.class, null);
		final Variable<String> v_vFlag = variable(String.class, null);
		final Variable<String> v_vFlagCompare = variable(String.class, "1");
		final Variable<String> v_v_Filename = variable(String.class, null);
		final Variable<StorageNode> v_v_originalfile = variable(StorageNode.class, null);
		final Variable<String> v_v_UUID = variable(String.class, "1234567890987654");
		final Variable<String> v_segmentDelimitor = variable(String.class, null);
		final Variable<String> v_elementDelimitpr = variable(String.class, null);
		final Variable<StorageNode> v_newVariable = variable(StorageNode.class, null);
		final Variable<String> v_newVariable2 = variable(String.class, "*");
		final Variable<String> v_vBlank = variable(String.class, "\n");
		final Variable<String> v_partnerEmailId = variable(String.class, null);
		final Variable<String> v_sendEmailToCustomer = variable(String.class, null);
		final Variable<String> v_sendEmailFrom = variable(String.class, null);
		final Variable<String> v_eBICustomerEmail = variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.CustomerAdminEmail>");
		final Variable<String> v_eBIHostEmail = variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.B2BCloudHostEmail>");

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Extract EDI Interchange Data", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Extract EDI Interchange Data");
					ExtractEdiInterchangeData task = new ExtractEdiInterchangeData();
					setupTask(task);
					return task.execute(p_interchangeProperties, v_intCtlNbr, variable(String.class, null), variable(String.class, null), v_senderID, variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), v_segmentDelimitor, v_elementDelimitpr, variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Extract EDI Acknowledgement Error Data", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Extract EDI Acknowledgement Error Data");
					ExtractEdiAcknowledgementErrorData task = new ExtractEdiAcknowledgementErrorData();
					setupTask(task);
					return task.execute(p_acknowledgementErrorProperties, variable(String.class, null), v_origGrpNo, variable(String.class, null), v_actCode, v_syntaxError, variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Convert Storage Node to String", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert Storage Node to String");
					ConvertStorageNodeToString task = new ConvertStorageNodeToString();
					setupTask(task);
					return task.execute(p_storageId, v_storagenodestring);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_segmentDelimitor, v_vBlank, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "jump", "next");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_storagenodestring, v_storagenodestring, v_segmentDelimitor, variable(String.class, ""));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("blank", "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_elementDelimitpr, v_newVariable2, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "jump", "next");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_storagenodestring, v_storagenodestring, v_elementDelimitpr, v_newVariable2);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("jump", "Convert String to Storage Node", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert String to Storage Node");
					ConvertStringToStorageNode task = new ConvertStringToStorageNode();
					setupTask(task);
					return task.execute(v_storagenodestring, v_inputfragment);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Create", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Create");
					CreateContextPoint task = new CreateContextPoint();
					setupTask(task);
					return task.execute(v_srcContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(v_srcContext, variable(String.class, "env.var.User_Reference_2"), new ContextPointVar(v_senderID));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgment997RS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgment997RS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgment997RS", "bps1://Ruleset").execute(v_inputfragment, v_newVariable, literalTypeFromString(TransformationSettings.class, "com.cleo.b2bcloud.core.acknowledgment.EDI997SourceTS"), null, v_srcContext, v_tgtContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_tgtContext, variable(String.class, "env.var.User_Reference_1"), new ContextPointVar(v_body));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_tgtContext, variable(String.class, "env.var.User_Reference_4"), new ContextPointVar(v_v_TPName));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_tgtContext, variable(String.class, "env.var.User_Reference_5"), new ContextPointVar(v_vFlag));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_tgtContext, variable(String.class, "env.var.Process_Id"), new ContextPointVar(v_v_Document));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_tgtContext, variable(String.class, "env.var.Acknowledgement_Id"), new ContextPointVar(v_v_UUID));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_v_UUID, v_vNull, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "messagebodybuild", "next");
		
		builder.addStep(null, "Get Storage Node for String", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Get Storage Node for String");
					GetStorageNodeFromUuid task = new GetStorageNodeFromUuid();
					setupTask(task);
					return task.execute(v_v_originalfile, v_v_UUID);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("messagebodybuild", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, variable(String.class, "Hello Team,\n\n"), v_body);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, variable(String.class, "\n\nThank You."));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_label1);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_intCtlNbr);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_label2);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_origGrpNo);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, variable(String.class, "\nTrading Partner: "));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_v_TPName);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_label5);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_v_Document);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_label3);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_actCode);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_label4);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, variable(String.class, "\n\n"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, variable(String.class, "ACK03-01 Segment ID code\nACK03-02 Segment Position in Transaction Set\nACK03-02 Segment ID code\nACK03-04 Segment Syntax Error Code\n       Allowed values\n              \"1\", \"Unrecognized segment ID\"\n              \"2\", \"Unexpected segment\"\n              \"3\", \"Mandatory segment missing\"\n              \"4\", \"Loop Occurs Over Maximum Times\"\n              \"5\", \"Segment Exceeds Maximum Use\"\n              \"6\", \"Segment Not in Defined Transaction Set\"\n              \"7\", \"Segment Not in Proper Sequence\"\n              \"8\", \"Segment Has Data Element Errors\"\n"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, variable(String.class, "\n\n"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_message, v_message, v_storagenodestring);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("filenameBuild", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_v_Filename, v_v_TPName, variable(String.class, "_"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_v_Filename, v_v_Filename, v_v_Document);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_v_Filename, v_v_Filename, variable(String.class, "_"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_v_Filename, v_v_Filename, v_intCtlNbr);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_v_Filename, v_v_Filename, variable(String.class, ".edi"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("subjectbuild", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subject, variable(String.class, "-"), v_subject);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subject, v_v_Document, v_subject);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subject, variable(String.class, "-"), v_subject);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subject, v_v_TPName, v_subject);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailToCustomer, v_eBICustomerEmail);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailFrom, v_eBIHostEmail);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_vFlag, v_vFlagCompare, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "next", "TP");
		
		builder.addStep("CSteam", "Send Email", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Send Email");
					SendEmail task = new SendEmail();
					setupTask(task);
					return task.execute(v_sendEmailToCustomer, v_sendEmailFrom, null, variable(String.class, null), v_subject, new Message(v_message), new Attachment(v_v_originalfile), v_v_Filename);
				} finally { _endTask();}
			}
		}, "end", "end");
		
		builder.addStep("TP", "com.cleo.b2bcloud.core.acknowledgment.GetPartnerContactsSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.acknowledgment.GetPartnerContactsSQL$BpsTask");
					com.cleo.b2bcloud.core.acknowledgment.GetPartnerContactsSQL.BpsTask task = new com.cleo.b2bcloud.core.acknowledgment.GetPartnerContactsSQL.BpsTask();
					setupTask(task);
					return task.execute_v2(v_v_TPName, v_senderID, v_partnerEmailId);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_partnerEmailId, v_vBlank, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "CSteam", "next");
		
		builder.addStep(null, "Send Email", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Send Email");
					SendEmail task = new SendEmail();
					setupTask(task);
					return task.execute(v_senderID, v_sendEmailFrom, v_sendEmailToCustomer, null, v_subject, new Message(v_message), new Attachment(v_v_originalfile), v_v_Filename);
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
