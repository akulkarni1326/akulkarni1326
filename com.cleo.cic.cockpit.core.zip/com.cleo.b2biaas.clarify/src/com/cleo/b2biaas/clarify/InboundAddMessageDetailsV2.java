package com.cleo.b2biaas.clarify;


public class InboundAddMessageDetailsV2 extends B2BAction {

	public void execute(com.extol.ebi.ruleset.lang.core.Object messageInfo,
			com.extol.ebi.ruleset.lang.core.String key,
			com.extol.ebi.ruleset.lang.core.String type,
			com.extol.ebi.ruleset.lang.core.String value) {

		
		MessageDetailsV2 messageV2 = new MessageDetailsV2();
		if (type != null) {
			messageV2.setType(type.asJavaString());
		}
		if (value != null) {
			messageV2.setValue(value.asJavaString());
		}
		((InboundMessageApiCallV2) messageInfo.asJavaObject()).detailsV2(
				key.asJavaString(), messageV2);
	}
}
