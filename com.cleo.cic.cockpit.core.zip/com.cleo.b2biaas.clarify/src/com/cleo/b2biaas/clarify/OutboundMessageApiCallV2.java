package com.cleo.b2biaas.clarify;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Manju Muthuraj
 * 
 */
public class OutboundMessageApiCallV2 extends B2BAction{

	private ConcurrentHashMap<String, String> outboundInfo = new ConcurrentHashMap<>();
	private LinkedHashMap<String, String> messageDetails = new LinkedHashMap<>();
	private LinkedHashMap<String, String> summaryString = new LinkedHashMap<>();
	private ConcurrentHashMap<String, String> reprocessingDetails = new ConcurrentHashMap<>();
	private ConcurrentHashMap<String, String> keyDetails = new ConcurrentHashMap<>();
	private LinkedHashMap<String, LinkedHashMap<String, String>> messageDetailsV2 = new LinkedHashMap<>();
	private List<Aggregates> aggregates = new ArrayList<Aggregates>();

	private Utility utility = new Utility();

	public OutboundMessageApiCallV2(String tpName, String docType,
			String parentMessageId, String messageId, String timeStamp,
			String faExpected, String currency, String logOfMessageId,
			String tpId) {

		getInfo().put(EventKeys.KEY_TPNAME, tpName);
		getInfo().put(EventKeys.KEY_DOCTYPE, docType);
		getInfo().put(EventKeys.KEY_PARENTMESSAGEID, parentMessageId);
		getInfo().put(EventKeys.KEY_MESSAGEID, messageId);
		getInfo().put(EventKeys.KEY_TIMESTAMP, timeStamp);
		getInfo().put(EventKeys.KEY_DIRECTION, EventKeys.DIRECTION_S);
		if (faExpected.isEmpty()) {
		  getInfo().put(EventKeys.KEY_FAEXPECTED, EventKeys.FALSE);
		} else {
		  getInfo().put(EventKeys.KEY_FAEXPECTED, faExpected);
		}
		getInfo().put(EventKeys.KEY_CURRENCY, currency);
		if (logOfMessageId != null && !EventKeys.NULL.equals(logOfMessageId.toLowerCase()) && !logOfMessageId.isEmpty() && !EventKeys.NA.equals(logOfMessageId.toLowerCase())) {
			getInfo().put(EventKeys.KEY_LOGOFMESSAGEID, logOfMessageId);
		} else {
			getInfo().put(EventKeys.KEY_LOGOFMESSAGEID, "");
		}
		getInfo().put(EventKeys.KEY_TPID, tpId);

	}

	public void details(String key, String value) {
		getMessageDetails().put(key, value);
	}

	public void detailsV2(String key, MessageDetailsV2 obj) {
		LinkedHashMap<String, String> data = new LinkedHashMap<String, String>();
		String varType = "";
		String varValue = "";

		if (obj != null) {
			if (obj.getType() != null && !obj.getType().isEmpty()) {
				varType = obj.getType();
			}
			if (obj.getValue() != null && !obj.getValue().isEmpty()) {
				varValue = obj.getValue();
			}
		}

		data.put(EventKeys.TYPE, varType);
		data.put(EventKeys.VALUE, varValue);

		getMessageDetailsV2().put(key, data);

	}

	public void aggregate(Aggregates aggregates) {
		getAggregates().add(aggregates);

	}

	public List<Aggregates> getAggregates() {
		return aggregates;
	}

	public void summaryString(String key, String value) {
		getSummaryString().put(key, value);

	}

	public void reprocessingString(String key, String value) {
		getReprocessingString().put(key, value);
	}

	public StringBuffer objToJson(OutboundMessageApiCallV2 mi)
			throws JsonProcessingException {

		ObjectMapper messageDetailsMapper = new ObjectMapper();

		String messagedetailsJson = utility.objectToString(mi.getMessageDetails());

		messagedetailsJson = utility.messageDetailsV2(mi.getMessageDetailsV2(), messageDetailsMapper,
				messagedetailsJson);

		String[] summaryArray = new String[mi.getSummaryString().size()];
		int i = 0;
		for (String key : mi.getSummaryString().keySet()) {
			summaryArray[i++] = "\"" + mi.getSummaryString().get(key) + "\"";
		}
		String summaryStringArray = Arrays.toString(summaryArray);

		String[] aggregatesArray = new String[mi.getAggregates().size()];
		int j = 0;
		for (Aggregates aggregates : mi.getAggregates()) {
			StringBuffer aggregateBuffer = new StringBuffer();
			aggregateBuffer.append("{");
			if (aggregates.getKey() != null && !aggregates.getKey().equals(""))
				aggregateBuffer.append("\"name\":" + "\"" + aggregates.getKey()
						+ "\",");
			if (aggregates.getValue() != null
					&& !aggregates.getValue().equals(""))
				aggregateBuffer.append("\"value\":" + "\""
						+ aggregates.getValue() + "\"");
			aggregateBuffer.append("}");
			aggregatesArray[j++] = aggregateBuffer.toString();
		}

		String aggregatesStringArray = Arrays.toString(aggregatesArray);

		String reprocessingDetailsJson = utility.objectToString(mi.getReprocessingString());
		

		// Add new key to message header
		String keyJson = utility.objectToString(mi.getKey());
		String sbKeyJson = keyJson.substring(1, keyJson.length() - 1);

		String infoJson = utility.objectToString(mi.getInfo());
		String substring = infoJson.substring(0, infoJson.length() - 1);
		StringBuffer sb = new StringBuffer(substring);
		
		if (!(mi.getKey().isEmpty())) {
			sb.append(",");
			sb.append(sbKeyJson.trim());
		}

		if (null != summaryArray && !(summaryArray.length == 0)) {
			sb.append(",");
			sb.append("\"summaryString\":");
			sb.append(summaryStringArray);
		}

		if (!(mi.getMessageDetails().isEmpty())) {
			sb.append(",");
			sb.append("\"messageDetails\":");
			sb.append(messagedetailsJson);
		} else {
			if (!(mi.getMessageDetailsV2().isEmpty())) {
				sb.append(",");
				sb.append("\"messageDetails\":");
				sb.append(messagedetailsJson);
			}
		}

		if (!(mi.getReprocessingString().isEmpty())) {
			sb.append(",");
			sb.append("\"reprocessingDetails\":");
			sb.append(reprocessingDetailsJson);
		}

		if (null != aggregatesArray && !(aggregatesArray.length == 0)) {
			sb.append(",");
			sb.append("\"aggregates\":");
			sb.append(aggregatesStringArray);
		}

		sb.append("}");
		return sb;
	}

	public void postMessageTob2biaaS(String serverUrl, String json,
			String securityToken) throws Exception {
		utility.postMessage(serverUrl, json, securityToken);

	}

	public LinkedHashMap<String, String> getMessageDetails() {
		return messageDetails;
	}

	public LinkedHashMap<String, LinkedHashMap<String, String>> getMessageDetailsV2() {
		return messageDetailsV2;
	}

	public void setMessageDetails(
			LinkedHashMap<String, String> messageDetails) {
		this.messageDetails = messageDetails;
	}

	public void setMessageDetailsV2(
			LinkedHashMap<String, LinkedHashMap<String, String>> messageDetailsV2) {
		this.messageDetailsV2 = messageDetailsV2;
	}

	public void setAggregates(List<Aggregates> aggregates) {
		this.aggregates = aggregates;
	}

	public ConcurrentHashMap<String, String> getInfo() {
		return outboundInfo;
	}

	public void setInfo(ConcurrentHashMap<String, String> info) {
		this.outboundInfo = info;
	}

	public LinkedHashMap<String, String> getSummaryString() {
		return summaryString;
	}

	public ConcurrentHashMap<String, String> getReprocessingString() {
		return reprocessingDetails;
	}

	public void setSummaryString(LinkedHashMap<String, String> summaryString) {
		this.summaryString = summaryString;
	}
	
	public void addKey(String key, String value) {
		getKey().put(key, value);

	}
	
	public ConcurrentHashMap<String, String> getKey() {
		return keyDetails;
	}

}