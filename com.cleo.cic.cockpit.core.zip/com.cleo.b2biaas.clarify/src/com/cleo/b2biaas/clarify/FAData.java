package com.cleo.b2biaas.clarify;

import java.util.ArrayList;

public class FAData {
	
	private String logOfMessageId;
	private String groupStatus;
	private String functionalIdentifierCode;
	private String groupControlNumber;
	private String ownerId;
	private String tpId;
	private String direction;
	private String timeStamp;

	public String getLogOfMessageId() {
		return logOfMessageId;
	}

	public void setLogOfMessageId(String logOfMessageId) {
		this.logOfMessageId = logOfMessageId;
	}

	public String getGroupStatus() {
		return groupStatus;
	}

	public void setGroupStatus(String groupStatus) {
		this.groupStatus = groupStatus;
	}

	public String getFunctionalIdentifierCode() {
		return functionalIdentifierCode;
	}

	public void setFunctionalIdentifierCode(String functionalIdentifierCode) {
		this.functionalIdentifierCode = functionalIdentifierCode;
	}

	public String getGroupControlNumber() {
		return groupControlNumber;
	}

	public void setGroupControlNumber(String groupControlNumber) {
		this.groupControlNumber = groupControlNumber;
	}

	public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	public String getTpId() {
		return tpId;
	}

	public void setTpId(String tpId) {
		this.tpId = tpId;
	}

	public ArrayList<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(ArrayList<Transaction> transactionInfo) {
		this.transactions = transactionInfo;
	}

	public void addTransaction(Transaction tx) {
		this.getTransactions().add(tx);
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append(logOfMessageId);
		sb.append(":");
		sb.append(groupStatus);
		return sb.toString();
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timestamp) {
		this.timeStamp = timestamp;
	}
	
	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	private ArrayList<Transaction> transactions = new ArrayList<>();

	class Transaction {
		public String getTransactionStatus() {
			return transactionStatus;
		}

		public void setTransactionStatus(String transactionStatus) {
			this.transactionStatus = transactionStatus;
		}

		public String getTransactionControlNumber() {
			return transactionControlNumber;
		}

		public void setTransactionControlNumber(String transactionControlNumber) {
			this.transactionControlNumber = transactionControlNumber;
		}

		private String transactionStatus;
		private String transactionControlNumber;
	}
}
