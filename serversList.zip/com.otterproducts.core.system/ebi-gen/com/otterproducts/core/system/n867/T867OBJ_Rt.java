/**
 * @generated
 */
package com.otterproducts.core.system.n867;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.reactor.pojo.lib.*;

@SuppressWarnings("all")
public class T867OBJ_Rt implements RuntimePojoSchemaProvider {
	private static RtPojoSchema schema_T867OBJ;

	public RtPojoSchema getSchema() {
		if (schema_T867OBJ == null) {
			RtPojoSchemaDetails schema_details_T867OBJ = new RtPojoSchemaDetails();
			schema_details_T867OBJ.setRootNodeName("t867");
			schema_details_T867OBJ.setRootNodeType(com.tibco.ns.foresight._2010._20.T867.class);
			schema_details_T867OBJ.setSerializationType(RtSerializationType.XML);
			schema_details_T867OBJ.setBasePackages("com.tibco.ns.foresight._2010._20");

			schema_T867OBJ = new RtPojoSchema(schema_details_T867OBJ);
		}

		return schema_T867OBJ;
	}
}
