package com.cleo.b2biaas.clarify;

import com.extol.ebi.reactor.lib.AbstractAction;

public class OutboundAddMessageDetailsV2 extends AbstractAction {

	public void execute(com.extol.ebi.ruleset.lang.core.Object messageInfo,
			com.extol.ebi.ruleset.lang.core.String key,
			com.extol.ebi.ruleset.lang.core.String type,
			com.extol.ebi.ruleset.lang.core.String value) {

		MessageDetailsV2 messageV2 = new MessageDetailsV2();

		if (type != null) {
			messageV2.setType(type.asJavaString());
		}
		if (value != null) {
			messageV2.setValue(value.asJavaString());
		}
		((OutboundMessageApiCallV2) messageInfo.asJavaObject()).detailsV2(
				key.asJavaString(), messageV2);
	}
}
