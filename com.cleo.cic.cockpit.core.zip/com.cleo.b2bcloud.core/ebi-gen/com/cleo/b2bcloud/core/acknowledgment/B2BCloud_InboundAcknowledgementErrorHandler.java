package com.cleo.b2bcloud.core.acknowledgment;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.bps.lib.types.EdiDataMap;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class B2BCloud_InboundAcknowledgementErrorHandler implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode storageId;
    
    @TupleIndex(value = 1)
    public EdiDataMap interchangeProperties;
    
    @TupleIndex(value = 2)
    public EdiDataMap acknowledgementErrorProperties;
    
    @TupleIndex(value = 3)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public B2BCloud_InboundAcknowledgementErrorHandler.ResultTuple execute(final StorageNode storageId, final EdiDataMap interchangeProperties, final EdiDataMap acknowledgementErrorProperties) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode storageId;
      
      @TupleIndex(value = 1)
      public com.extol.ebi.ruleset.lang.core.Object interchangeProperties;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.Object acknowledgementErrorProperties;
      
      @TupleIndex(value = 3)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public B2BCloud_InboundAcknowledgementErrorHandler.RulesetAction.ResultTuple execute(final StorageNode storageId, final com.extol.ebi.ruleset.lang.core.Object interchangeProperties, final com.extol.ebi.ruleset.lang.core.Object acknowledgementErrorProperties) {
      Object[] _bps_parameters = new Object[3];
      _bps_parameters[0] = storageId;
      _bps_parameters[1] = toBpsObject(interchangeProperties);
      _bps_parameters[2] = toBpsObject(acknowledgementErrorProperties);
      
      boolean _exit_PassStatus = launchScript("com.cleo.b2bcloud.core", "com.cleo.b2bcloud.core.acknowledgment.B2BCloud_InboundAcknowledgementErrorHandler", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.storageId = asStorageNode(_bps_parameters[0]);
      resultTuple.interchangeProperties = asObject(_bps_parameters[1]);
      resultTuple.acknowledgementErrorProperties = asObject(_bps_parameters[2]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
}
