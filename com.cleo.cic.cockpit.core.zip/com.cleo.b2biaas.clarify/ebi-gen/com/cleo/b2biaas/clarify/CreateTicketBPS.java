package com.cleo.b2biaas.clarify;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class CreateTicketBPS implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode targetContext;
    
    @TupleIndex(value = 1)
    public StorageNode inputDataFragment;
    
    @TupleIndex(value = 2)
    public com.extol.ebi.bps.lang.String ticketSubject;
    
    @TupleIndex(value = 3)
    public com.extol.ebi.bps.lang.String ticketBody;
    
    @TupleIndex(value = 4)
    public com.extol.ebi.bps.lang.String attachmentName;
    
    @TupleIndex(value = 5)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public CreateTicketBPS.ResultTuple execute(final StorageNode targetContext, final StorageNode inputDataFragment, final com.extol.ebi.bps.lang.String ticketSubject, final com.extol.ebi.bps.lang.String ticketBody, final com.extol.ebi.bps.lang.String attachmentName) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode targetContext;
      
      @TupleIndex(value = 1)
      public StorageNode inputDataFragment;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.String ticketSubject;
      
      @TupleIndex(value = 3)
      public com.extol.ebi.ruleset.lang.core.String ticketBody;
      
      @TupleIndex(value = 4)
      public com.extol.ebi.ruleset.lang.core.String attachmentName;
      
      @TupleIndex(value = 5)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public CreateTicketBPS.RulesetAction.ResultTuple execute(final StorageNode targetContext, final StorageNode inputDataFragment, final com.extol.ebi.ruleset.lang.core.String ticketSubject, final com.extol.ebi.ruleset.lang.core.String ticketBody, final com.extol.ebi.ruleset.lang.core.String attachmentName) {
      Object[] _bps_parameters = new Object[5];
      _bps_parameters[0] = targetContext;
      _bps_parameters[1] = inputDataFragment;
      _bps_parameters[2] = toBpsString(ticketSubject);
      _bps_parameters[3] = toBpsString(ticketBody);
      _bps_parameters[4] = toBpsString(attachmentName);
      
      boolean _exit_PassStatus = launchScript("com.cleo.b2biaas.clarify", "com.cleo.b2biaas.clarify.CreateTicketBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.targetContext = asStorageNode(_bps_parameters[0]);
      resultTuple.inputDataFragment = asStorageNode(_bps_parameters[1]);
      resultTuple.ticketSubject = asString(_bps_parameters[2]);
      resultTuple.ticketBody = asString(_bps_parameters[3]);
      resultTuple.attachmentName = asString(_bps_parameters[4]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
  
  public static class createTicketWithAttachment implements BpsCallable {
    public boolean execute(final Void returnValue, final com.extol.ebi.bps.lang.String messageId, final com.extol.ebi.bps.lang.String docType, final com.extol.ebi.bps.lang.String tpId, final com.extol.ebi.bps.lang.String ticketSubject, final com.extol.ebi.bps.lang.String ticketBody, final com.extol.ebi.bps.lang.String attachmentContent, final com.extol.ebi.bps.lang.String attachmentName) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
  }
}
