/**
* @generated
*/
package com.cleo.b2bcloud.core.acknowledgment;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.flatfile.lib.connectors.*;
import com.extol.ebi.reactor.flatfile.lib.schema.*;

@SuppressWarnings("all")
public class InboundAcknowledgment997RS_Rt extends AbstractReactor<RtFlatFileSchema,RtFlatFileSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String vMessage = asString("");
	private com.extol.ebi.ruleset.lang.core.String vGroupCntNo;
	private com.extol.ebi.ruleset.lang.core.String vDocType;
	private com.extol.ebi.ruleset.lang.core.String vTPID;
	private com.extol.ebi.ruleset.lang.core.String Message_Id;
	private com.extol.ebi.ruleset.lang.core.String vRefference;
	private com.extol.ebi.ruleset.lang.core.String vTPName;
	private com.extol.ebi.ruleset.lang.core.String vPosition;
	private com.extol.ebi.ruleset.lang.core.String vSegment;
	private com.extol.ebi.ruleset.lang.core.String vError;
	
	public SchemaProvider<RtFlatFileSchema> getSourceSchema() {
		return new com.cleo.b2bcloud.core.acknowledgment.EDI997FF_Rt();
	}
	
	public SchemaProvider<RtFlatFileSchema> getTargetSchema() {
		return new com.cleo.b2bcloud.core.acknowledgment.flatFile997FF_Rt();
	}
	
	public Connector getSourceConnector() {
		return new MultiFormatDelimitedFlatFileConnector();
	}

	public Connector getTargetConnector() {
		return new MultiFormatDelimitedFlatFileConnector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "for source._RecordGroup0.current._RecordGroup1", new Block() { public void body() {
			for (final SourceNode s0_cur__RecordGroup0 : source.getIterable("_RecordGroup0")) {
			for (final SourceNode s1_cur__RecordGroup1 : s0_cur__RecordGroup0.getIterable("_RecordGroup1")) {
		
		
			createCompositeRule(2, "for source._RecordGroup0.current._RecordGroup1.current._RecordGroup2", new Block() { public void body() {
				for (final SourceNode s2_cur__RecordGroup2 : s1_cur__RecordGroup1.getIterable("_RecordGroup2")) {
			
			
				createCompositeRule(3, "for source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK2", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringNotEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringNotEquals();
					createRuleCondition(3, "new StringNotEquals().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK5.AK502, \"A\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur__RecordGroup2.get("_AK5").get("AK502"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("A");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
					final SourceNode s3__AK2 = s2_cur__RecordGroup2.get("_AK2");
					if (exists(s3__AK2)) {
				
				
					createCompositeRule(4, "", new Block() { public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(5, "new Move().execute(source._RecordGroup0.current._RecordGroup1.current._AK1.AK103) => #[this.vGroupCntNo]", action);
							final SourceNode var0 = s1_cur__RecordGroup1.get("_AK1").get("AK103");
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vGroupCntNo = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(6, "new Move().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK2.AK202) => #[this.vDocType]", action);
							final SourceNode var0 = s3__AK2.get("AK202");
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vDocType = extractString(result);
						}
						{
							com.cleo.b2bcloud.core.acknowledgment.DocCT.RulesetAction action = new com.cleo.b2bcloud.core.acknowledgment.DocCT.RulesetAction();
							createSimpleRule(7, "new com.cleo.b2bcloud.core.acknowledgment.DocCT$RulesetAction().execute(this.vDocType) => #[this.vDocType]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgment997RS_Rt.this.vDocType;
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vDocType = result;
						}
						{
							com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2();
							createSimpleRule(8, "new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL$RulesetActionV2().execute(this.env.User_Reference_2, this.vGroupCntNo, source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK2.AK203) => ##[#[this.vRefference, this.env.User_Reference_3], #[this.vTPID], #[this.env.Acknowledgement_Id]]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgment997RS_Rt.this.env.User_Reference_2;
							final com.extol.ebi.ruleset.lang.core.String var1 = InboundAcknowledgment997RS_Rt.this.vGroupCntNo;
							final com.extol.ebi.ruleset.lang.core.String var2 = extractString(s3__AK2.get("AK203"));
							final com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQL.RulesetActionV2.ResultTuple result = action.execute(var0, var1, var2);
							InboundAcknowledgment997RS_Rt.this.vRefference = result.RefferenceNo;
							InboundAcknowledgment997RS_Rt.this.env.User_Reference_3 = result.RefferenceNo;
							InboundAcknowledgment997RS_Rt.this.vTPID = result.TRADING_PARTNER_ID;
							InboundAcknowledgment997RS_Rt.this.env.Acknowledgement_Id = result.UUID;
						}
						{
							com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2();
							createSimpleRule(9, "new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL$RulesetActionV2().execute(this.vTPID) => #[this.vTPName, this.env.User_Reference_4]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgment997RS_Rt.this.vTPID;
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vTPName = result;
							InboundAcknowledgment997RS_Rt.this.env.User_Reference_4 = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(10, "new Move().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK2.AK202) => #[this.env.Process_Id]", action);
							final SourceNode var0 = s3__AK2.get("AK202");
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.env.Process_Id = extractString(result);
						}
					}}).run();
					createCompositeRule(11, "for source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK3", new Block() { public void body() {
						final SourceNode s3__AK3 = s2_cur__RecordGroup2.get("_AK3");
						if (exists(s3__AK3)) {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(12, "new Move().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK4.current.AK402) => #[this.vPosition]", action);
							final SourceNode var0 = s2_cur__RecordGroup2.get("_AK4").get("AK402");
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vPosition = extractString(result);
						}
						{
							com.cleo.b2bcloud.core.acknowledgment.ErrorCT.RulesetAction action = new com.cleo.b2bcloud.core.acknowledgment.ErrorCT.RulesetAction();
							createSimpleRule(13, "new com.cleo.b2bcloud.core.acknowledgment.ErrorCT$RulesetAction().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK4.current.AK404) => #[this.vError]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur__RecordGroup2.get("_AK4").get("AK404"));
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vError = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(14, "new Move().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK3.AK302) => #[this.vSegment]", action);
							final SourceNode var0 = s3__AK3.get("AK302");
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vSegment = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.string.Concatenate action = new com.extol.ebi.reactor.lib.actions.string.Concatenate();
							createSimpleRule(15, "new Concatenate().execute(this.vMessage, \"The\") => #[this.vMessage]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgment997RS_Rt.this.vMessage;
							final com.extol.ebi.ruleset.lang.core.String var1 = asString("The");
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
							InboundAcknowledgment997RS_Rt.this.vMessage = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(16, "new ConcatenateMany().execute(\" \", true, this.vMessage, this.vDocType, \"with Group Control number\", this.vGroupCntNo, \"and \", this.vDocType, \"Number -\", this.vRefference, \"was rejected by Trading Partner\", this.vTPName) => #[this.vMessage]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
							final SourceNode var2 = toValueNode(InboundAcknowledgment997RS_Rt.this.vMessage);
							final SourceNode var3 = toValueNode(InboundAcknowledgment997RS_Rt.this.vDocType);
							final SourceNode var4 = toValueNode(asString("with Group Control number"));
							final SourceNode var5 = toValueNode(InboundAcknowledgment997RS_Rt.this.vGroupCntNo);
							final SourceNode var6 = toValueNode(asString("and "));
							final SourceNode var7 = toValueNode(InboundAcknowledgment997RS_Rt.this.vDocType);
							final SourceNode var8 = toValueNode(asString("Number -"));
							final SourceNode var9 = toValueNode(InboundAcknowledgment997RS_Rt.this.vRefference);
							final SourceNode var10 = toValueNode(asString("was rejected by Trading Partner"));
							final SourceNode var11 = toValueNode(InboundAcknowledgment997RS_Rt.this.vTPName);
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							InboundAcknowledgment997RS_Rt.this.vMessage = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(17, "new ConcatenateMany().execute(\" \", true, this.vMessage, \"due to error\", null, \"in segment\", source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK3.AK302, \"at position\", this.vPosition, \"(\", this.vError, \"). Please correct the data and resend.\n\") => #[this.vMessage]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
							final SourceNode var2 = toValueNode(InboundAcknowledgment997RS_Rt.this.vMessage);
							final SourceNode var3 = toValueNode(asString("due to error"));
							final SourceNode var4 = toNullValueNode();
							final SourceNode var5 = toValueNode(asString("in segment"));
							final SourceNode var6 = s3__AK3.get("AK302");
							final SourceNode var7 = toValueNode(asString("at position"));
							final SourceNode var8 = toValueNode(InboundAcknowledgment997RS_Rt.this.vPosition);
							final SourceNode var9 = toValueNode(asString("("));
							final SourceNode var10 = toValueNode(InboundAcknowledgment997RS_Rt.this.vError);
							final SourceNode var11 = toValueNode(asString("). Please correct the data and resend.\n"));
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							InboundAcknowledgment997RS_Rt.this.vMessage = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(18, "new Move().execute(1) => #[this.env.User_Reference_5]", action);
							final SourceNode var0 = toValueNode(asNumber(1));
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.env.User_Reference_5 = extractString(result);
						}
					}}}).run();
					createCompositeRule(19, "for source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK3", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces();
						createRuleCondition(19, "new IsNullOrWhiteSpaces().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK4.current.AK401) => #[]", condition);
						final SourceNode var0 = s2_cur__RecordGroup2.get("_AK4").get("AK401");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
						final SourceNode s3__AK3 = s2_cur__RecordGroup2.get("_AK3");
						if (exists(s3__AK3)) {
					
					
						{
							com.cleo.b2bcloud.core.acknowledgment.ErrorCT.RulesetAction action = new com.cleo.b2bcloud.core.acknowledgment.ErrorCT.RulesetAction();
							createSimpleRule(20, "new com.cleo.b2bcloud.core.acknowledgment.ErrorCT$RulesetAction().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK3.AK305) => #[this.vError]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3__AK3.get("AK305"));
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.vError = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(21, "new ConcatenateMany().execute(\" \", true, \"The\", this.vDocType, \"with Group Control number\", this.vGroupCntNo, \"and \", this.vDocType, \"Number -\", this.vRefference, \"was rejected by Trading Partner\", this.vTPName) => #[this.vMessage]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
							final SourceNode var2 = toValueNode(asString("The"));
							final SourceNode var3 = toValueNode(InboundAcknowledgment997RS_Rt.this.vDocType);
							final SourceNode var4 = toValueNode(asString("with Group Control number"));
							final SourceNode var5 = toValueNode(InboundAcknowledgment997RS_Rt.this.vGroupCntNo);
							final SourceNode var6 = toValueNode(asString("and "));
							final SourceNode var7 = toValueNode(InboundAcknowledgment997RS_Rt.this.vDocType);
							final SourceNode var8 = toValueNode(asString("Number -"));
							final SourceNode var9 = toValueNode(InboundAcknowledgment997RS_Rt.this.vRefference);
							final SourceNode var10 = toValueNode(asString("was rejected by Trading Partner"));
							final SourceNode var11 = toValueNode(InboundAcknowledgment997RS_Rt.this.vTPName);
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							InboundAcknowledgment997RS_Rt.this.vMessage = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(22, "new ConcatenateMany().execute(\" \", true, this.vMessage, \"due to error\", null, \"in segment\", source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK3.AK302, \"at position\", this.vPosition, \"(\", this.vError, \"). Please correct the data and resend.\n\") => #[this.vMessage]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
							final SourceNode var2 = toValueNode(InboundAcknowledgment997RS_Rt.this.vMessage);
							final SourceNode var3 = toValueNode(asString("due to error"));
							final SourceNode var4 = toNullValueNode();
							final SourceNode var5 = toValueNode(asString("in segment"));
							final SourceNode var6 = s3__AK3.get("AK302");
							final SourceNode var7 = toValueNode(asString("at position"));
							final SourceNode var8 = toValueNode(InboundAcknowledgment997RS_Rt.this.vPosition);
							final SourceNode var9 = toValueNode(asString("("));
							final SourceNode var10 = toValueNode(InboundAcknowledgment997RS_Rt.this.vError);
							final SourceNode var11 = toValueNode(asString("). Please correct the data and resend.\n"));
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							InboundAcknowledgment997RS_Rt.this.vMessage = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(23, "new Move().execute(1) => #[this.env.User_Reference_5]", action);
							final SourceNode var0 = toValueNode(asNumber(1));
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.env.User_Reference_5 = extractString(result);
						}
					}}}).run();
				}}}).run();
				createCompositeRule(24, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringNotEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringNotEquals();
					createRuleCondition(24, "new StringNotEquals().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK5.AK502, \"A\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur__RecordGroup2.get("_AK5").get("AK502"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("A");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					createCompositeRule(25, "for source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK2", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces();
						createRuleCondition(25, "new IsNullOrWhiteSpaces().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK3.AK301) => #[]", condition);
						final SourceNode var0 = s2_cur__RecordGroup2.get("_AK3").get("AK301");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
						final SourceNode s3__AK2 = s2_cur__RecordGroup2.get("_AK2");
						if (exists(s3__AK2)) {
					
					
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(26, "new ConcatenateMany().execute(\" \", true, \"We have not Received AK3/AK4 Segment in 997 for rejected\", this.vDocType, \"Number\", this.vRefference, \"with Group Control Number\", this.vGroupCntNo, \". Please let us know\", \"the reason\", \"for\", \"rejection.\n\") => #[this.vMessage]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
							final SourceNode var2 = toValueNode(asString("We have not Received AK3/AK4 Segment in 997 for rejected"));
							final SourceNode var3 = toValueNode(InboundAcknowledgment997RS_Rt.this.vDocType);
							final SourceNode var4 = toValueNode(asString("Number"));
							final SourceNode var5 = toValueNode(InboundAcknowledgment997RS_Rt.this.vRefference);
							final SourceNode var6 = toValueNode(asString("with Group Control Number"));
							final SourceNode var7 = toValueNode(InboundAcknowledgment997RS_Rt.this.vGroupCntNo);
							final SourceNode var8 = toValueNode(asString(". Please let us know"));
							final SourceNode var9 = toValueNode(asString("the reason"));
							final SourceNode var10 = toValueNode(asString("for"));
							final SourceNode var11 = toValueNode(asString("rejection.\n"));
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							InboundAcknowledgment997RS_Rt.this.vMessage = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(27, "new Move().execute(0) => #[this.env.User_Reference_5]", action);
							final SourceNode var0 = toValueNode(asNumber(0));
							final SourceNode result = action.execute(var0);
							InboundAcknowledgment997RS_Rt.this.env.User_Reference_5 = extractString(result);
						}
					}}}).run();
				}}).run();
				createCompositeRule(28, "for source._RecordGroup0.current._RecordGroup1.current._AK9", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringNotEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringNotEquals();
					createRuleCondition(28, "new StringNotEquals().execute(source._RecordGroup0.current._RecordGroup1.current._RecordGroup2.current._AK5.AK502, \"A\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur__RecordGroup2.get("_AK5").get("AK502"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("A");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
					final SourceNode s2__AK9 = s1_cur__RecordGroup1.get("_AK9");
					if (exists(s2__AK9)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
						createSimpleRule(29, "new ConcatenateMany().execute(\" \", null, this.vMessage, \"\nNumber of Transaction Sets Included :\", source._RecordGroup0.current._RecordGroup1.current._AK9.AK903, \"\nNumber of Received Transaction Sets :\", source._RecordGroup0.current._RecordGroup1.current._AK9.AK904, \"\nNumber of Accepted Transaction Sets \", source._RecordGroup0.current._RecordGroup1.current._AK9.AK905, null, null, null) => #[this.vMessage]", action);
						final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
						final com.extol.ebi.ruleset.lang.core.Boolean var1 = null;
						final SourceNode var2 = toValueNode(InboundAcknowledgment997RS_Rt.this.vMessage);
						final SourceNode var3 = toValueNode(asString("\nNumber of Transaction Sets Included :"));
						final SourceNode var4 = s2__AK9.get("AK903");
						final SourceNode var5 = toValueNode(asString("\nNumber of Received Transaction Sets :"));
						final SourceNode var6 = s2__AK9.get("AK904");
						final SourceNode var7 = toValueNode(asString("\nNumber of Accepted Transaction Sets "));
						final SourceNode var8 = s2__AK9.get("AK905");
						final SourceNode var9 = toNullValueNode();
						final SourceNode var10 = toNullValueNode();
						final SourceNode var11 = toNullValueNode();
						final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
						InboundAcknowledgment997RS_Rt.this.vMessage = result;
					}
				}}}).run();
			}}}).run();
			createCompositeRule(30, "for source._RecordGroup0.current._RecordGroup1.current._AK9", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces();
				createRuleCondition(30, "new IsNullOrWhiteSpaces().execute(this.vMessage) => #[]", condition);
				final SourceNode var0 = toValueNode(InboundAcknowledgment997RS_Rt.this.vMessage);
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
				final SourceNode s2__AK9 = s1_cur__RecordGroup1.get("_AK9");
				if (exists(s2__AK9)) {
			
			
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNullOrWhiteSpaces();
						createRuleCondition(31, "new IsNullOrWhiteSpaces().execute(this.vMessage) => #[]", condition);
						final SourceNode var0 = toValueNode(InboundAcknowledgment997RS_Rt.this.vMessage);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
						createSimpleRule(31, "new ConcatenateMany().execute(\" \", null, \"We have not received AK2 , AK3 or AK4 segment in 997 for rejected Functional Identifier Code\", source._RecordGroup0.current._RecordGroup1.current._AK1.AK102, \"with Group Control Number\", source._RecordGroup0.current._RecordGroup1.current._AK1.AK103, \"\nNumber of Transaction Sets Included :\", source._RecordGroup0.current._RecordGroup1.current._AK9.AK903, \"\nNumber of Received Transaction Sets :\", source._RecordGroup0.current._RecordGroup1.current._AK9.AK904, \"\nNumber of Accepted Transaction Sets \", source._RecordGroup0.current._RecordGroup1.current._AK9.AK905) => #[this.vMessage]", action);
						final com.extol.ebi.ruleset.lang.core.String var0 = asString(" ");
						final com.extol.ebi.ruleset.lang.core.Boolean var1 = null;
						final SourceNode var2 = toValueNode(asString("We have not received AK2 , AK3 or AK4 segment in 997 for rejected Functional Identifier Code"));
						final SourceNode var3 = s1_cur__RecordGroup1.get("_AK1").get("AK102");
						final SourceNode var4 = toValueNode(asString("with Group Control Number"));
						final SourceNode var5 = s1_cur__RecordGroup1.get("_AK1").get("AK103");
						final SourceNode var6 = toValueNode(asString("\nNumber of Transaction Sets Included :"));
						final SourceNode var7 = s2__AK9.get("AK903");
						final SourceNode var8 = toValueNode(asString("\nNumber of Received Transaction Sets :"));
						final SourceNode var9 = s2__AK9.get("AK904");
						final SourceNode var10 = toValueNode(asString("\nNumber of Accepted Transaction Sets "));
						final SourceNode var11 = s2__AK9.get("AK905");
						final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
						InboundAcknowledgment997RS_Rt.this.vMessage = result;
					}
				}
				{
					com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQLByGCN.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQLByGCN.RulesetActionV2();
					createSimpleRule(32, "new com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQLByGCN$RulesetActionV2().execute(this.env.User_Reference_2, source._RecordGroup0.current._RecordGroup1.current._AK1.AK103) => ##[#[this.vRefference, this.env.User_Reference_3], #[this.vTPID], #[this.env.Acknowledgement_Id]]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgment997RS_Rt.this.env.User_Reference_2;
					final com.extol.ebi.ruleset.lang.core.String var1 = extractString(s1_cur__RecordGroup1.get("_AK1").get("AK103"));
					final com.cleo.b2bcloud.core.acknowledgment.InboundAcknowledgmentSQLByGCN.RulesetActionV2.ResultTuple result = action.execute(var0, var1);
					InboundAcknowledgment997RS_Rt.this.vRefference = result.RefferenceNo;
					InboundAcknowledgment997RS_Rt.this.env.User_Reference_3 = result.RefferenceNo;
					InboundAcknowledgment997RS_Rt.this.vTPID = result.TRADING_PARTNER_ID;
					InboundAcknowledgment997RS_Rt.this.env.Acknowledgement_Id = result.UUID;
				}
				{
					com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2 action = new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.RulesetActionV2();
					createSimpleRule(33, "new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL$RulesetActionV2().execute(this.vTPID) => #[this.vTPName, this.env.User_Reference_4]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = InboundAcknowledgment997RS_Rt.this.vTPID;
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
					InboundAcknowledgment997RS_Rt.this.vTPName = result;
					InboundAcknowledgment997RS_Rt.this.env.User_Reference_4 = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(34, "new Move().execute(0) => #[this.env.User_Reference_5]", action);
					final SourceNode var0 = toValueNode(asNumber(0));
					final SourceNode result = action.execute(var0);
					InboundAcknowledgment997RS_Rt.this.env.User_Reference_5 = extractString(result);
				}
			}}}).run();
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(35, "new Move().execute(this.vMessage) => #[target._New_Record.current.New_Field, this.env.User_Reference_1]", action);
				final SourceNode var0 = toValueNode(InboundAcknowledgment997RS_Rt.this.vMessage);
				final SourceNode result = action.execute(var0);
				target.set(at("_New_Record", "New_Field"), result);
				InboundAcknowledgment997RS_Rt.this.env.User_Reference_1 = extractString(result);
			}
		}}}}).run();
	}

}
