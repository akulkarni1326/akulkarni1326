package com.cleo.cic.cockpit.core;

import com.extol.ebi.lang.annotations.Version;
import com.extol.ebi.lang.rulesetdataobject.AbstractRulesetDataObject;
import com.extol.ebi.ruleset.lang.RulesetTypeConverter;
import java.util.Map;

@Version(value = 2)
@SuppressWarnings("all")
public class cockpitRDO extends AbstractRulesetDataObject {
  public com.extol.ebi.ruleset.lang.core.String tradingPartnerId;
  
  public com.extol.ebi.ruleset.lang.core.String logOfMsgId;
  
  public com.extol.ebi.ruleset.lang.core.String tpName;
  
  public com.extol.ebi.ruleset.lang.core.String ownerId;
  
  public com.extol.ebi.ruleset.lang.core.String docType;
  
  public com.extol.ebi.ruleset.lang.core.String partnerName;
  
  public com.extol.ebi.ruleset.lang.core.String ownerName;
  
  public com.extol.ebi.ruleset.lang.core.String messageId;
  
  public com.extol.ebi.ruleset.lang.core.String User_Reference_1;
  
  public com.extol.ebi.ruleset.lang.core.String User_Reference_2;
  
  public com.extol.ebi.ruleset.lang.core.String User_Reference_3;
  
  public com.extol.ebi.ruleset.lang.core.String User_Reference_4;
  
  public com.extol.ebi.ruleset.lang.core.String User_Reference_5;
  
  public com.extol.ebi.ruleset.lang.core.String ReprocessParms;
  
  public com.extol.ebi.ruleset.lang.core.String originalLOM;
  
  protected void initialize(final Map<String, String> map, final RulesetTypeConverter tc) {
    tradingPartnerId = tc.asRulesetString(getValue(map, "tradingPartnerId"));
    logOfMsgId = tc.asRulesetString(getValue(map, "logOfMsgId"));
    tpName = tc.asRulesetString(getValue(map, "tpName"));
    ownerId = tc.asRulesetString(getValue(map, "ownerId"));
    docType = tc.asRulesetString(getValue(map, "docType"));
    partnerName = tc.asRulesetString(getValue(map, "partnerName"));
    ownerName = tc.asRulesetString(getValue(map, "ownerName"));
    messageId = tc.asRulesetString(getValue(map, "messageId"));
    User_Reference_1 = tc.asRulesetString(getValue(map, "User_Reference_1"));
    User_Reference_2 = tc.asRulesetString(getValue(map, "User_Reference_2"));
    User_Reference_3 = tc.asRulesetString(getValue(map, "User_Reference_3"));
    User_Reference_4 = tc.asRulesetString(getValue(map, "User_Reference_4"));
    User_Reference_5 = tc.asRulesetString(getValue(map, "User_Reference_5"));
    ReprocessParms = tc.asRulesetString(getValue(map, "ReprocessParms"));
    originalLOM = tc.asRulesetString(getValue(map, "originalLOM"));
  }
  
  public void copyToMap(final Map<String, String> map, final RulesetTypeConverter tc) {
    map.put(getMapKey("tradingPartnerId"), tc.toJavaString(tradingPartnerId));
    map.put(getMapKey("logOfMsgId"), tc.toJavaString(logOfMsgId));
    map.put(getMapKey("tpName"), tc.toJavaString(tpName));
    map.put(getMapKey("ownerId"), tc.toJavaString(ownerId));
    map.put(getMapKey("docType"), tc.toJavaString(docType));
    map.put(getMapKey("partnerName"), tc.toJavaString(partnerName));
    map.put(getMapKey("ownerName"), tc.toJavaString(ownerName));
    map.put(getMapKey("messageId"), tc.toJavaString(messageId));
    map.put(getMapKey("User_Reference_1"), tc.toJavaString(User_Reference_1));
    map.put(getMapKey("User_Reference_2"), tc.toJavaString(User_Reference_2));
    map.put(getMapKey("User_Reference_3"), tc.toJavaString(User_Reference_3));
    map.put(getMapKey("User_Reference_4"), tc.toJavaString(User_Reference_4));
    map.put(getMapKey("User_Reference_5"), tc.toJavaString(User_Reference_5));
    map.put(getMapKey("ReprocessParms"), tc.toJavaString(ReprocessParms));
    map.put(getMapKey("originalLOM"), tc.toJavaString(originalLOM));
  }
}
