/**
* @generated
*/
package com.otterproducts.core.edi.inbound.n867;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.misc.SetRouteFieldValues;
import com.extol.ebi.bps.lib.tasks.transformation.ExecuteTransformation;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps.lib.types.Date;
import com.extol.ebi.bps.lib.types.Route;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.bps2.lib.types.CloudEndpoint;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@SuppressWarnings("all")
public class Inbound867RouteBPS_Rt extends AbstractCatalyst {
	private final Variable<Ruleset> f_ruleset;
	private final Variable<String> f_v_PartnerName;
	private final Variable<CloudEndpoint> f_CloudEndpoint;
	private final Variable<Ruleset> f_CockpitRuleset;
	private final Variable<String> f_DocType;
	private final Variable<String> f_v_filename;
	private final Variable<String> f_v_CustomerID;
	private final Variable<String> f_v_OrderNumber;
	
	public Inbound867RouteBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
		f_ruleset = variable(Ruleset.class, null);
		f_v_PartnerName = variable(String.class, null);
		f_CloudEndpoint = variable(CloudEndpoint.class, null);
		f_CockpitRuleset = variable(Ruleset.class, null);
		f_DocType = variable(String.class, null);
		f_v_filename = variable(String.class, null);
		f_v_CustomerID = variable(String.class, null);
		f_v_OrderNumber = variable(String.class, null);
	}
	
	public boolean execute(@ParameterType(Route.class) Variable<Route> p_route, @ParameterType(StorageNode.class) Variable<StorageNode> p_context, @ParameterType(StorageNode.class) Variable<StorageNode> p_inputDataFragment) {
		final Variable<StorageNode> v_v_target = variable(StorageNode.class, null);
		final Variable<StorageNode> v_v_sourcecontext = variable(StorageNode.class, null);
		final Variable<StorageNode> v_v_targetcontext = variable(StorageNode.class, null);
		final Variable<Date> v_CurrentDateTime = variable(Date.class, null);
		final Variable<String> v_v_date = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Set Route Field Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Route Field Values");
					SetRouteFieldValues task = new SetRouteFieldValues();
					setupTask(task);
					return task.execute(p_route);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Execute Transformation - Single Output", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Execute Transformation - Single Output");
					ExecuteTransformation task = new ExecuteTransformation();
					setupTask(task);
					return task.execute(p_inputDataFragment, v_v_target, literalTypeFromString(TransformationSettings.class, "com.cleo.b2bcloud.core.DefaultTransformationSettingsTS"), f_ruleset, null, p_context, v_v_targetcontext);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "com.cleo.cic.cockpit.core.inbound.inboundCockpitReferenceBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.inbound.inboundCockpitReferenceBPS");
					return getInvokeDynamicTask("com.cleo.cic.cockpit.core.inbound.inboundCockpitReferenceBPS", "bps1://BusinessProcessScript").execute(p_inputDataFragment, p_context, f_CockpitRuleset, variable(String.class, "867"), f_v_PartnerName, v_v_targetcontext);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_v_targetcontext, variable(String.class, "env.var.User_Reference_1"), new ContextPointVar(f_v_OrderNumber));
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_v_targetcontext, variable(String.class, "env.var.User_Reference_2"), new ContextPointVar(v_v_date));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_v_targetcontext, variable(String.class, "env.var.User_Reference_3"), new ContextPointVar(f_v_CustomerID));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.adapters.WriteInboundFilesAD", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.adapters.WriteInboundFilesAD");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.adapters.WriteInboundFilesAD", "bps1://UnifiedAdapter").execute(v_v_target, null, f_v_filename, f_DocType, v_v_date, variable(String.class, "xml"), f_v_PartnerName, f_v_CustomerID, f_v_OrderNumber, f_v_OrderNumber);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		builder.addStep("Failure", "com.cleo.cic.cockpit.core.inbound.inboundErrorCockpitBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.inbound.inboundErrorCockpitBPS");
					return getInvokeDynamicTask("com.cleo.cic.cockpit.core.inbound.inboundErrorCockpitBPS", "bps1://BusinessProcessScript").execute(p_context, v_v_targetcontext, f_v_PartnerName, p_inputDataFragment);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, false));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
	
	public List<String> getFieldNames() {
		return Arrays.asList("f_ruleset", "f_v_PartnerName", "f_CloudEndpoint", "f_CockpitRuleset", "f_DocType", "f_v_filename", "f_v_CustomerID", "f_v_OrderNumber");
	}
	
	public void initialize(final Map<String, Object> map) {
		_setFieldWithMap(f_ruleset, "f_ruleset", map);
		_setFieldWithMap(f_v_PartnerName, "f_v_PartnerName", map);
		_setFieldWithMap(f_CloudEndpoint, "f_CloudEndpoint", map);
		_setFieldWithMap(f_CockpitRuleset, "f_CockpitRuleset", map);
		_setFieldWithMap(f_DocType, "f_DocType", map);
		_setFieldWithMap(f_v_filename, "f_v_filename", map);
		_setFieldWithMap(f_v_CustomerID, "f_v_CustomerID", map);
		_setFieldWithMap(f_v_OrderNumber, "f_v_OrderNumber", map);
	}
}
