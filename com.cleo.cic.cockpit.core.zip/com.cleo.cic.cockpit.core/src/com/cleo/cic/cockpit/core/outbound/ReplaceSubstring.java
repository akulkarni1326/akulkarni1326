package com.cleo.cic.cockpit.core.outbound;
import java.io.IOException;

 public class ReplaceSubstring{
    public String replaceDel (String source, String by, String with){
        String modData = null;
        try {
        	by = "\\" + by;
            modData = source.replaceAll(by,with);
        } catch (Exception e) {
            by = "\\" + by;
            modData = source.replaceAll(by,with);
            System.out.println(e);
        }
       // System.out.println(modData);
        return modData;
    }
    public String replaceEleSegDel(String rawData, int eleDelPos, int segDelPos){
        //System.out.println("method Name - replaceEleSegDel");
        String eleDelimiter = null;
        String segDelimiter = null;
        String target = null;
        eleDelimiter = rawData.substring(eleDelPos, eleDelPos + 1);
        //System.out.println("replaceEleSegDel eleDel" + eleDelimiter);
        target = replaceDel(rawData,eleDelimiter,"*");
        segDelimiter = rawData.substring(segDelPos, segDelPos + 1);
        //System.out.println("replaceEleSegDel segDel" + segDelimiter);
        target = replaceDel(target,segDelimiter,"~");
        return target;
    }
}

