package com.cleo.b2biaas.clarify;


public class InboundAddAggregates extends B2BAction {

	public void execute(
			com.extol.ebi.ruleset.lang.core.Object messageInfo, 
			com.extol.ebi.ruleset.lang.core.String key, 
			com.extol.ebi.ruleset.lang.core.String value) {
		String valRef = Utility.setEmptyStringIfNull(value);
		Aggregates aggregates=new Aggregates();
		aggregates.setKey(key.asJavaString());
		aggregates.setValue(valRef);
		((InboundMessageApiCallV2)messageInfo.asJavaObject()).aggregate(aggregates);
	}
}
