/**
 * @generated
 */
package com.otterproducts.core.system.n855;

import com.extol.ebi.transformationsettings.lib.*;

@SuppressWarnings("all")
public class Default855TransformationSettingsTS_Rt implements RtTransformationSettings {
	private RtConnectorSettings source;

	private RtConnectorSettings target;

	@Override
	public RtConnectorSettings getSource() {
		if (source == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();

			source = new RtConnectorSettings(helper);
		}
		return source;
	}

	@Override
	public RtConnectorSettings getTarget() {
		if (target == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();

			target = new RtConnectorSettings(helper);
		}
		return target;
	}
}
