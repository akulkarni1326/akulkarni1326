/**
 * @generated
 */
package com.xref.connection;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.database.lib.datasource.*;

@SuppressWarnings("all")
public class xrefinternalDS_Rt implements RtDataSource {
	@Override
	public String url() {
		return "jdbc:postgresql://kite-prod-2023-03-03.cleointegration.cloud:5432/kt_56d01f00-963b-41bd-a358-1eb405c9a11d";
	}

	@Override
	public String catalog() {
		return null;
	}
	
	@Override
	public String defaultSchema() {
		return "REFTABLES";
	}
	
	@Override
	public String username() {
		return "admin_56d01f00-963b-41bd-a358-1eb405c9a11d";
	}
	
	@Override
	public String password() {
		return "=Zg7Pan#-Kd,e)hT18#P8[t6o)x3CVEc";
	}

	private static final RtJdbcDriver jdbcDriver = initJdbcDriver();
	
	private static RtJdbcDriver initJdbcDriver() {
		List<String> classPathEntries = new ArrayList<>();
		
		return new RtJdbcDriver("org.postgresql.Driver", classPathEntries, xrefinternalDS_Rt.class.getClassLoader());
	}
	
	@Override
	public RtJdbcDriver jdbcDriver() {
		return jdbcDriver;
	}
}
