/**
* @generated
*/
package com.cleo.cic.cockpit.core.n810.outbound;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class outbound810v4010CockpitRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.DateTime v_currentDateTime;
	private com.extol.ebi.ruleset.lang.core.String v_currentDTMillisString;
	private com.extol.ebi.ruleset.lang.core.Number v_currentDTMillisNumeric;
	private com.extol.ebi.ruleset.lang.core.Number v_totalLineItemCounter;
	private com.extol.ebi.ruleset.lang.core.String v_totalLineItemsString;
	private com.extol.ebi.ruleset.lang.core.Object v_outboundMessage;
	private com.extol.ebi.ruleset.lang.core.String v_Date;
	private com.extol.ebi.ruleset.lang.core.String v_Total;
	private com.extol.ebi.ruleset.lang.core.String v_ParentMessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.String v_MessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> v_SplitReprocessParms;
	private com.extol.ebi.ruleset.lang.core.String v_ReprocessKey;
	private com.extol.ebi.ruleset.lang.core.Number v_ListCount;
	private com.extol.ebi.ruleset.lang.core.String v_ListCountString;
	private com.extol.ebi.ruleset.lang.core.String v_RouteValue;
	private com.cleo.cic.cockpit.core.cockpitRDO glb = addToContextMap(new com.cleo.cic.cockpit.core.cockpitRDO());
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.cleo.cic.cockpit.core.n810.n810v4010CockpitEDI_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "", new Block() { public void body() {
		
		
			createCompositeRule(2, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
					createSimpleRule(3, "new GetCurrentDateTime().execute() => #[this.v_currentDateTime]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
					outbound810v4010CockpitRS_Rt.this.v_currentDateTime = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
					createSimpleRule(4, "new GetMilliseconds().execute(this.v_currentDateTime) => #[this.v_currentDTMillisNumeric]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime var0 = outbound810v4010CockpitRS_Rt.this.v_currentDateTime;
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
					outbound810v4010CockpitRS_Rt.this.v_currentDTMillisNumeric = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(5, "new Move().execute(this.v_currentDTMillisNumeric) => #[this.v_currentDTMillisString]", action);
					final SourceNode var0 = toValueNode(outbound810v4010CockpitRS_Rt.this.v_currentDTMillisNumeric);
					final SourceNode result = action.execute(var0);
					outbound810v4010CockpitRS_Rt.this.v_currentDTMillisString = extractString(result);
				}
				createCompositeRule(6, "for source.Area2.sgIT1", new Block() { public void body() {
					final SourceNode s0_Area2 = source.get("Area2");
					if (exists(s0_Area2)) {
					for (final SourceNode s1_cur_sgIT1 : s0_Area2.getIterable("sgIT1")) {
				
				
					createCompositeRule(7, "for source.Area2.sgIT1.current.IT1", new Block() { public void body() {
						final SourceNode s2_IT1 = s1_cur_sgIT1.get("IT1");
						if (exists(s2_IT1)) {
					
					
						{
							com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
							createSimpleRule(8, "new Add().execute(this.v_totalLineItemCounter, 1, 0) => #[this.v_totalLineItemCounter]", action);
							final com.extol.ebi.ruleset.lang.core.Number var0 = outbound810v4010CockpitRS_Rt.this.v_totalLineItemCounter;
							final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
							final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(0);
							final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
							outbound810v4010CockpitRS_Rt.this.v_totalLineItemCounter = result;
						}
					}}}).run();
				}}}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(9, "new Move().execute(this.v_totalLineItemCounter) => #[this.v_totalLineItemsString]", action);
					final SourceNode var0 = toValueNode(outbound810v4010CockpitRS_Rt.this.v_totalLineItemCounter);
					final SourceNode result = action.execute(var0);
					outbound810v4010CockpitRS_Rt.this.v_totalLineItemsString = extractString(result);
				}
			}}).run();
			{
				boolean conditionResult;
				{
					com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
					createRuleCondition(10, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG324) => #[]", condition);
					final SourceNode var0 = source.get("Area1").get("BIG").get("BIG324");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
					
					conditionResult = result.asJavaBoolean().booleanValue();
				}
				if (conditionResult) {
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(10, "new Move().execute(source.Area1.BIG.BIG324) => #[this.v_ParentMessageId]", action);
					final SourceNode var0 = source.get("Area1").get("BIG").get("BIG324");
					final SourceNode result = action.execute(var0);
					outbound810v4010CockpitRS_Rt.this.v_ParentMessageId = extractString(result);
				}
			}
			{
				boolean conditionResult;
				{
					com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
					createRuleCondition(11, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG76) => #[]", condition);
					final SourceNode var0 = source.get("Area1").get("BIG").get("BIG76");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
					
					conditionResult = result.asJavaBoolean().booleanValue();
				}
				if (conditionResult) {
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(11, "new Move().execute(source.Area1.BIG.BIG76) => #[this.v_MessageId]", action);
					final SourceNode var0 = source.get("Area1").get("BIG").get("BIG76");
					final SourceNode result = action.execute(var0);
					outbound810v4010CockpitRS_Rt.this.v_MessageId = extractString(result);
				}
			}
			{
				com.cleo.b2biaas.clarify.OutboundCreateMessageHeader action = new com.cleo.b2biaas.clarify.OutboundCreateMessageHeader();
				createSimpleRule(12, "new com.cleo.b2biaas.clarify.OutboundCreateMessageHeader().execute(this.glb.tpName, \"810\", this.v_ParentMessageId, this.v_MessageId, this.v_currentDTMillisString, \"true\", \"USD\", this.glb.logOfMsgId, this.glb.tradingPartnerId) => #[this.v_outboundMessage]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = outbound810v4010CockpitRS_Rt.this.glb.tpName;
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("810");
				final com.extol.ebi.ruleset.lang.core.String var2 = outbound810v4010CockpitRS_Rt.this.v_ParentMessageId;
				final com.extol.ebi.ruleset.lang.core.String var3 = outbound810v4010CockpitRS_Rt.this.v_MessageId;
				final com.extol.ebi.ruleset.lang.core.String var4 = outbound810v4010CockpitRS_Rt.this.v_currentDTMillisString;
				final com.extol.ebi.ruleset.lang.core.String var5 = asString("true");
				final com.extol.ebi.ruleset.lang.core.String var6 = asString("USD");
				final com.extol.ebi.ruleset.lang.core.String var7 = outbound810v4010CockpitRS_Rt.this.glb.logOfMsgId;
				final com.extol.ebi.ruleset.lang.core.String var8 = outbound810v4010CockpitRS_Rt.this.glb.tradingPartnerId;
				final com.extol.ebi.ruleset.lang.core.Object result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8);
				outbound810v4010CockpitRS_Rt.this.v_outboundMessage = result;
			}
			{
				boolean conditionResult;
				{
					com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
					createRuleCondition(13, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG324) => #[]", condition);
					final SourceNode var0 = source.get("Area1").get("BIG").get("BIG324");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
					
					conditionResult = result.asJavaBoolean().booleanValue();
				}
				if (conditionResult) {
					com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2();
					createSimpleRule(13, "new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2().execute(this.v_outboundMessage, \"Order ID: \",\"\", source.Area1.BIG.BIG324) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = outbound810v4010CockpitRS_Rt.this.v_outboundMessage;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("Order ID: ");
					final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
					final com.extol.ebi.ruleset.lang.core.String var3 = extractString(source.get("Area1").get("BIG").get("BIG324"));
					action.execute(var0, var1, var2, var3);
				}
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(14, "new Move().execute(source.Area1.BIG.BIG373_3) => #[this.v_Date]", action);
				final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373_3");
				final SourceNode result = action.execute(var0);
				outbound810v4010CockpitRS_Rt.this.v_Date = extractString(result);
			}
			{
				boolean conditionResult;
				{
					com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
					createRuleCondition(15, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG373_3) => #[]", condition);
					final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373_3");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
					
					conditionResult = result.asJavaBoolean().booleanValue();
				}
				if (conditionResult) {
					com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2();
					createSimpleRule(15, "new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2().execute(this.v_outboundMessage, \"Order Date: \",\"{d}\", this.v_Date) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = outbound810v4010CockpitRS_Rt.this.v_outboundMessage;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("Order Date: ");
					final com.extol.ebi.ruleset.lang.core.String var2 = asString("{d}");
					final com.extol.ebi.ruleset.lang.core.String var3 = outbound810v4010CockpitRS_Rt.this.v_Date;
					action.execute(var0, var1, var2, var3);
				}
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(16, "new Move().execute(source.Area1.BIG.BIG373) => #[this.v_Date]", action);
				final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373");
				final SourceNode result = action.execute(var0);
				outbound810v4010CockpitRS_Rt.this.v_Date = extractString(result);
			}
			{
				boolean conditionResult;
				{
					com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
					createRuleCondition(17, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG373) => #[]", condition);
					final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
					
					conditionResult = result.asJavaBoolean().booleanValue();
				}
				if (conditionResult) {
					com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2();
					createSimpleRule(17, "new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2().execute(this.v_outboundMessage, \"Invoice Date: \",\"{d}\", this.v_Date) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = outbound810v4010CockpitRS_Rt.this.v_outboundMessage;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("Invoice Date: ");
					final com.extol.ebi.ruleset.lang.core.String var2 = asString("{d}");
					final com.extol.ebi.ruleset.lang.core.String var3 = outbound810v4010CockpitRS_Rt.this.v_Date;
					action.execute(var0, var1, var2, var3);
				}
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(18, "new Move().execute(source.Area3.TDS.TDS610) => #[this.v_Total]", action);
				final SourceNode var0 = source.get("Area3").get("TDS").get("TDS610");
				final SourceNode result = action.execute(var0);
				outbound810v4010CockpitRS_Rt.this.v_Total = extractString(result);
			}
			{
				boolean conditionResult;
				{
					com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
					createRuleCondition(19, "new IsNotNullOrWhiteSpaces().execute(source.Area3.TDS.TDS610) => #[]", condition);
					final SourceNode var0 = source.get("Area3").get("TDS").get("TDS610");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
					
					conditionResult = result.asJavaBoolean().booleanValue();
				}
				if (conditionResult) {
					com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2();
					createSimpleRule(19, "new com.cleo.b2biaas.clarify.OutboundAddMessageDetailsV2().execute(this.v_outboundMessage, \"Grand Total: \",\"\", this.v_Total) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = outbound810v4010CockpitRS_Rt.this.v_outboundMessage;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("Grand Total: ");
					final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
					final com.extol.ebi.ruleset.lang.core.String var3 = outbound810v4010CockpitRS_Rt.this.v_Total;
					action.execute(var0, var1, var2, var3);
				}
			}
			createCompositeRule(20, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.string.Split action = new com.extol.ebi.reactor.lib.actions.string.Split();
					createSimpleRule(21, "new Split().execute(\",\", this.glb.ReprocessParms) => #[this.v_SplitReprocessParms]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = asString(",");
					final com.extol.ebi.ruleset.lang.core.String var1 = outbound810v4010CockpitRS_Rt.this.glb.ReprocessParms;
					final com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> result = action.execute(var0, var1);
					outbound810v4010CockpitRS_Rt.this.v_SplitReprocessParms = result;
				}
				createCompositeRule(22, "for this.v_SplitReprocessParms", new Block() { public void body() {
					if(outbound810v4010CockpitRS_Rt.this.v_SplitReprocessParms != null) {
					for (final com.extol.ebi.ruleset.lang.core.String cur_v_SplitReprocessParms : outbound810v4010CockpitRS_Rt.this.v_SplitReprocessParms) {
				
				
					createCompositeRule(23, "", new Block() { public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
							createSimpleRule(24, "new Add().execute(1, this.v_ListCount, null) => #[this.v_ListCount]", action);
							final com.extol.ebi.ruleset.lang.core.Number var0 = asNumber(1);
							final com.extol.ebi.ruleset.lang.core.Number var1 = outbound810v4010CockpitRS_Rt.this.v_ListCount;
							final com.extol.ebi.ruleset.lang.core.Number var2 = null;
							final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
							outbound810v4010CockpitRS_Rt.this.v_ListCount = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(25, "new Move().execute(this.v_ListCount) => #[this.v_ListCountString]", action);
							final SourceNode var0 = toValueNode(outbound810v4010CockpitRS_Rt.this.v_ListCount);
							final SourceNode result = action.execute(var0);
							outbound810v4010CockpitRS_Rt.this.v_ListCountString = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(26, "new Move().execute(\"RouteValue\") => #[this.v_ReprocessKey]", action);
							final SourceNode var0 = toValueNode(asString("RouteValue"));
							final SourceNode result = action.execute(var0);
							outbound810v4010CockpitRS_Rt.this.v_ReprocessKey = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(27, "new ConcatenateMany().execute(null, null, this.v_ReprocessKey, \"0\", this.v_ListCountString, null, null, null, null, null, null, null) => #[this.v_ReprocessKey]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = null;
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = null;
							final SourceNode var2 = toValueNode(outbound810v4010CockpitRS_Rt.this.v_ReprocessKey);
							final SourceNode var3 = toValueNode(asString("0"));
							final SourceNode var4 = toValueNode(outbound810v4010CockpitRS_Rt.this.v_ListCountString);
							final SourceNode var5 = toNullValueNode();
							final SourceNode var6 = toNullValueNode();
							final SourceNode var7 = toNullValueNode();
							final SourceNode var8 = toNullValueNode();
							final SourceNode var9 = toNullValueNode();
							final SourceNode var10 = toNullValueNode();
							final SourceNode var11 = toNullValueNode();
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							outbound810v4010CockpitRS_Rt.this.v_ReprocessKey = result;
						}
					}}).run();
					createCompositeRule(28, "", new Block() { public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.collection.ListGet action = new com.extol.ebi.reactor.lib.actions.collection.ListGet();
							createSimpleRule(29, "new ListGet().execute(this.v_SplitReprocessParms, this.v_ListCount) => #[this.v_RouteValue]", action);
							final com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> var0 = outbound810v4010CockpitRS_Rt.this.v_SplitReprocessParms;
							final com.extol.ebi.ruleset.lang.core.Number var1 = outbound810v4010CockpitRS_Rt.this.v_ListCount;
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
							outbound810v4010CockpitRS_Rt.this.v_RouteValue = result;
						}
					}}).run();
					{
						com.cleo.b2biaas.clarify.OutboundAddReprocessingString action = new com.cleo.b2biaas.clarify.OutboundAddReprocessingString();
						createSimpleRule(30, "new com.cleo.b2biaas.clarify.OutboundAddReprocessingString().execute(this.v_outboundMessage, this.v_ReprocessKey, this.v_RouteValue) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = outbound810v4010CockpitRS_Rt.this.v_outboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = outbound810v4010CockpitRS_Rt.this.v_ReprocessKey;
						final com.extol.ebi.ruleset.lang.core.String var2 = outbound810v4010CockpitRS_Rt.this.v_RouteValue;
						action.execute(var0, var1, var2);
					}
				}}}}).run();
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNull condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNull();
						createRuleCondition(31, "new IsNotNull().execute(this.glb.originalLOM) => #[]", condition);
						final SourceNode var0 = toValueNode(outbound810v4010CockpitRS_Rt.this.glb.originalLOM);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.OutboundAddReprocessingString action = new com.cleo.b2biaas.clarify.OutboundAddReprocessingString();
						createSimpleRule(31, "new com.cleo.b2biaas.clarify.OutboundAddReprocessingString().execute(this.v_outboundMessage, \"originalLOM\", this.glb.originalLOM) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = outbound810v4010CockpitRS_Rt.this.v_outboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("originalLOM");
						final com.extol.ebi.ruleset.lang.core.String var2 = outbound810v4010CockpitRS_Rt.this.glb.originalLOM;
						action.execute(var0, var1, var2);
					}
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(32, "new Move().execute(\"SplitCode\") => #[this.env.User_Reference_1]", action);
					final SourceNode var0 = toValueNode(asString("SplitCode"));
					final SourceNode result = action.execute(var0);
					outbound810v4010CockpitRS_Rt.this.env.User_Reference_1 = extractString(result);
				}
			}}).run();
			{
				com.cleo.b2biaas.clarify.OutboundCloseMessage action = new com.cleo.b2biaas.clarify.OutboundCloseMessage();
				createSimpleRule(33, "new com.cleo.b2biaas.clarify.OutboundCloseMessage().execute(this.v_outboundMessage) => #[]", action);
				final com.extol.ebi.ruleset.lang.core.Object var0 = outbound810v4010CockpitRS_Rt.this.v_outboundMessage;
				action.execute(var0);
			}
		}}).run();
	}

}
