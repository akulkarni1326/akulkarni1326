/**
* @generated
*/
package com.otterproducts.core.system.n856;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.ConvertToString;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.transformation.CreateContextPoint;
import com.extol.ebi.bps.lib.tasks.transformation.SetContextPointValue;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class otterproducts_Outbound856LauncherBPS_Rt extends AbstractCatalyst {
	
	public otterproducts_Outbound856LauncherBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_payload, @ParameterType(String.class) Variable<String> p_fileName) {
		final Variable<StorageNode> v_sourceContext = variable(StorageNode.class, null);
		final Variable<StorageNode> v_targetContext = variable(StorageNode.class, null);
		final Variable<String> v_orderUUID = variable(String.class, "SilencercoOutbound856LauncherBPS");
		final Variable<String> v_v_bpsName = variable(String.class, null);
		final Variable<StorageNode> v_v_Target = variable(StorageNode.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Context Point - Create", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Create");
					CreateContextPoint task = new CreateContextPoint();
					setupTask(task);
					return task.execute(v_sourceContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Convert to String", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert to String");
					ConvertToString task = new ConvertToString();
					setupTask(task);
					return task.execute(p_payload, v_orderUUID);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(v_sourceContext, variable(String.class, "glb.var.SourceData"), new ContextPointVar(v_orderUUID));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.otterproducts.core.system.n856.otterproducts_Outbound856DARS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.otterproducts.core.system.n856.otterproducts_Outbound856DARS");
					return getInvokeDynamicTask("com.otterproducts.core.system.n856.otterproducts_Outbound856DARS", "bps1://Ruleset").execute(p_payload, v_v_Target, literalTypeFromString(TransformationSettings.class, "com.cleo.b2bcloud.core.DefaultTransformationSettingsTS"), null, v_sourceContext, v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Envelope Assembly By Context Point", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Envelope Assembly By Context Point");
					return getInvokeDynamicTask("com.extol.ebi.bps.lib.bps.EnvelopeAssemblyByContextPoint", "bps1://BusinessProcessScript").execute(v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep("Success", "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		builder.addStep("Failure", "com.cleo.b2bcloud.core.process.B2BCloudStandardErrorBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.process.B2BCloudStandardErrorBPS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.process.B2BCloudStandardErrorBPS", "bps1://BusinessProcessScript").execute(v_v_bpsName);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, false));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
