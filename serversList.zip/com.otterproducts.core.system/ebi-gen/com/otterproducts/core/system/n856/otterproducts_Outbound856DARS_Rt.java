/**
* @generated
*/
package com.otterproducts.core.system.n856;

import java.io.IOException;

import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.exceptions.ReactorIOException;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class otterproducts_Outbound856DARS_Rt extends AbstractReactor<RtPojoSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.String v_tpId;
	private com.extol.ebi.lang.storage.StorageNode sourcePayload;
	private com.extol.ebi.lang.storage.StorageNode v_sourceContext;
	private com.extol.ebi.ruleset.lang.core.String v_PartnerName;
	private com.otterproducts.core.system.outbound.OtterProductsRDO glb = addToContextMap(new com.otterproducts.core.system.outbound.OtterProductsRDO());
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	
	public SchemaProvider<RtPojoSchema> getSourceSchema() {
		return new com.otterproducts.core.system.n856.Shipment_OBJ_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new XMLObjectConnector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "for source.envelope", new Block() { public void body() {
			final SourceNode s0_envelope = source.get("envelope");
			if (exists(s0_envelope)) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(source.envelope.Header.delivery.to.address) => #[this.v_PartnerName]", action);
				final SourceNode var0 = s0_envelope.get("Header").get("delivery").get("to").get("address");
				final SourceNode result = action.execute(var0);
				otterproducts_Outbound856DARS_Rt.this.v_PartnerName = extractString(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(856) => #[this.v_tpId]", action);
				final SourceNode var0 = toValueNode(asNumber(856));
				final SourceNode result = action.execute(var0);
				otterproducts_Outbound856DARS_Rt.this.v_tpId = extractString(result);
			}
			{
				com.extol.ebi.reactor.server.actions.route.AssembleContext action = new com.extol.ebi.reactor.server.actions.route.AssembleContext();
				createSimpleRule(4, "new com.extol.ebi.reactor.server.actions.route.AssembleContext().execute() => #[this.v_sourceContext]", action);
				final com.extol.ebi.lang.storage.StorageNode result = action.execute();
				otterproducts_Outbound856DARS_Rt.this.v_sourceContext = result;
			}
			{
				com.extol.ebi.reactor.server.actions.general.CreateStorageNodeWithId action = new com.extol.ebi.reactor.server.actions.general.CreateStorageNodeWithId();
				createSimpleRule(5, "new com.extol.ebi.reactor.server.actions.general.CreateStorageNodeWithId().execute(this.glb.SourceData) => #[this.sourcePayload]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = otterproducts_Outbound856DARS_Rt.this.glb.SourceData;
				final com.extol.ebi.lang.storage.StorageNode result = action.execute(var0);
				otterproducts_Outbound856DARS_Rt.this.sourcePayload = result;
			}
		}}}).run();
		{
			com.otterproducts.core.system.outbound.OutboundAI.ExecuteContentRouter action = new com.otterproducts.core.system.outbound.OutboundAI.ExecuteContentRouter();
			createSimpleRule(6, "new com.otterproducts.core.system.outbound.OutboundAI$ExecuteContentRouter().execute(this.v_tpId, this.v_PartnerName, this.v_sourceContext, this.sourcePayload) => #[]", action);
			final com.extol.ebi.ruleset.lang.core.String var0 = otterproducts_Outbound856DARS_Rt.this.v_tpId;
			final com.extol.ebi.ruleset.lang.core.String var1 = otterproducts_Outbound856DARS_Rt.this.v_PartnerName;
			final com.extol.ebi.lang.storage.StorageNode var2 = otterproducts_Outbound856DARS_Rt.this.v_sourceContext;
			final com.extol.ebi.lang.storage.StorageNode var3 = otterproducts_Outbound856DARS_Rt.this.sourcePayload;
			final com.extol.ebi.ruleset.lang.core.Boolean result = action.execute(var0, var1, var2, var3);
		}
	}

}
