/**
 * @generated
 */
package com.otterproducts.core.system.n850;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.reactor.pojo.lib.*;

@SuppressWarnings("all")
public class PurchaseOrderMessageOBJ_Rt implements RuntimePojoSchemaProvider {
	private static RtPojoSchema schema_PurchaseOrderMessageOBJ;

	public RtPojoSchema getSchema() {
		if (schema_PurchaseOrderMessageOBJ == null) {
			RtPojoSchemaDetails schema_details_PurchaseOrderMessageOBJ = new RtPojoSchemaDetails();
			schema_details_PurchaseOrderMessageOBJ.setRootNodeName("purchaseOrderMessage");
			schema_details_PurchaseOrderMessageOBJ.setRootNodeType(com.otterproducts.core.system.n850.PurchaseOrderMessage.class);
			schema_details_PurchaseOrderMessageOBJ.setSerializationType(RtSerializationType.XML);
			schema_details_PurchaseOrderMessageOBJ.setBasePackages("com.otterproducts.core.system.n850");

			schema_PurchaseOrderMessageOBJ = new RtPojoSchema(schema_details_PurchaseOrderMessageOBJ);
		}

		return schema_PurchaseOrderMessageOBJ;
	}
}
