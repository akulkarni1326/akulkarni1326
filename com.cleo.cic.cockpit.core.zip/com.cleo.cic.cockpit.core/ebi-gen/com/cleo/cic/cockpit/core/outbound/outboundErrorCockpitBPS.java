package com.cleo.cic.cockpit.core.outbound;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class outboundErrorCockpitBPS implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode sourceContext;
    
    @TupleIndex(value = 1)
    public StorageNode targetContext;
    
    @TupleIndex(value = 2)
    public com.extol.ebi.bps.lang.String partnerName;
    
    @TupleIndex(value = 3)
    public com.extol.ebi.bps.lang.String tpIdValue;
    
    @TupleIndex(value = 4)
    public StorageNode sourceData;
    
    @TupleIndex(value = 5)
    public com.extol.ebi.bps.lang.String docType;
    
    @TupleIndex(value = 6)
    public com.extol.ebi.bps.lang.String ReprocessParams;
    
    @TupleIndex(value = 7)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public outboundErrorCockpitBPS.ResultTuple execute(final StorageNode sourceContext, final StorageNode targetContext, final com.extol.ebi.bps.lang.String partnerName, final com.extol.ebi.bps.lang.String tpIdValue, final StorageNode sourceData, final com.extol.ebi.bps.lang.String docType, final com.extol.ebi.bps.lang.String ReprocessParams) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode sourceContext;
      
      @TupleIndex(value = 1)
      public StorageNode targetContext;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.String partnerName;
      
      @TupleIndex(value = 3)
      public com.extol.ebi.ruleset.lang.core.String tpIdValue;
      
      @TupleIndex(value = 4)
      public StorageNode sourceData;
      
      @TupleIndex(value = 5)
      public com.extol.ebi.ruleset.lang.core.String docType;
      
      @TupleIndex(value = 6)
      public com.extol.ebi.ruleset.lang.core.String ReprocessParams;
      
      @TupleIndex(value = 7)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public outboundErrorCockpitBPS.RulesetAction.ResultTuple execute(final StorageNode sourceContext, final StorageNode targetContext, final com.extol.ebi.ruleset.lang.core.String partnerName, final com.extol.ebi.ruleset.lang.core.String tpIdValue, final StorageNode sourceData, final com.extol.ebi.ruleset.lang.core.String docType, final com.extol.ebi.ruleset.lang.core.String ReprocessParams) {
      Object[] _bps_parameters = new Object[7];
      _bps_parameters[0] = sourceContext;
      _bps_parameters[1] = targetContext;
      _bps_parameters[2] = toBpsString(partnerName);
      _bps_parameters[3] = toBpsString(tpIdValue);
      _bps_parameters[4] = sourceData;
      _bps_parameters[5] = toBpsString(docType);
      _bps_parameters[6] = toBpsString(ReprocessParams);
      
      boolean _exit_PassStatus = launchScript("com.cleo.cic.cockpit.core", "com.cleo.cic.cockpit.core.outbound.outboundErrorCockpitBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.sourceContext = asStorageNode(_bps_parameters[0]);
      resultTuple.targetContext = asStorageNode(_bps_parameters[1]);
      resultTuple.partnerName = asString(_bps_parameters[2]);
      resultTuple.tpIdValue = asString(_bps_parameters[3]);
      resultTuple.sourceData = asStorageNode(_bps_parameters[4]);
      resultTuple.docType = asString(_bps_parameters[5]);
      resultTuple.ReprocessParams = asString(_bps_parameters[6]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
}
