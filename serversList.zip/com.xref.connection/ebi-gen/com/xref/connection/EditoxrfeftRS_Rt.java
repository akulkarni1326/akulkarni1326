/**
* @generated
*/
package com.xref.connection;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.database.adapter.lib.connectors.*;
import com.extol.ebi.reactor.database.lib.schema.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;

@SuppressWarnings("all")
public class EditoxrfeftRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,RtDatabaseSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String v_Ref01;
	private com.extol.ebi.ruleset.lang.core.String v_Ref02;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.otterproducts.core.edi.schemas.n850v4010EDI_Rt();
	}
	
	public SchemaProvider<RtDatabaseSchema> getTargetSchema() {
		return new com.xref.connection.xrefSchemaDB_Rt();
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return new DatabaseFileConnector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "for source", new Block() { public void body() {
		
		
			createCompositeRule(2, "for source.Area1.REF", new Block() { public void body() {
				final SourceNode s0_Area1 = source.get("Area1");
				if (exists(s0_Area1)) {
				for (final SourceNode s1_cur_REF : s0_Area1.getIterable("REF")) {
			
			
				createCompositeRule(3, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(3, "new StringEquals().execute(source.Area1.REF.current.REF128, \"VN\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF128"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("VN");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(4, "new Move().execute(source.Area1.REF.current.REF128) => #[this.v_Ref01]", action);
						final SourceNode var0 = s1_cur_REF.get("REF128");
						final SourceNode result = action.execute(var0);
						EditoxrfeftRS_Rt.this.v_Ref01 = extractString(result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(5, "new Move().execute(source.Area1.REF.current.REF127) => #[this.v_Ref02]", action);
						final SourceNode var0 = s1_cur_REF.get("REF127");
						final SourceNode result = action.execute(var0);
						EditoxrfeftRS_Rt.this.v_Ref02 = extractString(result);
					}
				}}).run();
			}}}}).run();
			createCompositeRule(6, "for source.Area2.sgPO1 initNew target._ItemNumbers", new Block() { public void body() {
				final SourceNode s0_Area2 = source.get("Area2");
				if (exists(s0_Area2)) {
				for (final SourceNode s1_cur_sgPO1 : s0_Area2.getIterable("sgPO1")) {
			
				final TargetNode t0_cur__ItemNumbers = target.create(at("_ItemNumbers"));
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(7, "new Move().execute(this.v_Ref01) => #[target._ItemNumbers.current.refqual]", action);
					final SourceNode var0 = toValueNode(EditoxrfeftRS_Rt.this.v_Ref01);
					final SourceNode result = action.execute(var0);
					t0_cur__ItemNumbers.set(at("refqual"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(8, "new Move().execute(this.v_Ref02) => #[target._ItemNumbers.current.refvalue]", action);
					final SourceNode var0 = toValueNode(EditoxrfeftRS_Rt.this.v_Ref02);
					final SourceNode result = action.execute(var0);
					t0_cur__ItemNumbers.set(at("refvalue"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(9, "new Move().execute(source.Area1.BEG.BEG324) => #[target._ItemNumbers.current.ponumber]", action);
					final SourceNode var0 = source.get("Area1").get("BEG").get("BEG324");
					final SourceNode result = action.execute(var0);
					t0_cur__ItemNumbers.set(at("ponumber"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(10, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1235_3) => #[target._ItemNumbers.current.qual]", action);
					final SourceNode var0 = s1_cur_sgPO1.get("PO1").get("PO1235_3");
					final SourceNode result = action.execute(var0);
					t0_cur__ItemNumbers.set(at("qual"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(11, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1234_3) => #[target._ItemNumbers.current.itemnumber]", action);
					final SourceNode var0 = s1_cur_sgPO1.get("PO1").get("PO1234_3");
					final SourceNode result = action.execute(var0);
					t0_cur__ItemNumbers.set(at("itemnumber"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(12, "new Move().execute(0) => #[target._ItemNumbers.current.cicSerialId]", action);
					final SourceNode var0 = toValueNode(asNumber(0));
					final SourceNode result = action.execute(var0);
					t0_cur__ItemNumbers.set(at("cicSerialId"), result);
				}
			}}}}).run();
		}}).run();
	}

}
