package com.cleo.cic.cockpit.core.inbound;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class inboundCockpitReferenceBPS implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode sourceData;
    
    @TupleIndex(value = 1)
    public StorageNode contextSource;
    
    @TupleIndex(value = 2)
    public Ruleset transformationRuleset;
    
    @TupleIndex(value = 3)
    public com.extol.ebi.bps.lang.String documentType;
    
    @TupleIndex(value = 4)
    public com.extol.ebi.bps.lang.String partnerName;
    
    @TupleIndex(value = 5)
    public StorageNode contextTarget;
    
    @TupleIndex(value = 6)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public inboundCockpitReferenceBPS.ResultTuple execute(final StorageNode sourceData, final StorageNode contextSource, final Ruleset transformationRuleset, final com.extol.ebi.bps.lang.String documentType, final com.extol.ebi.bps.lang.String partnerName, final StorageNode contextTarget) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode sourceData;
      
      @TupleIndex(value = 1)
      public StorageNode contextSource;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.Object transformationRuleset;
      
      @TupleIndex(value = 3)
      public com.extol.ebi.ruleset.lang.core.String documentType;
      
      @TupleIndex(value = 4)
      public com.extol.ebi.ruleset.lang.core.String partnerName;
      
      @TupleIndex(value = 5)
      public StorageNode contextTarget;
      
      @TupleIndex(value = 6)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public inboundCockpitReferenceBPS.RulesetAction.ResultTuple execute(final StorageNode sourceData, final StorageNode contextSource, final com.extol.ebi.ruleset.lang.core.Object transformationRuleset, final com.extol.ebi.ruleset.lang.core.String documentType, final com.extol.ebi.ruleset.lang.core.String partnerName, final StorageNode contextTarget) {
      Object[] _bps_parameters = new Object[6];
      _bps_parameters[0] = sourceData;
      _bps_parameters[1] = contextSource;
      _bps_parameters[2] = toBpsObject(transformationRuleset);
      _bps_parameters[3] = toBpsString(documentType);
      _bps_parameters[4] = toBpsString(partnerName);
      _bps_parameters[5] = contextTarget;
      
      boolean _exit_PassStatus = launchScript("com.cleo.cic.cockpit.core", "com.cleo.cic.cockpit.core.inbound.inboundCockpitReferenceBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.sourceData = asStorageNode(_bps_parameters[0]);
      resultTuple.contextSource = asStorageNode(_bps_parameters[1]);
      resultTuple.transformationRuleset = asObject(_bps_parameters[2]);
      resultTuple.documentType = asString(_bps_parameters[3]);
      resultTuple.partnerName = asString(_bps_parameters[4]);
      resultTuple.contextTarget = asStorageNode(_bps_parameters[5]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
}
