/**
* @generated
*/
package com.otterproducts.core.edi.outbound.n855;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class Baseotterproducts_855v4010RS_Rt extends AbstractReactor<RtPojoSchema,RtEdiDerivedMessageSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String v_date;
	private com.extol.ebi.ruleset.lang.core.DateTime v_BAK04;
	private com.extol.ebi.ruleset.lang.core.String v_UOM;
	private com.extol.ebi.ruleset.lang.core.Number v_count;
	private com.extol.ebi.ruleset.lang.core.Number v_CTT02;
	private com.extol.ebi.ruleset.lang.core.Number v_Qty;
	
	public SchemaProvider<RtPojoSchema> getSourceSchema() {
		return new com.otterproducts.core.system.n855.PurchaseOrderAcknowledgementMessageOBJ_Rt();
	}
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getTargetSchema() {
		return new com.otterproducts.core.edi.schemas.n855v4010EDI_Rt();
	}
	
	public Connector getSourceConnector() {
		return new XMLObjectConnector();
	}

	public Connector getTargetConnector() {
		return new X12Connector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "initNew target.Area1.BAK", new Block() { public void body() {
		
			final TargetNode t0_Area1 = target.getLast(at("Area1"));
			final TargetNode t1_BAK = t0_Area1.getLast(at("BAK"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(\"00\") => #[target.Area1.BAK.BAK353]", action);
				final SourceNode var0 = toValueNode(asString("00"));
				final SourceNode result = action.execute(var0);
				t1_BAK.set(at("BAK353"), result);
			}
			createCompositeRule(3, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(3, "new StringEquals().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.OrderStatusName, \"Approved\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(source.get("purchaseOrderAcknowledgementMessage").get("CustomerOrder").get("OrderStatusName"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("Approved");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(4, "new Move().execute(\"AD\") => #[target.Area1.BAK.BAK587]", action);
					final SourceNode var0 = toValueNode(asString("AD"));
					final SourceNode result = action.execute(var0);
					t1_BAK.set(at("BAK587"), result);
				}
			}}).run();
			createCompositeRule(5, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.PurchaseOrderNumber", new Block() { public void body() {
				final SourceNode s0_purchaseOrderAcknowledgementMessage = source.get("purchaseOrderAcknowledgementMessage");
				if (exists(s0_purchaseOrderAcknowledgementMessage)) {
				final SourceNode s1_CustomerOrder = s0_purchaseOrderAcknowledgementMessage.get("CustomerOrder");
				if (exists(s1_CustomerOrder)) {
				final SourceNode s2_PurchaseOrderNumber = s1_CustomerOrder.get("PurchaseOrderNumber");
				if (exists(s2_PurchaseOrderNumber)) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(6, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.PurchaseOrderNumber) => #[target.Area1.BAK.BAK324]", action);
					final SourceNode var0 = s2_PurchaseOrderNumber;
					final SourceNode result = action.execute(var0);
					t1_BAK.set(at("BAK324"), result);
				}
			}}}}}).run();
			createCompositeRule(7, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.OrderDate", new Block() { public void body() {
				final SourceNode s0_purchaseOrderAcknowledgementMessage = source.get("purchaseOrderAcknowledgementMessage");
				if (exists(s0_purchaseOrderAcknowledgementMessage)) {
				final SourceNode s1_CustomerOrder = s0_purchaseOrderAcknowledgementMessage.get("CustomerOrder");
				if (exists(s1_CustomerOrder)) {
				final SourceNode s2_OrderDate = s1_CustomerOrder.get("OrderDate");
				if (exists(s2_OrderDate)) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(8, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.OrderDate) => #[this.v_date]", action);
					final SourceNode var0 = s2_OrderDate;
					final SourceNode result = action.execute(var0);
					Baseotterproducts_855v4010RS_Rt.this.v_date = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.string.Substring action = new com.extol.ebi.reactor.lib.actions.string.Substring();
					createSimpleRule(9, "new Substring().execute(this.v_date, 0, 10) => #[this.v_date]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = Baseotterproducts_855v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(0);
					final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(10);
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2);
					Baseotterproducts_855v4010RS_Rt.this.v_date = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.string.ExtractDigits action = new com.extol.ebi.reactor.lib.actions.string.ExtractDigits();
					createSimpleRule(10, "new ExtractDigits().execute(this.v_date) => #[this.v_date]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = Baseotterproducts_855v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
					Baseotterproducts_855v4010RS_Rt.this.v_date = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
					createSimpleRule(11, "new CreateDateTimeFromString().execute(this.v_date, \"yyyyMMdd\") => #[this.v_BAK04]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = Baseotterproducts_855v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyyMMdd");
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
					Baseotterproducts_855v4010RS_Rt.this.v_BAK04 = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(12, "new Move().execute(this.v_BAK04) => #[target.Area1.BAK.BAK373]", action);
					final SourceNode var0 = toValueNode(Baseotterproducts_855v4010RS_Rt.this.v_BAK04);
					final SourceNode result = action.execute(var0);
					t1_BAK.set(at("BAK373"), result);
				}
			}}}}}).run();
		}}).run();
		createCompositeRule(13, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine initNew target.Area2.sgPO1", new Block() { public void body() {
			final SourceNode s0_purchaseOrderAcknowledgementMessage = source.get("purchaseOrderAcknowledgementMessage");
			if (exists(s0_purchaseOrderAcknowledgementMessage)) {
			final SourceNode s1_CustomerOrder = s0_purchaseOrderAcknowledgementMessage.get("CustomerOrder");
			if (exists(s1_CustomerOrder)) {
			final SourceNode s2_CustomerOrderLines = s1_CustomerOrder.get("CustomerOrderLines");
			if (exists(s2_CustomerOrderLines)) {
			for (final SourceNode s3_cur_CustomerOrderLine : s2_CustomerOrderLines.getIterable("CustomerOrderLine")) {
		
			final TargetNode t0_Area2 = target.getLast(at("Area2"));
			final TargetNode t1_cur_sgPO1 = t0_Area2.create(at("sgPO1"));
		
			createCompositeRule(14, "initNew target.Area2.sgPO1.current.PO1", new Block() { public void body() {
			
				final TargetNode t2_PO1 = t1_cur_sgPO1.getLast(at("PO1"));
			
				createCompositeRule(15, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.Product.ProductId", new Block() { public void body() {
					final SourceNode s4_Product = s3_cur_CustomerOrderLine.get("Product");
					if (exists(s4_Product)) {
					final SourceNode s5_ProductId = s4_Product.get("ProductId");
					if (exists(s5_ProductId)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(16, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.Product.ProductId) => #[target.Area2.sgPO1.current.PO1.PO1234]", action);
						final SourceNode var0 = s5_ProductId;
						final SourceNode result = action.execute(var0);
						t2_PO1.set(at("PO1234"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(17, "new Move().execute(\"VN\") => #[target.Area2.sgPO1.current.PO1.PO1235]", action);
						final SourceNode var0 = toValueNode(asString("VN"));
						final SourceNode result = action.execute(var0);
						t2_PO1.set(at("PO1235"), result);
					}
				}}}}).run();
				createCompositeRule(18, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(18, "new StringEquals().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement, \"EACH\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_CustomerOrderLine.get("ProductQuantityUnitOfMeasurement"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("EACH");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(19, "new Move().execute(\"EA\") => #[target.Area2.sgPO1.current.PO1.PO1355]", action);
						final SourceNode var0 = toValueNode(asString("EA"));
						final SourceNode result = action.execute(var0);
						t2_PO1.set(at("PO1355"), result);
					}
				}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(20, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.OrderedQuantity) => #[target.Area2.sgPO1.current.PO1.PO1330, this.v_Qty]", action);
					final SourceNode var0 = s3_cur_CustomerOrderLine.get("OrderedQuantity");
					final SourceNode result = action.execute(var0);
					t2_PO1.set(at("PO1330"), result);
					Baseotterproducts_855v4010RS_Rt.this.v_Qty = extractNumber(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(21, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount) => #[target.Area2.sgPO1.current.PO1.PO1212]", action);
					final SourceNode var0 = s3_cur_CustomerOrderLine.get("ProductUnitPriceAmount");
					final SourceNode result = action.execute(var0);
					t2_PO1.set(at("PO1212"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(22, "new Move().execute(\"CT\") => #[target.Area2.sgPO1.current.PO1.PO1639]", action);
					final SourceNode var0 = toValueNode(asString("CT"));
					final SourceNode result = action.execute(var0);
					t2_PO1.set(at("PO1639"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
					createSimpleRule(23, "new Add().execute(this.v_Qty, this.v_CTT02, null) => #[this.v_CTT02]", action);
					final com.extol.ebi.ruleset.lang.core.Number var0 = Baseotterproducts_855v4010RS_Rt.this.v_Qty;
					final com.extol.ebi.ruleset.lang.core.Number var1 = Baseotterproducts_855v4010RS_Rt.this.v_CTT02;
					final com.extol.ebi.ruleset.lang.core.Number var2 = null;
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
					Baseotterproducts_855v4010RS_Rt.this.v_CTT02 = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(24, "new Move().execute(this.v_CTT02) => #[target.Area3.sgCTT.CTT.CTT347]", action);
					final SourceNode var0 = toValueNode(Baseotterproducts_855v4010RS_Rt.this.v_CTT02);
					final SourceNode result = action.execute(var0);
					target.set(at("Area3", "sgCTT", "CTT", "CTT347"), result);
				}
			}}).run();
			createCompositeRule(25, "initNew target.Area2.sgPO1.current.CTP", new Block() { public void body() {
			
				final TargetNode t2_cur_CTP = t1_cur_sgPO1.create(at("CTP"));
			
				createCompositeRule(26, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount", new Block() { public void body() {
					final SourceNode s4_ProductUnitPriceAmount = s3_cur_CustomerOrderLine.get("ProductUnitPriceAmount");
					if (exists(s4_ProductUnitPriceAmount)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(27, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount) => #[target.Area2.sgPO1.current.CTP.current.CTP212]", action);
						final SourceNode var0 = s4_ProductUnitPriceAmount;
						final SourceNode result = action.execute(var0);
						t2_cur_CTP.set(at("CTP212"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(28, "new Move().execute(\"ACT\") => #[target.Area2.sgPO1.current.CTP.current.CTP236]", action);
						final SourceNode var0 = toValueNode(asString("ACT"));
						final SourceNode result = action.execute(var0);
						t2_cur_CTP.set(at("CTP236"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(29, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.OrderedQuantity) => #[target.Area2.sgPO1.current.CTP.current.CTP380]", action);
						final SourceNode var0 = s3_cur_CustomerOrderLine.get("OrderedQuantity");
						final SourceNode result = action.execute(var0);
						t2_cur_CTP.set(at("CTP380"), result);
					}
					createCompositeRule(30, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(30, "new StringEquals().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement, \"EACH\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_CustomerOrderLine.get("ProductQuantityUnitOfMeasurement"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("EACH");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(31, "new Move().execute(\"EA\") => #[target.Area2.sgPO1.current.CTP.current.CTPC001.C00101]", action);
							final SourceNode var0 = toValueNode(asString("EA"));
							final SourceNode result = action.execute(var0);
							t2_cur_CTP.set(at("CTPC001", "C00101"), result);
						}
					}}).run();
				}}}).run();
			}}).run();
			createCompositeRule(32, "initNew target.Area2.sgPO1.current.sgACK.current.ACK", new Block() { public void body() {
			
				final TargetNode t2_cur_sgACK = t1_cur_sgPO1.getLast(at("sgACK"));
				final TargetNode t3_ACK = t2_cur_sgACK.getLast(at("ACK"));
			
				createCompositeRule(33, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.bool.BooleanEquals condition = new com.extol.ebi.reactor.lib.actions.bool.BooleanEquals();
					createRuleCondition(33, "new BooleanEquals().execute(source.purchaseOrderAcknowledgementMessage.OrderAcknowledgements.CustomerOrderLineAcknowledgement.current.IsAccepted, true) => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.Boolean var0 = extractBoolean(s0_purchaseOrderAcknowledgementMessage.get("OrderAcknowledgements").get("CustomerOrderLineAcknowledgement").get("IsAccepted"));
					final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(true);
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(34, "new Move().execute(\"AC\") => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK668]", action);
						final SourceNode var0 = toValueNode(asString("AC"));
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK668"), result);
					}
				}}).run();
				createCompositeRule(35, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.bool.BooleanEquals condition = new com.extol.ebi.reactor.lib.actions.bool.BooleanEquals();
					createRuleCondition(35, "new BooleanEquals().execute(source.purchaseOrderAcknowledgementMessage.OrderAcknowledgements.CustomerOrderLineAcknowledgement.current.IsQuantityChanged, false) => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.Boolean var0 = extractBoolean(s0_purchaseOrderAcknowledgementMessage.get("OrderAcknowledgements").get("CustomerOrderLineAcknowledgement").get("IsQuantityChanged"));
					final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(false);
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(36, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.OrderedQuantity) => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK380]", action);
						final SourceNode var0 = s3_cur_CustomerOrderLine.get("OrderedQuantity");
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK380"), result);
					}
				}}).run();
				createCompositeRule(37, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(37, "new StringEquals().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement, \"EACH\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_CustomerOrderLine.get("ProductQuantityUnitOfMeasurement"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("EACH");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(38, "new Move().execute(\"EA\") => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK355]", action);
						final SourceNode var0 = toValueNode(asString("EA"));
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK355"), result);
					}
				}}).run();
				createCompositeRule(39, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate", new Block() { public void body() {
					final SourceNode s4_PromisedShipDate = s3_cur_CustomerOrderLine.get("PromisedShipDate");
					if (exists(s4_PromisedShipDate)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(40, "new Move().execute(\"068\") => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK374]", action);
						final SourceNode var0 = toValueNode(asString("068"));
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK374"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(41, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate) => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK373]", action);
						final SourceNode var0 = s4_PromisedShipDate;
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK373"), result);
					}
				}}}).run();
			}}).run();
			createCompositeRule(42, "initNew target.Area2.sgPO1.current.sgACK.current.DTM", new Block() { public void body() {
			
				final TargetNode t2_cur_sgACK = t1_cur_sgPO1.getLast(at("sgACK"));
				final TargetNode t3_DTM = t2_cur_sgACK.getLast(at("DTM"));
			
				createCompositeRule(43, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate", new Block() { public void body() {
					final SourceNode s4_PromisedShipDate = s3_cur_CustomerOrderLine.get("PromisedShipDate");
					if (exists(s4_PromisedShipDate)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(44, "new Move().execute(\"067\") => #[target.Area2.sgPO1.current.sgACK.current.DTM.DTM374]", action);
						final SourceNode var0 = toValueNode(asString("067"));
						final SourceNode result = action.execute(var0);
						t3_DTM.set(at("DTM374"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(45, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate) => #[target.Area2.sgPO1.current.sgACK.current.DTM.DTM373]", action);
						final SourceNode var0 = s4_PromisedShipDate;
						final SourceNode result = action.execute(var0);
						t3_DTM.set(at("DTM373"), result);
					}
				}}}).run();
			}}).run();
			{
				com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
				createSimpleRule(46, "new Add().execute(this.v_count, 1, null) => #[this.v_count]", action);
				final com.extol.ebi.ruleset.lang.core.Number var0 = Baseotterproducts_855v4010RS_Rt.this.v_count;
				final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
				final com.extol.ebi.ruleset.lang.core.Number var2 = null;
				final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
				Baseotterproducts_855v4010RS_Rt.this.v_count = result;
			}
		}}}}}}).run();
		createCompositeRule(47, "initNew target.Area3.sgCTT.CTT", new Block() { public void body() {
		
			final TargetNode t0_Area3 = target.getLast(at("Area3"));
			final TargetNode t1_sgCTT = t0_Area3.getLast(at("sgCTT"));
			final TargetNode t2_CTT = t1_sgCTT.getLast(at("CTT"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(48, "new Move().execute(this.v_count) => #[target.Area3.sgCTT.CTT.CTT354]", action);
				final SourceNode var0 = toValueNode(Baseotterproducts_855v4010RS_Rt.this.v_count);
				final SourceNode result = action.execute(var0);
				t2_CTT.set(at("CTT354"), result);
			}
		}}).run();
	}

}
