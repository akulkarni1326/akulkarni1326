package com.cleo.cic.cockpit.core.outbound;

import java.io.IOException;

public class DelimiterReplace {
	public String replaceDelimiter (String ediData) throws IOException {
		String target = null;
        //System.out.println(ediData);
        ReplaceSubstring cockpitData= new ReplaceSubstring();
        //replace with * as element delimiter and ~ as segment delimiter
        if (ediData.startsWith("ST")){
            //System.out.println("Welcome to X12 World");
            target = cockpitData.replaceEleSegDel(ediData,2,14);
            //System.out.println("???" + target);
            return target;
        }
        
        else{
        	return ediData;
        }
	}


}
