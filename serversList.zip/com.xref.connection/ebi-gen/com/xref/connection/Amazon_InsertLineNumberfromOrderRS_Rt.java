/**
* @generated
*/
package com.xref.connection;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.database.adapter.lib.connectors.*;
import com.extol.ebi.reactor.database.lib.schema.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;

@SuppressWarnings("all")
public class Amazon_InsertLineNumberfromOrderRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,RtDatabaseSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String v_Ref01;
	private com.extol.ebi.ruleset.lang.core.String v_Ref02;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.otterproducts.core.edi.schemas.n850v4010EDI_Rt();
	}
	
	public SchemaProvider<RtDatabaseSchema> getTargetSchema() {
		return new com.xref.connection.InsertLinesAmazon_Rt();
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return new DatabaseFileConnector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "for source", new Block() { public void body() {
		
		
			createCompositeRule(2, "for source.Area2.sgPO1 initNew target._LineNumbers", new Block() { public void body() {
				final SourceNode s0_Area2 = source.get("Area2");
				if (exists(s0_Area2)) {
				for (final SourceNode s1_cur_sgPO1 : s0_Area2.getIterable("sgPO1")) {
			
				final TargetNode t0_cur__LineNumbers = target.create(at("_LineNumbers"));
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(3, "new Move().execute(source.Area1.BEG.BEG324) => #[target._LineNumbers.current.ponumber]", action);
					final SourceNode var0 = source.get("Area1").get("BEG").get("BEG324");
					final SourceNode result = action.execute(var0);
					t0_cur__LineNumbers.set(at("ponumber"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(4, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1330) => #[target._LineNumbers.current.qty]", action);
					final SourceNode var0 = s1_cur_sgPO1.get("PO1").get("PO1330");
					final SourceNode result = action.execute(var0);
					t0_cur__LineNumbers.set(at("qty"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(5, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1235) => #[target._LineNumbers.current.qual]", action);
					final SourceNode var0 = s1_cur_sgPO1.get("PO1").get("PO1235");
					final SourceNode result = action.execute(var0);
					t0_cur__LineNumbers.set(at("qual"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(6, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1234) => #[target._LineNumbers.current.itemnumber]", action);
					final SourceNode var0 = s1_cur_sgPO1.get("PO1").get("PO1234");
					final SourceNode result = action.execute(var0);
					t0_cur__LineNumbers.set(at("itemnumber"), result);
				}
				{
					com.extol.ebi.reactor.server.actions.general.GetNextNumberFromServer action = new com.extol.ebi.reactor.server.actions.general.GetNextNumberFromServer();
					createSimpleRule(7, "new com.extol.ebi.reactor.server.actions.general.GetNextNumberFromServer().execute(\"com.otterproducts.core.edi.inbound.n850.IngramNextNumberNN.Count\") => #[target._LineNumbers.current.cicSerialId]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = asString("com.otterproducts.core.edi.inbound.n850.IngramNextNumberNN.Count");
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
					t0_cur__LineNumbers.set(at("cicSerialId"), toValueNode(result));
				}
			}}}}).run();
		}}).run();
	}

}
