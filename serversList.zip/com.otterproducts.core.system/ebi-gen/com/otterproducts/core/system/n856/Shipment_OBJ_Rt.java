/**
 * @generated
 */
package com.otterproducts.core.system.n856;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.reactor.pojo.lib.*;

@SuppressWarnings("all")
public class Shipment_OBJ_Rt implements RuntimePojoSchemaProvider {
	private static RtPojoSchema schema_Shipment_OBJ;

	public RtPojoSchema getSchema() {
		if (schema_Shipment_OBJ == null) {
			RtPojoSchemaDetails schema_details_Shipment_OBJ = new RtPojoSchemaDetails();
			schema_details_Shipment_OBJ.setRootNodeName("envelope");
			schema_details_Shipment_OBJ.setRootNodeType(com.otterproducts.core.system.n856.Envelope.class);
			schema_details_Shipment_OBJ.setSerializationType(RtSerializationType.XML);
			schema_details_Shipment_OBJ.setBasePackages("com.otterproducts.core.system.n856");

			schema_Shipment_OBJ = new RtPojoSchema(schema_details_Shipment_OBJ);
		}

		return schema_Shipment_OBJ;
	}
}
