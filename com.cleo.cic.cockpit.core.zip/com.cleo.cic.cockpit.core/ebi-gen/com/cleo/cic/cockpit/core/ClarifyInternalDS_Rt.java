/**
 * @generated
 */
package com.cleo.cic.cockpit.core;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.database.lib.datasource.*;

@SuppressWarnings("all")
public class ClarifyInternalDS_Rt implements RtDataSource {
	@Override
	public String url() {
		return "<com.extol.ebi.globalvariable.lib.GlobalVariables.URL>";
	}

	@Override
	public String catalog() {
		return null;
	}
	
	@Override
	public String defaultSchema() {
		return "EBI";
	}
	
	@Override
	public String username() {
		return "<com.extol.ebi.globalvariable.lib.GlobalVariables.USERNAME>";
	}
	
	@Override
	public String password() {
		return "<com.extol.ebi.globalvariable.lib.GlobalVariables.PASSWORD>";
	}

	private static final RtJdbcDriver jdbcDriver = initJdbcDriver();
	
	private static RtJdbcDriver initJdbcDriver() {
		List<String> classPathEntries = new ArrayList<>();
		classPathEntries.add("<com.extol.ebi.globalvariable.lib.GlobalVariables.JDBC_DRIVER>");
		
		return new RtJdbcDriver("org.postgresql.Driver", classPathEntries, ClarifyInternalDS_Rt.class.getClassLoader());
	}
	
	@Override
	public RtJdbcDriver jdbcDriver() {
		return jdbcDriver;
	}
}
