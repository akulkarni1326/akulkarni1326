/**
* @generated
*/
package com.cleo.cic.cockpit.core.outbound;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.flatfile.lib.connectors.*;
import com.extol.ebi.reactor.flatfile.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class outboundErrorCockpitRS_Rt extends AbstractReactor<RtFlatFileSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	private com.cleo.cic.cockpit.core.cockpitRDO glb = addToContextMap(new com.cleo.cic.cockpit.core.cockpitRDO());
	private com.extol.ebi.ruleset.lang.core.DateTime v_DateTime;
	private com.extol.ebi.ruleset.lang.core.String v_TimeStamp;
	private com.extol.ebi.ruleset.lang.core.Number v_Milliseconds;
	private com.extol.ebi.ruleset.lang.core.Object v_MessageInfo;
	private com.extol.ebi.ruleset.lang.core.String v_dummy;
	private com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> v_SplitReprocessParms;
	private com.extol.ebi.ruleset.lang.core.String v_ReprocessKey;
	private com.extol.ebi.ruleset.lang.core.Number v_ListCount;
	private com.extol.ebi.ruleset.lang.core.String v_ListCountString;
	private com.extol.ebi.ruleset.lang.core.String v_RouteValue;
	
	public SchemaProvider<RtFlatFileSchema> getSourceSchema() {
		return new com.cleo.cic.cockpit.core.defaultErrorCockpitFF_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new FixedLengthFlatFileConnector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "", new Block() { public void body() {
		
		
			{
				com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
				createSimpleRule(2, "new GetCurrentDateTime().execute() => #[this.v_DateTime]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
				outboundErrorCockpitRS_Rt.this.v_DateTime = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
				createSimpleRule(3, "new GetMilliseconds().execute(this.v_DateTime) => #[this.v_Milliseconds]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime var0 = outboundErrorCockpitRS_Rt.this.v_DateTime;
				final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
				outboundErrorCockpitRS_Rt.this.v_Milliseconds = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(this.v_Milliseconds) => #[this.v_TimeStamp]", action);
				final SourceNode var0 = toValueNode(outboundErrorCockpitRS_Rt.this.v_Milliseconds);
				final SourceNode result = action.execute(var0);
				outboundErrorCockpitRS_Rt.this.v_TimeStamp = extractString(result);
			}
			{
				com.cleo.b2biaas.clarify.OutboundCreateMessageHeader action = new com.cleo.b2biaas.clarify.OutboundCreateMessageHeader();
				createSimpleRule(5, "new com.cleo.b2biaas.clarify.OutboundCreateMessageHeader().execute(this.glb.tpName, this.glb.docType, this.glb.messageId, this.glb.messageId, this.v_TimeStamp, \"true\", \"USD\", this.glb.logOfMsgId, this.glb.tradingPartnerId) => #[this.v_MessageInfo]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = outboundErrorCockpitRS_Rt.this.glb.tpName;
				final com.extol.ebi.ruleset.lang.core.String var1 = outboundErrorCockpitRS_Rt.this.glb.docType;
				final com.extol.ebi.ruleset.lang.core.String var2 = outboundErrorCockpitRS_Rt.this.glb.messageId;
				final com.extol.ebi.ruleset.lang.core.String var3 = outboundErrorCockpitRS_Rt.this.glb.messageId;
				final com.extol.ebi.ruleset.lang.core.String var4 = outboundErrorCockpitRS_Rt.this.v_TimeStamp;
				final com.extol.ebi.ruleset.lang.core.String var5 = asString("true");
				final com.extol.ebi.ruleset.lang.core.String var6 = asString("USD");
				final com.extol.ebi.ruleset.lang.core.String var7 = outboundErrorCockpitRS_Rt.this.glb.logOfMsgId;
				final com.extol.ebi.ruleset.lang.core.String var8 = outboundErrorCockpitRS_Rt.this.glb.tradingPartnerId;
				final com.extol.ebi.ruleset.lang.core.Object result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8);
				outboundErrorCockpitRS_Rt.this.v_MessageInfo = result;
			}
			createCompositeRule(6, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.string.Split action = new com.extol.ebi.reactor.lib.actions.string.Split();
					createSimpleRule(7, "new Split().execute(\",\", this.glb.ReprocessParms) => #[this.v_SplitReprocessParms]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = asString(",");
					final com.extol.ebi.ruleset.lang.core.String var1 = outboundErrorCockpitRS_Rt.this.glb.ReprocessParms;
					final com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> result = action.execute(var0, var1);
					outboundErrorCockpitRS_Rt.this.v_SplitReprocessParms = result;
				}
				createCompositeRule(8, "for this.v_SplitReprocessParms", new Block() { public void body() {
					if(outboundErrorCockpitRS_Rt.this.v_SplitReprocessParms != null) {
					for (final com.extol.ebi.ruleset.lang.core.String cur_v_SplitReprocessParms : outboundErrorCockpitRS_Rt.this.v_SplitReprocessParms) {
				
				
					createCompositeRule(9, "", new Block() { public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
							createSimpleRule(10, "new Add().execute(1, this.v_ListCount, null) => #[this.v_ListCount]", action);
							final com.extol.ebi.ruleset.lang.core.Number var0 = asNumber(1);
							final com.extol.ebi.ruleset.lang.core.Number var1 = outboundErrorCockpitRS_Rt.this.v_ListCount;
							final com.extol.ebi.ruleset.lang.core.Number var2 = null;
							final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
							outboundErrorCockpitRS_Rt.this.v_ListCount = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(11, "new Move().execute(this.v_ListCount) => #[this.v_ListCountString]", action);
							final SourceNode var0 = toValueNode(outboundErrorCockpitRS_Rt.this.v_ListCount);
							final SourceNode result = action.execute(var0);
							outboundErrorCockpitRS_Rt.this.v_ListCountString = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(12, "new Move().execute(\"RouteValue\") => #[this.v_ReprocessKey]", action);
							final SourceNode var0 = toValueNode(asString("RouteValue"));
							final SourceNode result = action.execute(var0);
							outboundErrorCockpitRS_Rt.this.v_ReprocessKey = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.string.ConcatenateMany action = new com.extol.ebi.reactor.lib.actions.string.ConcatenateMany();
							createSimpleRule(13, "new ConcatenateMany().execute(null, null, this.v_ReprocessKey, \"0\", this.v_ListCountString, null, null, null, null, null, null, null) => #[this.v_ReprocessKey]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = null;
							final com.extol.ebi.ruleset.lang.core.Boolean var1 = null;
							final SourceNode var2 = toValueNode(outboundErrorCockpitRS_Rt.this.v_ReprocessKey);
							final SourceNode var3 = toValueNode(asString("0"));
							final SourceNode var4 = toValueNode(outboundErrorCockpitRS_Rt.this.v_ListCountString);
							final SourceNode var5 = toNullValueNode();
							final SourceNode var6 = toNullValueNode();
							final SourceNode var7 = toNullValueNode();
							final SourceNode var8 = toNullValueNode();
							final SourceNode var9 = toNullValueNode();
							final SourceNode var10 = toNullValueNode();
							final SourceNode var11 = toNullValueNode();
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
							outboundErrorCockpitRS_Rt.this.v_ReprocessKey = result;
						}
					}}).run();
					createCompositeRule(14, "", new Block() { public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.collection.ListGet action = new com.extol.ebi.reactor.lib.actions.collection.ListGet();
							createSimpleRule(15, "new ListGet().execute(this.v_SplitReprocessParms, this.v_ListCount) => #[this.v_RouteValue]", action);
							final com.extol.ebi.ruleset.lang.core.List<com.extol.ebi.ruleset.lang.core.String> var0 = outboundErrorCockpitRS_Rt.this.v_SplitReprocessParms;
							final com.extol.ebi.ruleset.lang.core.Number var1 = outboundErrorCockpitRS_Rt.this.v_ListCount;
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
							outboundErrorCockpitRS_Rt.this.v_RouteValue = result;
						}
					}}).run();
					{
						com.cleo.b2biaas.clarify.OutboundAddReprocessingString action = new com.cleo.b2biaas.clarify.OutboundAddReprocessingString();
						createSimpleRule(16, "new com.cleo.b2biaas.clarify.OutboundAddReprocessingString().execute(this.v_MessageInfo, this.v_ReprocessKey, this.v_RouteValue) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = outboundErrorCockpitRS_Rt.this.v_MessageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = outboundErrorCockpitRS_Rt.this.v_ReprocessKey;
						final com.extol.ebi.ruleset.lang.core.String var2 = outboundErrorCockpitRS_Rt.this.v_RouteValue;
						action.execute(var0, var1, var2);
					}
				}}}}).run();
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNull condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNull();
						createRuleCondition(17, "new IsNotNull().execute(this.glb.originalLOM) => #[]", condition);
						final SourceNode var0 = toValueNode(outboundErrorCockpitRS_Rt.this.glb.originalLOM);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.OutboundAddReprocessingString action = new com.cleo.b2biaas.clarify.OutboundAddReprocessingString();
						createSimpleRule(17, "new com.cleo.b2biaas.clarify.OutboundAddReprocessingString().execute(this.v_MessageInfo, \"originalLOM\", this.glb.originalLOM) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = outboundErrorCockpitRS_Rt.this.v_MessageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("originalLOM");
						final com.extol.ebi.ruleset.lang.core.String var2 = outboundErrorCockpitRS_Rt.this.glb.originalLOM;
						action.execute(var0, var1, var2);
					}
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(18, "new Move().execute(\"SplitCode\") => #[this.env.User_Reference_1]", action);
					final SourceNode var0 = toValueNode(asString("SplitCode"));
					final SourceNode result = action.execute(var0);
					outboundErrorCockpitRS_Rt.this.env.User_Reference_1 = extractString(result);
				}
			}}).run();
			{
				com.cleo.b2biaas.clarify.OutboundCloseMessage action = new com.cleo.b2biaas.clarify.OutboundCloseMessage();
				createSimpleRule(19, "new com.cleo.b2biaas.clarify.OutboundCloseMessage().execute(this.v_MessageInfo) => #[]", action);
				final com.extol.ebi.ruleset.lang.core.Object var0 = outboundErrorCockpitRS_Rt.this.v_MessageInfo;
				action.execute(var0);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(20, "new Move().execute(source._Record.current.v_Error) => #[this.v_dummy]", action);
				final SourceNode var0 = source.get("_Record").get("v_Error");
				final SourceNode result = action.execute(var0);
				outboundErrorCockpitRS_Rt.this.v_dummy = extractString(result);
			}
		}}).run();
	}

}
