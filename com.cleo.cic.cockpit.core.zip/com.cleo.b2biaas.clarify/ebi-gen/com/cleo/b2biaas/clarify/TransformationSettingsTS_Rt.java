/**
 * @generated
 */
package com.cleo.b2biaas.clarify;

import com.extol.ebi.transformationsettings.lib.*;

@SuppressWarnings("all")
public class TransformationSettingsTS_Rt implements RtTransformationSettings {
	private RtConnectorSettings source;

	private RtConnectorSettings target;

	@Override
	public RtConnectorSettings getSource() {
		if (source == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();
			helper.delimiter = ',';

			source = new RtConnectorSettings(helper);
		}
		return source;
	}

	@Override
	public RtConnectorSettings getTarget() {
		if (target == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();
			helper.delimiter = ',';

			target = new RtConnectorSettings(helper);
		}
		return target;
	}
}
