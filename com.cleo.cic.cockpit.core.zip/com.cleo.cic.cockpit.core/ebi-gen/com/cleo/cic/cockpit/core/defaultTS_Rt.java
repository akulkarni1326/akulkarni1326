/**
 * @generated
 */
package com.cleo.cic.cockpit.core;

import com.extol.ebi.transformationsettings.lib.*;

@SuppressWarnings("all")
public class defaultTS_Rt implements RtTransformationSettings {
	private RtConnectorSettings source;

	private RtConnectorSettings target;

	@Override
	public RtConnectorSettings getSource() {
		if (source == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();

			source = new RtConnectorSettings(helper);
		}
		return source;
	}

	@Override
	public RtConnectorSettings getTarget() {
		if (target == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();

			target = new RtConnectorSettings(helper);
		}
		return target;
	}
}
