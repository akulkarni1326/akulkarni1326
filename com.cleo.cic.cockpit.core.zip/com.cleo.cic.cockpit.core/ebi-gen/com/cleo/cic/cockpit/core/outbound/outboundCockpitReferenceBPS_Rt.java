/**
* @generated
*/
package com.cleo.cic.cockpit.core.outbound;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.support.CallJavaAbstractTask;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStorageNodeToString;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStringToStorageNode;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.string.ReplaceString;
import com.extol.ebi.bps.lib.tasks.transformation.ExecuteTransformation;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps.lib.tasks.transformation.SetContextPointValue;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class outboundCockpitReferenceBPS_Rt extends AbstractCatalyst {
	
	public outboundCockpitReferenceBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_sourceContext, @ParameterType(StorageNode.class) Variable<StorageNode> p_targetContext, @ParameterType(StorageNode.class) Variable<StorageNode> p_ediData, @ParameterType(String.class) Variable<String> p_partnerName, @ParameterType(String.class) Variable<String> p_tpIdValue, @ParameterType(Ruleset.class) Variable<Ruleset> p_cockpitRuleset, @ParameterType(String.class) Variable<String> p_ReprocessParms) {
		final Variable<String> v_logOfMsgIdValue = variable(String.class, null);
		final Variable<String> v_tpId = variable(String.class, "glb.var.tradingPartnerId");
		final Variable<String> v_tpName = variable(String.class, "glb.var.tpName");
		final Variable<String> v_logOfMsgId = variable(String.class, "glb.var.logOfMsgId");
		final Variable<String> v_ediDataString = variable(String.class, null);
		final Variable<String> v_ediDataModString = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Convert Storage Node to String", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert Storage Node to String");
					ConvertStorageNodeToString task = new ConvertStorageNodeToString();
					setupTask(task);
					return task.execute(p_ediData, v_ediDataString);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.cic.cockpit.core.outbound.outboundCockpitReferenceBPS$DelimiterReplace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.outbound.outboundCockpitReferenceBPS$DelimiterReplace");
					DelimiterReplace task = new DelimiterReplace();
					setupTask(task);
					return task.execute(v_ediDataModString, v_ediDataString);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_ediDataModString, v_ediDataModString, variable(String.class, "~~"), variable(String.class, "~"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Convert String to Storage Node", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert String to Storage Node");
					ConvertStringToStorageNode task = new ConvertStringToStorageNode();
					setupTask(task);
					return task.execute(v_ediDataModString, p_ediData);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_targetContext, variable(String.class, "env.var.Log_of_Message_Id"), new ContextPointVar(v_logOfMsgIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, v_tpName, new ContextPointVar(p_partnerName));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, v_logOfMsgId, new ContextPointVar(v_logOfMsgIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, v_tpId, new ContextPointVar(p_tpIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, variable(String.class, "glb.var.ReprocessParms"), new ContextPointVar(p_ReprocessParms));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Execute Transformation - Single Output", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Execute Transformation - Single Output");
					ExecuteTransformation task = new ExecuteTransformation();
					setupTask(task);
					return task.execute(p_ediData, null, literalTypeFromString(TransformationSettings.class, "com.cleo.cic.cockpit.core.defaultTS"), p_cockpitRuleset, null, p_sourceContext, null);
				} finally { _endTask();}
			}
		}, "SUCCESS", "end");
		
		builder.addStep("SUCCESS", "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		builder.addStep("FAILURE", "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, false));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		return builder.createRunner().run();
	}
	
	public static class DelimiterReplace extends CallJavaAbstractTask {
		public DelimiterReplace() {
			super("com.cleo.cic.cockpit.core.outbound.DelimiterReplace", "java.lang.String replaceDelimiter(java.lang.String)", false);
		}
	}
}
