package com.cleo.b2biaas.clarify;

public class AddNonEDIOutboundReprocessingString extends B2BAction  {

	public void execute(
			com.extol.ebi.ruleset.lang.core.Object messageInfo, 
			com.extol.ebi.ruleset.lang.core.String key, 
			com.extol.ebi.ruleset.lang.core.String value) {
		((OutboundMessageApiCallV2)messageInfo.asJavaObject()).reprocessingString(key.asJavaString(), value.asJavaString());
	}
}


