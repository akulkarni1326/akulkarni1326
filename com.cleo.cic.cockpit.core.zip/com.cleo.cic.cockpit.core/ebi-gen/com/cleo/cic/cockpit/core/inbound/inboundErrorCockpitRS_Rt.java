/**
* @generated
*/
package com.cleo.cic.cockpit.core.inbound;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.flatfile.lib.connectors.*;
import com.extol.ebi.reactor.flatfile.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class inboundErrorCockpitRS_Rt extends AbstractReactor<RtFlatFileSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	private com.cleo.cic.cockpit.core.cockpitRDO glb = addToContextMap(new com.cleo.cic.cockpit.core.cockpitRDO());
	private com.extol.ebi.ruleset.lang.core.DateTime v_DateTime;
	private com.extol.ebi.ruleset.lang.core.String v_TimeStamp;
	private com.extol.ebi.ruleset.lang.core.Number v_Milliseconds;
	private com.extol.ebi.ruleset.lang.core.Object v_MessageInfo;
	private com.extol.ebi.ruleset.lang.core.String v_dummy;
	
	public SchemaProvider<RtFlatFileSchema> getSourceSchema() {
		return new com.cleo.cic.cockpit.core.defaultErrorCockpitFF_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new FixedLengthFlatFileConnector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "", new Block() { public void body() {
		
		
			{
				com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
				createSimpleRule(2, "new GetCurrentDateTime().execute() => #[this.v_DateTime]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
				inboundErrorCockpitRS_Rt.this.v_DateTime = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
				createSimpleRule(3, "new GetMilliseconds().execute(this.v_DateTime) => #[this.v_Milliseconds]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime var0 = inboundErrorCockpitRS_Rt.this.v_DateTime;
				final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
				inboundErrorCockpitRS_Rt.this.v_Milliseconds = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(this.v_Milliseconds) => #[this.v_TimeStamp]", action);
				final SourceNode var0 = toValueNode(inboundErrorCockpitRS_Rt.this.v_Milliseconds);
				final SourceNode result = action.execute(var0);
				inboundErrorCockpitRS_Rt.this.v_TimeStamp = extractString(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.string.Trim action = new com.extol.ebi.reactor.lib.actions.string.Trim();
				createSimpleRule(5, "new Trim().execute(this.glb.tradingPartnerId) => #[this.glb.tradingPartnerId]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = inboundErrorCockpitRS_Rt.this.glb.tradingPartnerId;
				final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
				inboundErrorCockpitRS_Rt.this.glb.tradingPartnerId = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.string.Trim action = new com.extol.ebi.reactor.lib.actions.string.Trim();
				createSimpleRule(6, "new Trim().execute(this.glb.ownerId) => #[this.glb.ownerId]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = inboundErrorCockpitRS_Rt.this.glb.ownerId;
				final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
				inboundErrorCockpitRS_Rt.this.glb.ownerId = result;
			}
			{
				com.cleo.b2biaas.clarify.InboundCreateMessageHeader action = new com.cleo.b2biaas.clarify.InboundCreateMessageHeader();
				createSimpleRule(7, "new com.cleo.b2biaas.clarify.InboundCreateMessageHeader().execute(this.glb.tradingPartnerId, this.glb.tpName, this.glb.docType, this.glb.messageId, this.glb.messageId, this.v_TimeStamp, \"true\", \"USD\", this.glb.ownerId, \"NA\", \"NA\", \"NA\") => #[this.v_MessageInfo]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = inboundErrorCockpitRS_Rt.this.glb.tradingPartnerId;
				final com.extol.ebi.ruleset.lang.core.String var1 = inboundErrorCockpitRS_Rt.this.glb.tpName;
				final com.extol.ebi.ruleset.lang.core.String var2 = inboundErrorCockpitRS_Rt.this.glb.docType;
				final com.extol.ebi.ruleset.lang.core.String var3 = inboundErrorCockpitRS_Rt.this.glb.messageId;
				final com.extol.ebi.ruleset.lang.core.String var4 = inboundErrorCockpitRS_Rt.this.glb.messageId;
				final com.extol.ebi.ruleset.lang.core.String var5 = inboundErrorCockpitRS_Rt.this.v_TimeStamp;
				final com.extol.ebi.ruleset.lang.core.String var6 = asString("true");
				final com.extol.ebi.ruleset.lang.core.String var7 = asString("USD");
				final com.extol.ebi.ruleset.lang.core.String var8 = inboundErrorCockpitRS_Rt.this.glb.ownerId;
				final com.extol.ebi.ruleset.lang.core.String var9 = asString("NA");
				final com.extol.ebi.ruleset.lang.core.String var10 = asString("NA");
				final com.extol.ebi.ruleset.lang.core.String var11 = asString("NA");
				final com.extol.ebi.ruleset.lang.core.Object result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
				inboundErrorCockpitRS_Rt.this.v_MessageInfo = result;
			}
			{
				com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader action = new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader();
				createSimpleRule(8, "new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader().execute(this.v_MessageInfo, \"logOfMessageId\", this.env.Log_of_Message_Id) => #[]", action);
				final com.extol.ebi.ruleset.lang.core.Object var0 = inboundErrorCockpitRS_Rt.this.v_MessageInfo;
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("logOfMessageId");
				final com.extol.ebi.ruleset.lang.core.String var2 = inboundErrorCockpitRS_Rt.this.env.Log_of_Message_Id;
				action.execute(var0, var1, var2);
			}
			{
				com.cleo.b2biaas.clarify.InboundCloseMessage action = new com.cleo.b2biaas.clarify.InboundCloseMessage();
				createSimpleRule(9, "new com.cleo.b2biaas.clarify.InboundCloseMessage().execute(this.v_MessageInfo) => #[]", action);
				final com.extol.ebi.ruleset.lang.core.Object var0 = inboundErrorCockpitRS_Rt.this.v_MessageInfo;
				action.execute(var0);
			}
		}}).run();
		{
			com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
			createSimpleRule(10, "new Move().execute(source._Record.current.v_Error) => #[this.v_dummy]", action);
			final SourceNode var0 = source.get("_Record").get("v_Error");
			final SourceNode result = action.execute(var0);
			inboundErrorCockpitRS_Rt.this.v_dummy = extractString(result);
		}
	}

}
