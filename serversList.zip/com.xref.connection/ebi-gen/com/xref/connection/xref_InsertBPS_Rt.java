/**
* @generated
*/
package com.xref.connection;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;

@SuppressWarnings("all")
public class xref_InsertBPS_Rt extends AbstractCatalyst {
	
	public xref_InsertBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute() {

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "com.xref.connection.Createxref_LineNumbersSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.xref.connection.Createxref_LineNumbersSQL$BpsTask");
					com.xref.connection.Createxref_LineNumbersSQL.BpsTask task = new com.xref.connection.Createxref_LineNumbersSQL.BpsTask();
					setupTask(task);
					return task.execute_v2();
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.xref.connection.Definexref_LineNumberSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.xref.connection.Definexref_LineNumberSQL$BpsTask");
					com.xref.connection.Definexref_LineNumberSQL.BpsTask task = new com.xref.connection.Definexref_LineNumberSQL.BpsTask();
					setupTask(task);
					return task.execute_v2();
				} finally { _endTask();}
			}
		}, "next", "end");
		
		return builder.createRunner().run();
	}
}
