/**
 * @generated
 */
package com.otterproducts.core.system.n810;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.reactor.pojo.lib.*;

@SuppressWarnings("all")
public class Invoice_810OBJ_Rt implements RuntimePojoSchemaProvider {
	private static RtPojoSchema schema_Invoice_810OBJ;

	public RtPojoSchema getSchema() {
		if (schema_Invoice_810OBJ == null) {
			RtPojoSchemaDetails schema_details_Invoice_810OBJ = new RtPojoSchemaDetails();
			schema_details_Invoice_810OBJ.setRootNodeName("envelope");
			schema_details_Invoice_810OBJ.setRootNodeType(com.intentia.mbm.Envelope.class);
			schema_details_Invoice_810OBJ.setSerializationType(RtSerializationType.XML);
			schema_details_Invoice_810OBJ.setBasePackages("com.intentia.mbm");

			schema_Invoice_810OBJ = new RtPojoSchema(schema_details_Invoice_810OBJ);
		}

		return schema_Invoice_810OBJ;
	}
}
