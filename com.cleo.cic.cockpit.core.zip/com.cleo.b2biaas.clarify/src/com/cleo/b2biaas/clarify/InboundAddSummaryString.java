package com.cleo.b2biaas.clarify;


/**
 * @author Manju Muthuraj
 * 
 */
public class InboundAddSummaryString  extends B2BAction {

	public void execute(
			com.extol.ebi.ruleset.lang.core.Object messageInfo, 
			com.extol.ebi.ruleset.lang.core.String key, 
			com.extol.ebi.ruleset.lang.core.String value) {
		String valRef = Utility.setEmptyStringIfNull(value);
		((InboundMessageApiCallV2)messageInfo.asJavaObject()).summaryString(key.asJavaString(), valRef);
	}
}
