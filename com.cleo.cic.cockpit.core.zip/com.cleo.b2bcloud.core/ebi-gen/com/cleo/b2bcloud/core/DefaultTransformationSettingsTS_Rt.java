/**
 * @generated
 */
package com.cleo.b2bcloud.core;

import com.extol.ebi.transformationsettings.lib.*;

@SuppressWarnings("all")
public class DefaultTransformationSettingsTS_Rt implements RtTransformationSettings {
	private RtConnectorSettings source;

	private RtConnectorSettings target;

	@Override
	public RtConnectorSettings getSource() {
		if (source == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();

			source = new RtConnectorSettings(helper);
		}
		return source;
	}

	@Override
	public RtConnectorSettings getTarget() {
		if (target == null) {
			ConnectorSettingsAttributesHelper helper = new ConnectorSettingsAttributesHelper();
			helper.enableValidationChecks = true;
			helper.validateRequired = ValidationErrorType.HardError;
			helper.validateMinimumLength = ValidationErrorType.HardError;
			helper.validateMaximumLength = ValidationErrorType.HardError;
			helper.validateMinimumOccurs = ValidationErrorType.HardError;
			helper.validateMaximumOccurs = ValidationErrorType.HardError;
			helper.validateDataType = ValidationErrorType.HardError;
			helper.validateAllowedValues = ValidationErrorType.HardError;

			target = new RtConnectorSettings(helper);
		}
		return target;
	}
}
