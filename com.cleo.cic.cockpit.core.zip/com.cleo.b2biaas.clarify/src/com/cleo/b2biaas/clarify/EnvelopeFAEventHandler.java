package com.cleo.b2biaas.clarify;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.extol.ebi.factory.EBIFactoryManager;

/**
 * @author Manju Muthuraj
 * 
 */
public class EnvelopeFAEventHandler  extends B2BAction {

	Utility utility = new Utility();

	public EnvelopeFAEventHandler() {
	}

	private String[] outboundDocumentEnvelopeKeys = { EventKeys.GROUP_CODE,
			EventKeys.LOGOF_MESSAGE_ID, EventKeys.INTERCHANGE_SENDER_ID,
			EventKeys.GROUP_CONTROL_NUMBER, EventKeys.INTERCHANGE_RECEIVER_ID,
			EventKeys.MESSAGE_CONTROL_NUMBER, EventKeys.INTERCHANGE_CONTROL_NUMBER };

	private boolean isValueNonEmpty(String value) {
		return value == null ? false : value.isEmpty() ? false : true;

	}

	private void removeFromMap(HashMap<String, String> map, String[] keys) {
		if (null != map && !map.isEmpty() && null != keys && keys.length > 0) {
			for (String key : keys) {
				map.remove(key);
			}
		}
	}


	public String postEnvelopeFAEvent(HashMap<String, String> parms) {

		String tpId = null;
		String ownerId = null;
		String receiverIdOutbound = null;
		String senderIdOutbound = null;
		String transactionControlNumber = null;
		String groupControlNumber = null;
		String interchangeControlNumber = null;
		String functionalIdentifierCode = null;
		String logOfMessageId = null;
		String uuid = null;
		HashMap<String, String> outboundDocumentEnvelope = new HashMap<String, String>();

		try {
			if (null != parms && !parms.isEmpty()) {

				String programCalledFromValue = parms.get(EventKeys.PROGRAM_CALLED_FROM);
				String groupCode = parms.get(EventKeys.GROUP_CODE);
				logInfo(EventKeys.EVENTKEYS_LOG+ parms);
				// Start : Handling of inbound FA's------------------------------------------
				if (EventKeys.INBOUND_FA_DOCUMENT_START
						.equalsIgnoreCase(programCalledFromValue)) {
					uuid = EBIFactoryManager.getFactory().createUUID()
							.getUUIDString();
					logInfo(EventKeys.GENERATING_THE_UUID_FOR_START_EVENT + uuid);
					new FAInfoAccumulator(EventKeys.INBOUND_FA_DOCUMENT);
				} else if (EventKeys.INBOUND_FA_DOCUMENT
						.equalsIgnoreCase(programCalledFromValue)) {
					FAInfoAccumulator.addInboundFADataToMap(parms);
					uuid = parms.get(EventKeys.CONTEXT);
				} else if (EventKeys.INBOUND_FA_DOCUMENT_END
						.equalsIgnoreCase(programCalledFromValue)) {
					String uuid_endEvent = parms.get(EventKeys.CONTEXT);
					logInfo(EventKeys.GETTING_UUID_FOR_END_EVENT + uuid_endEvent);

					FAData data = FAInfoAccumulator
							.getInboundFADataToSendToCockpit(uuid_endEvent);

					String retVal = utility.objectToString(data);
					StringBuffer sb = new StringBuffer();
					utility.postMessageTob2biaaS(sb.append(retVal),EventKeys.API_FA_MESSAGE_TENANT_V2, EventKeys.INBOUNDFA_DOCUMENT_LOG_HEADER);

					FAInfoAccumulator.clearInboundAccumulator(uuid_endEvent);
				}
				// End: Handling of inbound FA --------------------------------------------

				// Start : Handling of outbound FA's------------------------------------------
				if (EventKeys.OUTBOUND_FA_DOCUMENT
						.equalsIgnoreCase(programCalledFromValue)) {

					FAInfoAccumulator.addOutboundFADataToMap(parms);
					uuid = parms.get(EventKeys.LOGOF_MESSAGE_ID);
					new FAInfoAccumulator(EventKeys.OUTBOUND_FA_DOCUMENT);
				} else if (EventKeys.OUTBOUND_DOCUMENT
						.equalsIgnoreCase(programCalledFromValue)
						&& "FA".equals(groupCode)) {
					FAInfoAccumulator.addOutboundFADataToMap(parms);
					String uuid_outboundFa_envelope = parms
							.get(EventKeys.LOGOF_MESSAGE_ID);

					FAData data = FAInfoAccumulator
							.getOutboundFADataToSendToCockpit(uuid_outboundFa_envelope);
					String retVal = utility.objectToString(data);
					StringBuffer sb = new StringBuffer();
					utility.postMessageTob2biaaS(sb.append(retVal),EventKeys.API_FA_MESSAGE_TENANT_V2, EventKeys.OUTBOUNDFA_DOCUMENT_LOG_HEADER);

					FAInfoAccumulator
					.clearOutboundAccumulator(uuid_outboundFa_envelope);
				}
				// End: Handling of outbound FA--------------------------------------------

				if (EventKeys.OUTBOUND_DOCUMENT.equals(programCalledFromValue)
						&& !"FA".equals(groupCode)) {
					for (String key : outboundDocumentEnvelopeKeys) {
						if (parms.containsKey(key)) {
							String value = parms.get(key);
							if (key == EventKeys.INTERCHANGE_SENDER_ID
									&& isValueNonEmpty(value)) {
								senderIdOutbound = value;
							}
							if (key == EventKeys.INTERCHANGE_RECEIVER_ID
									&& isValueNonEmpty(value)) {
								receiverIdOutbound = value;
							}
							if (key == EventKeys.LOGOF_MESSAGE_ID
									&& isValueNonEmpty(value)) {
								logOfMessageId = value;
							}
							if (key == EventKeys.GROUP_CODE
									&& isValueNonEmpty(value)) {
								functionalIdentifierCode = value;
							}
							if (key == EventKeys.GROUP_CONTROL_NUMBER
									&& isValueNonEmpty(value)) {
								groupControlNumber = value;
							}
							if (key == EventKeys.INTERCHANGE_CONTROL_NUMBER
									&& isValueNonEmpty(value)) {
								interchangeControlNumber = value;
							}
							if (key == EventKeys.MESSAGE_CONTROL_NUMBER
									&& isValueNonEmpty(value)) {
								transactionControlNumber = value;
							}
							outboundDocumentEnvelope.put(key, value);
						}
					}
					tpId = receiverIdOutbound;
					ownerId = senderIdOutbound;
					outboundDocumentEnvelope.put(EventKeys.KEY_DIRECTION, EventKeys.DIRECTION_S);
					outboundDocumentEnvelope.put(EventKeys.KEY_OWNERID, ownerId.trim());
					outboundDocumentEnvelope.put(EventKeys.KEY_TPID, tpId.trim());
					outboundDocumentEnvelope.put(EventKeys.KEY_LOGOFMESSAGEID,
							logOfMessageId);
					outboundDocumentEnvelope.put(EventKeys.KEY_FUNCTIONALIDENTIFIERCODE,
							functionalIdentifierCode);
					outboundDocumentEnvelope.put(EventKeys.KEY_GCN,
							groupControlNumber);
					outboundDocumentEnvelope.put(EventKeys.KEY_TCN,
							transactionControlNumber);
					outboundDocumentEnvelope.put(EventKeys.KEY_ICN,
							interchangeControlNumber);
					removeFromMap(outboundDocumentEnvelope, new String[] {
							EventKeys.INTERCHANGE_SENDER_ID,
							EventKeys.INTERCHANGE_RECEIVER_ID,
							EventKeys.MESSAGE_CONTROL_NUMBER,
							EventKeys.GROUP_CODE,
							EventKeys.GROUP_CONTROL_NUMBER,
							EventKeys.LOGOF_MESSAGE_ID,
							EventKeys.INTERCHANGE_CONTROL_NUMBER});
					
					String json = utility.objectToString(outboundDocumentEnvelope);
					StringBuffer sb = new StringBuffer();
					utility.postMessageTob2biaaS(sb.append(json),EventKeys.API_MESSAGE_TENANT,
							EventKeys.OUTBOUNDDOCUMENT_LOG_HEADER);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return uuid;
	}

	public void printKeysToServerLog(HashMap<String, String> parms) {

		final String NL = System.getProperty(EventKeys.LINE_SEPARATOR);

		try {
			for (Map.Entry<String, String> entry : parms.entrySet()) {
				String k = entry.getKey();
				String v = entry.getValue();
				logInfo("Key: " + k + " Value: " + v + NL);
			}
		} catch (Exception ioe) {
			ioe.printStackTrace();
		}
	}

	public void writeKeysToFile(HashMap<String, String> parms) {
		final String fileLocation = "C:\\TestFolders\\ServerA\\ServerBOutputValues.txt";
		final String NL = System.getProperty("line.separator");
		final String SDFFormat = "MM/dd/yyyy hh:mm:ss a zzz";

		Date now = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat(SDFFormat);

		File file = new File(fileLocation);
		FileWriter fw = null;
		try {
			fw = new FileWriter(file, true);
			fw.write(NL + sdf.format(now) + NL);
			for (Map.Entry<String, String> entry : parms.entrySet()) {
				String k = entry.getKey();
				String v = entry.getValue();
				fw.write("Key: " + k + " Value: " + v + NL);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
