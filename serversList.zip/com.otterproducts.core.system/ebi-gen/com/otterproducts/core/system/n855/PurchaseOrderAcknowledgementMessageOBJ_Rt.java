/**
 * @generated
 */
package com.otterproducts.core.system.n855;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.reactor.pojo.lib.*;

@SuppressWarnings("all")
public class PurchaseOrderAcknowledgementMessageOBJ_Rt implements RuntimePojoSchemaProvider {
	private static RtPojoSchema schema_PurchaseOrderAcknowledgementMessageOBJ;

	public RtPojoSchema getSchema() {
		if (schema_PurchaseOrderAcknowledgementMessageOBJ == null) {
			RtPojoSchemaDetails schema_details_PurchaseOrderAcknowledgementMessageOBJ = new RtPojoSchemaDetails();
			schema_details_PurchaseOrderAcknowledgementMessageOBJ.setRootNodeName("purchaseOrderAcknowledgementMessage");
			schema_details_PurchaseOrderAcknowledgementMessageOBJ.setRootNodeType(org.otterbox.schemas.edi_1.PurchaseOrderAcknowledgementMessage.class);
			schema_details_PurchaseOrderAcknowledgementMessageOBJ.setSerializationType(RtSerializationType.XML);
			schema_details_PurchaseOrderAcknowledgementMessageOBJ.setBasePackages("com.otterproducts.core.system", "org.otterbox.schemas.edi_1");

			schema_PurchaseOrderAcknowledgementMessageOBJ = new RtPojoSchema(schema_details_PurchaseOrderAcknowledgementMessageOBJ);
		}

		return schema_PurchaseOrderAcknowledgementMessageOBJ;
	}
}
