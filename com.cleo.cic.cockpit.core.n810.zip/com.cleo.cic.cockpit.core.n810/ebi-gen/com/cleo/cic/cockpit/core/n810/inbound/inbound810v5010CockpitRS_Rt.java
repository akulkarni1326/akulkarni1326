/**
* @generated
*/
package com.cleo.cic.cockpit.core.n810.inbound;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class inbound810v5010CockpitRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.DateTime v_currentDateTime;
	private com.extol.ebi.ruleset.lang.core.Object v_inboundMessage;
	private com.extol.ebi.ruleset.lang.core.Number v_currentDateTimeMillis;
	private com.extol.ebi.ruleset.lang.core.String v_currentDateTimeMillisString;
	private com.cleo.cic.cockpit.core.cockpitRDO glb = addToContextMap(new com.cleo.cic.cockpit.core.cockpitRDO());
	private com.extol.ebi.ruleset.lang.core.String v_Date;
	private com.extol.ebi.ruleset.lang.core.String v_Total;
	private com.extol.ebi.ruleset.lang.core.String v_ParentMessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.String v_MessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.String v_InvoiceDate;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.cleo.cic.cockpit.core.n810.n810v5010CockpitEDI_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "", new Block() { public void body() {
		
		
			createCompositeRule(2, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
					createSimpleRule(3, "new GetCurrentDateTime().execute() => #[this.v_currentDateTime]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
					inbound810v5010CockpitRS_Rt.this.v_currentDateTime = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
					createSimpleRule(4, "new GetMilliseconds().execute(this.v_currentDateTime) => #[this.v_currentDateTimeMillis]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime var0 = inbound810v5010CockpitRS_Rt.this.v_currentDateTime;
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
					inbound810v5010CockpitRS_Rt.this.v_currentDateTimeMillis = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(5, "new Move().execute(this.v_currentDateTimeMillis) => #[this.v_currentDateTimeMillisString]", action);
					final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.v_currentDateTimeMillis);
					final SourceNode result = action.execute(var0);
					inbound810v5010CockpitRS_Rt.this.v_currentDateTimeMillisString = extractString(result);
				}
			}}).run();
			createCompositeRule(6, "", new Block() { public void body() {
			
			
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(7, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG324) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG324");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(7, "new Move().execute(source.Area1.BIG.BIG324) => #[this.v_ParentMessageId]", action);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG324");
						final SourceNode result = action.execute(var0);
						inbound810v5010CockpitRS_Rt.this.v_ParentMessageId = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(8, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG76) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG76");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(8, "new Move().execute(source.Area1.BIG.BIG76) => #[this.v_MessageId]", action);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG76");
						final SourceNode result = action.execute(var0);
						inbound810v5010CockpitRS_Rt.this.v_MessageId = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(9, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG373_3) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373_3");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(9, "new Move().execute(source.Area1.BIG.BIG373_3) => #[this.v_Date]", action);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373_3");
						final SourceNode result = action.execute(var0);
						inbound810v5010CockpitRS_Rt.this.v_Date = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(10, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG373) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(10, "new Move().execute(source.Area1.BIG.BIG373) => #[this.v_InvoiceDate]", action);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG373");
						final SourceNode result = action.execute(var0);
						inbound810v5010CockpitRS_Rt.this.v_InvoiceDate = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(11, "new IsNotNullOrWhiteSpaces().execute(source.Area3.TDS.TDS610) => #[]", condition);
						final SourceNode var0 = source.get("Area3").get("TDS").get("TDS610");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(11, "new Move().execute(source.Area3.TDS.TDS610) => #[this.v_Total]", action);
						final SourceNode var0 = source.get("Area3").get("TDS").get("TDS610");
						final SourceNode result = action.execute(var0);
						inbound810v5010CockpitRS_Rt.this.v_Total = extractString(result);
					}
				}
			}}).run();
			createCompositeRule(12, "", new Block() { public void body() {
			
			
				{
					com.cleo.b2biaas.clarify.InboundCreateMessageHeader action = new com.cleo.b2biaas.clarify.InboundCreateMessageHeader();
					createSimpleRule(13, "new com.cleo.b2biaas.clarify.InboundCreateMessageHeader().execute(this.glb.tradingPartnerId, this.glb.tpName, \"810\", this.v_ParentMessageId, this.v_MessageId, this.v_currentDateTimeMillisString, \"true\", \"USD\", this.glb.ownerId, this.env.Functional_Group_Code, this.env.Functional_Group_Control_Number, this.env.Message_Control_Number) => #[this.v_inboundMessage]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = inbound810v5010CockpitRS_Rt.this.glb.tradingPartnerId;
					final com.extol.ebi.ruleset.lang.core.String var1 = inbound810v5010CockpitRS_Rt.this.glb.tpName;
					final com.extol.ebi.ruleset.lang.core.String var2 = asString("810");
					final com.extol.ebi.ruleset.lang.core.String var3 = inbound810v5010CockpitRS_Rt.this.v_ParentMessageId;
					final com.extol.ebi.ruleset.lang.core.String var4 = inbound810v5010CockpitRS_Rt.this.v_MessageId;
					final com.extol.ebi.ruleset.lang.core.String var5 = inbound810v5010CockpitRS_Rt.this.v_currentDateTimeMillisString;
					final com.extol.ebi.ruleset.lang.core.String var6 = asString("true");
					final com.extol.ebi.ruleset.lang.core.String var7 = asString("USD");
					final com.extol.ebi.ruleset.lang.core.String var8 = inbound810v5010CockpitRS_Rt.this.glb.ownerId;
					final com.extol.ebi.ruleset.lang.core.String var9 = inbound810v5010CockpitRS_Rt.this.env.Functional_Group_Code;
					final com.extol.ebi.ruleset.lang.core.String var10 = inbound810v5010CockpitRS_Rt.this.env.Functional_Group_Control_Number;
					final com.extol.ebi.ruleset.lang.core.String var11 = inbound810v5010CockpitRS_Rt.this.env.Message_Control_Number;
					final com.extol.ebi.ruleset.lang.core.Object result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
					inbound810v5010CockpitRS_Rt.this.v_inboundMessage = result;
				}
				{
					com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader action = new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader();
					createSimpleRule(14, "new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader().execute(this.v_inboundMessage, \"logOfMessageId\", this.env.Log_of_Message_Id) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = inbound810v5010CockpitRS_Rt.this.v_inboundMessage;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("logOfMessageId");
					final com.extol.ebi.ruleset.lang.core.String var2 = inbound810v5010CockpitRS_Rt.this.env.Log_of_Message_Id;
					action.execute(var0, var1, var2);
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(15, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BIG.BIG324) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BIG").get("BIG324");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(15, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Order ID: \", \"\",source.Area1.BIG.BIG324) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound810v5010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Order ID: ");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
						final com.extol.ebi.ruleset.lang.core.String var3 = extractString(source.get("Area1").get("BIG").get("BIG324"));
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(16, "new IsNotNullOrWhiteSpaces().execute(this.v_Date) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.v_Date);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(16, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Order Date: \",\"{d}\", this.v_Date) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound810v5010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Order Date: ");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("{d}");
						final com.extol.ebi.ruleset.lang.core.String var3 = inbound810v5010CockpitRS_Rt.this.v_Date;
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(17, "new IsNotNullOrWhiteSpaces().execute(this.v_InvoiceDate) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.v_InvoiceDate);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(17, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Invoice Date: \",\"{d}\", this.v_InvoiceDate) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound810v5010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Invoice Date: ");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("{d}");
						final com.extol.ebi.ruleset.lang.core.String var3 = inbound810v5010CockpitRS_Rt.this.v_InvoiceDate;
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(18, "new IsNotNullOrWhiteSpaces().execute(this.v_Total) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.v_Total);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(18, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Grand Total: \",\"\", this.v_Total) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound810v5010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Grand Total: ");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
						final com.extol.ebi.ruleset.lang.core.String var3 = inbound810v5010CockpitRS_Rt.this.v_Total;
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					com.cleo.b2biaas.clarify.InboundCloseMessage action = new com.cleo.b2biaas.clarify.InboundCloseMessage();
					createSimpleRule(19, "new com.cleo.b2biaas.clarify.InboundCloseMessage().execute(this.v_inboundMessage) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = inbound810v5010CockpitRS_Rt.this.v_inboundMessage;
					action.execute(var0);
				}
			}}).run();
			createCompositeRule(20, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(21, "new Move().execute(this.glb.User_Reference_1) => #[this.env.User_Reference_1]", action);
					final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.glb.User_Reference_1);
					final SourceNode result = action.execute(var0);
					inbound810v5010CockpitRS_Rt.this.env.User_Reference_1 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(22, "new Move().execute(this.glb.User_Reference_2) => #[this.env.User_Reference_2]", action);
					final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.glb.User_Reference_2);
					final SourceNode result = action.execute(var0);
					inbound810v5010CockpitRS_Rt.this.env.User_Reference_2 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(23, "new Move().execute(this.glb.User_Reference_3) => #[this.env.User_Reference_3]", action);
					final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.glb.User_Reference_3);
					final SourceNode result = action.execute(var0);
					inbound810v5010CockpitRS_Rt.this.env.User_Reference_3 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(24, "new Move().execute(this.glb.User_Reference_4) => #[this.env.User_Reference_4]", action);
					final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.glb.User_Reference_4);
					final SourceNode result = action.execute(var0);
					inbound810v5010CockpitRS_Rt.this.env.User_Reference_4 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(25, "new Move().execute(this.glb.User_Reference_5) => #[this.env.User_Reference_5]", action);
					final SourceNode var0 = toValueNode(inbound810v5010CockpitRS_Rt.this.glb.User_Reference_5);
					final SourceNode result = action.execute(var0);
					inbound810v5010CockpitRS_Rt.this.env.User_Reference_5 = extractString(result);
				}
			}}).run();
		}}).run();
	}

}
