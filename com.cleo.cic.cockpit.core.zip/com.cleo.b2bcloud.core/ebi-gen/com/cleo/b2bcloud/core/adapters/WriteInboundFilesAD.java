package com.cleo.b2bcloud.core.adapters;

import com.cleo.clarify.cloudadapter.CloudAdapter;
import com.cleo.clarify.cloudadapter.CloudAdapterConfig;
import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps2.lib.types.CloudEndpoint;
import com.extol.ebi.lang.annotations.EbiName;
import com.extol.ebi.lang.bps.Optional;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.unifiedcomm.adapter.lib.AbstractUnifiedCommAdapter;
import java.util.List;

@SuppressWarnings("all")
public class WriteInboundFilesAD extends AbstractUnifiedCommAdapter implements CloudAdapter, BpsCallable {
  public CloudAdapterConfig getConfiguration(final StorageNode Payload, final CloudEndpoint OverrideEndpoint, final com.extol.ebi.bps.lang.String filename, final com.extol.ebi.bps.lang.String Doctype, final com.extol.ebi.bps.lang.String timestamp, final com.extol.ebi.bps.lang.String extension, final com.extol.ebi.bps.lang.String PartnerName, final com.extol.ebi.bps.lang.String CustomerID, final com.extol.ebi.bps.lang.String OrderNumber, final com.extol.ebi.bps.lang.String DocumentID) {
    final CloudAdapterConfig config = new CloudAdapterConfig();
    config.endpoint = null;
    config.filename = _literalService.createString("${Doctype}_${PartnerName}_${CustomerID}_${DocumentID}_${OrderNumber}_${timestamp}.${extension}");
    return config;
  }
  
  public String getAdapterInterfaceName() {
    return "com.cleo.clarify.cloudadapter.CloudAdapter";
  }
  
  public List<String> getParameterNames() {
    return java.util.Arrays.asList("Payload","OverrideEndpoint","filename","Doctype","timestamp","extension","PartnerName","CustomerID","OrderNumber","DocumentID");
  }
  
  @OverrideOpName(value = "bps1://UnifiedAdapter")
  public boolean execute(@EbiName(value = "Payload") final StorageNode Payload, @EbiName(value = "OverrideEndpoint") @Optional final CloudEndpoint OverrideEndpoint, final com.extol.ebi.bps.lang.String filename, final com.extol.ebi.bps.lang.String Doctype, final com.extol.ebi.bps.lang.String timestamp, final com.extol.ebi.bps.lang.String extension, final com.extol.ebi.bps.lang.String PartnerName, final com.extol.ebi.bps.lang.String CustomerID, final com.extol.ebi.bps.lang.String OrderNumber, final com.extol.ebi.bps.lang.String DocumentID) {
    //Stub;
    return false;
  }
}
