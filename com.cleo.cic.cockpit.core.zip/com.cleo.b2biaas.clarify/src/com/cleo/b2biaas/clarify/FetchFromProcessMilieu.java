package com.cleo.b2biaas.clarify;

import com.extol.businessprocess.ProcessMilieu;
import com.extol.businessprocess.ProcessMilieuWarden;

/**
 * @author Manju Muthuraj
 * 
 */
public class FetchFromProcessMilieu {

	private static final String DAYS = "Day";
	private static final String HOURS = "Hour";
	private static final String CIC_EDI_ROUTE_CONTEXT_LATE_ACK_THRESHOLD_UNIT_OF_TIME = "cic.ediRouteContext.lateAckThreshold.unitOfTime";
	private static final String CIC_EDI_ROUTE_CONTEXT_LATE_ACK_THRESHOLD_VALUE = "cic.ediRouteContext.lateAckThreshold.value";

	public String getFAcknowledgementDetails(String key) {
		ProcessMilieu processMilieu = ProcessMilieuWarden.getStrategy();
		String result = processMilieu.getValue(key);
		return result;
	}

	public String convertDaysToMinutes(String days) {
		if (days != null && !days.trim().isEmpty()) {
			int minutes = Integer.parseInt(days) * 1440;
			return Integer.toString(minutes);
		}
		return days;
	}

	public String convertHoursToMinutes(String hours) {
		if (hours != null && !hours.trim().isEmpty()) {
			int minutes = Integer.parseInt(hours) * 60;
			return Integer.toString(minutes);
		}
		return hours;
	}

	public String getLateFATimeInMinutes() {
		String lateAckThresholdValue = getFAcknowledgementDetails(CIC_EDI_ROUTE_CONTEXT_LATE_ACK_THRESHOLD_VALUE);
		String lateAckThresholdUnitOfTime = getFAcknowledgementDetails(CIC_EDI_ROUTE_CONTEXT_LATE_ACK_THRESHOLD_UNIT_OF_TIME);

		String lateFATime = null;

		switch (lateAckThresholdUnitOfTime) {
		case HOURS:
			lateFATime = convertHoursToMinutes(lateAckThresholdValue);
			break;

		case DAYS:
			lateFATime = convertDaysToMinutes(lateAckThresholdValue);
			break;

		default:
			lateFATime = lateAckThresholdValue;
			break;
		}
		return lateFATime;
	}
}
