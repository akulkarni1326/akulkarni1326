package com.cleo.cic.cockpit.core.outbound;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class outboundCockpitReferenceBPS implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode sourceContext;
    
    @TupleIndex(value = 1)
    public StorageNode targetContext;
    
    @TupleIndex(value = 2)
    public StorageNode ediData;
    
    @TupleIndex(value = 3)
    public com.extol.ebi.bps.lang.String partnerName;
    
    @TupleIndex(value = 4)
    public com.extol.ebi.bps.lang.String tpIdValue;
    
    @TupleIndex(value = 5)
    public Ruleset cockpitRuleset;
    
    @TupleIndex(value = 6)
    public com.extol.ebi.bps.lang.String ReprocessParms;
    
    @TupleIndex(value = 7)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public outboundCockpitReferenceBPS.ResultTuple execute(final StorageNode sourceContext, final StorageNode targetContext, final StorageNode ediData, final com.extol.ebi.bps.lang.String partnerName, final com.extol.ebi.bps.lang.String tpIdValue, final Ruleset cockpitRuleset, final com.extol.ebi.bps.lang.String ReprocessParms) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode sourceContext;
      
      @TupleIndex(value = 1)
      public StorageNode targetContext;
      
      @TupleIndex(value = 2)
      public StorageNode ediData;
      
      @TupleIndex(value = 3)
      public com.extol.ebi.ruleset.lang.core.String partnerName;
      
      @TupleIndex(value = 4)
      public com.extol.ebi.ruleset.lang.core.String tpIdValue;
      
      @TupleIndex(value = 5)
      public com.extol.ebi.ruleset.lang.core.Object cockpitRuleset;
      
      @TupleIndex(value = 6)
      public com.extol.ebi.ruleset.lang.core.String ReprocessParms;
      
      @TupleIndex(value = 7)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public outboundCockpitReferenceBPS.RulesetAction.ResultTuple execute(final StorageNode sourceContext, final StorageNode targetContext, final StorageNode ediData, final com.extol.ebi.ruleset.lang.core.String partnerName, final com.extol.ebi.ruleset.lang.core.String tpIdValue, final com.extol.ebi.ruleset.lang.core.Object cockpitRuleset, final com.extol.ebi.ruleset.lang.core.String ReprocessParms) {
      Object[] _bps_parameters = new Object[7];
      _bps_parameters[0] = sourceContext;
      _bps_parameters[1] = targetContext;
      _bps_parameters[2] = ediData;
      _bps_parameters[3] = toBpsString(partnerName);
      _bps_parameters[4] = toBpsString(tpIdValue);
      _bps_parameters[5] = toBpsObject(cockpitRuleset);
      _bps_parameters[6] = toBpsString(ReprocessParms);
      
      boolean _exit_PassStatus = launchScript("com.cleo.cic.cockpit.core", "com.cleo.cic.cockpit.core.outbound.outboundCockpitReferenceBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.sourceContext = asStorageNode(_bps_parameters[0]);
      resultTuple.targetContext = asStorageNode(_bps_parameters[1]);
      resultTuple.ediData = asStorageNode(_bps_parameters[2]);
      resultTuple.partnerName = asString(_bps_parameters[3]);
      resultTuple.tpIdValue = asString(_bps_parameters[4]);
      resultTuple.cockpitRuleset = asObject(_bps_parameters[5]);
      resultTuple.ReprocessParms = asString(_bps_parameters[6]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
  
  public static class DelimiterReplace implements BpsCallable {
    public boolean execute(final com.extol.ebi.bps.lang.String returnValue, final com.extol.ebi.bps.lang.String parm1) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
  }
}
