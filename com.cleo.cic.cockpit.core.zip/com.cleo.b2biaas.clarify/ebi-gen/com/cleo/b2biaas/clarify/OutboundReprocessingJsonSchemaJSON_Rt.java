/**
 * @generated
 */
package com.cleo.b2biaas.clarify;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.reactor.json.lib.schema.*;

@SuppressWarnings("all")
public class OutboundReprocessingJsonSchemaJSON_Rt implements RuntimeJsonSchemaProvider {
	private static RtJsonSchema schema_OutboundReprocessingJsonSchemaJSON;

	public RtJsonSchema getSchema() {
		if (schema_OutboundReprocessingJsonSchemaJSON == null) {
			FieldBuilder builder = new FieldBuilder("root");
			builder.withObjectType(cl_Root(), false);
			schema_OutboundReprocessingJsonSchemaJSON = new RtJsonSchema(builder.create());
		}

		return schema_OutboundReprocessingJsonSchemaJSON;
	}
	
	private RtJsonObjectClass cl_Root;
	
	private RtJsonObjectClass cl_Root() {
		if (cl_Root == null) {
			cl_Root = new RtJsonObjectClass("Root");
			List<RtJsonPairField> fields = new ArrayList<>();
			{
				FieldBuilder builder = new FieldBuilder("tileId");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("sourceStorageId");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("applicationKeys");
				builder.withStringType(true);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("applicationValues");
				builder.withStringType(true);
				fields.add(builder.create());
			}
			cl_Root.setFields(fields);
		}
	
		return cl_Root;
	}
}
