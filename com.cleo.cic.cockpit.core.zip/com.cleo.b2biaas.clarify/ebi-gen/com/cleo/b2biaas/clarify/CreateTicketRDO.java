package com.cleo.b2biaas.clarify;

import com.extol.ebi.lang.annotations.Version;
import com.extol.ebi.lang.rulesetdataobject.AbstractRulesetDataObject;
import com.extol.ebi.ruleset.lang.RulesetTypeConverter;
import java.util.Map;

@Version(value = 2)
@SuppressWarnings("all")
public class CreateTicketRDO extends AbstractRulesetDataObject {
  public com.extol.ebi.ruleset.lang.core.String messageId;
  
  public com.extol.ebi.ruleset.lang.core.String docType;
  
  public com.extol.ebi.ruleset.lang.core.String tradingPartnerId;
  
  public com.extol.ebi.ruleset.lang.core.String sourceData;
  
  public com.extol.ebi.ruleset.lang.core.String logOfMsgId;
  
  public com.extol.ebi.ruleset.lang.core.String originalLOM;
  
  public com.extol.ebi.ruleset.lang.core.String reprocess;
  
  protected void initialize(final Map<String, String> map, final RulesetTypeConverter tc) {
    messageId = tc.asRulesetString(getValue(map, "messageId"));
    docType = tc.asRulesetString(getValue(map, "docType"));
    tradingPartnerId = tc.asRulesetString(getValue(map, "tradingPartnerId"));
    sourceData = tc.asRulesetString(getValue(map, "sourceData"));
    logOfMsgId = tc.asRulesetString(getValue(map, "logOfMsgId"));
    originalLOM = tc.asRulesetString(getValue(map, "originalLOM"));
    reprocess = tc.asRulesetString(getValue(map, "reprocess"));
  }
  
  public void copyToMap(final Map<String, String> map, final RulesetTypeConverter tc) {
    map.put(getMapKey("messageId"), tc.toJavaString(messageId));
    map.put(getMapKey("docType"), tc.toJavaString(docType));
    map.put(getMapKey("tradingPartnerId"), tc.toJavaString(tradingPartnerId));
    map.put(getMapKey("sourceData"), tc.toJavaString(sourceData));
    map.put(getMapKey("logOfMsgId"), tc.toJavaString(logOfMsgId));
    map.put(getMapKey("originalLOM"), tc.toJavaString(originalLOM));
    map.put(getMapKey("reprocess"), tc.toJavaString(reprocess));
  }
}
