package com.cleo.b2biaas.clarify;

import java.util.concurrent.ConcurrentHashMap;

public class AddStorageNodeIds extends B2BAction {

	private ConcurrentHashMap<String, String> storageIds = new ConcurrentHashMap<>();
	private Utility utility = new Utility();

	public void execute(com.extol.ebi.ruleset.lang.core.String logOfMessageId,
			com.extol.ebi.ruleset.lang.core.String sourceStorageNodeId,
			com.extol.ebi.ruleset.lang.core.String targetStorageNodeId) {

		String logOfMessageIdTmp = "";
		String sourceStorageNodeIdTmp = "";
		String targetStorageNodeIdTmp = "";

		try {
			if (logOfMessageId != null && !EventKeys.NULL.equals(logOfMessageId.asJavaString().toLowerCase())
					&& !logOfMessageId.asJavaString().isEmpty()
					&& !EventKeys.NA.equals(logOfMessageId.asJavaString().toLowerCase())) {
				logOfMessageIdTmp = logOfMessageId.asJavaString();
			}

			if (sourceStorageNodeId != null && !EventKeys.NULL.equals(sourceStorageNodeId.asJavaString().toLowerCase())
					&& !sourceStorageNodeId.asJavaString().isEmpty()
					&& !EventKeys.NA.equals(sourceStorageNodeId.asJavaString().toLowerCase())) {
				sourceStorageNodeIdTmp = sourceStorageNodeId.asJavaString();
			}

			if (targetStorageNodeId != null && !EventKeys.NULL.equals(targetStorageNodeId.asJavaString().toLowerCase())
					&& !targetStorageNodeId.asJavaString().isEmpty()
					&& !EventKeys.NA.equals(targetStorageNodeId.asJavaString().toLowerCase())) {
				targetStorageNodeIdTmp = targetStorageNodeId.asJavaString();
			}

			if (!logOfMessageIdTmp.isEmpty()) {
				getStorageIds().put(EventKeys.KEY_LOGOFMESSAGEID, logOfMessageIdTmp);
			} else {
				throw new Exception(
						EventKeys.LOG_OF_MESSAGE_ID_CANNOT_BE_EMPTY);
			}

			if (!sourceStorageNodeIdTmp.isEmpty()) {
				getStorageIds().put(EventKeys.KEY_SOURCE_STORAGE_NODE_ID, sourceStorageNodeIdTmp);
			}

			if (!targetStorageNodeIdTmp.isEmpty()) {
				getStorageIds().put(EventKeys.KEY_TARGET_STORAGE_NODE_ID, targetStorageNodeIdTmp);
			}

			String updateMessage = utility.objectToString(getStorageIds());
			StringBuffer sbUpdateMessage = new StringBuffer(updateMessage);
			utility.postMessageTob2biaaS(sbUpdateMessage, EventKeys.API_UPDTAE_MESSAGE,
					EventKeys.UPDATE_MESSAGE_REQUEST_BODY);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public ConcurrentHashMap<String, String> getStorageIds() {
		return storageIds;
	}

}
