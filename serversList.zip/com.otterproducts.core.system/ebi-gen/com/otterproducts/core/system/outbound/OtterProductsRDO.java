package com.otterproducts.core.system.outbound;

import com.extol.ebi.lang.annotations.Version;
import com.extol.ebi.lang.rulesetdataobject.AbstractRulesetDataObject;
import com.extol.ebi.ruleset.lang.RulesetTypeConverter;
import java.util.Map;

@Version(value = 2)
@SuppressWarnings("all")
public class OtterProductsRDO extends AbstractRulesetDataObject {
  public com.extol.ebi.ruleset.lang.core.String SourceData;
  
  public com.extol.ebi.ruleset.lang.core.String PO109;
  
  protected void initialize(final Map<String, String> map, final RulesetTypeConverter tc) {
    SourceData = tc.asRulesetString(getValue(map, "SourceData"));
    PO109 = tc.asRulesetString(getValue(map, "PO109"));
  }
  
  public void copyToMap(final Map<String, String> map, final RulesetTypeConverter tc) {
    map.put(getMapKey("SourceData"), tc.toJavaString(SourceData));
    map.put(getMapKey("PO109"), tc.toJavaString(PO109));
  }
}
