package com.cleo.b2biaas.clarify;

import java.util.HashMap;

import com.extol.ebi.reactor.lib.types.ReactorObject;

/**
 * @author Manju Muthuraj
 * 
 */
public class InboundCreateMessageHeader extends B2BAction {

	public com.extol.ebi.ruleset.lang.core.Object execute(com.extol.ebi.ruleset.lang.core.String tpId,
			com.extol.ebi.ruleset.lang.core.String tpName, com.extol.ebi.ruleset.lang.core.String docType,
			com.extol.ebi.ruleset.lang.core.String parentMessageId, com.extol.ebi.ruleset.lang.core.String messageId,
			com.extol.ebi.ruleset.lang.core.String timeStamp, com.extol.ebi.ruleset.lang.core.String faExpected,
			com.extol.ebi.ruleset.lang.core.String currency, com.extol.ebi.ruleset.lang.core.String ownerId,
			com.extol.ebi.ruleset.lang.core.String functionalIdentifierCode,
			com.extol.ebi.ruleset.lang.core.String groupControlNumber,
			com.extol.ebi.ruleset.lang.core.String transactionControlNumber) {

		String currencyTmp = "";
		String parentMessageIdTmp = "";
		String faExpectedTmp = "";
		String interchangeControlNumber = "";
		String ownerIdTmp = EventKeys.NA;
		String functionalIdentifierCodeTmp = EventKeys.NA;
		String groupControlNumberTmp = EventKeys.NA;
		String transactionControlNumberTmp = EventKeys.NA;

		if (currency != null && !EventKeys.NULL.equals(currency.asJavaString().toLowerCase())
				&& !currency.asJavaString().isEmpty() && !EventKeys.NA.equals(currency.asJavaString().toLowerCase())) {
			currencyTmp = currency.asJavaString();
		}

		if (parentMessageId != null && !EventKeys.NULL.equals(parentMessageId.asJavaString().toLowerCase())
				&& !parentMessageId.asJavaString().isEmpty()
				&& !EventKeys.NA.equals(parentMessageId.asJavaString().toLowerCase())) {
			parentMessageIdTmp = parentMessageId.asJavaString();
		}

		if (faExpected != null && !EventKeys.NULL.equals(faExpected.asJavaString().toLowerCase())
				&& !faExpected.asJavaString().isEmpty()
				&& !EventKeys.NA.equals(faExpected.asJavaString().toLowerCase())) {
			faExpectedTmp = faExpected.asJavaString();
		}

		if (ownerId != null && !EventKeys.NULL.equals(ownerId.asJavaString().toLowerCase())
				&& !ownerId.asJavaString().isEmpty() && !EventKeys.NA.equals(ownerId.asJavaString().toLowerCase())) {
			ownerIdTmp = ownerId.asJavaString();
		}

		if (functionalIdentifierCode != null
				&& !EventKeys.NULL.equals(functionalIdentifierCode.asJavaString().toLowerCase())
				&& !functionalIdentifierCode.asJavaString().isEmpty()
				&& !EventKeys.NA.equals(functionalIdentifierCode.asJavaString().toLowerCase())) {
			functionalIdentifierCodeTmp = functionalIdentifierCode.asJavaString();
		}

		if (groupControlNumber != null && !EventKeys.NULL.equals(groupControlNumber.asJavaString().toLowerCase())
				&& !groupControlNumber.asJavaString().isEmpty()
				&& !EventKeys.NA.equals(groupControlNumber.asJavaString().toLowerCase())) {
			groupControlNumberTmp = groupControlNumber.asJavaString();
		}

		if (transactionControlNumber != null
				&& !EventKeys.NULL.equals(transactionControlNumber.asJavaString().toLowerCase())
				&& !transactionControlNumber.asJavaString().isEmpty()
				&& !EventKeys.NA.equals(transactionControlNumber.asJavaString().toLowerCase())) {
			transactionControlNumberTmp = transactionControlNumber.asJavaString();
		}

		HashMap<String, String> context = getContextForICN();
		if (context.containsKey(EventKeys.ENV_VAR_INTERCHANGE_CONTROL_NUMBER)) {
			interchangeControlNumber = context.get(EventKeys.ENV_VAR_INTERCHANGE_CONTROL_NUMBER);
		}

		InboundMessageApiCallV2 mi = new InboundMessageApiCallV2(tpId.asJavaString(), tpName.asJavaString(),
				docType.asJavaString(), parentMessageIdTmp, messageId.asJavaString(), timeStamp.asJavaString(),
				faExpectedTmp, currencyTmp, ownerIdTmp, functionalIdentifierCodeTmp, groupControlNumberTmp,
				transactionControlNumberTmp, interchangeControlNumber);
		return new ReactorObject(mi);
	}
}
