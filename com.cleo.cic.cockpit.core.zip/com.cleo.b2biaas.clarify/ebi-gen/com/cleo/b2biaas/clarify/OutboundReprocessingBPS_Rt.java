/**
* @generated
*/
package com.cleo.b2biaas.clarify;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class OutboundReprocessingBPS_Rt extends AbstractCatalyst {
	
	public OutboundReprocessingBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_sourceStorageNode) {
		final Variable<StorageNode> v_targetContext = variable(StorageNode.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "com.cleo.b2biaas.clarify.OutboundReprocessingRS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2biaas.clarify.OutboundReprocessingRS");
					return getInvokeDynamicTask("com.cleo.b2biaas.clarify.OutboundReprocessingRS", "bps1://Ruleset").execute(p_sourceStorageNode, null, literalTypeFromString(TransformationSettings.class, "com.cleo.b2biaas.clarify.TransformationSettingsTS"), null, null, v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Envelope Assembly By Context Point", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Envelope Assembly By Context Point");
					return getInvokeDynamicTask("com.extol.ebi.bps.lib.bps.EnvelopeAssemblyByContextPoint", "bps1://BusinessProcessScript").execute(v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		return builder.createRunner().run();
	}
}
