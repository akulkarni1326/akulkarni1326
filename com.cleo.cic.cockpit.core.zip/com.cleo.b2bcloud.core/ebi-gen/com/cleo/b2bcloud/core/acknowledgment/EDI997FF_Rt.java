/**
 * @generated
 */
package com.cleo.b2bcloud.core.acknowledgment;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.flatfile.lib.schema.*;

@SuppressWarnings("all")
public class EDI997FF_Rt implements RuntimeFlatFileSchemaProvider {

	private RtFlatFileSchema schema_EDI997FF;

	public RtFlatFileSchema getSchema() {
		if (schema_EDI997FF == null) {
			List<RtFilePartRef> parts = new ArrayList<>();
			parts.add(new RtFilePartRef("_RecordGroup0", 0, -1, rg_RecordGroup0()));

			schema_EDI997FF = new RtFlatFileSchema("EDI997FF", parts);
		}

		return schema_EDI997FF;
	}

	private RtRecord r_ISA;
	
	private RtRecord r_ISA() {
		if (r_ISA == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA01", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA02", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA03", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA04", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA05", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA06", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA07", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA08", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA09", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA010", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA011", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA012", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA013", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA014", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA015", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA016", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ISA017", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("ISA", fields.get(0));
	
			r_ISA = new RtRecord("ISA", fields, ra);
		}
	
		return r_ISA;
	}
	
	private RtRecord r_GS;
	
	private RtRecord r_GS() {
		if (r_GS == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS01", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS02", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS03", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS04", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS05", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS06", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS07", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS08", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GS09", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("GS", fields.get(0));
	
			r_GS = new RtRecord("GS", fields, ra);
		}
	
		return r_GS;
	}
	
	private RtRecord r_ST;
	
	private RtRecord r_ST() {
		if (r_ST == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ST01", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ST02", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("ST03", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("ST", fields.get(0));
	
			r_ST = new RtRecord("ST", fields, ra);
		}
	
		return r_ST;
	}
	
	private RtRecord r_AK1;
	
	private RtRecord r_AK1() {
		if (r_AK1 == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK101", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK102", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK103", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("AK1", fields.get(0));
			ra.groupOnRecord = true;
	
			r_AK1 = new RtRecord("AK1", fields, ra);
		}
	
		return r_AK1;
	}
	
	private RtRecord r_AK2;
	
	private RtRecord r_AK2() {
		if (r_AK2 == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK201", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK202", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK203", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("AK2", fields.get(0));
	
			r_AK2 = new RtRecord("AK2", fields, ra);
		}
	
		return r_AK2;
	}
	
	private RtRecord r_AK3;
	
	private RtRecord r_AK3() {
		if (r_AK3 == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK301", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK302", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK303", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK304", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK305", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("AK3", fields.get(0));
	
			r_AK3 = new RtRecord("AK3", fields, ra);
		}
	
		return r_AK3;
	}
	
	private RtRecord r_AK4;
	
	private RtRecord r_AK4() {
		if (r_AK4 == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK401", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK402", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK403", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK404", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK405", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("AK4", fields.get(0));
	
			r_AK4 = new RtRecord("AK4", fields, ra);
		}
	
		return r_AK4;
	}
	
	private RtRecord r_AK5;
	
	private RtRecord r_AK5() {
		if (r_AK5 == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK501", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK502", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK503", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("AK5", fields.get(0));
	
			r_AK5 = new RtRecord("AK5", fields, ra);
		}
	
		return r_AK5;
	}
	
	private RtRecord r_AK9;
	
	private RtRecord r_AK9() {
		if (r_AK9 == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK901", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK902", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK903", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK904", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("AK905", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("AK9", fields.get(0));
	
			r_AK9 = new RtRecord("AK9", fields, ra);
		}
	
		return r_AK9;
	}
	
	private RtRecord r_SE;
	
	private RtRecord r_SE() {
		if (r_SE == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("SE01", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("SE02", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("SE03", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("SE", fields.get(0));
	
			r_SE = new RtRecord("SE", fields, ra);
		}
	
		return r_SE;
	}
	
	private RtRecord r_GE;
	
	private RtRecord r_GE() {
		if (r_GE == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GE01", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GE02", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("GE03", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("GE", fields.get(0));
	
			r_GE = new RtRecord("GE", fields, ra);
		}
	
		return r_GE;
	}
	
	private RtRecord r_IEA;
	
	private RtRecord r_IEA() {
		if (r_IEA == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("IEA01", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("IEA02", RtFieldTypes.String, fa));
			}
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("IEA03", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
			ra.recordIdentifier = new RtFieldRecordIdentifier("IEA", fields.get(0));
	
			r_IEA = new RtRecord("IEA", fields, ra);
		}
	
		return r_IEA;
	}

	private RtRecordGroup rg_RecordGroup0;
	
	private RtRecordGroup rg_RecordGroup0() {
		if (rg_RecordGroup0 == null) {
			List<RtFilePartRef> parts = new ArrayList<>();
			parts.add(new RtFilePartRef("_ISA", 0, -1, r_ISA()));
			parts.add(new RtFilePartRef("_GS", 0, -1, r_GS()));
			parts.add(new RtFilePartRef("_RecordGroup1", 0, -1, rg_RecordGroup1()));
			parts.add(new RtFilePartRef("_GE", 0, -1, r_GE()));
			parts.add(new RtFilePartRef("_IEA", 0, -1, r_IEA()));
	
			rg_RecordGroup0 = new RtRecordGroup("RecordGroup0", parts, true);
		}
	
		return rg_RecordGroup0;
	}
	
	private RtRecordGroup rg_RecordGroup1;
	
	private RtRecordGroup rg_RecordGroup1() {
		if (rg_RecordGroup1 == null) {
			List<RtFilePartRef> parts = new ArrayList<>();
			parts.add(new RtFilePartRef("_ST", 0, -1, r_ST()));
			parts.add(new RtFilePartRef("_AK1", 0, 1, r_AK1()));
			parts.add(new RtFilePartRef("_RecordGroup2", 0, -1, rg_RecordGroup2()));
			parts.add(new RtFilePartRef("_AK9", 0, 1, r_AK9()));
			parts.add(new RtFilePartRef("_SE", 0, -1, r_SE()));
	
			rg_RecordGroup1 = new RtRecordGroup("RecordGroup1", parts, RtGroupType.UnorderedAfterStart, true);
		}
	
		return rg_RecordGroup1;
	}
	
	private RtRecordGroup rg_RecordGroup2;
	
	private RtRecordGroup rg_RecordGroup2() {
		if (rg_RecordGroup2 == null) {
			List<RtFilePartRef> parts = new ArrayList<>();
			parts.add(new RtFilePartRef("_AK2", 0, 1, r_AK2()));
			parts.add(new RtFilePartRef("_AK3", 0, 1, r_AK3()));
			parts.add(new RtFilePartRef("_AK4", 0, -1, r_AK4()));
			parts.add(new RtFilePartRef("_AK5", 0, 1, r_AK5()));
	
			rg_RecordGroup2 = new RtRecordGroup("RecordGroup2", parts, false);
		}
	
		return rg_RecordGroup2;
	}
}
