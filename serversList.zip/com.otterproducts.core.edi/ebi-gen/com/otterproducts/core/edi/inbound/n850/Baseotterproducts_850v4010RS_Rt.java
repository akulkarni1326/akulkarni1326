/**
* @generated
*/
package com.otterproducts.core.edi.inbound.n850;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class Baseotterproducts_850v4010RS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,RtPojoSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String v_date;
	private com.extol.ebi.ruleset.lang.core.DateTime v_Date;
	private com.extol.ebi.ruleset.lang.core.DateTime d_BEG05;
	private com.extol.ebi.ruleset.lang.core.Number v_sum;
	private com.extol.ebi.ruleset.lang.core.Number v_total;
	private com.extol.ebi.ruleset.lang.core.DateTime v_RequestedDeliveryNotAfterDate;
	private com.extol.ebi.ruleset.lang.core.DateTime v_RequestedDeliveryBeforeDate;
	private com.extol.ebi.ruleset.lang.core.String v_N104;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.otterproducts.core.edi.schemas.n850v4010EDI_Rt();
	}
	
	public SchemaProvider<RtPojoSchema> getTargetSchema() {
		return new com.otterproducts.core.system.n850.PurchaseOrderMessageOBJ_Rt();
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return new XMLObjectConnector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "for source.Area1.BEG", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			final SourceNode s1_BEG = s0_Area1.get("BEG");
			if (exists(s1_BEG)) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(\"Otter\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.FirstName]", action);
				final SourceNode var0 = toValueNode(asString("Otter"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "FirstName"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(\"EDI\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.LastName]", action);
				final SourceNode var0 = toValueNode(asString("EDI"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "LastName"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(\"otteredi@otterproducts.com\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.EmailAddress]", action);
				final SourceNode var0 = toValueNode(asString("otteredi@otterproducts.com"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "EmailAddress"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(5, "new Move().execute(\"970-419-7363\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.Phones.Phone.PhoneNumber]", action);
				final SourceNode var0 = toValueNode(asString("970-419-7363"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "Phones", "Phone", "PhoneNumber"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(6, "new Move().execute(\"work\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.Phones.Phone.PhoneTypeCode]", action);
				final SourceNode var0 = toValueNode(asString("work"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "Phones", "Phone", "PhoneTypeCode"), result);
			}
			createCompositeRule(7, "initNew target.purchaseOrderMessage.Order", new Block() { public void body() {
			
				final TargetNode t0_purchaseOrderMessage = target.getLast(at("purchaseOrderMessage"));
				final TargetNode t1_Order = t0_purchaseOrderMessage.getLast(at("Order"));
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(8, "new Move().execute(source.Area1.BEG.BEG324) => #[target.purchaseOrderMessage.Order.PurchaseOrderNumber, this.env.User_Reference_1]", action);
					final SourceNode var0 = s1_BEG.get("BEG324");
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("PurchaseOrderNumber"), result);
					Baseotterproducts_850v4010RS_Rt.this.env.User_Reference_1 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(9, "new Move().execute(source.Area1.BEG.BEG373) => #[this.v_Date]", action);
					final SourceNode var0 = s1_BEG.get("BEG373");
					final SourceNode result = action.execute(var0);
					Baseotterproducts_850v4010RS_Rt.this.v_Date = extractDateTime(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(10, "new Move().execute(this.v_Date) => #[target.purchaseOrderMessage.Order.OrderDate]", action);
					final SourceNode var0 = toValueNode(Baseotterproducts_850v4010RS_Rt.this.v_Date);
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("OrderDate"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(11, "new Move().execute(\"USD\") => #[target.purchaseOrderMessage.Order.CurrencyCode]", action);
					final SourceNode var0 = toValueNode(asString("USD"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("CurrencyCode"), result);
				}
				createCompositeRule(12, "for source.Area1.DTM", new Block() { public void body() {
					for (final SourceNode s1_cur_DTM : s0_Area1.getIterable("DTM")) {
				
				
					createCompositeRule(13, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(13, "new StringEquals().execute(source.Area1.DTM.current.DTM374, \"063\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_DTM.get("DTM374"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("063");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(14, "new Move().execute(source.Area1.DTM.current.DTM373) => #[target.purchaseOrderMessage.Order.DeliveryRequestedDate, target.purchaseOrderMessage.Order.RequestedDeliveryNotAfterDate, this.v_RequestedDeliveryNotAfterDate]", action);
							final SourceNode var0 = s1_cur_DTM.get("DTM373");
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("DeliveryRequestedDate"), result);
							t1_Order.set(at("RequestedDeliveryNotAfterDate"), result);
							Baseotterproducts_850v4010RS_Rt.this.v_RequestedDeliveryNotAfterDate = extractDateTime(result);
						}
					}}).run();
					createCompositeRule(15, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(15, "new StringEquals().execute(source.Area1.DTM.current.DTM374, \"064\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_DTM.get("DTM374"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("064");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(16, "new Move().execute(source.Area1.DTM.current.DTM373) => #[target.purchaseOrderMessage.Order.RequestedDeliveryNotBeforeDate, this.v_RequestedDeliveryBeforeDate]", action);
							final SourceNode var0 = s1_cur_DTM.get("DTM373");
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("RequestedDeliveryNotBeforeDate"), result);
							Baseotterproducts_850v4010RS_Rt.this.v_RequestedDeliveryBeforeDate = extractDateTime(result);
						}
					}}).run();
				}}}).run();
				createCompositeRule(17, "for source.Area1.REF", new Block() { public void body() {
					for (final SourceNode s1_cur_REF : s0_Area1.getIterable("REF")) {
				
				
					createCompositeRule(18, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(18, "new StringEquals().execute(source.Area1.REF.current.REF127, \"OTTF5\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF127"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("OTTF5");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(19, "new Move().execute(\"10001100\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.ID, target.purchaseOrderMessage.Order.BillToCustomerAccount.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerAccount.ID]", action);
							final SourceNode var0 = toValueNode(asString("10001100"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerLocation", "ID"), result);
							t1_Order.set(at("BillToCustomerAccount", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerAccount", "ID"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(20, "new Move().execute(\"Amazon.com Accounts Payable\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.Name]", action);
							final SourceNode var0 = toValueNode(asString("Amazon.com Accounts Payable"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "Name"), result);
						}
					}}).run();
				}}}).run();
				createCompositeRule(21, "for source.Area1.sgN1", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(21, "new StringEquals().execute(source.Area1.sgN1.current.N1.N198, \"ST\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s0_Area1.get("sgN1").get("N1").get("N198"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("ST");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
					for (final SourceNode s1_cur_sgN1 : s0_Area1.getIterable("sgN1")) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(22, "new Move().execute(source.Area1.sgN1.current.N1.N167) => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipmentId, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.PartyLocationIDCode, this.v_N104]", action);
						final SourceNode var0 = s1_cur_sgN1.get("N1").get("N167");
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("Shipments", "Shipment", "ShipmentId"), result);
						t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "PartyLocationIDCode"), result);
						Baseotterproducts_850v4010RS_Rt.this.v_N104 = extractString(result);
					}
				}}}).run();
				createCompositeRule(23, "for source.Area2.sgPO1.current.PO1 initNew target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine", new Block() { public void body() {
					final SourceNode s0_Area2 = source.get("Area2");
					if (exists(s0_Area2)) {
					for (final SourceNode s1_cur_sgPO1 : s0_Area2.getIterable("sgPO1")) {
					final SourceNode s2_PO1 = s1_cur_sgPO1.get("PO1");
					if (exists(s2_PO1)) {
				
					final TargetNode t2_CustomerOrderLines = t1_Order.getLast(at("CustomerOrderLines"));
					final TargetNode t3_cur_CustomerOrderLine = t2_CustomerOrderLines.create(at("CustomerOrderLine"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(24, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1350) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.PurchaseOrderLineNumber]", action);
						final SourceNode var0 = s2_PO1.get("PO1350");
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("PurchaseOrderLineNumber"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(25, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1330) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.OrderedQuantity]", action);
						final SourceNode var0 = s2_PO1.get("PO1330");
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("OrderedQuantity"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(26, "new Move().execute(\"EACH\") => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement]", action);
						final SourceNode var0 = toValueNode(asString("EACH"));
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("ProductQuantityUnitOfMeasurement"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(27, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1212) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount]", action);
						final SourceNode var0 = s2_PO1.get("PO1212");
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("ProductUnitPriceAmount"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(28, "new Move().execute(\"SEATTLE\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.CityName]", action);
						final SourceNode var0 = toValueNode(asString("SEATTLE"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "CityName"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(29, "new Move().execute(\"98108-0387\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.PostalCode]", action);
						final SourceNode var0 = toValueNode(asString("98108-0387"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "PostalCode"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(30, "new Move().execute(\"WA\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.StateCode]", action);
						final SourceNode var0 = toValueNode(asString("WA"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "StateCode"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(31, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.CountryCode]", action);
						final SourceNode var0 = toValueNode(asString("US"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "CountryCode"), result);
					}
					createCompositeRule(32, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(32, "new StringEquals().execute(source.Area2.sgPO1.current.PO1.PO1235, \"VN\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_PO1.get("PO1235"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("VN");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(33, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1234) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.Product.ProductId]", action);
							final SourceNode var0 = s2_PO1.get("PO1234");
							final SourceNode result = action.execute(var0);
							t3_cur_CustomerOrderLine.set(at("Product", "ProductId"), result);
						}
					}}).run();
					{
						com.extol.ebi.reactor.lib.actions.numeric.Multiply action = new com.extol.ebi.reactor.lib.actions.numeric.Multiply();
						createSimpleRule(34, "new com.extol.ebi.reactor.lib.actions.numeric.Multiply().execute(source.Area2.sgPO1.current.PO1.PO1330, source.Area2.sgPO1.current.PO1.PO1212, 0) => #[this.v_sum]", action);
						final com.extol.ebi.ruleset.lang.core.Number var0 = extractNumber(s2_PO1.get("PO1330"));
						final com.extol.ebi.ruleset.lang.core.Number var1 = extractNumber(s2_PO1.get("PO1212"));
						final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(0);
						final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
						Baseotterproducts_850v4010RS_Rt.this.v_sum = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
						createSimpleRule(35, "new com.extol.ebi.reactor.lib.actions.numeric.Add().execute(this.v_sum, this.v_total, null) => #[this.v_total]", action);
						final com.extol.ebi.ruleset.lang.core.Number var0 = Baseotterproducts_850v4010RS_Rt.this.v_sum;
						final com.extol.ebi.ruleset.lang.core.Number var1 = Baseotterproducts_850v4010RS_Rt.this.v_total;
						final com.extol.ebi.ruleset.lang.core.Number var2 = null;
						final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
						Baseotterproducts_850v4010RS_Rt.this.v_total = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(36, "new Move().execute(\"2324531766\") => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.PartnerOrderLineReferenceSourceNode]", action);
						final SourceNode var0 = toValueNode(asString("2324531766"));
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("PartnerOrderLineReferenceSourceNode"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(37, "new Move().execute(this.v_RequestedDeliveryBeforeDate) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.RequestedDeliveryNotBeforeDate]", action);
						final SourceNode var0 = toValueNode(Baseotterproducts_850v4010RS_Rt.this.v_RequestedDeliveryBeforeDate);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("RequestedDeliveryNotBeforeDate"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(38, "new Move().execute(this.v_RequestedDeliveryNotAfterDate) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.RequestedDeliveryNotAfterDate]", action);
						final SourceNode var0 = toValueNode(Baseotterproducts_850v4010RS_Rt.this.v_RequestedDeliveryNotAfterDate);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("RequestedDeliveryNotAfterDate"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(39, "new Move().execute(this.v_RequestedDeliveryNotAfterDate) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.DeliveryRequestedDate]", action);
						final SourceNode var0 = toValueNode(Baseotterproducts_850v4010RS_Rt.this.v_RequestedDeliveryNotAfterDate);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("DeliveryRequestedDate"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(40, "new Move().execute(this.v_N104) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.ShipmentId]", action);
						final SourceNode var0 = toValueNode(Baseotterproducts_850v4010RS_Rt.this.v_N104);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("ShipmentId"), result);
					}
				}}}}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(41, "new Move().execute(\"Buy\") => #[target.purchaseOrderMessage.Order.OrderTypeName]", action);
					final SourceNode var0 = toValueNode(asString("Buy"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("OrderTypeName"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(42, "new Move().execute(\"Unknown\") => #[target.purchaseOrderMessage.Order.OrderStatusName]", action);
					final SourceNode var0 = toValueNode(asString("Unknown"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("OrderStatusName"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(43, "new Move().execute(\"2324531766\") => #[target.purchaseOrderMessage.Order.PartnerOrderReferenceSourceNode]", action);
					final SourceNode var0 = toValueNode(asString("2324531766"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("PartnerOrderReferenceSourceNode"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(44, "new Move().execute(this.v_total) => #[target.purchaseOrderMessage.Order.TotalAmount]", action);
					final SourceNode var0 = toValueNode(Baseotterproducts_850v4010RS_Rt.this.v_total);
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("TotalAmount"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(45, "new Move().execute(\"PO Box 80387\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.AddressLine1]", action);
					final SourceNode var0 = toValueNode(asString("PO Box 80387"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("BillToCustomerLocation", "Address", "AddressLine1"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
					createSimpleRule(46, "new RawMove().execute(\"0000\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.PartyLocationIDCode]", action);
					final SourceNode var0 = toValueNode(asString("0000"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("BillToCustomerLocation", "PartyLocationIDCode"), result);
				}
			}}).run();
		}}}}).run();
	}

}
