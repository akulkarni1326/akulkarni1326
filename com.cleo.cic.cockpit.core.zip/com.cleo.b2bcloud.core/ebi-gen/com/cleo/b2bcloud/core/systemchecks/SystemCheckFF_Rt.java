/**
 * @generated
 */
package com.cleo.b2bcloud.core.systemchecks;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.flatfile.lib.schema.*;

@SuppressWarnings("all")
public class SystemCheckFF_Rt implements RuntimeFlatFileSchemaProvider {

	private RtFlatFileSchema schema_SystemCheckFF;

	public RtFlatFileSchema getSchema() {
		if (schema_SystemCheckFF == null) {
			List<RtFilePartRef> parts = new ArrayList<>();
			parts.add(new RtFilePartRef("_New_Record", 0, -1, r_New_Record()));

			schema_SystemCheckFF = new RtFlatFileSchema("SystemCheckFF", parts);
		}

		return schema_SystemCheckFF;
	}

	private RtRecord r_New_Record;
	
	private RtRecord r_New_Record() {
		if (r_New_Record == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fields.add(new RtFileField("New_Field", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
	
			r_New_Record = new RtRecord("New_Record", fields, ra);
		}
	
		return r_New_Record;
	}

}
