package com.cleo.b2bcloud.core.acknowledgment;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.codetable.lib.SingleInputCodeTable;
import com.extol.ebi.lang.CodeTable;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.reactor.lib.AbstractAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class ErrorCT implements CodeTable {
  public static class BpsTask implements BpsCallable {
    @OverrideOpName(value = "bps1://CodeTable")
    public boolean execute(final com.extol.ebi.bps.lang.String Key1, final com.extol.ebi.bps.lang.String Value) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
  }
  
  public static class RulesetAction extends AbstractAction implements RulesetCallable {
    public com.extol.ebi.ruleset.lang.core.String execute(final com.extol.ebi.ruleset.lang.core.String Key1) {
      String result = INSTANCE.get(asJavaString(Key1));
      return result == null ? null : asString(result);
    }
  }
  
  private static final SingleInputCodeTable INSTANCE = init();
  
  private static SingleInputCodeTable init() {
    SingleInputCodeTable ct = new SingleInputCodeTable(false, "");
    ct.addEntry("1", " Mandatory data element missing ");
    ct.addEntry("2", " Conditional required data element missing ");
    ct.addEntry("3", " Too many data elements ");
    ct.addEntry("4", " Data element too short ");
    ct.addEntry("5", " Data element too long ");
    ct.addEntry("6", " Invalid character in data element ");
    ct.addEntry("7", " Invalid code value ");
    ct.addEntry("8", " Invalid Date ");
    ct.addEntry("9", " Invalid Time ");
    ct.addEntry("10", " Exclusion Condition Violation ");
    return ct;
  }
}
