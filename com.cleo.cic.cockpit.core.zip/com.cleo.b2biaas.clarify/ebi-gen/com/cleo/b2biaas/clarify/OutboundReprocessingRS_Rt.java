/**
* @generated
*/
package com.cleo.b2biaas.clarify;

import java.io.IOException;

import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.exceptions.ReactorIOException;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.json.lib.connectors.*;
import com.extol.ebi.reactor.json.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class OutboundReprocessingRS_Rt extends AbstractReactor<RtJsonSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	private com.extol.ebi.lang.storage.StorageNode v_sourceStorageNode;
	private com.cleo.b2biaas.clarify.CreateTicketRDO glb = addToContextMap(new com.cleo.b2biaas.clarify.CreateTicketRDO());
	private com.extol.ebi.lang.storage.StorageNode context;
	
	public SchemaProvider<RtJsonSchema> getSourceSchema() {
		return new com.cleo.b2biaas.clarify.ReprocessingJSON_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new JsonConnector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "for source", new Block() { public void body() {
		
		
			{
				com.extol.ebi.reactor.server.actions.general.CreateStorageNodeWithId action = new com.extol.ebi.reactor.server.actions.general.CreateStorageNodeWithId();
				createSimpleRule(2, "new com.extol.ebi.reactor.server.actions.general.CreateStorageNodeWithId().execute(source.root.sourceStorageId) => #[this.v_sourceStorageNode]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(source.get("root").get("sourceStorageId"));
				final com.extol.ebi.lang.storage.StorageNode result = action.execute(var0);
				OutboundReprocessingRS_Rt.this.v_sourceStorageNode = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(source.root.originalLOM) => #[this.glb.originalLOM]", action);
				final SourceNode var0 = source.get("root").get("originalLOM");
				final SourceNode result = action.execute(var0);
				OutboundReprocessingRS_Rt.this.glb.originalLOM = extractString(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(true) => #[this.glb.reprocess]", action);
				final SourceNode var0 = toValueNode(asBoolean(true));
				final SourceNode result = action.execute(var0);
				OutboundReprocessingRS_Rt.this.glb.reprocess = extractString(result);
			}
			{
				com.extol.ebi.reactor.server.actions.route.AssembleContext action = new com.extol.ebi.reactor.server.actions.route.AssembleContext();
				createSimpleRule(5, "new com.extol.ebi.reactor.server.actions.route.AssembleContext().execute() => #[this.context]", action);
				final com.extol.ebi.lang.storage.StorageNode result = action.execute();
				OutboundReprocessingRS_Rt.this.context = result;
			}
			{
				com.extol.ebi.reactor.server.actions.route.ExecuteContentRouter action = new com.extol.ebi.reactor.server.actions.route.ExecuteContentRouter();
				createSimpleRule(6, "new com.extol.ebi.reactor.server.actions.route.ExecuteContentRouter().execute(source.root.RouteValue01, source.root.RouteValue02, source.root.RouteValue03, source.root.RouteValue04, source.root.RouteValue05, source.root.RouteValue06, source.root.RouteValue07, source.root.RouteValue08, source.root.RouteValue09, source.root.RouteValue10, source.root.RouteValue11, source.root.RouteValue12, source.root.RouteValue13, source.root.RouteValue14, source.root.RouteValue15, source.root.RouteValue16, source.root.RouteValue17, source.root.RouteValue18, source.root.RouteValue19, source.root.RouteValue20, this.context, this.v_sourceStorageNode) => #[]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(source.get("root").get("RouteValue01"));
				final com.extol.ebi.ruleset.lang.core.String var1 = extractString(source.get("root").get("RouteValue02"));
				final com.extol.ebi.ruleset.lang.core.String var2 = extractString(source.get("root").get("RouteValue03"));
				final com.extol.ebi.ruleset.lang.core.String var3 = extractString(source.get("root").get("RouteValue04"));
				final com.extol.ebi.ruleset.lang.core.String var4 = extractString(source.get("root").get("RouteValue05"));
				final com.extol.ebi.ruleset.lang.core.String var5 = extractString(source.get("root").get("RouteValue06"));
				final com.extol.ebi.ruleset.lang.core.String var6 = extractString(source.get("root").get("RouteValue07"));
				final com.extol.ebi.ruleset.lang.core.String var7 = extractString(source.get("root").get("RouteValue08"));
				final com.extol.ebi.ruleset.lang.core.String var8 = extractString(source.get("root").get("RouteValue09"));
				final com.extol.ebi.ruleset.lang.core.String var9 = extractString(source.get("root").get("RouteValue10"));
				final com.extol.ebi.ruleset.lang.core.String var10 = extractString(source.get("root").get("RouteValue11"));
				final com.extol.ebi.ruleset.lang.core.String var11 = extractString(source.get("root").get("RouteValue12"));
				final com.extol.ebi.ruleset.lang.core.String var12 = extractString(source.get("root").get("RouteValue13"));
				final com.extol.ebi.ruleset.lang.core.String var13 = extractString(source.get("root").get("RouteValue14"));
				final com.extol.ebi.ruleset.lang.core.String var14 = extractString(source.get("root").get("RouteValue15"));
				final com.extol.ebi.ruleset.lang.core.String var15 = extractString(source.get("root").get("RouteValue16"));
				final com.extol.ebi.ruleset.lang.core.String var16 = extractString(source.get("root").get("RouteValue17"));
				final com.extol.ebi.ruleset.lang.core.String var17 = extractString(source.get("root").get("RouteValue18"));
				final com.extol.ebi.ruleset.lang.core.String var18 = extractString(source.get("root").get("RouteValue19"));
				final com.extol.ebi.ruleset.lang.core.String var19 = extractString(source.get("root").get("RouteValue20"));
				final com.extol.ebi.lang.storage.StorageNode var20 = OutboundReprocessingRS_Rt.this.context;
				final com.extol.ebi.lang.storage.StorageNode var21 = OutboundReprocessingRS_Rt.this.v_sourceStorageNode;
				final com.extol.ebi.ruleset.lang.core.Boolean result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20, var21);
			}
		}}).run();
	}

}
