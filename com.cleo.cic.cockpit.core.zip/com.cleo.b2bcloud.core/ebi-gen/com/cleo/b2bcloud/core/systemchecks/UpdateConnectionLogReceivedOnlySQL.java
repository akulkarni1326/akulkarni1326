package com.cleo.b2bcloud.core.systemchecks;

import com.cleo.catalyst.lib.Variable;
import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.sqlaccess.SqlAccess;
import com.extol.ebi.reactor.database.lib.datasource.RtDataSource;
import com.extol.ebi.reactor.database.lib.schema.RtColumnTypes;
import com.extol.ebi.reactor.lib.AbstractAction;
import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;
import com.extol.ebi.sqlaccess.lib.BpsSqlAccessParameter;
import com.extol.ebi.sqlaccess.lib.Direction;
import com.extol.ebi.sqlaccess.lib.MultipleRecordsAction;
import com.extol.ebi.sqlaccess.lib.NoRecordsAction;
import com.extol.ebi.sqlaccess.lib.PreparedSqlAccess;
import com.extol.ebi.sqlaccess.lib.Retry;
import com.extol.ebi.sqlaccess.lib.SqlAccessHelper;
import com.extol.ebi.sqlaccess.lib.SqlAccessParameter;
import com.extol.ebi.sqlaccess.lib.TimeUnit;
import com.extol.ebi.sqlaccess.lib.Timeout;
import com.extol.ebi.sqlaccess.lib.V2SqlAccessTask;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("all")
public class UpdateConnectionLogReceivedOnlySQL implements SqlAccess {
  public void execute(final com.extol.ebi.ruleset.lang.core.String date, final com.extol.ebi.ruleset.lang.core.String activeCount) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class BpsTask extends V2SqlAccessTask implements BpsCallable {
    @OverrideOpName(value = "bps1://SQLAccess")
    public boolean execute(final com.extol.ebi.bps.lang.String date, final com.extol.ebi.bps.lang.String activeCount) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
    
    public boolean execute_v2(final Variable<String> date, final Variable<String> activeCount) {
      PreparedSqlAccess sqlAccess = buildSqlAccess(date);
      List<ValueNode> valueNodes = sqlAccess.performAction();
      
      activeCount.setValue(valueNodes == null ? null : extractValue(valueNodes.get(0), java.lang.String.class));
      
      return true;
    }
    
    private static PreparedSqlAccess buildSqlAccess(final Variable<String> date) {
      RtDataSource dataSource = new com.cleo.b2bcloud.core.systemchecks.ClarifyDatabaseDS_Rt();
      String statement = "update \"EBI\".\"LOG_OF_CONNECTION\" SET \"STATUS\" = \'9\' where \"EBI\".\"LOG_OF_CONNECTION\".\"STATUS\" =\'27\'  and \"DATE\" < ${date}";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      parameters.add(new BpsSqlAccessParameter("date", date, RtColumnTypes.BIGINT, Direction.IN));
      parameters.add(new BpsSqlAccessParameter("activeCount", RtColumnTypes.VARCHAR));
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
  
  public static class RulesetAction implements RulesetCallable, SqlAccess {
    public com.extol.ebi.ruleset.lang.core.String execute(final com.extol.ebi.ruleset.lang.core.String date) {
      return null;
    }
  }
  
  public static class RulesetActionV2 extends AbstractAction implements RulesetCallable, SqlAccess {
    public com.extol.ebi.ruleset.lang.core.String execute(final com.extol.ebi.ruleset.lang.core.String date) {
      PreparedSqlAccess sqlAccess = buildSqlAccess(date);
      List<ValueNode> valueNodes = sqlAccess.performAction();
      return (valueNodes == null ? null : valueNodes.get(0).extractString()); 
    }
    
    private static PreparedSqlAccess buildSqlAccess(final com.extol.ebi.ruleset.lang.core.String date) {
      RtDataSource dataSource = new com.cleo.b2bcloud.core.systemchecks.ClarifyDatabaseDS_Rt();
      String statement = "update \"EBI\".\"LOG_OF_CONNECTION\" SET \"STATUS\" = \'9\' where \"EBI\".\"LOG_OF_CONNECTION\".\"STATUS\" =\'27\'  and \"DATE\" < ${date}";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      parameters.add(new SqlAccessParameter("date", date, RtColumnTypes.BIGINT, Direction.IN));
      parameters.add(new SqlAccessParameter("activeCount", RtColumnTypes.VARCHAR));
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
}
