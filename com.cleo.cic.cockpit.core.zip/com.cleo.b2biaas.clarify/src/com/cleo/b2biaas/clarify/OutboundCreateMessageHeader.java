package com.cleo.b2biaas.clarify;

import com.extol.ebi.reactor.lib.types.ReactorObject;

/**
 * @author Manju Muthuraj
 * 
 */
public class OutboundCreateMessageHeader extends B2BAction {

	private FetchFromProcessMilieu faAckDetails = new FetchFromProcessMilieu();

	public com.extol.ebi.ruleset.lang.core.Object execute(com.extol.ebi.ruleset.lang.core.String tpName,
			com.extol.ebi.ruleset.lang.core.String docType, com.extol.ebi.ruleset.lang.core.String parentMessageId,
			com.extol.ebi.ruleset.lang.core.String messageId, com.extol.ebi.ruleset.lang.core.String timeStamp,
			com.extol.ebi.ruleset.lang.core.String faExpected, com.extol.ebi.ruleset.lang.core.String currency,
			com.extol.ebi.ruleset.lang.core.String logOfMessageId, com.extol.ebi.ruleset.lang.core.String tpId) {

		String currencyTmp = "";
		String parentMessageIdTmp = "";
		String faExpectedTmp = "";
		String faLateTime = null;
		String logOfMessageIdTmp = "";

		if (currency != null && !EventKeys.NULL.equals(currency.asJavaString().toLowerCase())
				&& !currency.asJavaString().isEmpty() && !EventKeys.NA.equals(currency.asJavaString().toLowerCase())) {
			currencyTmp = currency.asJavaString();
		}

		if (parentMessageId != null && !EventKeys.NULL.equals(parentMessageId.asJavaString().toLowerCase())
				&& !parentMessageId.asJavaString().isEmpty()
				&& !EventKeys.NA.equals(parentMessageId.asJavaString().toLowerCase())) {
			parentMessageIdTmp = parentMessageId.asJavaString();
		}

		if (faExpected != null && !faExpected.asJavaString().isEmpty()
				&& !EventKeys.NULL.equals(faExpected.asJavaString().toLowerCase())
				&& !EventKeys.NA.equals(faExpected.asJavaString().toLowerCase())) {
			faExpectedTmp = faExpected.asJavaString();
		}

		if (logOfMessageId != null && !logOfMessageId.asJavaString().isEmpty()
				&& !EventKeys.NULL.equals(logOfMessageId.asJavaString().toLowerCase())
				&& !EventKeys.NA.equals(logOfMessageId.asJavaString().toLowerCase())) {
			logOfMessageIdTmp = logOfMessageId.asJavaString();
		}

		OutboundMessageApiCallV2 mi = new OutboundMessageApiCallV2(tpName.asJavaString(), docType.asJavaString(),
				parentMessageIdTmp, messageId.asJavaString(), timeStamp.asJavaString(), faExpectedTmp, currencyTmp,
				logOfMessageIdTmp, tpId.asJavaString());

		try {
			faLateTime = faAckDetails.getLateFATimeInMinutes();
		} catch (Exception ex) {
			logInfo("Get getLateFATimeInMinutes details failed due to  " + ex);
		}

		if (faLateTime != null) {
			mi.addKey(EventKeys.LATE_FA_TIME, faLateTime);
		}

		return new ReactorObject(mi);
	}
}
