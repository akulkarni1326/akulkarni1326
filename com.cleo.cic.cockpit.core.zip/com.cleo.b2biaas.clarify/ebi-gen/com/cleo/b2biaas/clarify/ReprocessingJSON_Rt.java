/**
 * @generated
 */
package com.cleo.b2biaas.clarify;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.reactor.json.lib.schema.*;

@SuppressWarnings("all")
public class ReprocessingJSON_Rt implements RuntimeJsonSchemaProvider {
	private static RtJsonSchema schema_ReprocessingJSON;

	public RtJsonSchema getSchema() {
		if (schema_ReprocessingJSON == null) {
			FieldBuilder builder = new FieldBuilder("root");
			builder.withObjectType(cl_Root(), false);
			schema_ReprocessingJSON = new RtJsonSchema(builder.create());
		}

		return schema_ReprocessingJSON;
	}
	
	private RtJsonObjectClass cl_Root;
	
	private RtJsonObjectClass cl_Root() {
		if (cl_Root == null) {
			cl_Root = new RtJsonObjectClass("Root");
			List<RtJsonPairField> fields = new ArrayList<>();
			{
				FieldBuilder builder = new FieldBuilder("originalLOM");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("sourceStorageId");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue01");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue02");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue03");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue04");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue05");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue06");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue07");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue08");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue09");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue10");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue11");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue12");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue13");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue14");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue15");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue16");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue17");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue18");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue19");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			{
				FieldBuilder builder = new FieldBuilder("RouteValue20");
				builder.withStringType(false);
				fields.add(builder.create());
			}
			cl_Root.setFields(fields);
		}
	
		return cl_Root;
	}
}
