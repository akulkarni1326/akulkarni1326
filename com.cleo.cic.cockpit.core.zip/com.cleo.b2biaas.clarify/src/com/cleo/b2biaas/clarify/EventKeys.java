package com.cleo.b2biaas.clarify;

import com.extol.ebi.factory.EBIFactoryManager;

/**
 * @author Manju Muthuraj
 * 
 */
public class EventKeys {
	
	//Envelope
	public static final String INTERCHANGE_SENDER_ID_QUALIFIER = "InterchangeSenderIDQualifier";
	public static final String INTERCHANGE_SENDER_ID = "InterchangeSenderID" ;
	public static final String INTERCHANGE_RECEIVER_ID_QUALIFIER ="InterchangeReceiverIDQualifier";
	public static final String INTERCHANGE_RECEIVER_ID = "InterchangeReceiverID";
	public static final String LOGOF_MESSAGE_ID = "LogOfMessageID";
	public static final String GROUP_CODE = "GroupCode";
	public static final String GROUP_CONTROL_NUMBER = "GroupControlNumber";
	public static final String MESSAGE_CONTROL_NUMBER = "MessageControlNumber";
	public static final String INTERCHANGE_CONTROL_NUMBER = "InterchangeControlNumber";
	public static final String PROGRAM_CALLED_FROM = "ProgramCalledFrom";
	public static final String DIRECTION = "direction";
	public static final String TIMESTAMP = "timeStamp";
	
	//outbound/Inbound FA
	public static final String AK901 = "AK901";
	public static final String AK102 = "AK102";
	public static final String AK101 = "AK101";
	public static final String AK501 = "AK501";
	public static final String AK201 = "AK201";
	public static final String AK202 = "AK202";
	
	//API resources
	public static final String API_MESSAGE_TENANT = "/api/message/tenant/";
	public static final String API_FA_MESSAGE_TENANT = "/api/faMessage/tenant/";
	public static final String API_TICKET_TENANT = "/api/ticket/tenant/";
	public static final String API_FA_MESSAGE_TENANT_V2 = "/api/faMessageV2/tenant/";
	public static final String API_UPLOADATTACHMENT = "/uploadattachment";
	public static final String API_UPDTAE_MESSAGE = "/api/updatemessage/tenant/";
	
	//config.properties
	public static final String SERVER_URL = EBIFactoryManager.getFactory().loadProperties("config.properties", EventKeys.class).getProperty("SERVER_URL");
	public static final String TENANTID_STAGE = EBIFactoryManager.getFactory().loadProperties("config.properties", EventKeys.class).getProperty("TENANTID_STAGE");
	public static final String TENANTID_PRODUCTION = EBIFactoryManager.getFactory().loadProperties("config.properties", EventKeys.class).getProperty("TENANTID_PRODUCTION");
	public static final String ENVIRONMENT = EBIFactoryManager.getFactory().loadProperties("config.properties", EventKeys.class).getProperty("ENVIRONMENT");
	public static final String SECURITY_TOKEN_STAGE = EBIFactoryManager.getFactory().loadProperties("config.properties", EventKeys.class).getProperty("SECURITY_TOKEN_STAGE");
	public static final String SECURITY_TOKEN_PRODUCTION = EBIFactoryManager.getFactory().loadProperties("config.properties", EventKeys.class).getProperty("SECURITY_TOKEN_PRODUCTION");

	//JSON keys
	public static final String KEY_SOURCE_STORAGE_NODE_ID = "sourceStorageNodeId";
	public static final String KEY_TARGET_STORAGE_NODE_ID = "targetStorageNodeId";
	public static final String KEY_TPID = "tpId";
	public static final String KEY_TPNAME = "tpName";
	public static final String KEY_DOCTYPE = "docType";
	public static final String KEY_PARENTMESSAGEID = "parentMessageId";
	public static final String KEY_MESSAGEID = "messageId";
	public static final String KEY_TIMESTAMP = "timeStamp";
	public static final String KEY_DIRECTION = "direction";
	public static final String KEY_FAEXPECTED = "faExpected";
	public static final String KEY_CURRENCY = "currency";
	public static final String KEY_OWNERID = "ownerId";
	public static final String KEY_FUNCTIONALIDENTIFIERCODE = "functionalIdentifierCode";
	public static final String KEY_GCN = "groupControlNumber";
	public static final String KEY_TCN = "transactionControlNumber";
	public static final String KEY_ICN = "interchangeControlNumber";
	public static final String KEY_LOGOFMESSAGEID = "logOfMessageId";
	public static final String KEY_SUBJECT = "subject";
	public static final String KEY_BODY = "body";
	public static final String KEY_TYPE = "type";
	public static final String ENV_VAR_LOG_OF_MESSAGE_ID = "env.var.Log_of_Message_Id";
	public static final String ENV_VAR_INTERCHANGE_CONTROL_NUMBER = "env.var.Interchange_Control_Number";
	public static final String DIRECTION_R = "R";
	public static final String DIRECTION_S = "S";
	public static final String VALUE = "value";
	public static final String TYPE = "type";
	public static final String PROBLEM = "problem";
	public static final String UPLOAD_TOKEN_KEY = "uploadToken";
	public static final String OUTBOUND_DOCUMENT = "outboundDocument";
	public static final String OUTBOUND_FA_DOCUMENT = "outboundFADocument";
	public static final String INBOUND_FA_DOCUMENT_END = "inboundFADocumentEnd";
	public static final String INBOUND_FA_DOCUMENT = "inboundFADocument";
	public static final String INBOUND_FA_DOCUMENT_START = "inboundFADocumentStart";
	public static final String CONTEXT = "Context";
	public static final String LINE_SEPARATOR = "line.separator";
	public static final String HEADER_VALUE_APPLICATION_JSON = "application/json";
	public static final String HEADER_VALUE_APPLICATION_OCTETSTREAM = "application/octet-stream";
	public static final String HEADER_KEY_AUTHORIZATION = "Authorization";
	public static final String HEADER_KEY_CONTENT_TYPE = "Content-Type";
	public static final String HEADER_ACCEPT = "Accept";
	public static final String HTTP_POST_METHOD = "POST";
	public static final String LATE_FA_TIME = "lateFaTime";
	
	//Logging
	public static final String GENERATING_THE_UUID_FOR_START_EVENT = "<<<<<<<<<<<<<<< Generating the UUID for start event  ==>>>>> ";
	public static final String GETTING_UUID_FOR_END_EVENT = "<<<<<<<<<<<<<<< Getting UUID for end event  ==>>>>> ";
	public static final String ERROR_CREATING_JSON_STRUCTURE = "<<<<<<<<<<<<<<< Error creating Json structure >>>>>>>>>>>>>>> \n";
	public static final String THE_ENVIRONMENT_SHOULD_BE_EITHER_STAGE_OR_PRODUCTION = "<<<<<<<<<<<<<<< The environment should be either 'stage' or 'production'  ==>>>>> ";
	public static final String LOADING_PROPERTIES_FROM_RESOURCES_OF_API_PROJECT_FOR_COCKPIT = "<<<<<<<<<<<<<<< Loading properties from resources of API project for cockpit >>>>>>>>>>>>>>>";
	public static final String CREATE_TICKET_WITH_ATTACHMENT_REQUEST_BODY = "<<<<<<<<<<<<<<< Create Ticket With Attachment Request body >>>>>>>>>>>>>>> \n";
	public static final String LOADING_PROPERTIES_FROM_CLOUD_CONFIG_FOR_COCKPIT = "<<<<<<<<<<<<<<< Loading properties from cloud config for cockpit >>>>>>>>>>>>>>>";
	public static final String AS_LOG_OF_MESSAGE_ID_KEY_DOES_NOT_EXIST_GENERATING_THE_LOG_OF_MESSAGE_ID = "<<<<<<<<<<<<<<< As logOfMessageId key does not exist, generating the logOfMessageId  ==>>>>> ";
	public static final String CONTEXT_IS_SET_FOR_ENV_VAR_LOG_OF_MESSAGE_ID = "<<<<<<<<<<<<<<< Context is set for env.var.Log_of_Message_Id >>>>>>>>>>>>>>> \n";
	public static final String AS_VALUE_OF_LOG_OF_MESSAGE_ID_KEY_IS_NULL_OR_EMPTY_GENERATING_THE_LOG_OF_MESSAGE_ID = "<<<<<<<<<<<<<<<  As value of logOfMessageId key is null or empty, generating the logOfMessageId  ==>>>>> ";
	public static final String LOG_OF_MESSAGE_ID_KEY_EXISTS_AND_VALUE_IS = "<<<<<<<<<<<<<<< logOfMessageId key exists and value is   ==>>>>> ";
	public static final String INBOUND_MESSAGE_REQUEST_BODY = "<<<<<<<<<<<<<<< Inbound Message request body >>>>>>>>>>>>>>> \n";
	public static final String OUTBOUND_MESSAGE_REQUEST_BODY = "<<<<<<<<<<<<<<< Outbound Message request body >>>>>>>>>>>>>>> \n";
	public static final String UPDATE_MESSAGE_REQUEST_BODY = "<<<<<<<<<<<<<<< Update Message request body >>>>>>>>>>>>>>> \n";
	public static final String OUTBOUNDDOCUMENT_LOG_HEADER = "<<<<<<<<<<<<<<< outboundDocument Envelope Request body >>>>>>>>>>>>>>> \n";
	public static final String INBOUNDFA_DOCUMENT_LOG_HEADER = "<<<<<<<<<<<<<<< inboundFADocument Request body >>>>>>>>>>>>>>> \n";
	public static final String OUTBOUNDFA_DOCUMENT_LOG_HEADER = "<<<<<<<<<<<<<<< outboundFADocument Request body >>>>>>>>>>>>>>> \n";
	public static final String CONTEXT_MAP_SAVED = "<<<<<<<<<<<<<<< Context map saved >>>>>>>>>>>>>>> \n";
	public static final String SAVING_CONTEXT_MAP = "<<<<<<<<<<<<<<< Saving context map >>>>>>>>>>>>>>> \n";
	public static final String CONTEXT_MAP_ASSEMBLED = "<<<<<<<<<<<<<<< Context map assembled >>>>>>>>>>>>>>> \n";
	public static final String ASSEMBLING_THE_CONTEXT_MAP = "<<<<<<<<<<<<<<< Assembling the context map >>>>>>>>>>>>>>> \n";
	public static final String B2BIAAS_ENVIRONMENT = "<<<<<<<<<<<<<<< B2BiaaS Environment  ==>>>>> ";
	public static final String UPLOAD_TOKEN_LOG = "<<<<<<<<<<<<<<< Upload Token  ==>>>>> ";
	public static final String UPLOAD_ATTACHEMNET_URL = "<<<<<<<<<<<<<<< Upload Attachemnet URL  ==>>>>> ";
	public static final String EXITING_THE_RETRY_AFTER_3_RETRIES = "<<<<<<<<<<<<<<< Exiting the retry after 3 retries >>>>>>>>>>>>>>> \n";
	public static final String SERVER_RESPONSE_BODY = "<<<<<<<<<<<<<<< Server Response body >>>>>>>>>>>>>>> \n";
	public static final String SERVER_URL_LOG = "<<<<<<<<<<<<<<< SERVER_URL ==>>>>> ";
	public static final String EVENTKEYS_LOG = "<<<<<<<<<<<<<<< Event keys ==>>>>> ";
	public static final String CLOUD_CONFIG_IS_CONFIGURED = "<<<<<<<<<<<<<<< CloudConfig.isConfigured() ==>>>>> ";
	public static final String LOG_OF_MESSAGE_ID_CANNOT_BE_EMPTY = "============>>>>>>> 'logOfMessageId' cannot be empty as it is a mandatory field. Make sure to add a logOfMessageId.";
	public static final String NA = "na";
	public static final String FALSE = "false";
	public static final String NULL = "null";
	
}
