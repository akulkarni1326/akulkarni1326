/**
* @generated
*/
package com.cleo.b2bcloud.core.systemchecks;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.extol.ebi.bps.lib.tasks.misc.CompareValues;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStringToStorageNode;
import com.extol.ebi.bps.lib.tasks.string.AppendString;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps.lib.types.CompareType;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class SystemCheckBPS_Rt extends AbstractCatalyst {
	
	public SystemCheckBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute() {
		final Variable<String> v_vActiveCount = variable(String.class, null);
		final Variable<String> v_c0 = variable(String.class, "0");
		final Variable<String> v_vReceivedOnlyCount = variable(String.class, null);
		final Variable<String> v_vDateLong = variable(String.class, null);
		final Variable<StorageNode> v_input = variable(StorageNode.class, null);
		final Variable<StorageNode> v_targetContext = variable(StorageNode.class, null);
		final Variable<String> v_vReceivedUnwrappedCount = variable(String.class, null);
		final Variable<String> v_vGeneratedStatusCount = variable(String.class, "0");
		final Variable<String> v_vSubject = variable(String.class, null);
		final Variable<String> v_vDateMinusDayLong = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Convert String to Storage Node", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert String to Storage Node");
					ConvertStringToStorageNode task = new ConvertStringToStorageNode();
					setupTask(task);
					return task.execute(variable(String.class, "dummy"), v_input);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.ConvertDateRS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.ConvertDateRS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.ConvertDateRS", "bps1://Ruleset").execute(v_input, null, literalTypeFromString(TransformationSettings.class, "com.cleo.b2bcloud.core.DefaultTransformationSettingsTS"), null, null, v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_targetContext, variable(String.class, "env.var.User_Reference_1"), new ContextPointVar(v_vDateLong));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_targetContext, variable(String.class, "env.var.User_Reference_2"), new ContextPointVar(v_vDateMinusDayLong));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("activeStopped", "com.cleo.b2bcloud.core.systemchecks.CheckLogOfProcessSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.CheckLogOfProcessSQL$BpsTask");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.CheckLogOfProcessSQL$BpsTask", "bps1://SQLAccess").execute(v_vDateLong, v_vActiveCount);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_vActiveCount, v_c0, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "receivedOnly", "next");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", "bps1://BusinessProcessScript").execute(variable(String.class, "Active or Stopped Processes exist"));
				} finally { _endTask();}
			}
		}, "next", "next");
		
		builder.addStep("receivedOnly", "com.cleo.b2bcloud.core.systemchecks.CheckLogOfConnectionSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.CheckLogOfConnectionSQL$BpsTask");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.CheckLogOfConnectionSQL$BpsTask", "bps1://SQLAccess").execute(v_vDateLong, v_vReceivedOnlyCount);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_vReceivedOnlyCount, v_c0, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "generatedStatus", "next");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", "bps1://BusinessProcessScript").execute(variable(String.class, "Received Only Connection Exist"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("generatedStatus", "com.cleo.b2bcloud.core.systemchecks.CheckGeneratedConnectionsSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.CheckGeneratedConnectionsSQL$BpsTask");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.CheckGeneratedConnectionsSQL$BpsTask", "bps1://SQLAccess").execute(v_vDateLong, v_vDateMinusDayLong, v_vGeneratedStatusCount);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_vGeneratedStatusCount, v_c0, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "receivedUnwrapped", "next");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_vSubject, variable(String.class, "Generated Status Connection Exist: Count - "), v_vGeneratedStatusCount);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", "bps1://BusinessProcessScript").execute(v_vSubject);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("receivedUnwrapped", "com.cleo.b2bcloud.core.systemchecks.CheckLogOfMessageSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.CheckLogOfMessageSQL$BpsTask");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.CheckLogOfMessageSQL$BpsTask", "bps1://SQLAccess").execute(v_vDateLong, v_vReceivedUnwrappedCount);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_vReceivedUnwrappedCount, v_c0, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "end", "next");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.EmailNotificationBPS", "bps1://BusinessProcessScript").execute(variable(String.class, "Received and UnWrapped Messages Exist"));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
