/**
 * @generated
 */
package com.xref.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.extol.ebi.reactor.database.adapter.lib.rtfm.*;
import com.extol.ebi.reactor.database.lib.datasource.*;
import com.extol.ebi.reactor.database.lib.schema.RtDatabaseSchema;
import com.extol.ebi.reactor.database.lib.schema.RuntimeDatabaseSchemaProvider;

@SuppressWarnings("all")
public class InsertLinesAmazonDBA_Rt implements RuntimeDatabaseAdapterProvider {

	private RtDataSource dataSource;

	public RtDataSource getDataSource() {
		if (this.dataSource == null)  {
			this.dataSource = new com.xref.connection.xrefinternalDS_Rt();
		}
		return this.dataSource;
	}

	private RuntimeDatabaseSchemaProvider runtimeDatabaseSchemaProvider;

	public RtDatabaseSchema getDatabaseSchema() {
		if (this.runtimeDatabaseSchemaProvider == null) {
			this.runtimeDatabaseSchemaProvider = new com.xref.connection.InsertLinesAmazon_Rt();
		}

		return this.runtimeDatabaseSchemaProvider.getSchema();
	}

	public Interaction getInteraction(String name) {
		switch (name) {
		case "Insert":
			return Insert();
		}

		return null;
	}

	private RtInsert Insert;
	
	public RtInsert Insert() {
		if (this.Insert == null) {
			List<RtInsertMapBinding> bindings = new ArrayList<>();
			{
				bindings.add(new RtInsertMapBinding(LineNumbers()));
			}
	
			this.Insert = new RtInsert(RtTransactionLevel.None, false, bindings, 0);
		}
	
		return this.Insert;
	}

	private RtClassTableMap LineNumbers;
	
	private RtClassTableMap LineNumbers() {
		if (this.LineNumbers == null) {
			Map<String, String> relations = new HashMap<>();
	
			this.LineNumbers = new RtClassTableMap(getDatabaseSchema().getDefinedTableObject("LineNumbers"), "LineNumbers", relations);
		}
	
		return this.LineNumbers;
	}
}
