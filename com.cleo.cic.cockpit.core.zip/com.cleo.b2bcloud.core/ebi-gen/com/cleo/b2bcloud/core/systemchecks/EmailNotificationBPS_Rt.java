/**
* @generated
*/
package com.cleo.b2bcloud.core.systemchecks;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.SendEmail;
import com.extol.ebi.bps.lib.tasks.string.AppendString;
import com.extol.ebi.bps.lib.tasks.string.ResolveGlobalVariables;
import com.extol.ebi.bps.lib.types.unions.Attachment;
import com.extol.ebi.bps.lib.types.unions.Message;

@SuppressWarnings("all")
public class EmailNotificationBPS_Rt extends AbstractCatalyst {
	
	public EmailNotificationBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(String.class) Variable<String> p_failure) {
		final Variable<String> v_emailTo = variable(String.class, null);
		final Variable<String> v_emailFrom = variable(String.class, null);
		final Variable<String> v_customer = variable(String.class, null);
		final Variable<String> v_Subject = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep("HostEmail", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_emailFrom, variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.B2BCloudHostEmail>"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("SystemCheckEmailTo", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_emailTo, variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.SystemCheckEmailTo>"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("Environment", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_customer, variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.Environment>"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_Subject, v_customer, p_failure);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Send Email", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Send Email");
					SendEmail task = new SendEmail();
					setupTask(task);
					return task.execute(v_emailTo, v_emailFrom, null, null, v_Subject, new Message(v_Subject), new Attachment(null), null);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		return builder.createRunner().run();
	}
}
