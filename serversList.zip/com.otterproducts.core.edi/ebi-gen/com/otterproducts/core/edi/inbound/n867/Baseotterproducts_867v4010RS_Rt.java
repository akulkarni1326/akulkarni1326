/**
* @generated
*/
package com.otterproducts.core.edi.inbound.n867;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class Baseotterproducts_867v4010RS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,RtPojoSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String v_Date;
	private com.extol.ebi.ruleset.lang.core.DateTime vDate;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.otterproducts.core.edi.schemas.n867v4010EDI_Rt();
	}
	
	public SchemaProvider<RtPojoSchema> getTargetSchema() {
		return new com.otterproducts.core.system.n867.T867OBJ_Rt();
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return new XMLObjectConnector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "for source.Area1.BPT", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			final SourceNode s1_BPT = s0_Area1.get("BPT");
			if (exists(s1_BPT)) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(source.Area1.BPT.BPT127) => #[target.t867.LISA.LGS.LST.SBPT_2.E127_2_02, this.env.User_Reference_2]", action);
				final SourceNode var0 = s1_BPT.get("BPT127");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SBPT_2", "E127_2_02"), result);
				Baseotterproducts_867v4010RS_Rt.this.env.User_Reference_2 = extractString(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(source.Area1.BPT.BPT353) => #[target.t867.LISA.LGS.LST.SBPT_2.E353_2_01]", action);
				final SourceNode var0 = s1_BPT.get("BPT353");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SBPT_2", "E353_2_01"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(source.Area1.BPT.BPT373) => #[this.v_Date]", action);
				final SourceNode var0 = s1_BPT.get("BPT373");
				final SourceNode result = action.execute(var0);
				Baseotterproducts_867v4010RS_Rt.this.v_Date = extractString(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
				createSimpleRule(5, "new CreateDateTimeFromString().execute(this.v_Date, \"yyyymmdd\") => #[this.vDate]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = Baseotterproducts_867v4010RS_Rt.this.v_Date;
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyymmdd");
				final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
				Baseotterproducts_867v4010RS_Rt.this.vDate = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime();
				createSimpleRule(6, "new FormatDateTime().execute(this.vDate, \"mm/dd/yyyy\") => #[this.v_Date]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime var0 = Baseotterproducts_867v4010RS_Rt.this.vDate;
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("mm/dd/yyyy");
				final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
				Baseotterproducts_867v4010RS_Rt.this.v_Date = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(7, "new Move().execute(this.v_Date) => #[target.t867.LISA.LGS.LST.SBPT_2.E373_2_03]", action);
				final SourceNode var0 = toValueNode(Baseotterproducts_867v4010RS_Rt.this.v_Date);
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SBPT_2", "E373_2_03"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(8, "new Move().execute(source.Area1.BPT.BPT755) => #[target.t867.LISA.LGS.LST.SBPT_2.E755_2_04]", action);
				final SourceNode var0 = s1_BPT.get("BPT755");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SBPT_2", "E755_2_04"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
				createSimpleRule(9, "new RawMove().execute(source.Area1.ST.ST143) => #[target.t867.LISA.LGS.LST.SST_1.E143_1_01]", action);
				final SourceNode var0 = s0_Area1.get("ST").get("ST143");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SST_1", "E143_1_01"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
				createSimpleRule(10, "new RawMove().execute(source.Area1.ST.ST329) => #[target.t867.LISA.LGS.LST.SST_1.E329_1_02]", action);
				final SourceNode var0 = s0_Area1.get("ST").get("ST329");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SST_1", "E329_1_02"), result);
			}
		}}}}).run();
		createCompositeRule(11, "for source.Area1.DTM", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			for (final SourceNode s1_cur_DTM : s0_Area1.getIterable("DTM")) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(12, "new Move().execute(source.Area1.DTM.current.DTM373) => #[this.v_Date]", action);
				final SourceNode var0 = s1_cur_DTM.get("DTM373");
				final SourceNode result = action.execute(var0);
				Baseotterproducts_867v4010RS_Rt.this.v_Date = extractString(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
				createSimpleRule(13, "new CreateDateTimeFromString().execute(this.v_Date, \"yyyymmdd\") => #[this.vDate]", action);
				final com.extol.ebi.ruleset.lang.core.String var0 = Baseotterproducts_867v4010RS_Rt.this.v_Date;
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyymmdd");
				final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
				Baseotterproducts_867v4010RS_Rt.this.vDate = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime();
				createSimpleRule(14, "new FormatDateTime().execute(this.vDate, \"mm/dd/yyyy\") => #[this.v_Date]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime var0 = Baseotterproducts_867v4010RS_Rt.this.vDate;
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("mm/dd/yyyy");
				final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
				Baseotterproducts_867v4010RS_Rt.this.v_Date = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(15, "new Move().execute(source.Area1.DTM.current.DTM374) => #[target.t867.LISA.LGS.LST.SDTM_4.E374_4_01]", action);
				final SourceNode var0 = s1_cur_DTM.get("DTM374");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SDTM_4", "E374_4_01"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(16, "new Move().execute(this.v_Date) => #[target.t867.LISA.LGS.LST.SDTM_4.E373_4_02]", action);
				final SourceNode var0 = toValueNode(Baseotterproducts_867v4010RS_Rt.this.v_Date);
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SDTM_4", "E373_4_02"), result);
			}
		}}}}).run();
		createCompositeRule(17, "for source.Area1.REF", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			for (final SourceNode s1_cur_REF : s0_Area1.getIterable("REF")) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(18, "new Move().execute(source.Area1.REF.current.REF128) => #[target.t867.LISA.LGS.LST.SREF_5.E128_5_01]", action);
				final SourceNode var0 = s1_cur_REF.get("REF128");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SREF_5", "E128_5_01"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(19, "new Move().execute(source.Area1.REF.current.REF127) => #[target.t867.LISA.LGS.LST.SREF_5.E127_5_02]", action);
				final SourceNode var0 = s1_cur_REF.get("REF127");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SREF_5", "E127_5_02"), result);
			}
		}}}}).run();
		createCompositeRule(20, "for source.Area1.sgN1 initNew target.t867.LISA.LGS.LST.LN1_9", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			for (final SourceNode s1_cur_sgN1 : s0_Area1.getIterable("sgN1")) {
		
			final TargetNode t0_t867 = target.getLast(at("t867"));
			final TargetNode t1_LISA = t0_t867.getLast(at("LISA"));
			final TargetNode t2_LGS = t1_LISA.getLast(at("LGS"));
			final TargetNode t3_LST = t2_LGS.getLast(at("LST"));
			final TargetNode t4_cur_LN1_9 = t3_LST.create(at("LN1_9"));
		
			createCompositeRule(21, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(21, "new StringEquals().execute(source.Area1.sgN1.current.N1.N198, \"DS\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_sgN1.get("N1").get("N198"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("DS");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(22, "new Move().execute(\"DS\") => #[target.t867.LISA.LGS.LST.LN1_9.current.SN1_9.E98_9_01]", action);
					final SourceNode var0 = toValueNode(asString("DS"));
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN1_9", "E98_9_01"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(23, "new Move().execute(source.Area1.sgN1.current.N1.N193) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN1_9.E93_9_02]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N1").get("N193");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN1_9", "E93_9_02"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(24, "new Move().execute(source.Area1.sgN1.current.N3.current.N3166) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN3_11.E166_11_01]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N3").get("N3166");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN3_11", "E166_11_01"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(25, "new Move().execute(source.Area1.sgN1.current.N4.N419) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN4_12.E19_12_01]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N4").get("N419");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN4_12", "E19_12_01"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(26, "new Move().execute(source.Area1.sgN1.current.N4.N4156) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN4_12.E156_12_02]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N4").get("N4156");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN4_12", "E156_12_02"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(27, "new Move().execute(source.Area1.sgN1.current.N4.N4116) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN4_12.E116_12_03]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N4").get("N4116");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN4_12", "E116_12_03"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(28, "new Move().execute(source.Area1.sgN1.current.N4.N426) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN4_12.E26_12_04]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N4").get("N426");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN4_12", "E26_12_04"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(29, "new Move().execute(source.Area1.sgN1.current.N4.N4309) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN4_12.E309_12_05]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N4").get("N4309");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN4_12", "E309_12_05"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(30, "new Move().execute(source.Area1.sgN1.current.N4.N4310) => #[target.t867.LISA.LGS.LST.LN1_9.current.SN4_12.E310_12_06]", action);
					final SourceNode var0 = s1_cur_sgN1.get("N4").get("N4310");
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN4_12", "E310_12_06"), result);
				}
			}}).run();
		}}}}).run();
		createCompositeRule(31, "for source.Area1.sgN1 initNew target.t867.LISA.LGS.LST.LN1_9", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			for (final SourceNode s1_cur_sgN1 : s0_Area1.getIterable("sgN1")) {
		
			final TargetNode t0_t867 = target.getLast(at("t867"));
			final TargetNode t1_LISA = t0_t867.getLast(at("LISA"));
			final TargetNode t2_LGS = t1_LISA.getLast(at("LGS"));
			final TargetNode t3_LST = t2_LGS.getLast(at("LST"));
			final TargetNode t4_cur_LN1_9 = t3_LST.create(at("LN1_9"));
		
			createCompositeRule(32, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(33, "new Move().execute(\"CUNO\") => #[target.t867.LISA.LGS.LST.LN1_9.current.SN1_9.E98_9_01]", action);
					final SourceNode var0 = toValueNode(asString("CUNO"));
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN1_9", "E98_9_01"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(34, "new Move().execute(\"INGRAM MICRO\") => #[target.t867.LISA.LGS.LST.LN1_9.current.SN1_9.E93_9_02]", action);
					final SourceNode var0 = toValueNode(asString("INGRAM MICRO"));
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN1_9", "E93_9_02"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(35, "new Move().execute(\"10002972\") => #[target.t867.LISA.LGS.LST.LN1_9.current.SN1_9.E67_9_04]", action);
					final SourceNode var0 = toValueNode(asString("10002972"));
					final SourceNode result = action.execute(var0);
					t4_cur_LN1_9.set(at("SN1_9", "E67_9_04"), result);
				}
			}}).run();
		}}}}).run();
		createCompositeRule(36, "for source.Area2.sgPTD initNew target.t867.LISA.LGS.LST.LPTD_18", new Block() { public void body() {
			final SourceNode s0_Area2 = source.get("Area2");
			if (exists(s0_Area2)) {
			for (final SourceNode s1_cur_sgPTD : s0_Area2.getIterable("sgPTD")) {
		
			final TargetNode t0_t867 = target.getLast(at("t867"));
			final TargetNode t1_LISA = t0_t867.getLast(at("LISA"));
			final TargetNode t2_LGS = t1_LISA.getLast(at("LGS"));
			final TargetNode t3_LST = t2_LGS.getLast(at("LST"));
			final TargetNode t4_cur_LPTD_18 = t3_LST.create(at("LPTD_18"));
		
			createCompositeRule(37, "for source.Area2.sgPTD.current.PTD", new Block() { public void body() {
				final SourceNode s2_PTD = s1_cur_sgPTD.get("PTD");
				if (exists(s2_PTD)) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
					createSimpleRule(38, "new RawMove().execute(source.Area2.sgPTD.current.PTD.PTD521) => #[target.t867.LISA.LGS.LST.LPTD_18.current.SPTD_18.E521_18_01]", action);
					final SourceNode var0 = s2_PTD.get("PTD521");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("SPTD_18", "E521_18_01"), result);
				}
			}}}).run();
			createCompositeRule(39, "for source.Area2.sgPTD.current.sgN1 initNew target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24", new Block() { public void body() {
				for (final SourceNode s2_cur_sgN1 : s1_cur_sgPTD.getIterable("sgN1")) {
			
				final TargetNode t5_cur_LN1_24 = t4_cur_LPTD_18.create(at("LN1_24"));
			
				createCompositeRule(40, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(40, "new StringEquals().execute(source.Area2.sgPTD.current.sgN1.current.N1.N198, \"ST\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur_sgN1.get("N1").get("N198"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("ST");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(41, "new Move().execute(\"ST\") => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E98_24_01]", action);
						final SourceNode var0 = toValueNode(asString("ST"));
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E98_24_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(42, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N1.N193) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E93_24_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N1").get("N193");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E93_24_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
						createSimpleRule(43, "new RawMove().execute(source.Area2.sgPTD.current.sgN1.current.N1.N166) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E66_24_03]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N1").get("N166");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E66_24_03"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
						createSimpleRule(44, "new RawMove().execute(source.Area2.sgPTD.current.sgN1.current.N1.N167) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E67_24_04]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N1").get("N167");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E67_24_04"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(45, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N3.current.N3166) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN3_26.E166_26_01]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N3").get("N3166");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN3_26", "E166_26_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
						createSimpleRule(46, "new RawMove().execute(source.Area2.sgPTD.current.sgN1.current.N3.current.N3166_3) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN3_26.E166_26_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N3").get("N3166_3");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN3_26", "E166_26_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(47, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N419) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E19_27_01]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N419");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E19_27_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(48, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N4156) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E156_27_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N4156");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E156_27_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(49, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N4116) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E116_27_03]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N4116");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E116_27_03"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(50, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N426) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E26_27_04]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N426");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E26_27_04"), result);
					}
				}}).run();
				createCompositeRule(51, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(51, "new StringEquals().execute(source.Area2.sgPTD.current.sgN1.current.N1.N198, \"BT\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur_sgN1.get("N1").get("N198"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("BT");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(52, "new Move().execute(\"BT\") => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E98_24_01]", action);
						final SourceNode var0 = toValueNode(asString("BT"));
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E98_24_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(53, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N1.N193) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E93_24_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N1").get("N193");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E93_24_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(54, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N3.current.N3166) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN3_26.E166_26_01]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N3").get("N3166");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN3_26", "E166_26_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
						createSimpleRule(55, "new RawMove().execute(source.Area2.sgPTD.current.sgN1.current.N3.current.N3166_3) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN3_26.E166_26_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N3").get("N3166_3");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN3_26", "E166_26_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(56, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N419) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E19_27_01]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N419");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E19_27_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(57, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N4156) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E156_27_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N4156");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E156_27_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(58, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N4116) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E116_27_03]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N4116");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E116_27_03"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(59, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N426) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E26_27_04]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N426");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E26_27_04"), result);
					}
				}}).run();
				createCompositeRule(60, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(60, "new StringEquals().execute(source.Area2.sgPTD.current.sgN1.current.N1.N198, \"RS\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur_sgN1.get("N1").get("N198"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("RS");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(61, "new Move().execute(\"RS\") => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E98_24_01]", action);
						final SourceNode var0 = toValueNode(asString("RS"));
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E98_24_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(62, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N1.N193) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E93_24_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N1").get("N193");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E93_24_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(63, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N1.N166) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E66_24_03]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N1").get("N166");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E66_24_03"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(64, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N1.N167) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN1_24.E67_24_04]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N1").get("N167");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN1_24", "E67_24_04"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(65, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N3.current.N3166) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN3_26.E166_26_01]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N3").get("N3166");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN3_26", "E166_26_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
						createSimpleRule(66, "new RawMove().execute(source.Area2.sgPTD.current.sgN1.current.N3.current.N3166_3) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN3_26.E166_26_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N3").get("N3166_3");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN3_26", "E166_26_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(67, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N419) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E19_27_01]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N419");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E19_27_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(68, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N4156) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E156_27_02]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N4156");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E156_27_02"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(69, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N4116) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E116_27_03]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N4116");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E116_27_03"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(70, "new Move().execute(source.Area2.sgPTD.current.sgN1.current.N4.N426) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LN1_24.current.SN4_27.E26_27_04]", action);
						final SourceNode var0 = s2_cur_sgN1.get("N4").get("N426");
						final SourceNode result = action.execute(var0);
						t5_cur_LN1_24.set(at("SN4_27", "E26_27_04"), result);
					}
				}}).run();
			}}}).run();
			createCompositeRule(71, "for source.Area2.sgPTD.current.sgQTY", new Block() { public void body() {
				for (final SourceNode s2_cur_sgQTY : s1_cur_sgPTD.getIterable("sgQTY")) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(72, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.QTY.QTY673) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SQTY_32.E673_32_01]", action);
					final SourceNode var0 = s2_cur_sgQTY.get("QTY").get("QTY673");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SQTY_32", "E673_32_01"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(73, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.QTY.QTY380) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SQTY_32.E380_32_02]", action);
					final SourceNode var0 = s2_cur_sgQTY.get("QTY").get("QTY380");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SQTY_32", "E380_32_02"), result);
				}
			}}}).run();
			createCompositeRule(74, "for source.Area2.sgPTD.current.sgQTY.current.LIN", new Block() { public void body() {
				for (final SourceNode s2_cur_sgQTY : s1_cur_sgPTD.getIterable("sgQTY")) {
				final SourceNode s3_LIN = s2_cur_sgQTY.get("LIN");
				if (exists(s3_LIN)) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(75, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.LIN.LIN235) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SLIN_33.E235_33_02]", action);
					final SourceNode var0 = s3_LIN.get("LIN235");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SLIN_33", "E235_33_02"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(76, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.LIN.LIN234) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SLIN_33.E234_33_05]", action);
					final SourceNode var0 = s3_LIN.get("LIN234");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SLIN_33", "E234_33_05"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(77, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.LIN.LIN235_3) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SLIN_33.E235_33_04]", action);
					final SourceNode var0 = s3_LIN.get("LIN235_3");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SLIN_33", "E235_33_04"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(78, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.LIN.LIN234_3) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SLIN_33.E234_33_03]", action);
					final SourceNode var0 = s3_LIN.get("LIN234_3");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SLIN_33", "E234_33_03"), result);
				}
			}}}}).run();
			createCompositeRule(79, "for source.Area2.sgPTD.current.sgQTY.current.UIT", new Block() { public void body() {
				for (final SourceNode s2_cur_sgQTY : s1_cur_sgPTD.getIterable("sgQTY")) {
				for (final SourceNode s3_cur_UIT : s2_cur_sgQTY.getIterable("UIT")) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(80, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.UIT.current.UITC001.C00101) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SUIT_36.CC001_36_01.E355_36_0101]", action);
					final SourceNode var0 = s3_cur_UIT.get("UITC001").get("C00101");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SUIT_36", "CC001_36_01", "E355_36_0101"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(81, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.UIT.current.UIT212) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SUIT_36.E212_36_02]", action);
					final SourceNode var0 = s3_cur_UIT.get("UIT212");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SUIT_36", "E212_36_02"), result);
				}
			}}}}).run();
			createCompositeRule(82, "for source.Area2.sgPTD.current.sgQTY.current.REF", new Block() { public void body() {
				for (final SourceNode s2_cur_sgQTY : s1_cur_sgPTD.getIterable("sgQTY")) {
				for (final SourceNode s3_cur_REF : s2_cur_sgQTY.getIterable("REF")) {
			
			
				createCompositeRule(83, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(83, "new StringEquals().execute(source.Area2.sgPTD.current.sgQTY.current.REF.current.REF128, \"IV\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_REF.get("REF128"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("IV");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(84, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.REF.current.REF128) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SREF_43.E128_43_01]", action);
						final SourceNode var0 = s3_cur_REF.get("REF128");
						final SourceNode result = action.execute(var0);
						t4_cur_LPTD_18.set(at("LQTY_32", "SREF_43", "E128_43_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(85, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.REF.current.REF127) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SREF_43.E127_43_02]", action);
						final SourceNode var0 = s3_cur_REF.get("REF127");
						final SourceNode result = action.execute(var0);
						t4_cur_LPTD_18.set(at("LQTY_32", "SREF_43", "E127_43_02"), result);
					}
				}}).run();
				createCompositeRule(86, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(86, "new StringEquals().execute(source.Area2.sgPTD.current.sgQTY.current.REF.current.REF128, \"CR\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_REF.get("REF128"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("CR");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(87, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.REF.current.REF128) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SREF_43.E128_43_01]", action);
						final SourceNode var0 = s3_cur_REF.get("REF128");
						final SourceNode result = action.execute(var0);
						t4_cur_LPTD_18.set(at("LQTY_32", "SREF_43", "E128_43_01"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(88, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.REF.current.REF127) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SREF_43.E127_43_02]", action);
						final SourceNode var0 = s3_cur_REF.get("REF127");
						final SourceNode result = action.execute(var0);
						t4_cur_LPTD_18.set(at("LQTY_32", "SREF_43", "E127_43_02"), result);
					}
				}}).run();
			}}}}).run();
			createCompositeRule(89, "for source.Area2.sgPTD.current.sgQTY.current.DTM", new Block() { public void body() {
				for (final SourceNode s2_cur_sgQTY : s1_cur_sgPTD.getIterable("sgQTY")) {
				for (final SourceNode s3_cur_DTM : s2_cur_sgQTY.getIterable("DTM")) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(90, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.DTM.current.DTM374) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SDTM_45.E374_45_01]", action);
					final SourceNode var0 = s3_cur_DTM.get("DTM374");
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SDTM_45", "E374_45_01"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(91, "new Move().execute(source.Area2.sgPTD.current.sgQTY.current.DTM.current.DTM373) => #[this.v_Date]", action);
					final SourceNode var0 = s3_cur_DTM.get("DTM373");
					final SourceNode result = action.execute(var0);
					Baseotterproducts_867v4010RS_Rt.this.v_Date = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
					createSimpleRule(92, "new CreateDateTimeFromString().execute(this.v_Date, \"yyyymmdd\") => #[this.vDate]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = Baseotterproducts_867v4010RS_Rt.this.v_Date;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyymmdd");
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
					Baseotterproducts_867v4010RS_Rt.this.vDate = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime();
					createSimpleRule(93, "new FormatDateTime().execute(this.vDate, \"mm/dd/yyyy\") => #[this.v_Date]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime var0 = Baseotterproducts_867v4010RS_Rt.this.vDate;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("mm/dd/yyyy");
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
					Baseotterproducts_867v4010RS_Rt.this.v_Date = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(94, "new Move().execute(this.v_Date) => #[target.t867.LISA.LGS.LST.LPTD_18.current.LQTY_32.SDTM_45.E373_45_02]", action);
					final SourceNode var0 = toValueNode(Baseotterproducts_867v4010RS_Rt.this.v_Date);
					final SourceNode result = action.execute(var0);
					t4_cur_LPTD_18.set(at("LQTY_32", "SDTM_45", "E373_45_02"), result);
				}
			}}}}).run();
		}}}}).run();
		createCompositeRule(95, "for source.Area3.sgCTT", new Block() { public void body() {
			final SourceNode s0_Area3 = source.get("Area3");
			if (exists(s0_Area3)) {
			final SourceNode s1_sgCTT = s0_Area3.get("sgCTT");
			if (exists(s1_sgCTT)) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(96, "new Move().execute(source.Area3.sgCTT.CTT.CTT354) => #[target.t867.LISA.LGS.LST.LCTT_59.SCTT_59.E354_59_01]", action);
				final SourceNode var0 = s1_sgCTT.get("CTT").get("CTT354");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "LCTT_59", "SCTT_59", "E354_59_01"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(97, "new Move().execute(source.Area3.sgCTT.CTT.CTT347) => #[target.t867.LISA.LGS.LST.LCTT_59.SCTT_59.E347_59_02]", action);
				final SourceNode var0 = s1_sgCTT.get("CTT").get("CTT347");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "LCTT_59", "SCTT_59", "E347_59_02"), result);
			}
		}}}}).run();
		createCompositeRule(98, "for source.Area3.SE", new Block() { public void body() {
			final SourceNode s0_Area3 = source.get("Area3");
			if (exists(s0_Area3)) {
			final SourceNode s1_SE = s0_Area3.get("SE");
			if (exists(s1_SE)) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(99, "new Move().execute(source.Area3.SE.SE96) => #[target.t867.LISA.LGS.LST.SSE_62.E96_62_01]", action);
				final SourceNode var0 = s1_SE.get("SE96");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SSE_62", "E96_62_01"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(100, "new Move().execute(source.Area3.SE.SE329) => #[target.t867.LISA.LGS.LST.SSE_62.E329_62_02]", action);
				final SourceNode var0 = s1_SE.get("SE329");
				final SourceNode result = action.execute(var0);
				target.set(at("t867", "LISA", "LGS", "LST", "SSE_62", "E329_62_02"), result);
			}
		}}}}).run();
	}

}
