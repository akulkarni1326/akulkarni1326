package com.cleo.b2biaas.clarify;

import java.util.HashMap;

import com.extol.ebi.factory.EBIFactoryManager;

/**
 * @author Manju Muthuraj
 * 
 */
public class InboundCloseMessage extends B2BAction {
	
	
	Utility utility = new Utility();
	
	public void execute(com.extol.ebi.ruleset.lang.core.Object messageInfo) {

		InboundMessageApiCallV2 mi = (InboundMessageApiCallV2) messageInfo
				.asJavaObject();
		try {

			if (mi.getKey().containsKey(EventKeys.KEY_LOGOFMESSAGEID)) {

				String logOfMessageId = mi.getKey().get(EventKeys.KEY_LOGOFMESSAGEID);
				logInfo(EventKeys.LOG_OF_MESSAGE_ID_KEY_EXISTS_AND_VALUE_IS
						+ logOfMessageId);
				if (logOfMessageId == null || logOfMessageId.isEmpty()
						|| logOfMessageId.toLowerCase() == EventKeys.NULL || logOfMessageId.toLowerCase() == EventKeys.NA) {
					logOfMessageId = EBIFactoryManager.getFactory()
							.createUUID().getUUIDString();
					
					logInfo(EventKeys.AS_VALUE_OF_LOG_OF_MESSAGE_ID_KEY_IS_NULL_OR_EMPTY_GENERATING_THE_LOG_OF_MESSAGE_ID
							+ logOfMessageId);
					mi.getKey().put(EventKeys.KEY_LOGOFMESSAGEID, logOfMessageId);
					
					HashMap<String, String> map = getContext();
					map.put(EventKeys.ENV_VAR_LOG_OF_MESSAGE_ID, logOfMessageId);
					saveContext(map);

					logInfo(EventKeys.CONTEXT_IS_SET_FOR_ENV_VAR_LOG_OF_MESSAGE_ID);
				}
			} else {

				String generatedLogId = EBIFactoryManager.getFactory()
						.createUUID().getUUIDString();
				logInfo(EventKeys.AS_LOG_OF_MESSAGE_ID_KEY_DOES_NOT_EXIST_GENERATING_THE_LOG_OF_MESSAGE_ID
						+ generatedLogId);
				mi.addKey(EventKeys.KEY_LOGOFMESSAGEID, generatedLogId);
				
				HashMap<String, String> map = getContext();
				map.put(EventKeys.ENV_VAR_LOG_OF_MESSAGE_ID, generatedLogId);
				saveContext(map);
				logInfo(EventKeys.CONTEXT_IS_SET_FOR_ENV_VAR_LOG_OF_MESSAGE_ID);
			}

			StringBuffer sb = mi.objToJson(mi);
			
			utility.postMessageTob2biaaS(sb,EventKeys.API_MESSAGE_TENANT,EventKeys.INBOUND_MESSAGE_REQUEST_BODY);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	}