/**
* @generated
*/
package com.cleo.b2bcloud.core.process;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.SendEmail;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.string.ReplaceString;
import com.extol.ebi.bps.lib.tasks.string.ResolveGlobalVariables;
import com.extol.ebi.bps.lib.types.unions.Attachment;
import com.extol.ebi.bps.lib.types.unions.Message;
import com.extol.ebi.lang.storage.StorageNode;

@SuppressWarnings("all")
public class B2BCloud_NoOutboundRouteError_Rt extends AbstractCatalyst {
	
	public B2BCloud_NoOutboundRouteError_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(String.class) Variable<String> p_messageType, @ParameterType(String.class) Variable<String> p_tpId, @ParameterType(StorageNode.class) Variable<StorageNode> p_sourceDataGroup) {
		final Variable<String> v_sendEmailFrom = variable(String.class, null);
		final Variable<String> v_sendEmailTo = variable(String.class, null);
		final Variable<String> v_subjectFull = variable(String.class, null);
		final Variable<String> v_messageFull = variable(String.class, null);
		final Variable<String> v_environment = variable(String.class, null);
		final Variable<Boolean> v_setExitStatusSuccess = variable(Boolean.class, true);
		final Variable<Boolean> v_setExitStatusFailure = variable(Boolean.class, false);
		final Variable<String> v_subject1 = variable(String.class, "xxx ERROR: Clarify - zzz - No Outbound Route Found");
		final Variable<String> v_message1 = variable(String.class, "Cleo Clarify B2B Cloud could not match the attached data to an Outbound Route for the following:\\n\\nTP ID: yyy\\nMessage Type: Outbound qqq");
		final Variable<String> v_environment_GV = variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.Environment>");
		final Variable<String> v_attachmentName1 = variable(String.class, "uuu_Outbound_vvv.txt");
		final Variable<String> v_attachmentNameFull = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep("HostEmail", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailTo, variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.B2BCloudAdminEmail>"));
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("AdminEmail", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailFrom, variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.B2BCloudHostEmail>"));
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("Environment", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_environment, v_environment_GV);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("subject1", "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_subjectFull, v_subject1, variable(String.class, "xxx"), v_environment);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("subject2", "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_subjectFull, v_subjectFull, variable(String.class, "zzz"), p_messageType);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("message1", "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_messageFull, v_message1, variable(String.class, "yyy"), p_tpId);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("message2", "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_messageFull, v_messageFull, variable(String.class, "qqq"), p_messageType);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("attachment1", "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_attachmentNameFull, v_attachmentName1, variable(String.class, "uuu"), p_tpId);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("attachment2", "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_attachmentNameFull, v_attachmentNameFull, variable(String.class, "vvv"), p_messageType);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep(null, "Send Email", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Send Email");
					SendEmail task = new SendEmail();
					setupTask(task);
					return task.execute(v_sendEmailTo, v_sendEmailFrom, variable(String.class, null), variable(String.class, null), v_subjectFull, new Message(v_messageFull), new Attachment(p_sourceDataGroup), v_attachmentNameFull);
				} finally { _endTask();}
			}
		}, "next", "FAILURE");
		
		builder.addStep("SUCCESS", "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(v_setExitStatusSuccess);
				} finally { _endTask();}
			}
		}, "end", "end");
		
		builder.addStep("FAILURE", "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(v_setExitStatusFailure);
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
