/**
* @generated
*/
package com.cleo.b2bcloud.core.systemchecks;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStringToStorageNode;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class MANUAL_UpdateActiveStatusBPS_Rt extends AbstractCatalyst {
	
	public MANUAL_UpdateActiveStatusBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute() {
		final Variable<String> v_vActiveCount = variable(String.class, null);
		final Variable<String> v_c0 = variable(String.class, "0");
		final Variable<String> v_vReceivedOnlyCount = variable(String.class, null);
		final Variable<String> v_vDateLong = variable(String.class, null);
		final Variable<StorageNode> v_input = variable(StorageNode.class, null);
		final Variable<StorageNode> v_targetContext = variable(StorageNode.class, null);
		final Variable<String> v_vReceivedUnwrappedCount = variable(String.class, null);
		final Variable<String> v_vGeneratedStatusCount = variable(String.class, "0");
		final Variable<String> v_vSubject = variable(String.class, null);
		final Variable<String> v_vDateMinusDayLong = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Convert String to Storage Node", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert String to Storage Node");
					ConvertStringToStorageNode task = new ConvertStringToStorageNode();
					setupTask(task);
					return task.execute(variable(String.class, "dummy"), v_input);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.ConvertDateRS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.ConvertDateRS");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.ConvertDateRS", "bps1://Ruleset").execute(v_input, null, literalTypeFromString(TransformationSettings.class, "com.cleo.b2bcloud.core.DefaultTransformationSettingsTS"), null, null, v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_targetContext, variable(String.class, "env.var.User_Reference_1"), new ContextPointVar(v_vDateLong));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(v_targetContext, variable(String.class, "env.var.User_Reference_2"), new ContextPointVar(v_vDateMinusDayLong));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.UpdateActiveLogOfProcessSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.UpdateActiveLogOfProcessSQL$BpsTask");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.UpdateActiveLogOfProcessSQL$BpsTask", "bps1://SQLAccess").execute(v_vDateLong, v_vActiveCount);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
