/**
* @generated
*/
package com.otterproducts.edi.amazon.inbound.n850;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class amazon850v4010RS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,RtPojoSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String v_date;
	private com.extol.ebi.ruleset.lang.core.DateTime v_Date;
	private com.extol.ebi.ruleset.lang.core.DateTime d_BEG05;
	private com.extol.ebi.ruleset.lang.core.Number v_sum;
	private com.extol.ebi.ruleset.lang.core.Number v_total;
	private com.extol.ebi.ruleset.lang.core.String v_RequestedDeliveryNotAfterDate;
	private com.extol.ebi.ruleset.lang.core.String v_RequestedDeliveryBeforeDate;
	private com.extol.ebi.ruleset.lang.core.String v_N104;
	private com.extol.ebi.ruleset.lang.core.String v_date1;
	private com.extol.ebi.ruleset.lang.core.String v_Sum;
	private com.extol.ebi.ruleset.lang.core.Number V_EpochTime;
	private com.extol.ebi.ruleset.lang.core.DateTime v_currentDateTime;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.otterproducts.core.edi.schemas.n850v4010EDI_Rt();
	}
	
	public SchemaProvider<RtPojoSchema> getTargetSchema() {
		return new com.otterproducts.core.system.n850.PurchaseOrderMessageOBJ_Rt();
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return new XMLObjectConnector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "for source.Area1.BEG", new Block() { public void body() {
			final SourceNode s0_Area1 = source.get("Area1");
			if (exists(s0_Area1)) {
			final SourceNode s1_BEG = s0_Area1.get("BEG");
			if (exists(s1_BEG)) {
		
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(\"Otter\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.FirstName]", action);
				final SourceNode var0 = toValueNode(asString("Otter"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "FirstName"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(\"EDI\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.LastName]", action);
				final SourceNode var0 = toValueNode(asString("EDI"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "LastName"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(\"otteredi@otterproducts.com\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.EmailAddress]", action);
				final SourceNode var0 = toValueNode(asString("otteredi@otterproducts.com"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "EmailAddress"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(5, "new Move().execute(\"970-419-7363\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.Phones.Phone.PhoneNumber]", action);
				final SourceNode var0 = toValueNode(asString("970-419-7363"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "Phones", "Phone", "PhoneNumber"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(6, "new Move().execute(\"work\") => #[target.purchaseOrderMessage.AdministrativeContact.Contact.current.Phones.Phone.PhoneTypeCode]", action);
				final SourceNode var0 = toValueNode(asString("work"));
				final SourceNode result = action.execute(var0);
				target.set(at("purchaseOrderMessage", "AdministrativeContact", "Contact", "Phones", "Phone", "PhoneTypeCode"), result);
			}
			createCompositeRule(7, "initNew target.purchaseOrderMessage.Order", new Block() { public void body() {
			
				final TargetNode t0_purchaseOrderMessage = target.getLast(at("purchaseOrderMessage"));
				final TargetNode t1_Order = t0_purchaseOrderMessage.getLast(at("Order"));
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(8, "new Move().execute(source.Area1.BEG.BEG324) => #[target.purchaseOrderMessage.Order.PurchaseOrderNumber, this.env.User_Reference_1]", action);
					final SourceNode var0 = s1_BEG.get("BEG324");
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("PurchaseOrderNumber"), result);
					amazon850v4010RS_Rt.this.env.User_Reference_1 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(9, "new Move().execute(source.Area1.BEG.BEG373) => #[this.v_date]", action);
					final SourceNode var0 = s1_BEG.get("BEG373");
					final SourceNode result = action.execute(var0);
					amazon850v4010RS_Rt.this.v_date = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.string.Substring action = new com.extol.ebi.reactor.lib.actions.string.Substring();
					createSimpleRule(10, "new Substring().execute(this.v_date, 1, 10) => #[this.v_date]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = amazon850v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
					final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(10);
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2);
					amazon850v4010RS_Rt.this.v_date = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
					createSimpleRule(11, "new CreateDateTimeFromString().execute(this.v_date, \"yyyyMMdd\") => #[this.d_BEG05]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = amazon850v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyyMMdd");
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
					amazon850v4010RS_Rt.this.d_BEG05 = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime();
					createSimpleRule(12, "new FormatDateTime().execute(this.d_BEG05, \"yyyy-MM-dd\") => #[this.v_date]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime var0 = amazon850v4010RS_Rt.this.d_BEG05;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyy-MM-dd");
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
					amazon850v4010RS_Rt.this.v_date = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(13, "new Move().execute(this.v_date) => #[target.purchaseOrderMessage.Order.OrderDate]", action);
					final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_date);
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("OrderDate"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(14, "new Move().execute(\"USD\") => #[target.purchaseOrderMessage.Order.CurrencyCode]", action);
					final SourceNode var0 = toValueNode(asString("USD"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("CurrencyCode"), result);
				}
				createCompositeRule(15, "for source.Area1.DTM", new Block() { public void body() {
					for (final SourceNode s1_cur_DTM : s0_Area1.getIterable("DTM")) {
				
				
					createCompositeRule(16, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(16, "new StringEquals().execute(source.Area1.DTM.current.DTM374, \"063\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_DTM.get("DTM374"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("063");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(17, "new Move().execute(source.Area1.DTM.current.DTM373) => #[this.v_date]", action);
							final SourceNode var0 = s1_cur_DTM.get("DTM373");
							final SourceNode result = action.execute(var0);
							amazon850v4010RS_Rt.this.v_date = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.string.Substring action = new com.extol.ebi.reactor.lib.actions.string.Substring();
							createSimpleRule(18, "new Substring().execute(this.v_date, 1, 10) => #[this.v_date]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = amazon850v4010RS_Rt.this.v_date;
							final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
							final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(10);
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2);
							amazon850v4010RS_Rt.this.v_date = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
							createSimpleRule(19, "new CreateDateTimeFromString().execute(this.v_date, \"yyyyMMdd\") => #[this.v_Date]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = amazon850v4010RS_Rt.this.v_date;
							final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyyMMdd");
							final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
							amazon850v4010RS_Rt.this.v_Date = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime();
							createSimpleRule(20, "new FormatDateTime().execute(this.v_Date, \"yyyy-MM-dd\") => #[this.v_date]", action);
							final com.extol.ebi.ruleset.lang.core.DateTime var0 = amazon850v4010RS_Rt.this.v_Date;
							final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyy-MM-dd");
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
							amazon850v4010RS_Rt.this.v_date = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(21, "new Move().execute(this.v_date) => #[target.purchaseOrderMessage.Order.DeliveryRequestedDate, target.purchaseOrderMessage.Order.RequestedDeliveryNotAfterDate, this.v_RequestedDeliveryNotAfterDate]", action);
							final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_date);
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("DeliveryRequestedDate"), result);
							t1_Order.set(at("RequestedDeliveryNotAfterDate"), result);
							amazon850v4010RS_Rt.this.v_RequestedDeliveryNotAfterDate = extractString(result);
						}
					}}).run();
					createCompositeRule(22, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(22, "new StringEquals().execute(source.Area1.DTM.current.DTM374, \"064\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_DTM.get("DTM374"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("064");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(23, "new Move().execute(source.Area1.DTM.current.DTM373) => #[this.v_date1]", action);
							final SourceNode var0 = s1_cur_DTM.get("DTM373");
							final SourceNode result = action.execute(var0);
							amazon850v4010RS_Rt.this.v_date1 = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.string.Substring action = new com.extol.ebi.reactor.lib.actions.string.Substring();
							createSimpleRule(24, "new Substring().execute(this.v_date1, 1, 10) => #[this.v_date1]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = amazon850v4010RS_Rt.this.v_date1;
							final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
							final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(10);
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2);
							amazon850v4010RS_Rt.this.v_date1 = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
							createSimpleRule(25, "new CreateDateTimeFromString().execute(this.v_date1, \"yyyyMMdd\") => #[this.v_Date]", action);
							final com.extol.ebi.ruleset.lang.core.String var0 = amazon850v4010RS_Rt.this.v_date1;
							final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyyMMdd");
							final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
							amazon850v4010RS_Rt.this.v_Date = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.FormatDateTime();
							createSimpleRule(26, "new FormatDateTime().execute(this.v_Date, \"yyyy-MM-dd\") => #[this.v_date1]", action);
							final com.extol.ebi.ruleset.lang.core.DateTime var0 = amazon850v4010RS_Rt.this.v_Date;
							final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyy-MM-dd");
							final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
							amazon850v4010RS_Rt.this.v_date1 = result;
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(27, "new Move().execute(this.v_date1) => #[target.purchaseOrderMessage.Order.RequestedDeliveryNotBeforeDate, this.v_RequestedDeliveryBeforeDate]", action);
							final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_date1);
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("RequestedDeliveryNotBeforeDate"), result);
							amazon850v4010RS_Rt.this.v_RequestedDeliveryBeforeDate = extractString(result);
						}
					}}).run();
				}}}).run();
				createCompositeRule(28, "for source.Area1.REF", new Block() { public void body() {
					for (final SourceNode s1_cur_REF : s0_Area1.getIterable("REF")) {
				
				
					createCompositeRule(29, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(29, "new StringEquals().execute(source.Area1.REF.current.REF127, \"OTTF5\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF127"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("OTTF5");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(30, "new Move().execute(\"10001100\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.ID, target.purchaseOrderMessage.Order.BillToCustomerAccount.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerAccount.ID, this.env.User_Reference_3]", action);
							final SourceNode var0 = toValueNode(asString("10001100"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerLocation", "ID"), result);
							t1_Order.set(at("BillToCustomerAccount", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerAccount", "ID"), result);
							amazon850v4010RS_Rt.this.env.User_Reference_3 = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(31, "new Move().execute(\"Amazon.com Accounts Payable\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.Name]", action);
							final SourceNode var0 = toValueNode(asString("Amazon.com Accounts Payable"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "Name"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(32, "new Move().execute(\"\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerLocations, target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerTypeName, target.purchaseOrderMessage.Order.BillToCustomerAccount.EmailAddress, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerContact, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Name, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine1, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine2, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.PostalCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.StateCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CityName]", action);
							final SourceNode var0 = toValueNode(asString(""));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "CustomerLocations"), result);
							t1_Order.set(at("BillToCustomerAccount", "CustomerTypeName"), result);
							t1_Order.set(at("BillToCustomerAccount", "EmailAddress"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerContact"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Name"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine1"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine2"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "PostalCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "StateCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CityName"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(33, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CountryCode]", action);
							final SourceNode var0 = toValueNode(asString("US"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CountryCode"), result);
						}
					}}).run();
					createCompositeRule(34, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(34, "new StringEquals().execute(source.Area1.REF.current.REF127, \"OTTET\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF127"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("OTTET");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(35, "new Move().execute(10000010) => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.ID, target.purchaseOrderMessage.Order.BillToCustomerAccount.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerAccount.ID, this.env.User_Reference_3]", action);
							final SourceNode var0 = toValueNode(asNumber(10000010));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerLocation", "ID"), result);
							t1_Order.set(at("BillToCustomerAccount", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerAccount", "ID"), result);
							amazon850v4010RS_Rt.this.env.User_Reference_3 = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(36, "new Move().execute(\"Amazon.com Accounts Payable\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.Name]", action);
							final SourceNode var0 = toValueNode(asString("Amazon.com Accounts Payable"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "Name"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(37, "new Move().execute(\"\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerLocations, target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerTypeName, target.purchaseOrderMessage.Order.BillToCustomerAccount.EmailAddress, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerContact, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Name, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine1, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine2, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.PostalCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.StateCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CityName]", action);
							final SourceNode var0 = toValueNode(asString(""));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "CustomerLocations"), result);
							t1_Order.set(at("BillToCustomerAccount", "CustomerTypeName"), result);
							t1_Order.set(at("BillToCustomerAccount", "EmailAddress"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerContact"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Name"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine1"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine2"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "PostalCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "StateCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CityName"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(38, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CountryCode]", action);
							final SourceNode var0 = toValueNode(asString("US"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CountryCode"), result);
						}
					}}).run();
					createCompositeRule(39, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(39, "new StringEquals().execute(source.Area1.REF.current.REF127, \"LIFO3\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF127"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("LIFO3");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(40, "new Move().execute(10001936) => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.ID, target.purchaseOrderMessage.Order.BillToCustomerAccount.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerAccount.ID, this.env.User_Reference_3]", action);
							final SourceNode var0 = toValueNode(asNumber(10001936));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerLocation", "ID"), result);
							t1_Order.set(at("BillToCustomerAccount", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerAccount", "ID"), result);
							amazon850v4010RS_Rt.this.env.User_Reference_3 = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(41, "new Move().execute(\"Amazon.com Accounts Payable\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.Name]", action);
							final SourceNode var0 = toValueNode(asString("Amazon.com Accounts Payable"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "Name"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(42, "new Move().execute(\"\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerLocations, target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerTypeName, target.purchaseOrderMessage.Order.BillToCustomerAccount.EmailAddress, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerContact, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Name, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine1, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine2, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.PostalCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.StateCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CityName]", action);
							final SourceNode var0 = toValueNode(asString(""));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "CustomerLocations"), result);
							t1_Order.set(at("BillToCustomerAccount", "CustomerTypeName"), result);
							t1_Order.set(at("BillToCustomerAccount", "EmailAddress"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerContact"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Name"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine1"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine2"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "PostalCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "StateCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CityName"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(43, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CountryCode]", action);
							final SourceNode var0 = toValueNode(asString("US"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CountryCode"), result);
						}
					}}).run();
					createCompositeRule(44, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(44, "new StringEquals().execute(source.Area1.REF.current.REF127, \"OTUEX\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF127"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("OTUEX");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(45, "new Move().execute(10004211) => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.ID, target.purchaseOrderMessage.Order.BillToCustomerAccount.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerAccount.ID, this.env.User_Reference_3]", action);
							final SourceNode var0 = toValueNode(asNumber(10004211));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerLocation", "ID"), result);
							t1_Order.set(at("BillToCustomerAccount", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerAccount", "ID"), result);
							amazon850v4010RS_Rt.this.env.User_Reference_3 = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(46, "new Move().execute(\"Amazon.com Accounts Payable\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.Name]", action);
							final SourceNode var0 = toValueNode(asString("Amazon.com Accounts Payable"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "Name"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(47, "new Move().execute(\"\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerLocations, target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerTypeName, target.purchaseOrderMessage.Order.BillToCustomerAccount.EmailAddress, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerContact, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Name, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine1, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine2, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.PostalCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.StateCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CityName]", action);
							final SourceNode var0 = toValueNode(asString(""));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "CustomerLocations"), result);
							t1_Order.set(at("BillToCustomerAccount", "CustomerTypeName"), result);
							t1_Order.set(at("BillToCustomerAccount", "EmailAddress"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerContact"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Name"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine1"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine2"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "PostalCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "StateCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CityName"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(48, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CountryCode]", action);
							final SourceNode var0 = toValueNode(asString("US"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CountryCode"), result);
						}
					}}).run();
					createCompositeRule(49, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(49, "new StringEquals().execute(source.Area1.REF.current.REF127, \"OTUGI\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF127"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("OTUGI");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(50, "new Move().execute(10004258) => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.ID, target.purchaseOrderMessage.Order.BillToCustomerAccount.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerAccount.ID, this.env.User_Reference_3]", action);
							final SourceNode var0 = toValueNode(asNumber(10004258));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerLocation", "ID"), result);
							t1_Order.set(at("BillToCustomerAccount", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerAccount", "ID"), result);
							amazon850v4010RS_Rt.this.env.User_Reference_3 = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(51, "new Move().execute(\"Amazon.com Accounts Payable\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.Name]", action);
							final SourceNode var0 = toValueNode(asString("Amazon.com Accounts Payable"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "Name"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(52, "new Move().execute(\"\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerLocations, target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerTypeName, target.purchaseOrderMessage.Order.BillToCustomerAccount.EmailAddress, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerContact, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Name, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine1, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine2, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.PostalCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.StateCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CityName]", action);
							final SourceNode var0 = toValueNode(asString(""));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "CustomerLocations"), result);
							t1_Order.set(at("BillToCustomerAccount", "CustomerTypeName"), result);
							t1_Order.set(at("BillToCustomerAccount", "EmailAddress"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerContact"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Name"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine1"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine2"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "PostalCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "StateCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CityName"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(53, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CountryCode]", action);
							final SourceNode var0 = toValueNode(asString("US"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CountryCode"), result);
						}
					}}).run();
					createCompositeRule(54, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(54, "new StringEquals().execute(source.Area1.REF.current.REF127, \"OTUMB\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_cur_REF.get("REF127"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("OTUMB");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(55, "new Move().execute(10004299) => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.ID, target.purchaseOrderMessage.Order.BillToCustomerAccount.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.ID, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerAccount.ID, this.env.User_Reference_3]", action);
							final SourceNode var0 = toValueNode(asNumber(10004299));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerLocation", "ID"), result);
							t1_Order.set(at("BillToCustomerAccount", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "ID"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerAccount", "ID"), result);
							amazon850v4010RS_Rt.this.env.User_Reference_3 = extractString(result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(56, "new Move().execute(\"Amazon.com Accounts Payable\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.Name]", action);
							final SourceNode var0 = toValueNode(asString("Amazon.com Accounts Payable"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "Name"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(57, "new Move().execute(\"\") => #[target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerLocations, target.purchaseOrderMessage.Order.BillToCustomerAccount.CustomerTypeName, target.purchaseOrderMessage.Order.BillToCustomerAccount.EmailAddress, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerContact, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Name, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine1, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.AddressLine2, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.PostalCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.StateCode, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CityName]", action);
							final SourceNode var0 = toValueNode(asString(""));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("BillToCustomerAccount", "CustomerLocations"), result);
							t1_Order.set(at("BillToCustomerAccount", "CustomerTypeName"), result);
							t1_Order.set(at("BillToCustomerAccount", "EmailAddress"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerContact"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Name"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine1"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "AddressLine2"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "PostalCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "StateCode"), result);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CityName"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(58, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CountryCode]", action);
							final SourceNode var0 = toValueNode(asString("US"));
							final SourceNode result = action.execute(var0);
							t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CountryCode"), result);
						}
					}}).run();
				}}}).run();
				createCompositeRule(59, "for source.Area1.sgN1", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(59, "new StringEquals().execute(source.Area1.sgN1.current.N1.N198, \"ST\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s0_Area1.get("sgN1").get("N1").get("N198"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("ST");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
					for (final SourceNode s1_cur_sgN1 : s0_Area1.getIterable("sgN1")) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(60, "new Move().execute(source.Area1.sgN1.current.N1.N167) => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipmentId, target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.PartyLocationIDCode, this.v_N104]", action);
						final SourceNode var0 = s1_cur_sgN1.get("N1").get("N167");
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("Shipments", "Shipment", "ShipmentId"), result);
						t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "PartyLocationIDCode"), result);
						amazon850v4010RS_Rt.this.v_N104 = extractString(result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(61, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.Shipments.Shipment.ShipToCustomerLocation.Address.CountryCode]", action);
						final SourceNode var0 = toValueNode(asString("US"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("Shipments", "Shipment", "ShipToCustomerLocation", "Address", "CountryCode"), result);
					}
				}}}).run();
				createCompositeRule(62, "for source.Area2.sgPO1.current.PO1 initNew target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine", new Block() { public void body() {
					final SourceNode s0_Area2 = source.get("Area2");
					if (exists(s0_Area2)) {
					for (final SourceNode s1_cur_sgPO1 : s0_Area2.getIterable("sgPO1")) {
					final SourceNode s2_PO1 = s1_cur_sgPO1.get("PO1");
					if (exists(s2_PO1)) {
				
					final TargetNode t2_CustomerOrderLines = t1_Order.getLast(at("CustomerOrderLines"));
					final TargetNode t3_cur_CustomerOrderLine = t2_CustomerOrderLines.create(at("CustomerOrderLine"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(63, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1350) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.PurchaseOrderLineNumber]", action);
						final SourceNode var0 = s2_PO1.get("PO1350");
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("PurchaseOrderLineNumber"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(64, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1330) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.OrderedQuantity]", action);
						final SourceNode var0 = s2_PO1.get("PO1330");
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("OrderedQuantity"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(65, "new Move().execute(\"EACH\") => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement]", action);
						final SourceNode var0 = toValueNode(asString("EACH"));
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("ProductQuantityUnitOfMeasurement"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(66, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1212) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount]", action);
						final SourceNode var0 = s2_PO1.get("PO1212");
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("ProductUnitPriceAmount"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(67, "new Move().execute(\"SEATTLE\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.CityName]", action);
						final SourceNode var0 = toValueNode(asString("SEATTLE"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "CityName"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(68, "new Move().execute(\"98108-0387\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.PostalCode]", action);
						final SourceNode var0 = toValueNode(asString("98108-0387"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "PostalCode"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(69, "new Move().execute(\"WA\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.StateCode]", action);
						final SourceNode var0 = toValueNode(asString("WA"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "StateCode"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(70, "new Move().execute(\"US\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.CountryCode]", action);
						final SourceNode var0 = toValueNode(asString("US"));
						final SourceNode result = action.execute(var0);
						t1_Order.set(at("BillToCustomerLocation", "Address", "CountryCode"), result);
					}
					createCompositeRule(71, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(71, "new StringEquals().execute(source.Area2.sgPO1.current.PO1.PO1235, \"VN\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_PO1.get("PO1235"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("VN");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(72, "new Move().execute(source.Area2.sgPO1.current.PO1.PO1234) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.Product.ProductId]", action);
							final SourceNode var0 = s2_PO1.get("PO1234");
							final SourceNode result = action.execute(var0);
							t3_cur_CustomerOrderLine.set(at("Product", "ProductId"), result);
						}
					}}).run();
					{
						com.extol.ebi.reactor.lib.actions.numeric.Multiply action = new com.extol.ebi.reactor.lib.actions.numeric.Multiply();
						createSimpleRule(73, "new com.extol.ebi.reactor.lib.actions.numeric.Multiply().execute(source.Area2.sgPO1.current.PO1.PO1330, source.Area2.sgPO1.current.PO1.PO1212, 2) => #[this.v_sum]", action);
						final com.extol.ebi.ruleset.lang.core.Number var0 = extractNumber(s2_PO1.get("PO1330"));
						final com.extol.ebi.ruleset.lang.core.Number var1 = extractNumber(s2_PO1.get("PO1212"));
						final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(2);
						final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
						amazon850v4010RS_Rt.this.v_sum = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
						createSimpleRule(74, "new com.extol.ebi.reactor.lib.actions.numeric.Add().execute(this.v_sum, this.v_total, 2) => #[this.v_total]", action);
						final com.extol.ebi.ruleset.lang.core.Number var0 = amazon850v4010RS_Rt.this.v_sum;
						final com.extol.ebi.ruleset.lang.core.Number var1 = amazon850v4010RS_Rt.this.v_total;
						final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(2);
						final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
						amazon850v4010RS_Rt.this.v_total = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(75, "new Move().execute(\"2324531766\") => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.PartnerOrderLineReferenceSourceNode]", action);
						final SourceNode var0 = toValueNode(asString("2324531766"));
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("PartnerOrderLineReferenceSourceNode"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(76, "new Move().execute(this.v_RequestedDeliveryBeforeDate) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.RequestedDeliveryNotBeforeDate]", action);
						final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_RequestedDeliveryBeforeDate);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("RequestedDeliveryNotBeforeDate"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(77, "new Move().execute(this.v_RequestedDeliveryNotAfterDate) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.RequestedDeliveryNotAfterDate]", action);
						final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_RequestedDeliveryNotAfterDate);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("RequestedDeliveryNotAfterDate"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(78, "new Move().execute(this.v_RequestedDeliveryNotAfterDate) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.DeliveryRequestedDate]", action);
						final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_RequestedDeliveryNotAfterDate);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("DeliveryRequestedDate"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(79, "new Move().execute(this.v_N104) => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.ShipmentId]", action);
						final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_N104);
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("ShipmentId"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(80, "new Move().execute(\" \") => #[target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.Product.CustomerProductId, target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.Product.Description, target.purchaseOrderMessage.Order.CustomerOrderLines.CustomerOrderLine.current.Product.UPC]", action);
						final SourceNode var0 = toValueNode(asString(" "));
						final SourceNode result = action.execute(var0);
						t3_cur_CustomerOrderLine.set(at("Product", "CustomerProductId"), result);
						t3_cur_CustomerOrderLine.set(at("Product", "Description"), result);
						t3_cur_CustomerOrderLine.set(at("Product", "UPC"), result);
					}
				}}}}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(81, "new Move().execute(\"Buy\") => #[target.purchaseOrderMessage.Order.OrderTypeName]", action);
					final SourceNode var0 = toValueNode(asString("Buy"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("OrderTypeName"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(82, "new Move().execute(\"Unknown\") => #[target.purchaseOrderMessage.Order.OrderStatusName]", action);
					final SourceNode var0 = toValueNode(asString("Unknown"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("OrderStatusName"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(83, "new Move().execute(\"2324531766\") => #[target.purchaseOrderMessage.Order.PartnerOrderReferenceSourceNode]", action);
					final SourceNode var0 = toValueNode(asString("2324531766"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("PartnerOrderReferenceSourceNode"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(84, "new Move().execute(this.v_total) => #[target.purchaseOrderMessage.Order.TotalAmount]", action);
					final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.v_total);
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("TotalAmount"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(85, "new Move().execute(\"PO Box 80387\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.Address.AddressLine1]", action);
					final SourceNode var0 = toValueNode(asString("PO Box 80387"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("BillToCustomerLocation", "Address", "AddressLine1"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
					createSimpleRule(86, "new RawMove().execute(\"0000\") => #[target.purchaseOrderMessage.Order.BillToCustomerLocation.PartyLocationIDCode]", action);
					final SourceNode var0 = toValueNode(asString("0000"));
					final SourceNode result = action.execute(var0);
					t1_Order.set(at("BillToCustomerLocation", "PartyLocationIDCode"), result);
				}
			}}).run();
			{
				com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
				createSimpleRule(87, "new GetCurrentDateTime().execute() => #[this.v_currentDateTime]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
				amazon850v4010RS_Rt.this.v_currentDateTime = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
				createSimpleRule(88, "new GetMilliseconds().execute(this.v_currentDateTime) => #[this.V_EpochTime]", action);
				final com.extol.ebi.ruleset.lang.core.DateTime var0 = amazon850v4010RS_Rt.this.v_currentDateTime;
				final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
				amazon850v4010RS_Rt.this.V_EpochTime = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(89, "new Move().execute(this.V_EpochTime) => #[this.env.User_Reference_2]", action);
				final SourceNode var0 = toValueNode(amazon850v4010RS_Rt.this.V_EpochTime);
				final SourceNode result = action.execute(var0);
				amazon850v4010RS_Rt.this.env.User_Reference_2 = extractString(result);
			}
		}}}}).run();
	}

}
