package com.cleo.cic.cockpit.core;

import com.cleo.catalyst.lib.Variable;
import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.sqlaccess.SqlAccess;
import com.extol.ebi.reactor.database.lib.datasource.RtDataSource;
import com.extol.ebi.reactor.database.lib.schema.RtColumnTypes;
import com.extol.ebi.reactor.lib.AbstractAction;
import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;
import com.extol.ebi.sqlaccess.lib.BpsSqlAccessParameter;
import com.extol.ebi.sqlaccess.lib.Direction;
import com.extol.ebi.sqlaccess.lib.MultipleRecordsAction;
import com.extol.ebi.sqlaccess.lib.NoRecordsAction;
import com.extol.ebi.sqlaccess.lib.PreparedSqlAccess;
import com.extol.ebi.sqlaccess.lib.Retry;
import com.extol.ebi.sqlaccess.lib.SqlAccessHelper;
import com.extol.ebi.sqlaccess.lib.SqlAccessParameter;
import com.extol.ebi.sqlaccess.lib.TimeUnit;
import com.extol.ebi.sqlaccess.lib.Timeout;
import com.extol.ebi.sqlaccess.lib.V2SqlAccessTask;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("all")
public class getLastFailureProcessNumberSQL implements SqlAccess {
  public void execute(final com.extol.ebi.ruleset.lang.core.String ParentProcessNumber, final com.extol.ebi.ruleset.lang.core.String FailedProcessNumber) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class BpsTask extends V2SqlAccessTask implements BpsCallable {
    @OverrideOpName(value = "bps1://SQLAccess")
    public boolean execute(final com.extol.ebi.bps.lang.String ParentProcessNumber, final com.extol.ebi.bps.lang.String FailedProcessNumber) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
    
    public boolean execute_v2(final Variable<String> ParentProcessNumber, final Variable<String> FailedProcessNumber) {
      PreparedSqlAccess sqlAccess = buildSqlAccess(ParentProcessNumber);
      List<ValueNode> valueNodes = sqlAccess.performAction();
      
      FailedProcessNumber.setValue(valueNodes == null ? null : extractValue(valueNodes.get(0), java.lang.String.class));
      
      return true;
    }
    
    private static PreparedSqlAccess buildSqlAccess(final Variable<String> ParentProcessNumber) {
      RtDataSource dataSource = new com.cleo.cic.cockpit.core.ClarifyInternalDS_Rt();
      String statement = "SELECT MAX(\"PROCESS_USER_REF\") FROM \"EBI\".\"LOG_OF_PROCESS\" WHERE \"ACTIVITY_ID\" = (SELECT \"ACTIVITY_ID\"  FROM \"EBI\".\"LOG_OF_PROCESS\"  WHERE \"PROCESS_USER_REF\"=${ParentProcessNumber}) AND \"STATUS\" = 4";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      parameters.add(new BpsSqlAccessParameter("ParentProcessNumber", ParentProcessNumber, RtColumnTypes.BIGINT, Direction.IN));
      parameters.add(new BpsSqlAccessParameter("FailedProcessNumber", RtColumnTypes.BIGINT));
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
  
  public static class RulesetAction implements RulesetCallable, SqlAccess {
    public com.extol.ebi.ruleset.lang.core.String execute(final com.extol.ebi.ruleset.lang.core.String ParentProcessNumber) {
      return null;
    }
  }
  
  public static class RulesetActionV2 extends AbstractAction implements RulesetCallable, SqlAccess {
    public com.extol.ebi.ruleset.lang.core.String execute(final com.extol.ebi.ruleset.lang.core.String ParentProcessNumber) {
      PreparedSqlAccess sqlAccess = buildSqlAccess(ParentProcessNumber);
      List<ValueNode> valueNodes = sqlAccess.performAction();
      return (valueNodes == null ? null : valueNodes.get(0).extractString()); 
    }
    
    private static PreparedSqlAccess buildSqlAccess(final com.extol.ebi.ruleset.lang.core.String ParentProcessNumber) {
      RtDataSource dataSource = new com.cleo.cic.cockpit.core.ClarifyInternalDS_Rt();
      String statement = "SELECT MAX(\"PROCESS_USER_REF\") FROM \"EBI\".\"LOG_OF_PROCESS\" WHERE \"ACTIVITY_ID\" = (SELECT \"ACTIVITY_ID\"  FROM \"EBI\".\"LOG_OF_PROCESS\"  WHERE \"PROCESS_USER_REF\"=${ParentProcessNumber}) AND \"STATUS\" = 4";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      parameters.add(new SqlAccessParameter("ParentProcessNumber", ParentProcessNumber, RtColumnTypes.BIGINT, Direction.IN));
      parameters.add(new SqlAccessParameter("FailedProcessNumber", RtColumnTypes.BIGINT));
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
}
