/**
* @generated
*/
package com.cleo.cic.cockpit.core;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.support.CallJavaAbstractTask;
import com.extol.ebi.bps.lib.tasks.logging.GetProcessNumber;
import com.extol.ebi.bps.lib.tasks.misc.CompareValues;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStorageNodeToString;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.misc.SetVariable;
import com.extol.ebi.bps.lib.tasks.string.ReplaceString;
import com.extol.ebi.bps.lib.types.AdapterPayload;
import com.extol.ebi.bps.lib.types.CompareType;
import com.extol.ebi.lang.storage.StorageNode;

@SuppressWarnings("all")
public class GetFailureProcessLogsBPS_Rt extends AbstractCatalyst {
	
	public GetFailureProcessLogsBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_ErrorLog, @ParameterType(String.class) Variable<String> p_FailedProcessNumber) {
		final Variable<String> v_log_message_url = variable(String.class, null);
		final Variable<StorageNode> v_processLog = variable(StorageNode.class, null);
		final Variable<String> v_processlogString = variable(String.class, null);
		final Variable<String> v_processNumber = variable(String.class, null);
		final Variable<String> v_failedProcessNumber = variable(String.class, null);
		final Variable<StorageNode> v_errorLog = variable(StorageNode.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Get Process Number", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Get Process Number");
					GetProcessNumber task = new GetProcessNumber();
					setupTask(task);
					return task.execute(v_processNumber);
				} finally { _endTask();}
			}
		}, "next", "Fatal");
		
		builder.addStep(null, "com.cleo.cic.cockpit.core.getLastFailureProcessNumberSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.getLastFailureProcessNumberSQL$BpsTask");
					com.cleo.cic.cockpit.core.getLastFailureProcessNumberSQL.BpsTask task = new com.cleo.cic.cockpit.core.getLastFailureProcessNumberSQL.BpsTask();
					setupTask(task);
					return task.execute_v2(v_processNumber, v_failedProcessNumber);
				} finally { _endTask();}
			}
		}, "next", "Fatal");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_failedProcessNumber, variable(Object.class, null), literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "next", "GetProcessLog");
		
		builder.addStep("GetLastActiveProcessNumber", "com.cleo.cic.cockpit.core.getLastActiveProcessNumberSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.getLastActiveProcessNumberSQL$BpsTask");
					com.cleo.cic.cockpit.core.getLastActiveProcessNumberSQL.BpsTask task = new com.cleo.cic.cockpit.core.getLastActiveProcessNumberSQL.BpsTask();
					setupTask(task);
					return task.execute_v2(v_processNumber, v_failedProcessNumber);
				} finally { _endTask();}
			}
		}, "GetProcessLog", "Fatal");
		
		builder.addStep("GetProcessLog", "com.cleo.cic.cockpit.core.ProcessURLSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.ProcessURLSQL$BpsTask");
					com.cleo.cic.cockpit.core.ProcessURLSQL.BpsTask task = new com.cleo.cic.cockpit.core.ProcessURLSQL.BpsTask();
					setupTask(task);
					return task.execute_v2(v_failedProcessNumber, v_log_message_url);
				} finally { _endTask();}
			}
		}, "next", "Fatal");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_log_message_url, v_log_message_url, variable(String.class, "processLog.xml"), variable(String.class, " "));
				} finally { _endTask();}
			}
		}, "next", "Fatal");
		
		builder.addStep(null, "com.cleo.cic.cockpit.core.ProcessLogFA", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.ProcessLogFA");
					return getInvokeDynamicTask("com.cleo.cic.cockpit.core.ProcessLogFA", "bps1://FileAdapter/?userParm=processLogURL").execute(new AdapterPayload(v_processLog), v_log_message_url);
				} finally { _endTask();}
			}
		}, "next", "Fatal");
		
		builder.addStep(null, "Convert Storage Node to String", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert Storage Node to String");
					ConvertStorageNodeToString task = new ConvertStorageNodeToString();
					setupTask(task);
					return task.execute(v_processLog, v_processlogString);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.cic.cockpit.core.GetFailureProcessLogsBPS$ProcessLogParser", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.GetFailureProcessLogsBPS$ProcessLogParser");
					ProcessLogParser task = new ProcessLogParser();
					setupTask(task);
					return task.execute(v_errorLog, v_processlogString);
				} finally { _endTask();}
			}
		}, "next", "Fatal");
		
		builder.addStep(null, "Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Value");
					SetVariable task = new SetVariable();
					setupTask(task);
					return task.execute(p_ErrorLog, v_errorLog);
				} finally { _endTask();}
			}
		}, "next", "Fatal");
		
		builder.addStep(null, "Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Value");
					SetVariable task = new SetVariable();
					setupTask(task);
					return task.execute(p_FailedProcessNumber, v_failedProcessNumber);
				} finally { _endTask();}
			}
		}, "end", "Fatal");
		
		builder.addStep("Fatal", "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, false));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		return builder.createRunner().run();
	}
	
	public static class ProcessLogParser extends CallJavaAbstractTask {
		public ProcessLogParser() {
			super("com.cleo.cic.cockpit.core.ProcessLogParser", "com.extol.ebi.lang.storage.StorageNode getErrorLogs(java.lang.String)", false ,"file:///D:/CCP/Cleo_Integration_Cloud_Studio_Workspace/MessageLifecycleTestTenant/com.cleo.cic.cockpit.core/src/XPathParser.jar");
		}
	}
}
