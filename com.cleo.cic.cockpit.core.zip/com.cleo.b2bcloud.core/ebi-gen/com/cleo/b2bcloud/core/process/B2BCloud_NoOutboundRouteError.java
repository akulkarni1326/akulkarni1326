package com.cleo.b2bcloud.core.process;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class B2BCloud_NoOutboundRouteError implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public com.extol.ebi.bps.lang.String messageType;
    
    @TupleIndex(value = 1)
    public com.extol.ebi.bps.lang.String tpId;
    
    @TupleIndex(value = 2)
    public StorageNode sourceDataGroup;
    
    @TupleIndex(value = 3)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public B2BCloud_NoOutboundRouteError.ResultTuple execute(final com.extol.ebi.bps.lang.String messageType, final com.extol.ebi.bps.lang.String tpId, final StorageNode sourceDataGroup) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public com.extol.ebi.ruleset.lang.core.String messageType;
      
      @TupleIndex(value = 1)
      public com.extol.ebi.ruleset.lang.core.String tpId;
      
      @TupleIndex(value = 2)
      public StorageNode sourceDataGroup;
      
      @TupleIndex(value = 3)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public B2BCloud_NoOutboundRouteError.RulesetAction.ResultTuple execute(final com.extol.ebi.ruleset.lang.core.String messageType, final com.extol.ebi.ruleset.lang.core.String tpId, final StorageNode sourceDataGroup) {
      Object[] _bps_parameters = new Object[3];
      _bps_parameters[0] = toBpsString(messageType);
      _bps_parameters[1] = toBpsString(tpId);
      _bps_parameters[2] = sourceDataGroup;
      
      boolean _exit_PassStatus = launchScript("com.cleo.b2bcloud.core", "com.cleo.b2bcloud.core.process.B2BCloud_NoOutboundRouteError", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.messageType = asString(_bps_parameters[0]);
      resultTuple.tpId = asString(_bps_parameters[1]);
      resultTuple.sourceDataGroup = asStorageNode(_bps_parameters[2]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
}
