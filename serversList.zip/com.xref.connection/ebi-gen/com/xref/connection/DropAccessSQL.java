package com.xref.connection;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.sqlaccess.SqlAccess;
import com.extol.ebi.reactor.database.lib.datasource.RtDataSource;
import com.extol.ebi.reactor.lib.AbstractAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;
import com.extol.ebi.sqlaccess.lib.MultipleRecordsAction;
import com.extol.ebi.sqlaccess.lib.NoRecordsAction;
import com.extol.ebi.sqlaccess.lib.PreparedSqlAccess;
import com.extol.ebi.sqlaccess.lib.Retry;
import com.extol.ebi.sqlaccess.lib.SqlAccessHelper;
import com.extol.ebi.sqlaccess.lib.SqlAccessParameter;
import com.extol.ebi.sqlaccess.lib.TimeUnit;
import com.extol.ebi.sqlaccess.lib.Timeout;
import com.extol.ebi.sqlaccess.lib.V2SqlAccessTask;
import java.util.ArrayList;

@SuppressWarnings("all")
public class DropAccessSQL implements SqlAccess {
  public void execute() {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class BpsTask extends V2SqlAccessTask implements BpsCallable {
    @OverrideOpName(value = "bps1://SQLAccess")
    public boolean execute() {
      throw new UnsupportedOperationException("execute is not implemented");
    }
    
    public boolean execute_v2() {
      PreparedSqlAccess sqlAccess = buildSqlAccess();
      sqlAccess.performAction();
      return true;
    }
    
    private static PreparedSqlAccess buildSqlAccess() {
      RtDataSource dataSource = new com.xref.connection.xrefinternalDS_Rt();
      String statement = "Drop table \"REFTABLES\".\"LineNumbers\";";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
  
  public static class RulesetAction implements RulesetCallable, SqlAccess {
    public Void execute() {
      return null;
    }
  }
  
  public static class RulesetActionV2 extends AbstractAction implements RulesetCallable, SqlAccess {
    public Void execute() {
      PreparedSqlAccess sqlAccess = buildSqlAccess();
      sqlAccess.performAction();
      return null;
    }
    
    private static PreparedSqlAccess buildSqlAccess() {
      RtDataSource dataSource = new com.xref.connection.xrefinternalDS_Rt();
      String statement = "Drop table \"REFTABLES\".\"LineNumbers\";";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
}
