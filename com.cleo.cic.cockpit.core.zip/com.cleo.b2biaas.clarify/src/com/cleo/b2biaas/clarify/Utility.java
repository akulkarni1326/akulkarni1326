package com.cleo.b2biaas.clarify;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Manju Muthuraj
 * 
 */
public class Utility extends B2BAction {


	public void postMessage(String serverUrl, String json, String securityToken)
			throws Exception {
		int low = 1;
		int high = 1000;
		int connectionTimeout = 30000;
		Random r = new Random();

		for (int retry = 0; retry <= 3; retry++) {
			try {

				URL url = new URL(serverUrl);
				HttpURLConnection conn = (HttpURLConnection) url
						.openConnection();
				conn.setRequestMethod(EventKeys.HTTP_POST_METHOD);
				conn.setRequestProperty(EventKeys.HEADER_ACCEPT, EventKeys.HEADER_VALUE_APPLICATION_JSON);
				conn.setRequestProperty(EventKeys.HEADER_KEY_CONTENT_TYPE, EventKeys.HEADER_VALUE_APPLICATION_JSON);
				conn.setRequestProperty(EventKeys.HEADER_KEY_AUTHORIZATION, "Bearer "
						+ securityToken);
				conn.setDoOutput(true);
				conn.setReadTimeout(connectionTimeout);

				OutputStream os = conn.getOutputStream();
				os.write(json.getBytes());

				os.flush();

				int responseCode = conn.getResponseCode();
				if (responseCode != 200 && responseCode != 202) {
					throw new RuntimeException("Failed : HTTP error code : "
							+ conn.getResponseCode() + ": Response message : "
							+ conn.getResponseMessage());
				}

				BufferedReader br = new BufferedReader(new InputStreamReader(
						(conn.getInputStream())));

				
				String output;
				while ((output = br.readLine()) != null) {
					logInfo(EventKeys.SERVER_RESPONSE_BODY + output);
				}

				conn.disconnect();
				break;

			} catch (Exception e) {

				// If we've exhausted our retries, throw the exception
				if (retry == 3) {
					logInfo(EventKeys.EXITING_THE_RETRY_AFTER_3_RETRIES);
					throw new Exception(e);
					// throw e;
				}
				// Wait an indeterminate amount of time (range determined by n)
				try {
					logInfo("Post Message to Cockpit failed due to " +  e.getMessage() + " Retrying for 3 times. Retry attempt:  " + (retry + 1));
					Thread.sleep(((int) Math.round(Math.pow(2, retry)) * 2000)
							+ (r.nextInt(high - low) + low));
				} catch (InterruptedException ignored) {
					// Ignoring interruptions in the Thread sleep so that
					// retries continue
				}
			}

		}
	}
	
	public static String setEmptyStringIfNull(
			com.extol.ebi.ruleset.lang.core.String value) {
		String valRef = "";
		if (value == null || value.asJavaString().isEmpty()) {
			valRef = "";
		}else {
			valRef = value.asJavaString();
		}
		return valRef;
	}
	
	public String objectToString(ConcurrentHashMap<String,String> concurrentHashMap) {
		String json = null;
		ObjectMapper mapper = new ObjectMapper();
		try {

			json = mapper.writerWithDefaultPrettyPrinter()
					.writeValueAsString(concurrentHashMap);			

		} catch (Exception e) {
			// Log and ignore the error. Let the ruleset not fail because of
			// this error
			logInfo(EventKeys.ERROR_CREATING_JSON_STRUCTURE + e.toString());
		}
		return json;
	}
	
	public String objectToString(HashMap<String,String> hashMap) {
		String json = null;
		ObjectMapper mapper = new ObjectMapper();
		try {

			json = mapper.writerWithDefaultPrettyPrinter()
					.writeValueAsString(hashMap);			

		} catch (Exception e) {
			// Log and ignore the error. Let the ruleset not fail because of
			// this error
			logInfo(EventKeys.ERROR_CREATING_JSON_STRUCTURE + e.toString());
		}
		return json;
	}
	
	public String objectToString(FAData fadata) {
		String json = null;
		ObjectMapper mapper = new ObjectMapper();
		try {

			json = mapper.writerWithDefaultPrettyPrinter()
					.writeValueAsString(fadata);			

		} catch (Exception e) {
			// Log and ignore the error. Let the ruleset not fail because of
			// this error
			logInfo(EventKeys.ERROR_CREATING_JSON_STRUCTURE + e.toString());
		}
		return json;
	}
	
	public String messageDetailsV2(LinkedHashMap<String, LinkedHashMap<String, String>> mi,
			ObjectMapper messageDetailsMapper, String messagedetailsJson)
			throws JsonProcessingException {
		if (!mi.isEmpty()) {
			messagedetailsJson = messagedetailsJson.replace("}", "").trim();
			String messagedetailsV2Json = messageDetailsMapper
					.writerWithDefaultPrettyPrinter().writeValueAsString(
							mi);
			messagedetailsV2Json = messagedetailsV2Json.substring(
					messagedetailsV2Json.indexOf("{") + 1).trim();
			messagedetailsJson += messagedetailsV2Json;
		}
		return messagedetailsJson;
	}
	
	public void postMessageTob2biaaS(StringBuffer sb,String apiresource,String logMsg)
			throws Exception { 
		logInfo(EventKeys.CLOUD_CONFIG_IS_CONFIGURED + CloudConfig.isConfigured());
		if (CloudConfig.isConfigured()) {
			logInfo(EventKeys.LOADING_PROPERTIES_FROM_CLOUD_CONFIG_FOR_COCKPIT);

			String MESSAGE_API_URL = CloudConfig.getServerUrl()
					+ apiresource
					+ CloudConfig.getTenantId();
			logInfo(EventKeys.SERVER_URL_LOG+MESSAGE_API_URL);
			logInfo(logMsg
					+ sb.toString());
			postMessage(MESSAGE_API_URL, sb.toString(),
					CloudConfig.getSecurityToken());
		} else {
			logInfo(EventKeys.LOADING_PROPERTIES_FROM_RESOURCES_OF_API_PROJECT_FOR_COCKPIT);
			logInfo(EventKeys.B2BIAAS_ENVIRONMENT + EventKeys.ENVIRONMENT);
			
			if ("stage".equals(EventKeys.ENVIRONMENT)) {

				String MESSAGE_API_STAGE_URL = EventKeys.SERVER_URL
						+ apiresource
						+ EventKeys.TENANTID_STAGE;
				logInfo(EventKeys.SERVER_URL_LOG+MESSAGE_API_STAGE_URL);
				logInfo(logMsg
						+ sb.toString());
				postMessage(MESSAGE_API_STAGE_URL,
						sb.toString(), EventKeys.SECURITY_TOKEN_STAGE);
			} else {
				if ("production".equals(EventKeys.ENVIRONMENT)) {

					String MESSAGE_API_PRODUCTION_URL = EventKeys.SERVER_URL
							+ apiresource
							+ EventKeys.TENANTID_PRODUCTION;
					logInfo(EventKeys.SERVER_URL_LOG+MESSAGE_API_PRODUCTION_URL);
					logInfo(logMsg
							+ sb.toString());
					postMessage(MESSAGE_API_PRODUCTION_URL,
							sb.toString(),
							EventKeys.SECURITY_TOKEN_PRODUCTION);
				} else {
					throw new Exception(
							EventKeys.THE_ENVIRONMENT_SHOULD_BE_EITHER_STAGE_OR_PRODUCTION
									+ EventKeys.ENVIRONMENT);
				}
			}
		}
	}
}
