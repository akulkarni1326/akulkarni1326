package com.otterproducts.core.system.n810;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class otterproducts_Outbound810LauncherBPS implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode payload;
    
    @TupleIndex(value = 1)
    public com.extol.ebi.bps.lang.String fileName;
    
    @TupleIndex(value = 2)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public otterproducts_Outbound810LauncherBPS.ResultTuple execute(final StorageNode payload, final com.extol.ebi.bps.lang.String fileName) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode payload;
      
      @TupleIndex(value = 1)
      public com.extol.ebi.ruleset.lang.core.String fileName;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public otterproducts_Outbound810LauncherBPS.RulesetAction.ResultTuple execute(final StorageNode payload, final com.extol.ebi.ruleset.lang.core.String fileName) {
      Object[] _bps_parameters = new Object[2];
      _bps_parameters[0] = payload;
      _bps_parameters[1] = toBpsString(fileName);
      
      boolean _exit_PassStatus = launchScript("com.otterproducts.core.system", "com.otterproducts.core.system.n810.otterproducts_Outbound810LauncherBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.payload = asStorageNode(_bps_parameters[0]);
      resultTuple.fileName = asString(_bps_parameters[1]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
}
