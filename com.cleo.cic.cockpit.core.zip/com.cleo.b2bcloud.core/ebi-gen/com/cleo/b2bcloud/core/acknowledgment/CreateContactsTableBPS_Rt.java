/**
* @generated
*/
package com.cleo.b2bcloud.core.acknowledgment;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;

@SuppressWarnings("all")
public class CreateContactsTableBPS_Rt extends AbstractCatalyst {
	
	public CreateContactsTableBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute() {

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "com.cleo.b2bcloud.core.acknowledgment.CreateContactsTableSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.acknowledgment.CreateContactsTableSQL$BpsTask");
					com.cleo.b2bcloud.core.acknowledgment.CreateContactsTableSQL.BpsTask task = new com.cleo.b2bcloud.core.acknowledgment.CreateContactsTableSQL.BpsTask();
					setupTask(task);
					return task.execute_v2();
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
