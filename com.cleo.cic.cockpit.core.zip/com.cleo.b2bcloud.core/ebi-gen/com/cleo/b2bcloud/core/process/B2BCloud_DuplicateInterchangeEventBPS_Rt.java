/**
* @generated
*/
package com.cleo.b2bcloud.core.process;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.exitpoint.ExtractEdiInterchangeData;
import com.extol.ebi.bps.lib.tasks.misc.SendEmail;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.string.AppendString;
import com.extol.ebi.bps.lib.tasks.string.ReplaceString;
import com.extol.ebi.bps.lib.tasks.string.ResolveGlobalVariables;
import com.extol.ebi.bps.lib.types.EdiDataMap;
import com.extol.ebi.bps.lib.types.unions.Attachment;
import com.extol.ebi.bps.lib.types.unions.Message;
import com.extol.ebi.lang.storage.StorageNode;

@SuppressWarnings("all")
public class B2BCloud_DuplicateInterchangeEventBPS_Rt extends AbstractCatalyst {
	
	public B2BCloud_DuplicateInterchangeEventBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_storageId, @ParameterType(EdiDataMap.class) Variable<EdiDataMap> p_interchangeProperties) {
		final Variable<String> v_intCtlNbr = variable(String.class, null);
		final Variable<String> v_message = variable(String.class, null);
		final Variable<String> v_sendEmailToB2BCloud = variable(String.class, null);
		final Variable<String> v_sendEmailToCustomer = variable(String.class, null);
		final Variable<String> v_sendEmailFrom = variable(String.class, null);
		final Variable<String> v_environment = variable(String.class, null);
		final Variable<String> v_subjectFull = variable(String.class, null);
		final Variable<String> v_subject = variable(String.class, " Duplicate Interchange Event");
		final Variable<String> v_label1 = variable(String.class, "Hello Team,\r\n\r\nWe have received a file with below details that failed due to Duplicate interchange:\r\n\r\nInterchange Control #: xxx \r\nEDI Sender ID : yyy \r\nTP Name: zzz\r\n\r\nPlease check the attachment and let us know in case any action is required from our end.\r\n\r\nThanks\r\nCleo Support\r\ncloudsupport@cleointegration.cloud");
		final Variable<String> v_eBIB2bCloudEmail = variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.B2BCloudAdminEmail>");
		final Variable<String> v_eBICustomerEmail = variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.CustomerAdminEmail>");
		final Variable<String> v_ClarifyHostEmail = variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.B2BCloudHostEmail>");
		final Variable<String> v_environment_GV = variable(String.class, "<com.cleo.b2bcloud.core.B2BCloudGV.Environment>");
		final Variable<String> v_attachmentName = variable(String.class, null);
		final Variable<String> v_receiverId = variable(String.class, null);
		final Variable<String> v_senderId = variable(String.class, null);
		final Variable<String> v_activeCount = variable(String.class, null);
		final Variable<String> v_TPID = variable(String.class, null);
		final Variable<String> v_TPName = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep("CloudSupportEmail", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailToB2BCloud, v_eBIB2bCloudEmail);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep("CustomerEmail", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailToCustomer, v_eBICustomerEmail);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep("HostEmail", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailFrom, v_ClarifyHostEmail);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep("Environment", "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_environment, v_environment_GV);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Extract EDI Interchange Data", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Extract EDI Interchange Data");
					ExtractEdiInterchangeData task = new ExtractEdiInterchangeData();
					setupTask(task);
					return task.execute(p_interchangeProperties, v_intCtlNbr, v_receiverId, variable(String.class, null), v_senderId, variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null), variable(String.class, null));
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.acknowledgment.TPIDSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.acknowledgment.TPIDSQL$BpsTask");
					com.cleo.b2bcloud.core.acknowledgment.TPIDSQL.BpsTask task = new com.cleo.b2bcloud.core.acknowledgment.TPIDSQL.BpsTask();
					setupTask(task);
					return task.execute_v2(v_senderId, v_TPID);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL$BpsTask");
					com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.BpsTask task = new com.cleo.b2bcloud.core.acknowledgment.TradingPartnerSQL.BpsTask();
					setupTask(task);
					return task.execute_v2(v_TPID, v_TPName);
				} finally { _endTask();}
			}
		}, "next", "next");
		
		builder.addStep("Message", "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_message, v_label1, variable(String.class, "xxx"), v_intCtlNbr);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_message, v_message, variable(String.class, "yyy"), v_senderId);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "String - Replace", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Replace");
					ReplaceString task = new ReplaceString();
					setupTask(task);
					return task.execute(v_message, v_message, variable(String.class, "zzz"), v_TPName);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep("Subject", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subjectFull, v_environment, v_subject);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep("AttachmentName", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_attachmentName, v_intCtlNbr, variable(String.class, ".edi"));
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Send Email", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Send Email");
					SendEmail task = new SendEmail();
					setupTask(task);
					return task.execute(v_sendEmailToCustomer, v_sendEmailFrom, v_eBIB2bCloudEmail, variable(String.class, null), v_subjectFull, new Message(v_message), new Attachment(p_storageId), v_attachmentName);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "com.cleo.b2bcloud.core.systemchecks.UpdateReceivedandUnwrappedSQL$BpsTask", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2bcloud.core.systemchecks.UpdateReceivedandUnwrappedSQL$BpsTask");
					return getInvokeDynamicTask("com.cleo.b2bcloud.core.systemchecks.UpdateReceivedandUnwrappedSQL$BpsTask", "bps1://SQLAccess").execute(v_intCtlNbr, v_receiverId, v_senderId, v_activeCount);
				} finally { _endTask();}
			}
		}, "end", "Failure");
		
		builder.addStep("Failure", "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, false));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
