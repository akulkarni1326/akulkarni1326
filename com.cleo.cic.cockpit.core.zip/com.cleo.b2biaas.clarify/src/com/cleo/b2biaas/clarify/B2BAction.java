package com.cleo.b2biaas.clarify;

import java.util.HashMap;

import com.extol.ebi.reactor.lib.AbstractAction;

public abstract class B2BAction extends AbstractAction {


	public HashMap<String, String> getContext() {
		logInfo(EventKeys.ASSEMBLING_THE_CONTEXT_MAP);
		HashMap<String, String> map = new HashMap<>();
		assembleContextMap(map);
		logInfo(EventKeys.CONTEXT_MAP_ASSEMBLED);
		return map;

	}

	public void saveContext(HashMap<String, String> map) {
		logInfo(EventKeys.SAVING_CONTEXT_MAP);
		restoreContextMap(map);
		logInfo(EventKeys.CONTEXT_MAP_SAVED);
	}
	
	public HashMap<String, String> getContextForICN(){
		return getContext();
	}

}