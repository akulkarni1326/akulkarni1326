/**
 * @generated
 */
package com.cleo.b2bcloud.core.acknowledgment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.extol.ebi.reactor.edi.lib.schema.*;

@SuppressWarnings("all")
public class InboundAcknowledgment997_Rt implements RuntimeEdiDerivedMessageSchemaProvider {

	private RtEdiDerivedMessageSchema schema_InboundAcknowledgment997;

	public RtEdiDerivedMessageSchema getSchema() {
		if (schema_InboundAcknowledgment997 == null) {
			DerivedMessageHelper h = new DerivedMessageHelper();
			h.message = message997();
			
			schema_InboundAcknowledgment997 = new RtEdiDerivedMessageSchema("InboundAcknowledgment997", h);
		}

		return schema_InboundAcknowledgment997;
	}
	
	private RtMessage message997;
	
	private RtMessage message997() {
		if (message997 == null) {
			MessageHelper h = new MessageHelper();
			h.name = "Functional Acknowledgment";
			h.functionalGroup = "FA";
			h.version = "004010";
			h.standardsClass = "X";
			h.industryGroup = "X";

			List<RtArea> areas = new ArrayList<>();
			areas.add(area1());

			message997 = new RtMessage("997", areas, h);
		}

		return message997;
	}
	
	private RtArea area1;
	
	private RtArea area1() {
		if (area1 == null) {
			Map<String, RtSegmentGroup> segmentGroups_0 = new HashMap<>();
			{
				Map<String, RtSegmentGroup> segmentGroups_1 = new HashMap<>();
				{
					List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
					segmentFeatures.add(new RtSegmentReference("040", 0, 1, segmentAK3()));
					segmentFeatures.add(new RtSegmentReference("050", 0, 99, segmentAK4()));
					
					segmentGroups_1.put("AK3", new RtSegmentGroup("AK3", segmentFeatures));
				}
				List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
				segmentFeatures.add(new RtSegmentReference("030", 0, 1, segmentAK2()));
				segmentFeatures.add(new RtSegmentGroupReference("040", 0, 999999, segmentGroups_1.get("AK3")));
				segmentFeatures.add(new RtSegmentReference("060", 1, 1, segmentAK5()));
				
				segmentGroups_0.put("AK2", new RtSegmentGroup("AK2", segmentFeatures, segmentGroups_1));
			}
			List<SegmentStructureReference> segmentFeatures = new ArrayList<>();
			segmentFeatures.add(new RtSegmentReference("010", 1, 1, segmentST()));
			segmentFeatures.add(new RtSegmentReference("020", 1, 1, segmentAK1()));
			segmentFeatures.add(new RtSegmentGroupReference("030", 0, 999999, segmentGroups_0.get("AK2")));
			segmentFeatures.add(new RtSegmentReference("070", 1, 1, segmentAK9()));
			segmentFeatures.add(new RtSegmentReference("080", 1, 1, segmentSE()));
			
			area1 = new RtArea("1", segmentFeatures, segmentGroups_0);
		}
		
		return area1;
	}
	
	private RtSegment segmentST;
	
	private RtSegment segmentST() {
		if (segmentST == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "ST143", simpleElement143()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "ST329", simpleElement329()));
			segmentST = new RtSegment("ST", elementReferences);
		}

		return segmentST;
	}
	
	private RtSegment segmentAK1;
	
	private RtSegment segmentAK1() {
		if (segmentAK1 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "AK1479", simpleElement479()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "AK128", simpleElement28()));
			segmentAK1 = new RtSegment("AK1", elementReferences);
		}

		return segmentAK1;
	}
	
	private RtSegment segmentAK2;
	
	private RtSegment segmentAK2() {
		if (segmentAK2 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "AK2143", simpleElement143()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "AK2329", simpleElement329()));
			segmentAK2 = new RtSegment("AK2", elementReferences);
		}

		return segmentAK2;
	}
	
	private RtSegment segmentAK3;
	
	private RtSegment segmentAK3() {
		if (segmentAK3 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "AK3721", simpleElement721()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "AK3719", simpleElement719()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "AK3447", simpleElement447()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "AK3720", simpleElement720()));
			segmentAK3 = new RtSegment("AK3", elementReferences);
		}

		return segmentAK3;
	}
	
	private RtSegment segmentAK4;
	
	private RtSegment segmentAK4() {
		if (segmentAK4 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtCompositeElementReference("01", 1, 1, "AK4C030", compositeElementC030()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "AK4725", simpleElement725()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "AK4723", simpleElement723()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "AK4724", simpleElement724()));
			segmentAK4 = new RtSegment("AK4", elementReferences);
		}

		return segmentAK4;
	}
	
	private RtSegment segmentAK5;
	
	private RtSegment segmentAK5() {
		if (segmentAK5 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "AK5717", simpleElement717()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "AK5718", simpleElement718()));
			elementReferences.add(new RtSimpleElementReference("03", 0, 1, "AK5718_3", simpleElement718()));
			elementReferences.add(new RtSimpleElementReference("04", 0, 1, "AK5718_4", simpleElement718()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "AK5718_5", simpleElement718()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "AK5718_6", simpleElement718()));
			segmentAK5 = new RtSegment("AK5", elementReferences);
		}

		return segmentAK5;
	}
	
	private RtSegment segmentAK9;
	
	private RtSegment segmentAK9() {
		if (segmentAK9 == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "AK9715", simpleElement715()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "AK997", simpleElement97()));
			elementReferences.add(new RtSimpleElementReference("03", 1, 1, "AK9123", simpleElement123()));
			elementReferences.add(new RtSimpleElementReference("04", 1, 1, "AK92", simpleElement2()));
			elementReferences.add(new RtSimpleElementReference("05", 0, 1, "AK9716", simpleElement716()));
			elementReferences.add(new RtSimpleElementReference("06", 0, 1, "AK9716_3", simpleElement716()));
			elementReferences.add(new RtSimpleElementReference("07", 0, 1, "AK9716_4", simpleElement716()));
			elementReferences.add(new RtSimpleElementReference("08", 0, 1, "AK9716_5", simpleElement716()));
			elementReferences.add(new RtSimpleElementReference("09", 0, 1, "AK9716_6", simpleElement716()));
			segmentAK9 = new RtSegment("AK9", elementReferences);
		}

		return segmentAK9;
	}
	
	private RtSegment segmentSE;
	
	private RtSegment segmentSE() {
		if (segmentSE == null) {
			List<ElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "SE96", simpleElement96()));
			elementReferences.add(new RtSimpleElementReference("02", 1, 1, "SE329", simpleElement329()));
			segmentSE = new RtSegment("SE", elementReferences);
		}

		return segmentSE;
	}
	
	private RtCompositeElement compositeElementC030;

	private RtCompositeElement compositeElementC030() {
		if (compositeElementC030 == null) {
			List<RtSimpleElementReference> elementReferences = new ArrayList<>();
			elementReferences.add(new RtSimpleElementReference("01", 1, 1, "C03001", simpleElement722()));
			elementReferences.add(new RtSimpleElementReference("02", 0, 1, "C03002", simpleElement1528()));

			compositeElementC030 = new RtCompositeElement("C030", elementReferences);
		}

		return compositeElementC030;
	}
	
	private RtSimpleElement simpleElement143;
	
	private RtSimpleElement simpleElement143() {
		if (simpleElement143 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Set Identifier Code";
			h.minLength = 3;
			h.maxLength = 3;
			
			h.addAllowedValue("100");
			h.addAllowedValue("101");
			h.addAllowedValue("104");
			h.addAllowedValue("105");
			h.addAllowedValue("106");
			h.addAllowedValue("107");
			h.addAllowedValue("108");
			h.addAllowedValue("109");
			h.addAllowedValue("110");
			h.addAllowedValue("112");
			h.addAllowedValue("120");
			h.addAllowedValue("121");
			h.addAllowedValue("124");
			h.addAllowedValue("125");
			h.addAllowedValue("126");
			h.addAllowedValue("127");
			h.addAllowedValue("128");
			h.addAllowedValue("129");
			h.addAllowedValue("130");
			h.addAllowedValue("131");
			h.addAllowedValue("135");
			h.addAllowedValue("138");
			h.addAllowedValue("139");
			h.addAllowedValue("140");
			h.addAllowedValue("141");
			h.addAllowedValue("142");
			h.addAllowedValue("143");
			h.addAllowedValue("144");
			h.addAllowedValue("146");
			h.addAllowedValue("147");
			h.addAllowedValue("148");
			h.addAllowedValue("149");
			h.addAllowedValue("150");
			h.addAllowedValue("151");
			h.addAllowedValue("152");
			h.addAllowedValue("153");
			h.addAllowedValue("154");
			h.addAllowedValue("155");
			h.addAllowedValue("157");
			h.addAllowedValue("159");
			h.addAllowedValue("160");
			h.addAllowedValue("161");
			h.addAllowedValue("163");
			h.addAllowedValue("170");
			h.addAllowedValue("175");
			h.addAllowedValue("176");
			h.addAllowedValue("180");
			h.addAllowedValue("185");
			h.addAllowedValue("186");
			h.addAllowedValue("188");
			h.addAllowedValue("189");
			h.addAllowedValue("190");
			h.addAllowedValue("191");
			h.addAllowedValue("194");
			h.addAllowedValue("195");
			h.addAllowedValue("196");
			h.addAllowedValue("197");
			h.addAllowedValue("198");
			h.addAllowedValue("199");
			h.addAllowedValue("200");
			h.addAllowedValue("201");
			h.addAllowedValue("202");
			h.addAllowedValue("203");
			h.addAllowedValue("204");
			h.addAllowedValue("205");
			h.addAllowedValue("206");
			h.addAllowedValue("210");
			h.addAllowedValue("211");
			h.addAllowedValue("212");
			h.addAllowedValue("213");
			h.addAllowedValue("214");
			h.addAllowedValue("215");
			h.addAllowedValue("216");
			h.addAllowedValue("217");
			h.addAllowedValue("218");
			h.addAllowedValue("219");
			h.addAllowedValue("220");
			h.addAllowedValue("222");
			h.addAllowedValue("223");
			h.addAllowedValue("224");
			h.addAllowedValue("225");
			h.addAllowedValue("242");
			h.addAllowedValue("244");
			h.addAllowedValue("248");
			h.addAllowedValue("249");
			h.addAllowedValue("250");
			h.addAllowedValue("251");
			h.addAllowedValue("252");
			h.addAllowedValue("255");
			h.addAllowedValue("256");
			h.addAllowedValue("260");
			h.addAllowedValue("261");
			h.addAllowedValue("262");
			h.addAllowedValue("263");
			h.addAllowedValue("264");
			h.addAllowedValue("265");
			h.addAllowedValue("266");
			h.addAllowedValue("267");
			h.addAllowedValue("268");
			h.addAllowedValue("270");
			h.addAllowedValue("271");
			h.addAllowedValue("272");
			h.addAllowedValue("273");
			h.addAllowedValue("275");
			h.addAllowedValue("276");
			h.addAllowedValue("277");
			h.addAllowedValue("278");
			h.addAllowedValue("280");
			h.addAllowedValue("285");
			h.addAllowedValue("286");
			h.addAllowedValue("288");
			h.addAllowedValue("290");
			h.addAllowedValue("300");
			h.addAllowedValue("301");
			h.addAllowedValue("303");
			h.addAllowedValue("304");
			h.addAllowedValue("306");
			h.addAllowedValue("309");
			h.addAllowedValue("310");
			h.addAllowedValue("311");
			h.addAllowedValue("312");
			h.addAllowedValue("313");
			h.addAllowedValue("315");
			h.addAllowedValue("317");
			h.addAllowedValue("319");
			h.addAllowedValue("321");
			h.addAllowedValue("322");
			h.addAllowedValue("323");
			h.addAllowedValue("324");
			h.addAllowedValue("325");
			h.addAllowedValue("326");
			h.addAllowedValue("350");
			h.addAllowedValue("352");
			h.addAllowedValue("353");
			h.addAllowedValue("354");
			h.addAllowedValue("355");
			h.addAllowedValue("356");
			h.addAllowedValue("357");
			h.addAllowedValue("358");
			h.addAllowedValue("361");
			h.addAllowedValue("362");
			h.addAllowedValue("404");
			h.addAllowedValue("410");
			h.addAllowedValue("411");
			h.addAllowedValue("414");
			h.addAllowedValue("417");
			h.addAllowedValue("418");
			h.addAllowedValue("419");
			h.addAllowedValue("420");
			h.addAllowedValue("421");
			h.addAllowedValue("422");
			h.addAllowedValue("423");
			h.addAllowedValue("425");
			h.addAllowedValue("426");
			h.addAllowedValue("429");
			h.addAllowedValue("431");
			h.addAllowedValue("432");
			h.addAllowedValue("433");
			h.addAllowedValue("434");
			h.addAllowedValue("435");
			h.addAllowedValue("436");
			h.addAllowedValue("437");
			h.addAllowedValue("440");
			h.addAllowedValue("451");
			h.addAllowedValue("452");
			h.addAllowedValue("453");
			h.addAllowedValue("455");
			h.addAllowedValue("456");
			h.addAllowedValue("460");
			h.addAllowedValue("463");
			h.addAllowedValue("466");
			h.addAllowedValue("468");
			h.addAllowedValue("470");
			h.addAllowedValue("475");
			h.addAllowedValue("485");
			h.addAllowedValue("486");
			h.addAllowedValue("490");
			h.addAllowedValue("492");
			h.addAllowedValue("494");
			h.addAllowedValue("500");
			h.addAllowedValue("501");
			h.addAllowedValue("503");
			h.addAllowedValue("504");
			h.addAllowedValue("511");
			h.addAllowedValue("517");
			h.addAllowedValue("521");
			h.addAllowedValue("527");
			h.addAllowedValue("536");
			h.addAllowedValue("540");
			h.addAllowedValue("561");
			h.addAllowedValue("567");
			h.addAllowedValue("568");
			h.addAllowedValue("601");
			h.addAllowedValue("602");
			h.addAllowedValue("620");
			h.addAllowedValue("622");
			h.addAllowedValue("625");
			h.addAllowedValue("650");
			h.addAllowedValue("715");
			h.addAllowedValue("805");
			h.addAllowedValue("806");
			h.addAllowedValue("810");
			h.addAllowedValue("811");
			h.addAllowedValue("812");
			h.addAllowedValue("813");
			h.addAllowedValue("814");
			h.addAllowedValue("815");
			h.addAllowedValue("816");
			h.addAllowedValue("818");
			h.addAllowedValue("819");
			h.addAllowedValue("820");
			h.addAllowedValue("821");
			h.addAllowedValue("822");
			h.addAllowedValue("823");
			h.addAllowedValue("824");
			h.addAllowedValue("826");
			h.addAllowedValue("827");
			h.addAllowedValue("828");
			h.addAllowedValue("829");
			h.addAllowedValue("830");
			h.addAllowedValue("831");
			h.addAllowedValue("832");
			h.addAllowedValue("833");
			h.addAllowedValue("834");
			h.addAllowedValue("835");
			h.addAllowedValue("836");
			h.addAllowedValue("837");
			h.addAllowedValue("838");
			h.addAllowedValue("839");
			h.addAllowedValue("840");
			h.addAllowedValue("841");
			h.addAllowedValue("842");
			h.addAllowedValue("843");
			h.addAllowedValue("844");
			h.addAllowedValue("845");
			h.addAllowedValue("846");
			h.addAllowedValue("847");
			h.addAllowedValue("848");
			h.addAllowedValue("849");
			h.addAllowedValue("850");
			h.addAllowedValue("851");
			h.addAllowedValue("852");
			h.addAllowedValue("853");
			h.addAllowedValue("854");
			h.addAllowedValue("855");
			h.addAllowedValue("856");
			h.addAllowedValue("857");
			h.addAllowedValue("858");
			h.addAllowedValue("859");
			h.addAllowedValue("860");
			h.addAllowedValue("861");
			h.addAllowedValue("862");
			h.addAllowedValue("863");
			h.addAllowedValue("864");
			h.addAllowedValue("865");
			h.addAllowedValue("866");
			h.addAllowedValue("867");
			h.addAllowedValue("868");
			h.addAllowedValue("869");
			h.addAllowedValue("870");
			h.addAllowedValue("871");
			h.addAllowedValue("872");
			h.addAllowedValue("875");
			h.addAllowedValue("876");
			h.addAllowedValue("877");
			h.addAllowedValue("878");
			h.addAllowedValue("879");
			h.addAllowedValue("880");
			h.addAllowedValue("881");
			h.addAllowedValue("882");
			h.addAllowedValue("883");
			h.addAllowedValue("884");
			h.addAllowedValue("885");
			h.addAllowedValue("886");
			h.addAllowedValue("887");
			h.addAllowedValue("888");
			h.addAllowedValue("889");
			h.addAllowedValue("891");
			h.addAllowedValue("893");
			h.addAllowedValue("894");
			h.addAllowedValue("895");
			h.addAllowedValue("896");
			h.addAllowedValue("920");
			h.addAllowedValue("924");
			h.addAllowedValue("925");
			h.addAllowedValue("926");
			h.addAllowedValue("928");
			h.addAllowedValue("940");
			h.addAllowedValue("943");
			h.addAllowedValue("944");
			h.addAllowedValue("945");
			h.addAllowedValue("947");
			h.addAllowedValue("980");
			h.addAllowedValue("990");
			h.addAllowedValue("994");
			h.addAllowedValue("996");
			h.addAllowedValue("997");
			h.addAllowedValue("998");
			simpleElement143 = new RtSimpleElement("143", "ID", h);
		}
	
		return simpleElement143;
	}
	
	private RtSimpleElement simpleElement329;
	
	private RtSimpleElement simpleElement329() {
		if (simpleElement329 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Set Control Number";
			h.minLength = 4;
			h.maxLength = 9;
			
			simpleElement329 = new RtSimpleElement("329", "AN", h);
		}
	
		return simpleElement329;
	}
	
	private RtSimpleElement simpleElement479;
	
	private RtSimpleElement simpleElement479() {
		if (simpleElement479 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Functional Identifier Code";
			h.minLength = 2;
			h.maxLength = 2;
			
			h.addAllowedValue("AA");
			h.addAllowedValue("AB");
			h.addAllowedValue("AD");
			h.addAllowedValue("AF");
			h.addAllowedValue("AG");
			h.addAllowedValue("AH");
			h.addAllowedValue("AI");
			h.addAllowedValue("AK");
			h.addAllowedValue("AL");
			h.addAllowedValue("AN");
			h.addAllowedValue("AO");
			h.addAllowedValue("AR");
			h.addAllowedValue("AS");
			h.addAllowedValue("AT");
			h.addAllowedValue("AW");
			h.addAllowedValue("BC");
			h.addAllowedValue("BE");
			h.addAllowedValue("BF");
			h.addAllowedValue("BL");
			h.addAllowedValue("BS");
			h.addAllowedValue("CA");
			h.addAllowedValue("CB");
			h.addAllowedValue("CC");
			h.addAllowedValue("CD");
			h.addAllowedValue("CE");
			h.addAllowedValue("CF");
			h.addAllowedValue("CG");
			h.addAllowedValue("CH");
			h.addAllowedValue("CI");
			h.addAllowedValue("CJ");
			h.addAllowedValue("CK");
			h.addAllowedValue("CM");
			h.addAllowedValue("CN");
			h.addAllowedValue("CO");
			h.addAllowedValue("CP");
			h.addAllowedValue("CR");
			h.addAllowedValue("CS");
			h.addAllowedValue("CT");
			h.addAllowedValue("CV");
			h.addAllowedValue("DA");
			h.addAllowedValue("DD");
			h.addAllowedValue("DF");
			h.addAllowedValue("DI");
			h.addAllowedValue("DM");
			h.addAllowedValue("DS");
			h.addAllowedValue("DX");
			h.addAllowedValue("D3");
			h.addAllowedValue("D4");
			h.addAllowedValue("D5");
			h.addAllowedValue("EC");
			h.addAllowedValue("ED");
			h.addAllowedValue("EI");
			h.addAllowedValue("ER");
			h.addAllowedValue("ES");
			h.addAllowedValue("EV");
			h.addAllowedValue("EX");
			h.addAllowedValue("FA");
			h.addAllowedValue("FB");
			h.addAllowedValue("FC");
			h.addAllowedValue("FG");
			h.addAllowedValue("FH");
			h.addAllowedValue("FR");
			h.addAllowedValue("FT");
			h.addAllowedValue("GB");
			h.addAllowedValue("GC");
			h.addAllowedValue("GE");
			h.addAllowedValue("GF");
			h.addAllowedValue("GL");
			h.addAllowedValue("GP");
			h.addAllowedValue("GR");
			h.addAllowedValue("GT");
			h.addAllowedValue("HB");
			h.addAllowedValue("HC");
			h.addAllowedValue("HI");
			h.addAllowedValue("HN");
			h.addAllowedValue("HP");
			h.addAllowedValue("HR");
			h.addAllowedValue("HS");
			h.addAllowedValue("IA");
			h.addAllowedValue("IB");
			h.addAllowedValue("IC");
			h.addAllowedValue("ID");
			h.addAllowedValue("IE");
			h.addAllowedValue("IG");
			h.addAllowedValue("II");
			h.addAllowedValue("IJ");
			h.addAllowedValue("IM");
			h.addAllowedValue("IN");
			h.addAllowedValue("IO");
			h.addAllowedValue("IP");
			h.addAllowedValue("IR");
			h.addAllowedValue("IS");
			h.addAllowedValue("KM");
			h.addAllowedValue("LA");
			h.addAllowedValue("LB");
			h.addAllowedValue("LI");
			h.addAllowedValue("LN");
			h.addAllowedValue("LR");
			h.addAllowedValue("LS");
			h.addAllowedValue("LT");
			h.addAllowedValue("MA");
			h.addAllowedValue("MC");
			h.addAllowedValue("MD");
			h.addAllowedValue("ME");
			h.addAllowedValue("MF");
			h.addAllowedValue("MG");
			h.addAllowedValue("MH");
			h.addAllowedValue("MI");
			h.addAllowedValue("MJ");
			h.addAllowedValue("MK");
			h.addAllowedValue("MM");
			h.addAllowedValue("MN");
			h.addAllowedValue("MO");
			h.addAllowedValue("MP");
			h.addAllowedValue("MQ");
			h.addAllowedValue("MR");
			h.addAllowedValue("MS");
			h.addAllowedValue("MT");
			h.addAllowedValue("MV");
			h.addAllowedValue("MW");
			h.addAllowedValue("MX");
			h.addAllowedValue("MY");
			h.addAllowedValue("NC");
			h.addAllowedValue("NL");
			h.addAllowedValue("NP");
			h.addAllowedValue("NT");
			h.addAllowedValue("OC");
			h.addAllowedValue("OG");
			h.addAllowedValue("OR");
			h.addAllowedValue("OW");
			h.addAllowedValue("PA");
			h.addAllowedValue("PB");
			h.addAllowedValue("PC");
			h.addAllowedValue("PD");
			h.addAllowedValue("PE");
			h.addAllowedValue("PF");
			h.addAllowedValue("PG");
			h.addAllowedValue("PH");
			h.addAllowedValue("PI");
			h.addAllowedValue("PJ");
			h.addAllowedValue("PK");
			h.addAllowedValue("PL");
			h.addAllowedValue("PN");
			h.addAllowedValue("PO");
			h.addAllowedValue("PQ");
			h.addAllowedValue("PR");
			h.addAllowedValue("PS");
			h.addAllowedValue("PT");
			h.addAllowedValue("PU");
			h.addAllowedValue("PV");
			h.addAllowedValue("PY");
			h.addAllowedValue("QG");
			h.addAllowedValue("QM");
			h.addAllowedValue("QO");
			h.addAllowedValue("RA");
			h.addAllowedValue("RB");
			h.addAllowedValue("RC");
			h.addAllowedValue("RD");
			h.addAllowedValue("RE");
			h.addAllowedValue("RH");
			h.addAllowedValue("RI");
			h.addAllowedValue("RJ");
			h.addAllowedValue("RK");
			h.addAllowedValue("RL");
			h.addAllowedValue("RM");
			h.addAllowedValue("RN");
			h.addAllowedValue("RO");
			h.addAllowedValue("RP");
			h.addAllowedValue("RQ");
			h.addAllowedValue("RR");
			h.addAllowedValue("RS");
			h.addAllowedValue("RT");
			h.addAllowedValue("RU");
			h.addAllowedValue("RV");
			h.addAllowedValue("RW");
			h.addAllowedValue("RX");
			h.addAllowedValue("RY");
			h.addAllowedValue("RZ");
			h.addAllowedValue("SA");
			h.addAllowedValue("SB");
			h.addAllowedValue("SC");
			h.addAllowedValue("SD");
			h.addAllowedValue("SE");
			h.addAllowedValue("SG");
			h.addAllowedValue("SH");
			h.addAllowedValue("SI");
			h.addAllowedValue("SJ");
			h.addAllowedValue("SL");
			h.addAllowedValue("SM");
			h.addAllowedValue("SN");
			h.addAllowedValue("SO");
			h.addAllowedValue("SP");
			h.addAllowedValue("SQ");
			h.addAllowedValue("SR");
			h.addAllowedValue("SS");
			h.addAllowedValue("ST");
			h.addAllowedValue("SU");
			h.addAllowedValue("SV");
			h.addAllowedValue("SW");
			h.addAllowedValue("TA");
			h.addAllowedValue("TC");
			h.addAllowedValue("TD");
			h.addAllowedValue("TF");
			h.addAllowedValue("TI");
			h.addAllowedValue("TM");
			h.addAllowedValue("TN");
			h.addAllowedValue("TO");
			h.addAllowedValue("TP");
			h.addAllowedValue("TR");
			h.addAllowedValue("TS");
			h.addAllowedValue("TT");
			h.addAllowedValue("TX");
			h.addAllowedValue("UA");
			h.addAllowedValue("UB");
			h.addAllowedValue("UC");
			h.addAllowedValue("UD");
			h.addAllowedValue("UI");
			h.addAllowedValue("UP");
			h.addAllowedValue("UW");
			h.addAllowedValue("VA");
			h.addAllowedValue("VB");
			h.addAllowedValue("VC");
			h.addAllowedValue("VD");
			h.addAllowedValue("VE");
			h.addAllowedValue("VH");
			h.addAllowedValue("VI");
			h.addAllowedValue("VS");
			h.addAllowedValue("WA");
			h.addAllowedValue("WB");
			h.addAllowedValue("WG");
			h.addAllowedValue("WI");
			h.addAllowedValue("WL");
			h.addAllowedValue("WR");
			h.addAllowedValue("WT");
			simpleElement479 = new RtSimpleElement("479", "ID", h);
		}
	
		return simpleElement479;
	}
	
	private RtSimpleElement simpleElement28;
	
	private RtSimpleElement simpleElement28() {
		if (simpleElement28 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Group Control Number";
			h.minLength = 1;
			h.maxLength = 9;
			
			simpleElement28 = new RtSimpleElement("28", "N0", h);
		}
	
		return simpleElement28;
	}
	
	private RtSimpleElement simpleElement721;
	
	private RtSimpleElement simpleElement721() {
		if (simpleElement721 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Segment ID Code";
			h.minLength = 2;
			h.maxLength = 3;
			
			simpleElement721 = new RtSimpleElement("721", "ID", h);
		}
	
		return simpleElement721;
	}
	
	private RtSimpleElement simpleElement719;
	
	private RtSimpleElement simpleElement719() {
		if (simpleElement719 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Segment Position in Transaction Set";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement719 = new RtSimpleElement("719", "N0", h);
		}
	
		return simpleElement719;
	}
	
	private RtSimpleElement simpleElement447;
	
	private RtSimpleElement simpleElement447() {
		if (simpleElement447 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Loop Identifier Code";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement447 = new RtSimpleElement("447", "AN", h);
		}
	
		return simpleElement447;
	}
	
	private RtSimpleElement simpleElement720;
	
	private RtSimpleElement simpleElement720() {
		if (simpleElement720 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Segment Syntax Error Code";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("1");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			simpleElement720 = new RtSimpleElement("720", "ID", h);
		}
	
		return simpleElement720;
	}
	
	private RtSimpleElement simpleElement722;
	
	private RtSimpleElement simpleElement722() {
		if (simpleElement722 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Element Position in Segment";
			h.minLength = 1;
			h.maxLength = 2;
			
			simpleElement722 = new RtSimpleElement("722", "N0", h);
		}
	
		return simpleElement722;
	}
	
	private RtSimpleElement simpleElement1528;
	
	private RtSimpleElement simpleElement1528() {
		if (simpleElement1528 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Component Data Element Position in Composite";
			h.minLength = 1;
			h.maxLength = 2;
			
			simpleElement1528 = new RtSimpleElement("1528", "N0", h);
		}
	
		return simpleElement1528;
	}
	
	private RtSimpleElement simpleElement725;
	
	private RtSimpleElement simpleElement725() {
		if (simpleElement725 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Data Element Reference Number";
			h.minLength = 1;
			h.maxLength = 4;
			
			simpleElement725 = new RtSimpleElement("725", "N0", h);
		}
	
		return simpleElement725;
	}
	
	private RtSimpleElement simpleElement723;
	
	private RtSimpleElement simpleElement723() {
		if (simpleElement723 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Data Element Syntax Error Code";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("2");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			h.addAllowedValue("9");
			simpleElement723 = new RtSimpleElement("723", "ID", h);
		}
	
		return simpleElement723;
	}
	
	private RtSimpleElement simpleElement724;
	
	private RtSimpleElement simpleElement724() {
		if (simpleElement724 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Copy of Bad Data Element";
			h.minLength = 1;
			h.maxLength = 99;
			
			simpleElement724 = new RtSimpleElement("724", "AN", h);
		}
	
		return simpleElement724;
	}
	
	private RtSimpleElement simpleElement717;
	
	private RtSimpleElement simpleElement717() {
		if (simpleElement717 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Set Acknowledgment Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("E");
			h.addAllowedValue("M");
			h.addAllowedValue("R");
			h.addAllowedValue("W");
			h.addAllowedValue("X");
			simpleElement717 = new RtSimpleElement("717", "ID", h);
		}
	
		return simpleElement717;
	}
	
	private RtSimpleElement simpleElement718;
	
	private RtSimpleElement simpleElement718() {
		if (simpleElement718 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Transaction Set Syntax Error Code";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("27");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			h.addAllowedValue("7");
			h.addAllowedValue("8");
			h.addAllowedValue("9");
			simpleElement718 = new RtSimpleElement("718", "ID", h);
		}
	
		return simpleElement718;
	}
	
	private RtSimpleElement simpleElement715;
	
	private RtSimpleElement simpleElement715() {
		if (simpleElement715 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Functional Group Acknowledge Code";
			h.minLength = 1;
			h.maxLength = 1;
			
			h.addAllowedValue("A");
			h.addAllowedValue("E");
			h.addAllowedValue("M");
			h.addAllowedValue("P");
			h.addAllowedValue("R");
			h.addAllowedValue("W");
			h.addAllowedValue("X");
			simpleElement715 = new RtSimpleElement("715", "ID", h);
		}
	
		return simpleElement715;
	}
	
	private RtSimpleElement simpleElement97;
	
	private RtSimpleElement simpleElement97() {
		if (simpleElement97 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number of Transaction Sets Included";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement97 = new RtSimpleElement("97", "N0", h);
		}
	
		return simpleElement97;
	}
	
	private RtSimpleElement simpleElement123;
	
	private RtSimpleElement simpleElement123() {
		if (simpleElement123 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number of Received Transaction Sets";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement123 = new RtSimpleElement("123", "N0", h);
		}
	
		return simpleElement123;
	}
	
	private RtSimpleElement simpleElement2;
	
	private RtSimpleElement simpleElement2() {
		if (simpleElement2 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number of Accepted Transaction Sets";
			h.minLength = 1;
			h.maxLength = 6;
			
			simpleElement2 = new RtSimpleElement("2", "N0", h);
		}
	
		return simpleElement2;
	}
	
	private RtSimpleElement simpleElement716;
	
	private RtSimpleElement simpleElement716() {
		if (simpleElement716 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Functional Group Syntax Error Code";
			h.minLength = 1;
			h.maxLength = 3;
			
			h.addAllowedValue("1");
			h.addAllowedValue("10");
			h.addAllowedValue("11");
			h.addAllowedValue("12");
			h.addAllowedValue("13");
			h.addAllowedValue("14");
			h.addAllowedValue("15");
			h.addAllowedValue("16");
			h.addAllowedValue("17");
			h.addAllowedValue("18");
			h.addAllowedValue("19");
			h.addAllowedValue("2");
			h.addAllowedValue("20");
			h.addAllowedValue("21");
			h.addAllowedValue("22");
			h.addAllowedValue("23");
			h.addAllowedValue("24");
			h.addAllowedValue("25");
			h.addAllowedValue("26");
			h.addAllowedValue("3");
			h.addAllowedValue("4");
			h.addAllowedValue("5");
			h.addAllowedValue("6");
			simpleElement716 = new RtSimpleElement("716", "ID", h);
		}
	
		return simpleElement716;
	}
	
	private RtSimpleElement simpleElement96;
	
	private RtSimpleElement simpleElement96() {
		if (simpleElement96 == null) {
			SimpleElementHelper h = new SimpleElementHelper();
			h.name = "Number of Included Segments";
			h.minLength = 1;
			h.maxLength = 10;
			
			simpleElement96 = new RtSimpleElement("96", "N0", h);
		}
	
		return simpleElement96;
	}
}
