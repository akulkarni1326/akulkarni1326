/**
 * @generated
 */
package com.xref.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.extol.ebi.reactor.database.lib.schema.*;

@SuppressWarnings("all")
public class xrefSchemaDB_Rt implements RuntimeDatabaseSchemaProvider {

	private RtDatabaseSchema schema_xrefSchemaDB;

	public RtDatabaseSchema getSchema() {
		if (schema_xrefSchemaDB == null) {
			List<RtTableObjectRef> refs = new ArrayList<>();
			refs.add(new RtTableObjectRef("_ItemNumbers", true, to_ItemNumbers(), false));

			Map<String,RtTableObject> definedTables = new HashMap<>();
			definedTables.put("ItemNumbers", to_ItemNumbers());

			schema_xrefSchemaDB = new RtDatabaseSchema("xrefSchemaDB", refs, definedTables);
		}

		return schema_xrefSchemaDB;
	}

	private RtTableObject to_ItemNumbers;
	
	private RtTableObject to_ItemNumbers() {
		if (to_ItemNumbers == null) {
			List<RtColumn> columns = new ArrayList<>();
			{
				ColumnHelper ch = new ColumnHelper();
				ch.defaultValueLiteral = "nextval(\'\"REFTABLES\".\"ItemNumbers_cicSerialId_seq\"\'::regclass)";
				ch.size = 10;
				columns.add(new RtColumn("cicSerialId", RtColumnTypes.INTEGER, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("refqual", RtColumnTypes.VARCHAR, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("refvalue", RtColumnTypes.VARCHAR, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("ponumber", RtColumnTypes.VARCHAR, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("qual", RtColumnTypes.VARCHAR, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("itemnumber", RtColumnTypes.VARCHAR, ch));
			}
	
			List<RtTableObjectRef> refs = new ArrayList<>();
	
			to_ItemNumbers = new RtTableObject("ItemNumbers", columns, refs, false);
		}
	
		return to_ItemNumbers;
	}
}
