package com.cleo.cic.cockpit.core;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class GetFailureProcessLogsBPS implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode ErrorLog;
    
    @TupleIndex(value = 1)
    public com.extol.ebi.bps.lang.String FailedProcessNumber;
    
    @TupleIndex(value = 2)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public GetFailureProcessLogsBPS.ResultTuple execute(final StorageNode ErrorLog, final com.extol.ebi.bps.lang.String FailedProcessNumber) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode ErrorLog;
      
      @TupleIndex(value = 1)
      public com.extol.ebi.ruleset.lang.core.String FailedProcessNumber;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public GetFailureProcessLogsBPS.RulesetAction.ResultTuple execute(final StorageNode ErrorLog, final com.extol.ebi.ruleset.lang.core.String FailedProcessNumber) {
      Object[] _bps_parameters = new Object[2];
      _bps_parameters[0] = ErrorLog;
      _bps_parameters[1] = toBpsString(FailedProcessNumber);
      
      boolean _exit_PassStatus = launchScript("com.cleo.cic.cockpit.core", "com.cleo.cic.cockpit.core.GetFailureProcessLogsBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.ErrorLog = asStorageNode(_bps_parameters[0]);
      resultTuple.FailedProcessNumber = asString(_bps_parameters[1]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
  
  public static class ProcessLogParser implements BpsCallable {
    public boolean execute(final StorageNode ErrorLog, final com.extol.ebi.bps.lang.String processLogContent) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
  }
}
