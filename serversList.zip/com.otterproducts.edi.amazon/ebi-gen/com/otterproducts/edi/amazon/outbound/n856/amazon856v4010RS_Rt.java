/**
* @generated
*/
package com.otterproducts.edi.amazon.outbound.n856;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class amazon856v4010RS_Rt extends AbstractReactor<RtPojoSchema,RtEdiDerivedMessageSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.Number v_TD102;
	private com.extol.ebi.ruleset.lang.core.Number v_Sum_TD102;
	private com.extol.ebi.ruleset.lang.core.Number v_TD107;
	private com.extol.ebi.ruleset.lang.core.Number v_Sum_TD107;
	
	public SchemaProvider<RtPojoSchema> getSourceSchema() {
		return new com.otterproducts.core.system.n856.Shipment_OBJ_Rt();
	}
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getTargetSchema() {
		return new com.otterproducts.core.edi.schemas.n856v4010EDI_Rt();
	}
	
	public Connector getSourceConnector() {
		return new XMLObjectConnector();
	}

	public Connector getTargetConnector() {
		return new X12Connector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "initNew target.Area1.BSN", new Block() { public void body() {
		
			final TargetNode t0_Area1 = target.getLast(at("Area1"));
			final TargetNode t1_BSN = t0_Area1.getLast(at("BSN"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(source.envelope.Body.X12856.BSN.e01_0353) => #[target.Area1.BSN.BSN353]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12856").get("BSN").get("e01_0353");
				final SourceNode result = action.execute(var0);
				t1_BSN.set(at("BSN353"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(source.envelope.Body.X12856.BSN.e02_0396) => #[target.Area1.BSN.BSN396]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12856").get("BSN").get("e02_0396");
				final SourceNode result = action.execute(var0);
				t1_BSN.set(at("BSN396"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(source.envelope.Body.X12856.BSN.e03_0373) => #[target.Area1.BSN.BSN373]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12856").get("BSN").get("e03_0373");
				final SourceNode result = action.execute(var0);
				t1_BSN.set(at("BSN373"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(5, "new Move().execute(source.envelope.Body.X12856.BSN.e04_0337) => #[target.Area1.BSN.BSN337]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12856").get("BSN").get("e04_0337");
				final SourceNode result = action.execute(var0);
				t1_BSN.set(at("BSN337"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(6, "new Move().execute(source.envelope.Body.X12856.BSN.e05_1005) => #[target.Area1.BSN.BSN1005]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12856").get("BSN").get("e05_1005");
				final SourceNode result = action.execute(var0);
				t1_BSN.set(at("BSN1005"), result);
			}
		}}).run();
		createCompositeRule(7, "for source.envelope.Body.X12856.LOOP_HL_g001 initNew target.Area2.sgHL", new Block() { public void body() {
			final SourceNode s0_envelope = source.get("envelope");
			if (exists(s0_envelope)) {
			final SourceNode s1_Body = s0_envelope.get("Body");
			if (exists(s1_Body)) {
			final SourceNode s2_X12856 = s1_Body.get("X12856");
			if (exists(s2_X12856)) {
			for (final SourceNode s3_cur_LOOP_HL_g001 : s2_X12856.getIterable("LOOP_HL_g001")) {
		
			final TargetNode t0_Area2 = target.getLast(at("Area2"));
			final TargetNode t1_cur_sgHL = t0_Area2.create(at("sgHL"));
		
			createCompositeRule(8, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(8, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735, \"S\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_LOOP_HL_g001.get("HL").get("e03_0735"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("S");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(9, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e01_0628) => #[target.Area2.sgHL.current.HL.HL628]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e01_0628");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL628"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(10, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735) => #[target.Area2.sgHL.current.HL.HL735]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e03_0735");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL735"), result);
				}
				createCompositeRule(11, "for source.envelope.Body.X12856.LOOP_HL_g001.current.TD1", new Block() { public void body() {
					for (final SourceNode s4_cur_TD1 : s3_cur_LOOP_HL_g001.getIterable("TD1")) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(12, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.TD1.current.e01_0103) => #[target.Area2.sgHL.current.TD1.current.TD1103]", action);
						final SourceNode var0 = s4_cur_TD1.get("e01_0103");
						final SourceNode result = action.execute(var0);
						t1_cur_sgHL.set(at("TD1", "TD1103"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(13, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.TD1.current.e02_0080) => #[this.v_TD102]", action);
						final SourceNode var0 = s4_cur_TD1.get("e02_0080");
						final SourceNode result = action.execute(var0);
						amazon856v4010RS_Rt.this.v_TD102 = extractNumber(result);
					}
					{
						com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
						createSimpleRule(14, "new Add().execute(this.v_TD102, this.v_Sum_TD102, null) => #[this.v_Sum_TD102]", action);
						final com.extol.ebi.ruleset.lang.core.Number var0 = amazon856v4010RS_Rt.this.v_TD102;
						final com.extol.ebi.ruleset.lang.core.Number var1 = amazon856v4010RS_Rt.this.v_Sum_TD102;
						final com.extol.ebi.ruleset.lang.core.Number var2 = null;
						final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
						amazon856v4010RS_Rt.this.v_Sum_TD102 = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(15, "new Move().execute(this.v_Sum_TD102) => #[target.Area2.sgHL.current.TD1.current.TD180]", action);
						final SourceNode var0 = toValueNode(amazon856v4010RS_Rt.this.v_Sum_TD102);
						final SourceNode result = action.execute(var0);
						t1_cur_sgHL.set(at("TD1", "TD180"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(16, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.TD1.current.e06_0187) => #[target.Area2.sgHL.current.TD1.current.TD1187]", action);
						final SourceNode var0 = s4_cur_TD1.get("e06_0187");
						final SourceNode result = action.execute(var0);
						t1_cur_sgHL.set(at("TD1", "TD1187"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(17, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.TD1.current.e07_0081) => #[this.v_TD107]", action);
						final SourceNode var0 = s4_cur_TD1.get("e07_0081");
						final SourceNode result = action.execute(var0);
						amazon856v4010RS_Rt.this.v_TD107 = extractNumber(result);
					}
					{
						com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
						createSimpleRule(18, "new Add().execute(this.v_TD107, this.v_Sum_TD107, null) => #[this.v_Sum_TD107]", action);
						final com.extol.ebi.ruleset.lang.core.Number var0 = amazon856v4010RS_Rt.this.v_TD107;
						final com.extol.ebi.ruleset.lang.core.Number var1 = amazon856v4010RS_Rt.this.v_Sum_TD107;
						final com.extol.ebi.ruleset.lang.core.Number var2 = null;
						final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
						amazon856v4010RS_Rt.this.v_Sum_TD107 = result;
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(19, "new Move().execute(this.v_Sum_TD107) => #[target.Area2.sgHL.current.TD1.current.TD181]", action);
						final SourceNode var0 = toValueNode(amazon856v4010RS_Rt.this.v_Sum_TD107);
						final SourceNode result = action.execute(var0);
						t1_cur_sgHL.set(at("TD1", "TD181"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(20, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.TD1.current.e08_0355) => #[target.Area2.sgHL.current.TD1.current.TD1355]", action);
						final SourceNode var0 = s4_cur_TD1.get("e08_0355");
						final SourceNode result = action.execute(var0);
						t1_cur_sgHL.set(at("TD1", "TD1355"), result);
					}
				}}}).run();
				createCompositeRule(21, "initNew target.Area2.sgHL.current.TD5", new Block() { public void body() {
				
					final TargetNode t2_cur_TD5 = t1_cur_sgHL.create(at("TD5"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(22, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.TD5.e02_0066) => #[target.Area2.sgHL.current.TD5.current.TD566]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("TD5").get("e02_0066");
						final SourceNode result = action.execute(var0);
						t2_cur_TD5.set(at("TD566"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(23, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.TD5.e03_0067) => #[target.Area2.sgHL.current.TD5.current.TD567]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("TD5").get("e03_0067");
						final SourceNode result = action.execute(var0);
						t2_cur_TD5.set(at("TD567"), result);
					}
				}}).run();
				createCompositeRule(24, "for source.envelope.Body.X12856.LOOP_HL_g001.current.REF initNew target.Area2.sgHL.current.REF", new Block() { public void body() {
					for (final SourceNode s4_cur_REF : s3_cur_LOOP_HL_g001.getIterable("REF")) {
				
					final TargetNode t2_cur_REF = t1_cur_sgHL.create(at("REF"));
				
					createCompositeRule(25, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(25, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e01_0128, \"BM\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s4_cur_REF.get("e01_0128"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("BM");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(26, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e01_0128) => #[target.Area2.sgHL.current.REF.current.REF128]", action);
							final SourceNode var0 = s4_cur_REF.get("e01_0128");
							final SourceNode result = action.execute(var0);
							t2_cur_REF.set(at("REF128"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(27, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e02_0127) => #[target.Area2.sgHL.current.REF.current.REF127]", action);
							final SourceNode var0 = s4_cur_REF.get("e02_0127");
							final SourceNode result = action.execute(var0);
							t2_cur_REF.set(at("REF127"), result);
						}
					}}).run();
					createCompositeRule(28, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(28, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e01_0128, \"CN\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s4_cur_REF.get("e01_0128"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("CN");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(29, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e01_0128) => #[target.Area2.sgHL.current.REF.current.REF128]", action);
							final SourceNode var0 = s4_cur_REF.get("e01_0128");
							final SourceNode result = action.execute(var0);
							t2_cur_REF.set(at("REF128"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(30, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e02_0127) => #[target.Area2.sgHL.current.REF.current.REF127]", action);
							final SourceNode var0 = s4_cur_REF.get("e02_0127");
							final SourceNode result = action.execute(var0);
							t2_cur_REF.set(at("REF127"), result);
						}
					}}).run();
					createCompositeRule(31, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(31, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e01_0128, \"BX\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s4_cur_REF.get("e01_0128"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("BX");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(32, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e01_0128) => #[target.Area2.sgHL.current.REF.current.REF128]", action);
							final SourceNode var0 = s4_cur_REF.get("e01_0128");
							final SourceNode result = action.execute(var0);
							t2_cur_REF.set(at("REF128"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(33, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e02_0127) => #[target.Area2.sgHL.current.REF.current.REF127]", action);
							final SourceNode var0 = s4_cur_REF.get("e02_0127");
							final SourceNode result = action.execute(var0);
							t2_cur_REF.set(at("REF127"), result);
						}
					}}).run();
				}}}).run();
				createCompositeRule(34, "for source.envelope.Body.X12856.LOOP_HL_g001.current.DTM initNew target.Area2.sgHL.current.DTM", new Block() { public void body() {
					for (final SourceNode s4_cur_DTM : s3_cur_LOOP_HL_g001.getIterable("DTM")) {
				
					final TargetNode t2_cur_DTM = t1_cur_sgHL.create(at("DTM"));
				
					createCompositeRule(35, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(35, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.DTM.current.e01_0374, \"011\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s4_cur_DTM.get("e01_0374"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("011");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(36, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.DTM.current.e01_0374) => #[target.Area2.sgHL.current.DTM.current.DTM374]", action);
							final SourceNode var0 = s4_cur_DTM.get("e01_0374");
							final SourceNode result = action.execute(var0);
							t2_cur_DTM.set(at("DTM374"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(37, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.DTM.current.e02_0373) => #[target.Area2.sgHL.current.DTM.current.DTM373]", action);
							final SourceNode var0 = s4_cur_DTM.get("e02_0373");
							final SourceNode result = action.execute(var0);
							t2_cur_DTM.set(at("DTM373"), result);
						}
					}}).run();
					createCompositeRule(38, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(38, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.DTM.current.e01_0374, \"017\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s4_cur_DTM.get("e01_0374"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("017");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(39, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.DTM.current.e01_0374) => #[target.Area2.sgHL.current.DTM.current.DTM374]", action);
							final SourceNode var0 = s4_cur_DTM.get("e01_0374");
							final SourceNode result = action.execute(var0);
							t2_cur_DTM.set(at("DTM374"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(40, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.DTM.current.e02_0373) => #[target.Area2.sgHL.current.DTM.current.DTM373]", action);
							final SourceNode var0 = s4_cur_DTM.get("e02_0373");
							final SourceNode result = action.execute(var0);
							t2_cur_DTM.set(at("DTM373"), result);
						}
					}}).run();
				}}}).run();
				createCompositeRule(41, "initNew target.Area2.sgHL.current.FOB", new Block() { public void body() {
				
					final TargetNode t2_FOB = t1_cur_sgHL.getLast(at("FOB"));
				
					createCompositeRule(42, "for source.envelope.Body.X12856.LOOP_HL_g001.current.FOB.e05_0335", new Block() { public void body() {
						final SourceNode s4_FOB = s3_cur_LOOP_HL_g001.get("FOB");
						if (exists(s4_FOB)) {
						final SourceNode s5_e05_0335 = s4_FOB.get("e05_0335");
						if (exists(s5_e05_0335)) {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(43, "new Move().execute(\"CC\") => #[target.Area2.sgHL.current.FOB.FOB146]", action);
							final SourceNode var0 = toValueNode(asString("CC"));
							final SourceNode result = action.execute(var0);
							t2_FOB.set(at("FOB146"), result);
						}
					}}}}).run();
				}}).run();
				createCompositeRule(44, "for source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005 initNew target.Area2.sgHL.current.sgN1", new Block() { public void body() {
					for (final SourceNode s4_cur_LOOP_N1_g005 : s3_cur_LOOP_HL_g001.getIterable("LOOP_N1_g005")) {
				
					final TargetNode t2_cur_sgN1 = t1_cur_sgHL.create(at("sgN1"));
				
					createCompositeRule(45, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(45, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e01_0098, \"SF\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s4_cur_LOOP_N1_g005.get("N1").get("e01_0098"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("SF");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(46, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e01_0098) => #[target.Area2.sgHL.current.sgN1.current.N1.N198]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N1").get("e01_0098");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N198"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(47, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e02_0093) => #[target.Area2.sgHL.current.sgN1.current.N1.N193]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N1").get("e02_0093");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N193"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(48, "new Move().execute(\"ZZ\") => #[target.Area2.sgHL.current.sgN1.current.N1.N166]", action);
							final SourceNode var0 = toValueNode(asString("ZZ"));
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N166"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(49, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e04_0067) => #[target.Area2.sgHL.current.sgN1.current.N1.N167]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N1").get("e04_0067");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N167"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(50, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e01_0019) => #[target.Area2.sgHL.current.sgN1.current.N4.N419]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e01_0019");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N419"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(51, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e02_0156) => #[target.Area2.sgHL.current.sgN1.current.N4.N4156]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e02_0156");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N4156"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(52, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e03_0116) => #[target.Area2.sgHL.current.sgN1.current.N4.N4116]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e03_0116");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N4116"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(53, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e04_0026) => #[target.Area2.sgHL.current.sgN1.current.N4.N426]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e04_0026");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N426"), result);
						}
					}}).run();
					createCompositeRule(54, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(54, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e01_0098, \"ST\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s4_cur_LOOP_N1_g005.get("N1").get("e01_0098"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("ST");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(55, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e01_0098) => #[target.Area2.sgHL.current.sgN1.current.N1.N198]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N1").get("e01_0098");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N198"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(56, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e02_0093) => #[target.Area2.sgHL.current.sgN1.current.N1.N193]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N1").get("e02_0093");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N193"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(57, "new Move().execute(\"92\") => #[target.Area2.sgHL.current.sgN1.current.N1.N166]", action);
							final SourceNode var0 = toValueNode(asString("92"));
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N166"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(58, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N1.e04_0067) => #[target.Area2.sgHL.current.sgN1.current.N1.N167]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N1").get("e04_0067");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N1", "N167"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(59, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e01_0019) => #[target.Area2.sgHL.current.sgN1.current.N4.N419]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e01_0019");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N419"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(60, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e02_0156) => #[target.Area2.sgHL.current.sgN1.current.N4.N4156]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e02_0156");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N4156"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(61, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e03_0116) => #[target.Area2.sgHL.current.sgN1.current.N4.N4116]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e03_0116");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N4116"), result);
						}
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(62, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LOOP_N1_g005.current.N4.e04_0026) => #[target.Area2.sgHL.current.sgN1.current.N4.N426]", action);
							final SourceNode var0 = s4_cur_LOOP_N1_g005.get("N4").get("e04_0026");
							final SourceNode result = action.execute(var0);
							t2_cur_sgN1.set(at("N4", "N426"), result);
						}
					}}).run();
				}}}).run();
			}}).run();
			createCompositeRule(63, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(63, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735, \"O\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_LOOP_HL_g001.get("HL").get("e03_0735"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("O");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(64, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e01_0628) => #[target.Area2.sgHL.current.HL.HL628]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e01_0628");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL628"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(65, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e02_0734) => #[target.Area2.sgHL.current.HL.HL734]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e02_0734");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL734"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(66, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735) => #[target.Area2.sgHL.current.HL.HL735]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e03_0735");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL735"), result);
				}
				createCompositeRule(67, "initNew target.Area2.sgHL.current.PRF", new Block() { public void body() {
				
					final TargetNode t2_PRF = t1_cur_sgHL.getLast(at("PRF"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(68, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.PRF.e01_0324) => #[target.Area2.sgHL.current.PRF.PRF324, this.env.User_Reference_1]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("PRF").get("e01_0324");
						final SourceNode result = action.execute(var0);
						t2_PRF.set(at("PRF324"), result);
						amazon856v4010RS_Rt.this.env.User_Reference_1 = extractString(result);
					}
				}}).run();
			}}).run();
			createCompositeRule(69, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(69, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735, \"P\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_LOOP_HL_g001.get("HL").get("e03_0735"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("P");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(70, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e01_0628) => #[target.Area2.sgHL.current.HL.HL628]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e01_0628");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL628"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(71, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e02_0734) => #[target.Area2.sgHL.current.HL.HL734]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e02_0734");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL734"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(72, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735) => #[target.Area2.sgHL.current.HL.HL735]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e03_0735");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL735"), result);
				}
				createCompositeRule(73, "initNew target.Area2.sgHL.current.REF", new Block() { public void body() {
				
					final TargetNode t2_cur_REF = t1_cur_sgHL.create(at("REF"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(74, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e01_0128) => #[target.Area2.sgHL.current.REF.current.REF128]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("REF").get("e01_0128");
						final SourceNode result = action.execute(var0);
						t2_cur_REF.set(at("REF128"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(75, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.REF.current.e02_0127) => #[target.Area2.sgHL.current.REF.current.REF127]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("REF").get("e02_0127");
						final SourceNode result = action.execute(var0);
						t2_cur_REF.set(at("REF127"), result);
					}
				}}).run();
				createCompositeRule(76, "initNew target.Area2.sgHL.current.MAN", new Block() { public void body() {
				
					final TargetNode t2_cur_MAN = t1_cur_sgHL.create(at("MAN"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(77, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.MAN.e01_0088) => #[target.Area2.sgHL.current.MAN.current.MAN88]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("MAN").get("e01_0088");
						final SourceNode result = action.execute(var0);
						t2_cur_MAN.set(at("MAN88"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(78, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.MAN.e02_0087) => #[target.Area2.sgHL.current.MAN.current.MAN87]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("MAN").get("e02_0087");
						final SourceNode result = action.execute(var0);
						t2_cur_MAN.set(at("MAN87"), result);
					}
				}}).run();
			}}).run();
			createCompositeRule(79, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(79, "new StringEquals().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735, \"I\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_LOOP_HL_g001.get("HL").get("e03_0735"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("I");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(80, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e01_0628) => #[target.Area2.sgHL.current.HL.HL628]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e01_0628");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL628"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(81, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e02_0734) => #[target.Area2.sgHL.current.HL.HL734]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e02_0734");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL734"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(82, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.HL.e03_0735) => #[target.Area2.sgHL.current.HL.HL735]", action);
					final SourceNode var0 = s3_cur_LOOP_HL_g001.get("HL").get("e03_0735");
					final SourceNode result = action.execute(var0);
					t1_cur_sgHL.set(at("HL", "HL735"), result);
				}
				createCompositeRule(83, "initNew target.Area2.sgHL.current.LIN", new Block() { public void body() {
				
					final TargetNode t2_LIN = t1_cur_sgHL.getLast(at("LIN"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(84, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LIN.e09_0234) => #[target.Area2.sgHL.current.LIN.LIN350]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("LIN").get("e09_0234");
						final SourceNode result = action.execute(var0);
						t2_LIN.set(at("LIN350"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(85, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LIN.e03_0234) => #[target.Area2.sgHL.current.LIN.LIN234]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("LIN").get("e03_0234");
						final SourceNode result = action.execute(var0);
						t2_LIN.set(at("LIN234"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(86, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LIN.e02_0235) => #[target.Area2.sgHL.current.LIN.LIN235]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("LIN").get("e02_0235");
						final SourceNode result = action.execute(var0);
						t2_LIN.set(at("LIN235"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(87, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LIN.e04_0235) => #[target.Area2.sgHL.current.LIN.LIN235_3]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("LIN").get("e04_0235");
						final SourceNode result = action.execute(var0);
						t2_LIN.set(at("LIN235_3"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(88, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.LIN.e05_0234) => #[target.Area2.sgHL.current.LIN.LIN234_3]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("LIN").get("e05_0234");
						final SourceNode result = action.execute(var0);
						t2_LIN.set(at("LIN234_3"), result);
					}
				}}).run();
				createCompositeRule(89, "initNew target.Area2.sgHL.current.SN1", new Block() { public void body() {
				
					final TargetNode t2_SN1 = t1_cur_sgHL.getLast(at("SN1"));
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(90, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.SN1.e02_0382) => #[target.Area2.sgHL.current.SN1.SN1382]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("SN1").get("e02_0382");
						final SourceNode result = action.execute(var0);
						t2_SN1.set(at("SN1382"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(91, "new Move().execute(source.envelope.Body.X12856.LOOP_HL_g001.current.SN1.e03_0355) => #[target.Area2.sgHL.current.SN1.SN1355]", action);
						final SourceNode var0 = s3_cur_LOOP_HL_g001.get("SN1").get("e03_0355");
						final SourceNode result = action.execute(var0);
						t2_SN1.set(at("SN1355"), result);
					}
				}}).run();
			}}).run();
		}}}}}}).run();
		createCompositeRule(92, "initNew target.Area3.CTT", new Block() { public void body() {
		
			final TargetNode t0_Area3 = target.getLast(at("Area3"));
			final TargetNode t1_CTT = t0_Area3.getLast(at("CTT"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(93, "new Move().execute(source.envelope.Body.X12856.CTT.e01_0354) => #[target.Area3.CTT.CTT354]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12856").get("CTT").get("e01_0354");
				final SourceNode result = action.execute(var0);
				t1_CTT.set(at("CTT354"), result);
			}
		}}).run();
	}

}
