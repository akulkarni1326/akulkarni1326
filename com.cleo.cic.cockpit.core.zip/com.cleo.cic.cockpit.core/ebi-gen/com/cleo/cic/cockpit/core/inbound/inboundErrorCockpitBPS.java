package com.cleo.cic.cockpit.core.inbound;

import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.bps.lib.types.BusinessProcess;
import com.extol.ebi.lang.bps.Bps;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class inboundErrorCockpitBPS implements Bps, BpsCallable, BusinessProcess {
  public static class ResultTuple implements Tuple {
    @TupleIndex(value = 0)
    public StorageNode sourceContext;
    
    @TupleIndex(value = 1)
    public StorageNode targetContext;
    
    @TupleIndex(value = 2)
    public com.extol.ebi.bps.lang.String partnerName;
    
    @TupleIndex(value = 3)
    public StorageNode sourceData;
    
    @TupleIndex(value = 4)
    public com.extol.ebi.bps.lang.Boolean _exit_PassStatus;
  }
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public inboundErrorCockpitBPS.ResultTuple execute(final StorageNode sourceContext, final StorageNode targetContext, final com.extol.ebi.bps.lang.String partnerName, final StorageNode sourceData) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public StorageNode sourceContext;
      
      @TupleIndex(value = 1)
      public StorageNode targetContext;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.String partnerName;
      
      @TupleIndex(value = 3)
      public StorageNode sourceData;
      
      @TupleIndex(value = 4)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public inboundErrorCockpitBPS.RulesetAction.ResultTuple execute(final StorageNode sourceContext, final StorageNode targetContext, final com.extol.ebi.ruleset.lang.core.String partnerName, final StorageNode sourceData) {
      Object[] _bps_parameters = new Object[4];
      _bps_parameters[0] = sourceContext;
      _bps_parameters[1] = targetContext;
      _bps_parameters[2] = toBpsString(partnerName);
      _bps_parameters[3] = sourceData;
      
      boolean _exit_PassStatus = launchScript("com.cleo.cic.cockpit.core", "com.cleo.cic.cockpit.core.inbound.inboundErrorCockpitBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.sourceContext = asStorageNode(_bps_parameters[0]);
      resultTuple.targetContext = asStorageNode(_bps_parameters[1]);
      resultTuple.partnerName = asString(_bps_parameters[2]);
      resultTuple.sourceData = asStorageNode(_bps_parameters[3]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
}
