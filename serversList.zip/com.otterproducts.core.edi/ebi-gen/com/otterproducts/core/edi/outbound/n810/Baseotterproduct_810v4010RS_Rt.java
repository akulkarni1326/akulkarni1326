/**
* @generated
*/
package com.otterproducts.core.edi.outbound.n810;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class Baseotterproduct_810v4010RS_Rt extends AbstractReactor<RtPojoSchema,RtEdiDerivedMessageSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.Number v_count;
	private com.extol.ebi.ruleset.lang.core.Number v_qty;
	private com.extol.ebi.ruleset.lang.core.Number v_Totalqty;
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	
	public SchemaProvider<RtPojoSchema> getSourceSchema() {
		return new com.otterproducts.core.system.n810.Invoice_810OBJ_Rt();
	}
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getTargetSchema() {
		return new com.otterproducts.core.edi.schemas.n810v4010EDI_Rt();
	}
	
	public Connector getSourceConnector() {
		return new XMLObjectConnector();
	}

	public Connector getTargetConnector() {
		return new X12Connector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "initNew target.Area1.BIG", new Block() { public void body() {
		
			final TargetNode t0_Area1 = target.getLast(at("Area1"));
			final TargetNode t1_BIG = t0_Area1.getLast(at("BIG"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(source.envelope.Body.X12810.BIG.e01_0373) => #[target.Area1.BIG.BIG373]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("BIG").get("e01_0373");
				final SourceNode result = action.execute(var0);
				t1_BIG.set(at("BIG373"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(source.envelope.Body.X12810.BIG.e02_0076) => #[target.Area1.BIG.BIG76]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("BIG").get("e02_0076");
				final SourceNode result = action.execute(var0);
				t1_BIG.set(at("BIG76"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(4, "new Move().execute(source.envelope.Body.X12810.BIG.e03_0373) => #[target.Area1.BIG.BIG373_3]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("BIG").get("e03_0373");
				final SourceNode result = action.execute(var0);
				t1_BIG.set(at("BIG373_3"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(5, "new Move().execute(source.envelope.Body.X12810.BIG.e04_0324) => #[target.Area1.BIG.BIG324]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("BIG").get("e04_0324");
				final SourceNode result = action.execute(var0);
				t1_BIG.set(at("BIG324"), result);
			}
		}}).run();
		createCompositeRule(6, "initNew target.Area1.CUR", new Block() { public void body() {
		
			final TargetNode t0_Area1 = target.getLast(at("Area1"));
			final TargetNode t1_CUR = t0_Area1.getLast(at("CUR"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(7, "new Move().execute(source.envelope.Body.X12810.CUR.e01_0098) => #[target.Area1.CUR.CUR98]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("CUR").get("e01_0098");
				final SourceNode result = action.execute(var0);
				t1_CUR.set(at("CUR98"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(8, "new Move().execute(source.envelope.Body.X12810.CUR.e02_0100) => #[target.Area1.CUR.CUR100]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("CUR").get("e02_0100");
				final SourceNode result = action.execute(var0);
				t1_CUR.set(at("CUR100"), result);
			}
		}}).run();
		createCompositeRule(9, "for source.envelope.Body.X12810.LOOP_N1_g001 initNew target.Area1.sgN1", new Block() { public void body() {
			final SourceNode s0_envelope = source.get("envelope");
			if (exists(s0_envelope)) {
			final SourceNode s1_Body = s0_envelope.get("Body");
			if (exists(s1_Body)) {
			final SourceNode s2_X12810 = s1_Body.get("X12810");
			if (exists(s2_X12810)) {
			for (final SourceNode s3_cur_LOOP_N1_g001 : s2_X12810.getIterable("LOOP_N1_g001")) {
		
			final TargetNode t0_Area1 = target.getLast(at("Area1"));
			final TargetNode t1_cur_sgN1 = t0_Area1.create(at("sgN1"));
		
			createCompositeRule(10, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(10, "new StringEquals().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N1.e01_0098, \"SU\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_LOOP_N1_g001.get("N1").get("e01_0098"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("SU");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(11, "new Move().execute(\"RI\") => #[target.Area1.sgN1.current.N1.N198]", action);
					final SourceNode var0 = toValueNode(asString("RI"));
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N1", "N198"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(12, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N1.e02_0093) => #[target.Area1.sgN1.current.N1.N193]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N1").get("e02_0093");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N1", "N193"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(13, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N3.e01_0166) => #[target.Area1.sgN1.current.N3.current.N3166]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N3").get("e01_0166");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N3", "N3166"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(14, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N3.e02_0166) => #[target.Area1.sgN1.current.N3.current.N3166_3]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N3").get("e02_0166");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N3", "N3166_3"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(15, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e01_0019) => #[target.Area1.sgN1.current.N4.N419]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e01_0019");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N419"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(16, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e02_0156) => #[target.Area1.sgN1.current.N4.N4156]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e02_0156");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N4156"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(17, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e03_0116) => #[target.Area1.sgN1.current.N4.N4116]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e03_0116");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N4116"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(18, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e04_0026) => #[target.Area1.sgN1.current.N4.N426]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e04_0026");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N426"), result);
				}
			}}).run();
			createCompositeRule(19, "", new ConditionedBlock() {
			public boolean condition() {
				com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
				createRuleCondition(19, "new StringEquals().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N1.e01_0098, \"ST\") => #[]", condition);
				final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_LOOP_N1_g001.get("N1").get("e01_0098"));
				final com.extol.ebi.ruleset.lang.core.String var1 = asString("ST");
				final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
				
				return result.asJavaBoolean().booleanValue();
			}
			public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(20, "new Move().execute(\"ST\") => #[target.Area1.sgN1.current.N1.N198]", action);
					final SourceNode var0 = toValueNode(asString("ST"));
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N1", "N198"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(21, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N1.e02_0093) => #[target.Area1.sgN1.current.N1.N193]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N1").get("e02_0093");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N1", "N193"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(22, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N3.e01_0166) => #[target.Area1.sgN1.current.N3.current.N3166]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N3").get("e01_0166");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N3", "N3166"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(23, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N3.e02_0166) => #[target.Area1.sgN1.current.N3.current.N3166_3]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N3").get("e02_0166");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N3", "N3166_3"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(24, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e01_0019) => #[target.Area1.sgN1.current.N4.N419]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e01_0019");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N419"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(25, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N1.e04_0067) => #[target.Area1.sgN1.current.N1.N167]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N1").get("e04_0067");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N1", "N167"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(26, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N1.e03_0066) => #[target.Area1.sgN1.current.N1.N166]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N1").get("e03_0066");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N1", "N166"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(27, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e02_0156) => #[target.Area1.sgN1.current.N4.N4156]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e02_0156");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N4156"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(28, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e03_0116) => #[target.Area1.sgN1.current.N4.N4116]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e03_0116");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N4116"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(29, "new Move().execute(source.envelope.Body.X12810.LOOP_N1_g001.current.N4.e04_0026) => #[target.Area1.sgN1.current.N4.N426]", action);
					final SourceNode var0 = s3_cur_LOOP_N1_g001.get("N4").get("e04_0026");
					final SourceNode result = action.execute(var0);
					t1_cur_sgN1.set(at("N4", "N426"), result);
				}
			}}).run();
		}}}}}}).run();
		createCompositeRule(30, "initNew target.Area1.ITD", new Block() { public void body() {
		
			final TargetNode t0_Area1 = target.getLast(at("Area1"));
			final TargetNode t1_cur_ITD = t0_Area1.create(at("ITD"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(31, "new Move().execute(source.envelope.Body.X12810.ITD.e01_0336) => #[target.Area1.ITD.current.ITD336]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("ITD").get("e01_0336");
				final SourceNode result = action.execute(var0);
				t1_cur_ITD.set(at("ITD336"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(32, "new Move().execute(source.envelope.Body.X12810.ITD.e02_0333) => #[target.Area1.ITD.current.ITD333]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("ITD").get("e02_0333");
				final SourceNode result = action.execute(var0);
				t1_cur_ITD.set(at("ITD333"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(33, "new Move().execute(source.envelope.Body.X12810.ITD.e03_0338) => #[target.Area1.ITD.current.ITD338]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("ITD").get("e03_0338");
				final SourceNode result = action.execute(var0);
				t1_cur_ITD.set(at("ITD338"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(34, "new Move().execute(source.envelope.Body.X12810.ITD.e04_0370) => #[target.Area1.ITD.current.ITD370]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("ITD").get("e04_0370");
				final SourceNode result = action.execute(var0);
				t1_cur_ITD.set(at("ITD370"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(35, "new Move().execute(source.envelope.Body.X12810.ITD.e05_0351) => #[target.Area1.ITD.current.ITD351]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("ITD").get("e05_0351");
				final SourceNode result = action.execute(var0);
				t1_cur_ITD.set(at("ITD351"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(36, "new Move().execute(source.envelope.Body.X12810.ITD.e06_0446) => #[target.Area1.ITD.current.ITD446]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("ITD").get("e06_0446");
				final SourceNode result = action.execute(var0);
				t1_cur_ITD.set(at("ITD446"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(37, "new Move().execute(source.envelope.Body.X12810.ITD.e07_0386) => #[target.Area1.ITD.current.ITD386]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("ITD").get("e07_0386");
				final SourceNode result = action.execute(var0);
				t1_cur_ITD.set(at("ITD386"), result);
			}
		}}).run();
		createCompositeRule(38, "for source.envelope.Body.X12810.LOOP_IT1_g006 initNew target.Area2.sgIT1", new Block() { public void body() {
			final SourceNode s0_envelope = source.get("envelope");
			if (exists(s0_envelope)) {
			final SourceNode s1_Body = s0_envelope.get("Body");
			if (exists(s1_Body)) {
			final SourceNode s2_X12810 = s1_Body.get("X12810");
			if (exists(s2_X12810)) {
			for (final SourceNode s3_cur_LOOP_IT1_g006 : s2_X12810.getIterable("LOOP_IT1_g006")) {
		
			final TargetNode t0_Area2 = target.getLast(at("Area2"));
			final TargetNode t1_cur_sgIT1 = t0_Area2.create(at("sgIT1"));
		
			{
				com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
				createSimpleRule(39, "new Add().execute(this.v_count, 1, 0) => #[this.v_count]", action);
				final com.extol.ebi.ruleset.lang.core.Number var0 = Baseotterproduct_810v4010RS_Rt.this.v_count;
				final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
				final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(0);
				final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
				Baseotterproduct_810v4010RS_Rt.this.v_count = result;
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(40, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e04_0212) => #[target.Area2.sgIT1.current.IT1.IT1212]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e04_0212");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1212"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(41, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e01_0350) => #[target.Area2.sgIT1.current.IT1.IT1350]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e01_0350");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1350"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(42, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e02_0358) => #[target.Area2.sgIT1.current.IT1.IT1358]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e02_0358");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1358"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(43, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e02_0358) => #[this.v_qty]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e02_0358");
				final SourceNode result = action.execute(var0);
				Baseotterproduct_810v4010RS_Rt.this.v_qty = extractNumber(result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(44, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e03_0355) => #[target.Area2.sgIT1.current.IT1.IT1355]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e03_0355");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1355"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(45, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e05_0639) => #[target.Area2.sgIT1.current.IT1.IT1639]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e05_0639");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1639"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(46, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e06_0235) => #[target.Area2.sgIT1.current.IT1.IT1235]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e06_0235");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1235"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(47, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e07_0234) => #[target.Area2.sgIT1.current.IT1.IT1234]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e07_0234");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1234"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(48, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e08_0235) => #[target.Area2.sgIT1.current.IT1.IT1235_3]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e08_0235");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1235_3"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(49, "new Move().execute(source.envelope.Body.X12810.LOOP_IT1_g006.current.IT1.e09_0234) => #[target.Area2.sgIT1.current.IT1.IT1234_3]", action);
				final SourceNode var0 = s3_cur_LOOP_IT1_g006.get("IT1").get("e09_0234");
				final SourceNode result = action.execute(var0);
				t1_cur_sgIT1.set(at("IT1", "IT1234_3"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
				createSimpleRule(50, "new Add().execute(this.v_qty, this.v_Totalqty, null) => #[this.v_Totalqty]", action);
				final com.extol.ebi.ruleset.lang.core.Number var0 = Baseotterproduct_810v4010RS_Rt.this.v_qty;
				final com.extol.ebi.ruleset.lang.core.Number var1 = Baseotterproduct_810v4010RS_Rt.this.v_Totalqty;
				final com.extol.ebi.ruleset.lang.core.Number var2 = null;
				final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
				Baseotterproduct_810v4010RS_Rt.this.v_Totalqty = result;
			}
		}}}}}}).run();
		createCompositeRule(51, "initNew target.Area3.TDS", new Block() { public void body() {
		
			final TargetNode t0_Area3 = target.getLast(at("Area3"));
			final TargetNode t1_TDS = t0_Area3.getLast(at("TDS"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(52, "new Move().execute(source.envelope.Body.X12810.TDS.e01_0610) => #[target.Area3.TDS.TDS610]", action);
				final SourceNode var0 = source.get("envelope").get("Body").get("X12810").get("TDS").get("e01_0610");
				final SourceNode result = action.execute(var0);
				t1_TDS.set(at("TDS610"), result);
			}
		}}).run();
		createCompositeRule(53, "initNew target.Area3.CTT", new Block() { public void body() {
		
			final TargetNode t0_Area3 = target.getLast(at("Area3"));
			final TargetNode t1_CTT = t0_Area3.getLast(at("CTT"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(54, "new Move().execute(this.v_count) => #[target.Area3.CTT.CTT354]", action);
				final SourceNode var0 = toValueNode(Baseotterproduct_810v4010RS_Rt.this.v_count);
				final SourceNode result = action.execute(var0);
				t1_CTT.set(at("CTT354"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(55, "new Move().execute(this.v_Totalqty) => #[target.Area3.CTT.CTT347]", action);
				final SourceNode var0 = toValueNode(Baseotterproduct_810v4010RS_Rt.this.v_Totalqty);
				final SourceNode result = action.execute(var0);
				t1_CTT.set(at("CTT347"), result);
			}
		}}).run();
	}

}
