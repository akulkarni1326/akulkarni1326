/**
* @generated
*/
package com.cleo.cic.cockpit.core.outbound;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.CompareValues;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStorageNodeToString;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStringToStorageNode;
import com.extol.ebi.bps.lib.tasks.misc.SendEmail;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.string.AppendString;
import com.extol.ebi.bps.lib.tasks.string.ContainsString;
import com.extol.ebi.bps.lib.tasks.string.ResolveGlobalVariables;
import com.extol.ebi.bps.lib.tasks.transformation.ExecuteTransformation;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps.lib.tasks.transformation.SetContextPointValue;
import com.extol.ebi.bps.lib.types.CompareType;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.bps.lib.types.unions.Attachment;
import com.extol.ebi.bps.lib.types.unions.Message;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;

@SuppressWarnings("all")
public class outboundErrorCockpitBPS_Rt extends AbstractCatalyst {
	
	public outboundErrorCockpitBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_sourceContext, @ParameterType(StorageNode.class) Variable<StorageNode> p_targetContext, @ParameterType(String.class) Variable<String> p_partnerName, @ParameterType(String.class) Variable<String> p_tpIdValue, @ParameterType(StorageNode.class) Variable<StorageNode> p_sourceData, @ParameterType(String.class) Variable<String> p_docType, @ParameterType(String.class) Variable<String> p_ReprocessParams) {
		final Variable<String> v_TransactionSet = variable(String.class, "glb.var.docType");
		final Variable<String> v_logOfMsgIdValue = variable(String.class, null);
		final Variable<String> v_tpId = variable(String.class, "glb.var.tradingPartnerId");
		final Variable<String> v_tpName = variable(String.class, "glb.var.tpName");
		final Variable<String> v_logOfMsgId = variable(String.class, "glb.var.logOfMsgId");
		final Variable<String> v_v_Dummy = variable(String.class, "dummy");
		final Variable<StorageNode> v_source = variable(StorageNode.class, null);
		final Variable<String> v_v_DocType = variable(String.class, null);
		final Variable<String> v_ticketSubject = variable(String.class, null);
		final Variable<String> v_ticketBody = variable(String.class, null);
		final Variable<String> v_subjectFull = variable(String.class, null);
		final Variable<String> v_messageFull = variable(String.class, null);
		final Variable<String> v_environment = variable(String.class, null);
		final Variable<String> v_subject1 = variable(String.class, " ERROR:");
		final Variable<String> v_message1 = variable(String.class, "Cleo Integration Cloud encountered an error.  Please review the process logs.");
		final Variable<String> v_message2 = variable(String.class, " Data Reference Value: ");
		final Variable<String> v_attachmentName = variable(String.class, null);
		final Variable<String> v_dataReferenceValue = variable(String.class, null);
		final Variable<String> v_WarrantyTPs = variable(String.class, null);
		final Variable<String> v_sendEmailTo = variable(String.class, null);
		final Variable<String> v_environment_1 = variable(String.class, "<com.cleo.cic.cockpit.core.cockpitGlobalGV.Environment>");
		final Variable<Boolean> v_TPUnderWarranty = variable(Boolean.class, null);
		final Variable<String> v_sendEmailFrom = variable(String.class, null);
		final Variable<String> v_dummyMail = variable(String.class, "no-reply@cleo.com");
		final Variable<Boolean> v_newVariable = variable(Boolean.class, null);
		final Variable<StorageNode> v_errorlog = variable(StorageNode.class, null);
		final Variable<String> v_failedProcessNumber = variable(String.class, null);
		final Variable<String> v_errorLogString = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_WarrantyTPs, variable(String.class, "<com.cleo.cic.cockpit.core.cockpitGlobalGV.WarrantyTPs>"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_sendEmailTo, variable(String.class, "<com.cleo.cic.cockpit.core.cockpitGlobalGV.TPOwnerEmail>"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Resolve Global Variables", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Resolve Global Variables");
					ResolveGlobalVariables task = new ResolveGlobalVariables();
					setupTask(task);
					return task.execute(v_environment, v_environment_1);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_targetContext, variable(String.class, "env.var.Log_of_Message_Id"), new ContextPointVar(v_logOfMsgIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_targetContext, variable(String.class, "env.var.User_Reference_1"), new ContextPointVar(v_dataReferenceValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, v_TransactionSet, new ContextPointVar(p_docType));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, v_tpName, new ContextPointVar(p_partnerName));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, v_logOfMsgId, new ContextPointVar(v_logOfMsgIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, v_tpId, new ContextPointVar(p_tpIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, variable(String.class, "glb.var.messageId"), new ContextPointVar(v_dataReferenceValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Set Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Set Value");
					SetContextPointValue task = new SetContextPointValue();
					setupTask(task);
					return task.execute(p_sourceContext, variable(String.class, "glb.var.ReprocessParms"), new ContextPointVar(p_ReprocessParams));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Convert String to Storage Node", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert String to Storage Node");
					ConvertStringToStorageNode task = new ConvertStringToStorageNode();
					setupTask(task);
					return task.execute(v_v_Dummy, v_source);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Execute Transformation - Single Output", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Execute Transformation - Single Output");
					ExecuteTransformation task = new ExecuteTransformation();
					setupTask(task);
					return task.execute(v_source, null, literalTypeFromString(TransformationSettings.class, "com.cleo.cic.cockpit.core.defaultTS"), literalTypeFromString(Ruleset.class, "com.cleo.cic.cockpit.core.outbound.outboundErrorCockpitRS"), null, p_sourceContext, p_targetContext);
				} finally { _endTask();}
			}
		}, "next", "next");
		
		builder.addStep("Failure", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_ticketSubject, variable(String.class, "Error During Outbound"), v_v_DocType);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_ticketSubject, v_ticketSubject, variable(String.class, " Outbound Route Transformation"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_ticketBody, variable(String.class, "There has been an error during the out]bound "), v_v_DocType);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_ticketBody, v_ticketBody, variable(String.class, "Outbound transformation Ruleset.  Please see Auditor for details."));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subjectFull, v_subject1, p_partnerName);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subjectFull, v_subjectFull, variable(String.class, "-"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subjectFull, v_subjectFull, p_docType);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("AttachmentName", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_attachmentName, v_subjectFull, variable(String.class, ".txt"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_messageFull, v_message1, v_message2);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_messageFull, v_messageFull, v_dataReferenceValue);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("ProcessLogs", "com.cleo.cic.cockpit.core.GetFailureProcessLogsBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.GetFailureProcessLogsBPS");
					return getInvokeDynamicTask("com.cleo.cic.cockpit.core.GetFailureProcessLogsBPS", "bps1://BusinessProcessScript").execute(v_errorlog, v_failedProcessNumber);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Convert Storage Node to String", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert Storage Node to String");
					ConvertStorageNodeToString task = new ConvertStorageNodeToString();
					setupTask(task);
					return task.execute(v_errorlog, v_errorLogString);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_messageFull, v_messageFull, variable(String.class, "\r\n\r\n\r\nError Logs : \r\n\r\n"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_messageFull, v_messageFull, v_errorLogString);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subjectFull, v_subjectFull, variable(String.class, " PN #"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subjectFull, v_subjectFull, v_failedProcessNumber);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "String - Contains", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Contains");
					ContainsString task = new ContainsString();
					setupTask(task);
					return task.execute(v_newVariable, v_environment, variable(String.class, "{Customer} - {Env}"), null);
				} finally { _endTask();}
			}
		}, "DontAppendEnv", "AppendEnv");
		
		builder.addStep("AppendEnv", "String - Append", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Append");
					AppendString task = new AppendString();
					setupTask(task);
					return task.execute(v_subjectFull, v_environment, v_subjectFull);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep("DontAppendEnv", "String - Contains", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("String - Contains");
					ContainsString task = new ContainsString();
					setupTask(task);
					return task.execute(v_TPUnderWarranty, v_WarrantyTPs, p_partnerName, null);
				} finally { _endTask();}
			}
		}, "next", "CreateTicketBPS");
		
		builder.addStep(null, "Compare Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Compare Values");
					CompareValues task = new CompareValues();
					setupTask(task);
					return task.execute(v_sendEmailTo, v_dummyMail, literalTypeFromString(CompareType.class, "Equal (=)"), null);
				} finally { _endTask();}
			}
		}, "CreateTicketBPS", "SendEmail");
		
		builder.addStep("SendEmail", "Send Email", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Send Email");
					SendEmail task = new SendEmail();
					setupTask(task);
					return task.execute(v_sendEmailTo, v_sendEmailFrom, variable(String.class, null), variable(String.class, null), v_subjectFull, new Message(v_messageFull), new Attachment(p_sourceData), v_attachmentName);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		builder.addStep("CreateTicketBPS", "com.cleo.b2biaas.clarify.CreateTicketBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2biaas.clarify.CreateTicketBPS");
					return getInvokeDynamicTask("com.cleo.b2biaas.clarify.CreateTicketBPS", "bps1://BusinessProcessScript").execute(p_targetContext, p_sourceData, v_subjectFull, v_messageFull, variable(String.class, "Data_Reference.txt"));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
}
