/**
* @generated
*/
package com.cleo.cic.cockpit.core.n850.inbound;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class inbound850v5030CockpitRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.DateTime v_CurrentDateTime;
	private com.extol.ebi.ruleset.lang.core.Number v_milliseconds;
	private com.extol.ebi.ruleset.lang.core.String v_timestamp;
	private com.extol.ebi.ruleset.lang.core.Object v_messageInfo;
	private com.extol.ebi.ruleset.lang.core.Number n_PO1_Counter;
	private com.extol.ebi.ruleset.lang.core.String v_PO1_Counter;
	private com.extol.ebi.ruleset.lang.core.String v_SenderId;
	private com.cleo.cic.cockpit.core.cockpitRDO glb = addToContextMap(new com.cleo.cic.cockpit.core.cockpitRDO());
	private com.extol.ebi.ruleset.lang.core.String v_ShipToParty;
	private com.extol.ebi.ruleset.lang.core.String v_BillToParty;
	private com.extol.ebi.ruleset.lang.core.String v_PODate;
	private com.extol.ebi.ruleset.lang.core.String v_UnitsOrdered;
	private com.extol.ebi.ruleset.lang.core.String v_ParentMessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.String v_MessageId = asString("NA");
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.cleo.cic.cockpit.core.n850.n850v5030CockpitEDI_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "", new Block() { public void body() {
		
		
			createCompositeRule(2, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
					createSimpleRule(3, "new GetCurrentDateTime().execute() => #[this.v_CurrentDateTime]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
					inbound850v5030CockpitRS_Rt.this.v_CurrentDateTime = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
					createSimpleRule(4, "new GetMilliseconds().execute(this.v_CurrentDateTime) => #[this.v_milliseconds]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime var0 = inbound850v5030CockpitRS_Rt.this.v_CurrentDateTime;
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.v_milliseconds = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(5, "new Move().execute(this.v_milliseconds) => #[this.v_timestamp]", action);
					final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.v_milliseconds);
					final SourceNode result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.v_timestamp = extractString(result);
				}
			}}).run();
			createCompositeRule(6, "", new Block() { public void body() {
			
			
				createCompositeRule(7, "for source.Area1.sgN1", new Block() { public void body() {
					final SourceNode s0_Area1 = source.get("Area1");
					if (exists(s0_Area1)) {
					for (final SourceNode s1_cur_sgN1 : s0_Area1.getIterable("sgN1")) {
				
				
					createCompositeRule(8, "for source.Area1.sgN1.current.N1", new Block() { public void body() {
						final SourceNode s2_N1 = s1_cur_sgN1.get("N1");
						if (exists(s2_N1)) {
					
					
						createCompositeRule(9, "", new Block() { public void body() {
						
						
							{
								boolean conditionResult;
								{
									com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized condition = new com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized();
									createRuleCondition(10, "new StringEqualsNormalized().execute(source.Area1.sgN1.current.N1.N198, \"ST\") => #[]", condition);
									final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_N1.get("N198"));
									final com.extol.ebi.ruleset.lang.core.String var1 = asString("ST");
									final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
									
									conditionResult = result.asJavaBoolean().booleanValue();
								}
								if (conditionResult) {
									com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
									createSimpleRule(10, "new Move().execute(source.Area1.sgN1.current.N1.N193) => #[this.v_ShipToParty]", action);
									final SourceNode var0 = s2_N1.get("N193");
									final SourceNode result = action.execute(var0);
									inbound850v5030CockpitRS_Rt.this.v_ShipToParty = extractString(result);
								}
							}
							{
								boolean conditionResult;
								{
									com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized condition = new com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized();
									createRuleCondition(11, "new StringEqualsNormalized().execute(source.Area1.sgN1.current.N1.N198, \"BT\") => #[]", condition);
									final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_N1.get("N198"));
									final com.extol.ebi.ruleset.lang.core.String var1 = asString("BT");
									final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
									
									conditionResult = result.asJavaBoolean().booleanValue();
								}
								if (conditionResult) {
									com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
									createSimpleRule(11, "new Move().execute(source.Area1.sgN1.current.N1.N193) => #[this.v_BillToParty]", action);
									final SourceNode var0 = s2_N1.get("N193");
									final SourceNode result = action.execute(var0);
									inbound850v5030CockpitRS_Rt.this.v_BillToParty = extractString(result);
								}
							}
						}}).run();
					}}}).run();
				}}}}).run();
				createCompositeRule(12, "for source.Area2.sgPO1", new Block() { public void body() {
					final SourceNode s0_Area2 = source.get("Area2");
					if (exists(s0_Area2)) {
					for (final SourceNode s1_cur_sgPO1 : s0_Area2.getIterable("sgPO1")) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
						createSimpleRule(13, "new Add().execute(1, this.n_PO1_Counter, 0) => #[this.n_PO1_Counter]", action);
						final com.extol.ebi.ruleset.lang.core.Number var0 = asNumber(1);
						final com.extol.ebi.ruleset.lang.core.Number var1 = inbound850v5030CockpitRS_Rt.this.n_PO1_Counter;
						final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(0);
						final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
						inbound850v5030CockpitRS_Rt.this.n_PO1_Counter = result;
					}
				}}}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(14, "new Move().execute(this.n_PO1_Counter) => #[this.v_PO1_Counter]", action);
					final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.n_PO1_Counter);
					final SourceNode result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.v_PO1_Counter = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.string.Trim action = new com.extol.ebi.reactor.lib.actions.string.Trim();
					createSimpleRule(15, "new Trim().execute(this.env.Sender_Id) => #[this.v_SenderId]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = inbound850v5030CockpitRS_Rt.this.env.Sender_Id;
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.v_SenderId = result;
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(16, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BEG.BEG324) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BEG").get("BEG324");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(16, "new Move().execute(source.Area1.BEG.BEG324) => #[this.v_ParentMessageId]", action);
						final SourceNode var0 = source.get("Area1").get("BEG").get("BEG324");
						final SourceNode result = action.execute(var0);
						inbound850v5030CockpitRS_Rt.this.v_ParentMessageId = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(17, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BEG.BEG324) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BEG").get("BEG324");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(17, "new Move().execute(source.Area1.BEG.BEG324) => #[this.v_MessageId]", action);
						final SourceNode var0 = source.get("Area1").get("BEG").get("BEG324");
						final SourceNode result = action.execute(var0);
						inbound850v5030CockpitRS_Rt.this.v_MessageId = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(18, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BEG.BEG373) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BEG").get("BEG373");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(18, "new Move().execute(source.Area1.BEG.BEG373) => #[this.v_PODate]", action);
						final SourceNode var0 = source.get("Area1").get("BEG").get("BEG373");
						final SourceNode result = action.execute(var0);
						inbound850v5030CockpitRS_Rt.this.v_PODate = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(19, "new IsNotNullOrWhiteSpaces().execute(source.Area3.sgCTT.CTT.CTT347) => #[]", condition);
						final SourceNode var0 = source.get("Area3").get("sgCTT").get("CTT").get("CTT347");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(19, "new Move().execute(source.Area3.sgCTT.CTT.CTT347) => #[this.v_UnitsOrdered]", action);
						final SourceNode var0 = source.get("Area3").get("sgCTT").get("CTT").get("CTT347");
						final SourceNode result = action.execute(var0);
						inbound850v5030CockpitRS_Rt.this.v_UnitsOrdered = extractString(result);
					}
				}
			}}).run();
			createCompositeRule(20, "", new Block() { public void body() {
			
			
				{
					com.cleo.b2biaas.clarify.InboundCreateMessageHeader action = new com.cleo.b2biaas.clarify.InboundCreateMessageHeader();
					createSimpleRule(21, "new com.cleo.b2biaas.clarify.InboundCreateMessageHeader().execute(this.v_SenderId, this.glb.tpName, \"850\", this.v_ParentMessageId, this.v_MessageId, this.v_timestamp, \"true\", \"USD\", this.glb.ownerId, \"PO\", this.env.Functional_Group_Control_Number, this.env.Message_Control_Number) => #[this.v_messageInfo]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = inbound850v5030CockpitRS_Rt.this.v_SenderId;
					final com.extol.ebi.ruleset.lang.core.String var1 = inbound850v5030CockpitRS_Rt.this.glb.tpName;
					final com.extol.ebi.ruleset.lang.core.String var2 = asString("850");
					final com.extol.ebi.ruleset.lang.core.String var3 = inbound850v5030CockpitRS_Rt.this.v_ParentMessageId;
					final com.extol.ebi.ruleset.lang.core.String var4 = inbound850v5030CockpitRS_Rt.this.v_MessageId;
					final com.extol.ebi.ruleset.lang.core.String var5 = inbound850v5030CockpitRS_Rt.this.v_timestamp;
					final com.extol.ebi.ruleset.lang.core.String var6 = asString("true");
					final com.extol.ebi.ruleset.lang.core.String var7 = asString("USD");
					final com.extol.ebi.ruleset.lang.core.String var8 = inbound850v5030CockpitRS_Rt.this.glb.ownerId;
					final com.extol.ebi.ruleset.lang.core.String var9 = asString("PO");
					final com.extol.ebi.ruleset.lang.core.String var10 = inbound850v5030CockpitRS_Rt.this.env.Functional_Group_Control_Number;
					final com.extol.ebi.ruleset.lang.core.String var11 = inbound850v5030CockpitRS_Rt.this.env.Message_Control_Number;
					final com.extol.ebi.ruleset.lang.core.Object result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
					inbound850v5030CockpitRS_Rt.this.v_messageInfo = result;
				}
				{
					com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader action = new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader();
					createSimpleRule(22, "new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader().execute(this.v_messageInfo, \"logOfMessageId\", this.env.Log_of_Message_Id) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("logOfMessageId");
					final com.extol.ebi.ruleset.lang.core.String var2 = inbound850v5030CockpitRS_Rt.this.env.Log_of_Message_Id;
					action.execute(var0, var1, var2);
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(23, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BEG.BEG324) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BEG").get("BEG324");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetails action = new com.cleo.b2biaas.clarify.InboundAddMessageDetails();
						createSimpleRule(23, "new com.cleo.b2biaas.clarify.InboundAddMessageDetails().execute(this.v_messageInfo, \"Purchase Order\", source.Area1.BEG.BEG324) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Purchase Order");
						final com.extol.ebi.ruleset.lang.core.String var2 = extractString(source.get("Area1").get("BEG").get("BEG324"));
						action.execute(var0, var1, var2);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(24, "new IsNotNullOrWhiteSpaces().execute(this.v_PODate) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.v_PODate);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetails action = new com.cleo.b2biaas.clarify.InboundAddMessageDetails();
						createSimpleRule(24, "new com.cleo.b2biaas.clarify.InboundAddMessageDetails().execute(this.v_messageInfo, \"Purchase Order Date\", this.v_PODate) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Purchase Order Date");
						final com.extol.ebi.ruleset.lang.core.String var2 = inbound850v5030CockpitRS_Rt.this.v_PODate;
						action.execute(var0, var1, var2);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(25, "new IsNotNullOrWhiteSpaces().execute(this.v_ShipToParty) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.v_ShipToParty);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetails action = new com.cleo.b2biaas.clarify.InboundAddMessageDetails();
						createSimpleRule(25, "new com.cleo.b2biaas.clarify.InboundAddMessageDetails().execute(this.v_messageInfo, \"Ship To Party\", this.v_ShipToParty) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Ship To Party");
						final com.extol.ebi.ruleset.lang.core.String var2 = inbound850v5030CockpitRS_Rt.this.v_ShipToParty;
						action.execute(var0, var1, var2);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(26, "new IsNotNullOrWhiteSpaces().execute(this.v_BillToParty) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.v_BillToParty);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetails action = new com.cleo.b2biaas.clarify.InboundAddMessageDetails();
						createSimpleRule(26, "new com.cleo.b2biaas.clarify.InboundAddMessageDetails().execute(this.v_messageInfo, \"Bill To Party\", this.v_BillToParty) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Bill To Party");
						final com.extol.ebi.ruleset.lang.core.String var2 = inbound850v5030CockpitRS_Rt.this.v_BillToParty;
						action.execute(var0, var1, var2);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(27, "new IsNotNullOrWhiteSpaces().execute(this.v_UnitsOrdered) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.v_UnitsOrdered);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetails action = new com.cleo.b2biaas.clarify.InboundAddMessageDetails();
						createSimpleRule(27, "new com.cleo.b2biaas.clarify.InboundAddMessageDetails().execute(this.v_messageInfo, \"Total Units Ordered\", this.v_UnitsOrdered) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Total Units Ordered");
						final com.extol.ebi.ruleset.lang.core.String var2 = inbound850v5030CockpitRS_Rt.this.v_UnitsOrdered;
						action.execute(var0, var1, var2);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(28, "new IsNotNullOrWhiteSpaces().execute(this.v_PO1_Counter) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.v_PO1_Counter);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetails action = new com.cleo.b2biaas.clarify.InboundAddMessageDetails();
						createSimpleRule(28, "new com.cleo.b2biaas.clarify.InboundAddMessageDetails().execute(this.v_messageInfo, \"NumberOfLineItems\", this.v_PO1_Counter) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("NumberOfLineItems");
						final com.extol.ebi.ruleset.lang.core.String var2 = inbound850v5030CockpitRS_Rt.this.v_PO1_Counter;
						action.execute(var0, var1, var2);
					}
				}
				{
					com.cleo.b2biaas.clarify.InboundCloseMessage action = new com.cleo.b2biaas.clarify.InboundCloseMessage();
					createSimpleRule(29, "new com.cleo.b2biaas.clarify.InboundCloseMessage().execute(this.v_messageInfo) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = inbound850v5030CockpitRS_Rt.this.v_messageInfo;
					action.execute(var0);
				}
			}}).run();
			createCompositeRule(30, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(31, "new Move().execute(this.glb.User_Reference_1) => #[this.env.User_Reference_1]", action);
					final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.glb.User_Reference_1);
					final SourceNode result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.env.User_Reference_1 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(32, "new Move().execute(this.glb.User_Reference_2) => #[this.env.User_Reference_2]", action);
					final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.glb.User_Reference_2);
					final SourceNode result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.env.User_Reference_2 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(33, "new Move().execute(this.glb.User_Reference_3) => #[this.env.User_Reference_3]", action);
					final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.glb.User_Reference_3);
					final SourceNode result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.env.User_Reference_3 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(34, "new Move().execute(this.glb.User_Reference_4) => #[this.env.User_Reference_4]", action);
					final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.glb.User_Reference_4);
					final SourceNode result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.env.User_Reference_4 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(35, "new Move().execute(this.glb.User_Reference_5) => #[this.env.User_Reference_5]", action);
					final SourceNode var0 = toValueNode(inbound850v5030CockpitRS_Rt.this.glb.User_Reference_5);
					final SourceNode result = action.execute(var0);
					inbound850v5030CockpitRS_Rt.this.env.User_Reference_5 = extractString(result);
				}
			}}).run();
		}}).run();
	}

}
