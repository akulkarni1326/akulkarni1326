/**
 * @generated
 */
package com.cleo.cic.cockpit.core;

import java.util.ArrayList;
import java.util.List;

import com.extol.ebi.reactor.flatfile.lib.schema.*;

@SuppressWarnings("all")
public class defaultErrorCockpitFF_Rt implements RuntimeFlatFileSchemaProvider {

	private RtFlatFileSchema schema_defaultErrorCockpitFF;

	public RtFlatFileSchema getSchema() {
		if (schema_defaultErrorCockpitFF == null) {
			List<RtFilePartRef> parts = new ArrayList<>();
			parts.add(new RtFilePartRef("_Record", 0, -1, r_Record()));

			schema_defaultErrorCockpitFF = new RtFlatFileSchema("defaultErrorCockpitFF", parts);
		}

		return schema_defaultErrorCockpitFF;
	}

	private RtRecord r_Record;
	
	private RtRecord r_Record() {
		if (r_Record == null) {
			List<RtFileField> fields = new ArrayList<>();
			{
				FieldAttributeHelper fa = new FieldAttributeHelper();
				fa.length = 50;
				fields.add(new RtFileField("v_Error", RtFieldTypes.String, fa));
			}
			
			RecordAttributeHelper ra = new RecordAttributeHelper();
	
			r_Record = new RtRecord("Record", fields, ra);
		}
	
		return r_Record;
	}

}
