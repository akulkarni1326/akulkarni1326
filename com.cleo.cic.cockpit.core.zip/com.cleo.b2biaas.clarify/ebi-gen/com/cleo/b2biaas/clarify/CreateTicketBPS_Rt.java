/**
* @generated
*/
package com.cleo.b2biaas.clarify;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.support.CallJavaAbstractTask;
import com.extol.ebi.bps.lib.tasks.misc.ConvertStorageNodeToString;
import com.extol.ebi.bps.lib.tasks.transformation.GetContextPointValue;
import com.extol.ebi.bps2.lib.types.unions.ContextPointVar;
import com.extol.ebi.lang.storage.StorageNode;

@SuppressWarnings("all")
public class CreateTicketBPS_Rt extends AbstractCatalyst {
	
	public CreateTicketBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
	}
	
	public boolean execute(@ParameterType(StorageNode.class) Variable<StorageNode> p_targetContext, @ParameterType(StorageNode.class) Variable<StorageNode> p_inputDataFragment, @ParameterType(String.class) Variable<String> p_ticketSubject, @ParameterType(String.class) Variable<String> p_ticketBody, @ParameterType(String.class) Variable<String> p_attachmentName) {
		final Variable<String> v_messageId = variable(String.class, "glb.var.messageId");
		final Variable<String> v_docType = variable(String.class, "glb.var.docType");
		final Variable<String> v_tpId = variable(String.class, "glb.var.tradingPartnerId");
		final Variable<String> v_messageIdValue = variable(String.class, null);
		final Variable<String> v_docTypeValue = variable(String.class, null);
		final Variable<String> v_tpIdValue = variable(String.class, null);
		final Variable<Void> v_returnValue = variable(Void.class, null);
		final Variable<String> v_attachmentContentValue = variable(String.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_targetContext, v_messageId, new ContextPointVar(v_messageIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_targetContext, v_docType, new ContextPointVar(v_docTypeValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Context Point - Get Value", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Context Point - Get Value");
					GetContextPointValue task = new GetContextPointValue();
					setupTask(task);
					return task.execute(p_targetContext, v_tpId, new ContextPointVar(v_tpIdValue));
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Convert Storage Node to String", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Convert Storage Node to String");
					ConvertStorageNodeToString task = new ConvertStorageNodeToString();
					setupTask(task);
					return task.execute(p_inputDataFragment, v_attachmentContentValue);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "com.cleo.b2biaas.clarify.CreateTicketBPS$createTicketWithAttachment", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.b2biaas.clarify.CreateTicketBPS$createTicketWithAttachment");
					createTicketWithAttachment task = new createTicketWithAttachment();
					setupTask(task);
					return task.execute(v_returnValue, v_messageIdValue, v_docTypeValue, v_tpIdValue, p_ticketSubject, p_ticketBody, v_attachmentContentValue, p_attachmentName);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		return builder.createRunner().run();
	}
	
	public static class createTicketWithAttachment extends CallJavaAbstractTask {
		public createTicketWithAttachment() {
			super("com.cleo.b2biaas.clarify.CreateTicketWithAttachmentExtAPI", "void createTicketAttachment(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)", false);
		}
	}
}
