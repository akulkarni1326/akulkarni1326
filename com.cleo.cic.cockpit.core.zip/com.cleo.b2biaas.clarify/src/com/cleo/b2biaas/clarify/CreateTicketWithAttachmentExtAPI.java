package com.cleo.b2biaas.clarify;


/**
 * @author Manju Muthuraj
 * 
 */
public class CreateTicketWithAttachmentExtAPI extends B2BAction{
	

	public void createTicketAttachment(String messageId,String docType,String tpId,String ticketSubject,String ticketBody,String attachmentContent,String attachmentName) {

		try {
			TicketAPICallV2 ticket = new TicketAPICallV2();
			UploadAttachment ua = new UploadAttachment();
			Utility utility = new Utility();
			String uploadToken = null;
			String ticketJson = null;
			
			if (CloudConfig.isConfigured()) {
				logInfo(EventKeys.CREATE_TICKET_WITH_ATTACHMENT_REQUEST_BODY);
				String TICKET_API_URL = CloudConfig.getServerUrl()
						+ EventKeys.API_TICKET_TENANT
						+ CloudConfig.getTenantId();

				String uploadAttachUrl = CloudConfig.getServerUrl()
						+ EventKeys.API_TICKET_TENANT
						+ CloudConfig.getTenantId() + EventKeys.API_UPLOADATTACHMENT;

				logInfo(EventKeys.UPLOAD_ATTACHEMNET_URL + uploadAttachUrl);

				if (null != attachmentContent && !"null".equals(attachmentContent)
						&& !attachmentContent.isEmpty()
						&& null != attachmentName &&!"null".equals(attachmentName)
						&& !attachmentName.isEmpty()) {
					
					// Get the upload token from Zendesk.
					uploadToken = ua.getAttachmentToken(
							attachmentName,
							attachmentContent,
							CloudConfig.getSecurityToken(),
							uploadAttachUrl);
				} else {
					uploadToken = "null";
				}
				logInfo(EventKeys.UPLOAD_TOKEN_LOG + uploadToken);
			
				// Create ticket with upload token.
				ticket.createTicketWithAttachement(messageId,
						docType, tpId,
						ticketSubject,
						ticketBody, uploadToken);

				ticketJson = utility.objectToString(ticket.getTicketInfo());

				logInfo(EventKeys.CREATE_TICKET_WITH_ATTACHMENT_REQUEST_BODY
						+ ticketJson.toString());

				utility.postMessage(TICKET_API_URL,
						ticketJson.toString(), CloudConfig.getSecurityToken());					
			
			}else {
				logInfo(EventKeys.LOADING_PROPERTIES_FROM_RESOURCES_OF_API_PROJECT_FOR_COCKPIT);
				logInfo(EventKeys.B2BIAAS_ENVIRONMENT + EventKeys.ENVIRONMENT);

			if ("stage".equals(EventKeys.ENVIRONMENT)) {

				String TICKET_API_STAGE_URL = EventKeys.SERVER_URL
						+ EventKeys.API_TICKET_TENANT
						+ EventKeys.TENANTID_STAGE;

				String uploadAttachUrl = EventKeys.SERVER_URL
						+ EventKeys.API_TICKET_TENANT
						+ EventKeys.TENANTID_STAGE + EventKeys.API_UPLOADATTACHMENT;

				logInfo(EventKeys.UPLOAD_ATTACHEMNET_URL + uploadAttachUrl);

				if (null != attachmentContent && !"null".equals(attachmentContent)
						&& !attachmentContent.isEmpty()
						&& null != attachmentName &&!"null".equals(attachmentName)
						&& !attachmentName.isEmpty()) {
					
					// Get the upload token from Zendesk.
					uploadToken = ua.getAttachmentToken(
							attachmentName,
							attachmentContent,
							EventKeys.SECURITY_TOKEN_STAGE,
							uploadAttachUrl);
				} else {
					uploadToken = "null";
				}
				logInfo(EventKeys.UPLOAD_TOKEN_LOG + uploadToken);
			
				// Create ticket with upload token.
				ticket.createTicketWithAttachement(messageId,
						docType, tpId,
						ticketSubject,
						ticketBody, uploadToken);

				ticketJson = utility.objectToString(ticket.getTicketInfo());

				logInfo(EventKeys.CREATE_TICKET_WITH_ATTACHMENT_REQUEST_BODY
						+ ticketJson.toString());

				utility.postMessage(TICKET_API_STAGE_URL,
						ticketJson.toString(), EventKeys.SECURITY_TOKEN_STAGE);
			} else {
				if ("production".equals(EventKeys.ENVIRONMENT)) {
					String TICKET_API_PRODUCTION_URL = EventKeys.SERVER_URL
							+ EventKeys.API_TICKET_TENANT
							+ EventKeys.TENANTID_PRODUCTION;

					String uploadAttachUrl = EventKeys.SERVER_URL
							+ EventKeys.API_TICKET_TENANT
							+ EventKeys.TENANTID_PRODUCTION
							+ EventKeys.API_UPLOADATTACHMENT;
					
					logInfo(EventKeys.UPLOAD_ATTACHEMNET_URL + uploadAttachUrl);

					if (null != attachmentContent && !"null".equals(attachmentContent)
							&& !attachmentContent.isEmpty()
							&& null != attachmentName &&!"null".equals(attachmentName)
							&& !attachmentName.isEmpty()) {

						// Get the upload token from Zendesk.
						uploadToken = ua.getAttachmentToken(attachmentName,
								attachmentContent,
								EventKeys.SECURITY_TOKEN_PRODUCTION,
								uploadAttachUrl);
					} else {
						uploadToken = "null";
					}

					logInfo(EventKeys.UPLOAD_TOKEN_LOG + uploadToken);
					
					// Create ticket with upload token.
					ticket.createTicketWithAttachement(
							messageId, docType,
							tpId, ticketSubject,
							ticketBody,
							uploadToken);

					ticketJson = utility.objectToString(ticket.getTicketInfo());

					logInfo(EventKeys.CREATE_TICKET_WITH_ATTACHMENT_REQUEST_BODY
							+ ticketJson.toString());

					utility.postMessage(TICKET_API_PRODUCTION_URL,
							ticketJson.toString(),
							EventKeys.SECURITY_TOKEN_PRODUCTION);
				} else {
					throw new Exception(
							EventKeys.THE_ENVIRONMENT_SHOULD_BE_EITHER_STAGE_OR_PRODUCTION
									+ EventKeys.ENVIRONMENT);
				}
			}
		  }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
