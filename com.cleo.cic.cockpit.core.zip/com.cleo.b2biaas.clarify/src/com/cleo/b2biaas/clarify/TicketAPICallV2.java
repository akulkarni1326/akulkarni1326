package com.cleo.b2biaas.clarify;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Manju Muthuraj
 * 
 */
public class TicketAPICallV2 {

	private ConcurrentHashMap<String, String> createTicketInfo = new ConcurrentHashMap<>();

	public void createTicketWithAttachement(String messageId, String docType,
			String tpId, String ticketSubject, String ticketBody,
			String uploadToken) {		

		getTicketInfo().put(EventKeys.KEY_MESSAGEID, messageId);
		getTicketInfo().put(EventKeys.KEY_DOCTYPE, docType);
		getTicketInfo().put(EventKeys.KEY_TPID, tpId);
		getTicketInfo().put(EventKeys.KEY_SUBJECT, ticketSubject);
		getTicketInfo().put(EventKeys.KEY_BODY, ticketBody);
		getTicketInfo().put(EventKeys.KEY_TYPE, EventKeys.PROBLEM);
		if (uploadToken != null && !"null".equals(uploadToken) && !uploadToken.isEmpty()) {
			getTicketInfo().put(EventKeys.UPLOAD_TOKEN_KEY, uploadToken);
		}		

	}

	public ConcurrentHashMap<String, String> getTicketInfo() {
		return createTicketInfo;
	}

	public void setTicketInfo(ConcurrentHashMap<String, String> info) {
		this.createTicketInfo = info;
	}

}
