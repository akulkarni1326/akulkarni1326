package com.cleo.b2biaas.clarify;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class FAInfoAccumulator {


	final static String NL = System.getProperty(EventKeys.LINE_SEPARATOR);

	String callType = null;

	static HashMap<String, Object> inboundfaMapInfo = new HashMap<String, Object>();
	static HashMap<String, Object> outboundfaMapInfo = new HashMap<String, Object>();

	public FAInfoAccumulator(String callType) {
		super();
		this.callType = callType;

	}

	public static void addInboundFADataToMap(HashMap<String, String> faData) {

		List faList = null;
		String uuid = faData.get(EventKeys.CONTEXT);
		faList = (List) inboundfaMapInfo.get(uuid);
		if (faList == null) {
			faList = new ArrayList<Object>();
		}
		faData.put(EventKeys.DIRECTION, EventKeys.DIRECTION_R);
		faData.put(EventKeys.TIMESTAMP, Long.toString(System.currentTimeMillis()));
		faList.add(faData);
		inboundfaMapInfo.put(uuid, faList);
	}

	public static void addOutboundFADataToMap(HashMap<String, String> faData) {

		List faList = null;
	
		String uuid = faData.get(EventKeys.LOGOF_MESSAGE_ID);
		faList = (List) outboundfaMapInfo.get(uuid);
		if (faList == null) {
			faList = new ArrayList<Object>();
		}
		faData.put(EventKeys.DIRECTION, EventKeys.DIRECTION_S);
		faData.put(EventKeys.TIMESTAMP, Long.toString(System.currentTimeMillis()));
		faList.add(faData);
		outboundfaMapInfo.put(uuid, faList);
	}

	
	public static void clearInboundAccumulator(String uuid) {
		List object = (List) inboundfaMapInfo.get(uuid);
		object.clear();
		inboundfaMapInfo.remove(uuid);
	}

	public static void clearOutboundAccumulator(String uuid) {
		List object = (List) outboundfaMapInfo.get(uuid);
		object.clear();
		outboundfaMapInfo.remove(uuid);
	}

	@SuppressWarnings("unchecked")
	public static FAData getInboundFADataToSendToCockpit(String uuid) {
		FAData data = new FAData();
		FAData.Transaction t = null;

		List FAInfo = (List) inboundfaMapInfo.get(uuid);

		for (int i = 0; i < FAInfo.size(); i++) {
			if (FAInfo.get(i) != null && FAInfo.get(i) instanceof HashMap) {
				HashMap<String, Object> faData = (HashMap<String, Object>) FAInfo.get(i);
				String intSndrID = (String) faData.get(EventKeys.INTERCHANGE_SENDER_ID);
				String intRcvrID = (String) faData.get(EventKeys.INTERCHANGE_RECEIVER_ID);
				String akGrpCode = (String) faData.get(EventKeys.AK101);
				String akGrpCtrlNumber = (String) faData.get(EventKeys.AK102);
				String akMsgID = (String) faData.get(EventKeys.AK201);
				String akMsgCtrlNumber = (String) faData.get(EventKeys.AK202);
				String akLogOfMessageID = (String) faData.get(EventKeys.LOGOF_MESSAGE_ID);
				String akMsgSts = (String) faData.get(EventKeys.AK501);
				String akGrpSts = (String) faData.get(EventKeys.AK901);
				String direction = (String) faData.get(EventKeys.DIRECTION);
				String timestamp = (String) faData.get(EventKeys.TIMESTAMP);
				

				if (i == 0) {
					data.setLogOfMessageId(akLogOfMessageID);
					data.setGroupStatus(akGrpSts);
					data.setFunctionalIdentifierCode(akGrpCode);
					data.setGroupControlNumber(akGrpCtrlNumber);
					data.setOwnerId(intRcvrID.trim());
					data.setTpId(intSndrID.trim());
					data.setDirection(direction);
					data.setTimeStamp(timestamp);
				}
				if (akMsgID != null && !akMsgID.isEmpty()) {
					t = data.new Transaction();
					t.setTransactionControlNumber(akMsgCtrlNumber);
					t.setTransactionStatus(akMsgSts);
					data.addTransaction(t);
				}
			}
		}
		return data;
	}

	@SuppressWarnings("unchecked")
	public static FAData getOutboundFADataToSendToCockpit(String uuid) {
		FAData data = new FAData();
		FAData.Transaction t = null;

		List FAInfo = (List) outboundfaMapInfo.get(uuid);

		for (int i = 0; i < FAInfo.size(); i++) {
			if (FAInfo.get(i) != null && FAInfo.get(i) instanceof HashMap) {
				HashMap<String, Object> faData = (HashMap<String, Object>) FAInfo
						.get(i);
			
				String intSndrID = (String) faData.get(EventKeys.INTERCHANGE_SENDER_ID);
				String intRcvrID = (String) faData.get(EventKeys.INTERCHANGE_RECEIVER_ID);
				String akGrpCode = (String) faData.get(EventKeys.AK101);
				String akGrpCtrlNumber = (String) faData.get(EventKeys.AK102);
				String akMsgID = (String) faData.get(EventKeys.AK201);
				String akMsgCtrlNumber = (String) faData.get(EventKeys.AK202);
				String akLogOfMessageID = (String) faData.get(EventKeys.LOGOF_MESSAGE_ID);
				String akMsgSts = (String) faData.get(EventKeys.AK501);
				String akGrpSts = (String) faData.get(EventKeys.AK901);
				String direction = (String) faData.get(EventKeys.DIRECTION);
				String timestamp = (String) faData.get(EventKeys.TIMESTAMP);
				
				if (i == 0) {
					data.setLogOfMessageId(akLogOfMessageID);
					data.setGroupStatus(akGrpSts);
					data.setFunctionalIdentifierCode(akGrpCode);
					data.setGroupControlNumber(akGrpCtrlNumber);
					data.setDirection(direction);
					data.setTimeStamp(timestamp);
				}
				if (intSndrID != null && intRcvrID != null) {
					data.setOwnerId(intSndrID.trim());
					data.setTpId(intRcvrID.trim());

				}
				if (akMsgID != null && !akMsgID.trim().isEmpty()) {
					t = data.new Transaction();
					t.setTransactionControlNumber(akMsgCtrlNumber);
					t.setTransactionStatus(akMsgSts);
					data.addTransaction(t);

				}
			}
		}
		return data;
	}
}
