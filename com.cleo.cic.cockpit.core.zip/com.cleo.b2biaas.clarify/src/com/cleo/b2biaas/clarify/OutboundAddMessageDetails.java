package com.cleo.b2biaas.clarify;


/**
 * @author Manju Muthuraj
 * 
 */
public class OutboundAddMessageDetails  extends OutboundAddMessageDetailsV2 {

	public void execute(com.extol.ebi.ruleset.lang.core.Object messageInfo,
			com.extol.ebi.ruleset.lang.core.String key,
			com.extol.ebi.ruleset.lang.core.String value) {
		
		super.execute(messageInfo, key, null, value);
	}
}
