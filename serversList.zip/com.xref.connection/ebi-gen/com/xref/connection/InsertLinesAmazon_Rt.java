/**
 * @generated
 */
package com.xref.connection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.extol.ebi.reactor.database.lib.schema.*;

@SuppressWarnings("all")
public class InsertLinesAmazon_Rt implements RuntimeDatabaseSchemaProvider {

	private RtDatabaseSchema schema_InsertLinesAmazon;

	public RtDatabaseSchema getSchema() {
		if (schema_InsertLinesAmazon == null) {
			List<RtTableObjectRef> refs = new ArrayList<>();
			refs.add(new RtTableObjectRef("_LineNumbers", true, to_LineNumbers(), false));

			Map<String,RtTableObject> definedTables = new HashMap<>();
			definedTables.put("LineNumbers", to_LineNumbers());

			schema_InsertLinesAmazon = new RtDatabaseSchema("InsertLinesAmazon", refs, definedTables);
		}

		return schema_InsertLinesAmazon;
	}

	private RtTableObject to_LineNumbers;
	
	private RtTableObject to_LineNumbers() {
		if (to_LineNumbers == null) {
			List<RtColumn> columns = new ArrayList<>();
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 10;
				columns.add(new RtColumn("cicSerialId", RtColumnTypes.INTEGER, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("ponumber", RtColumnTypes.VARCHAR, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("qty", RtColumnTypes.VARCHAR, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("qual", RtColumnTypes.VARCHAR, ch));
			}
			{
				ColumnHelper ch = new ColumnHelper();
				ch.size = 2147483647;
				columns.add(new RtColumn("itemnumber", RtColumnTypes.VARCHAR, ch));
			}
	
			List<RtTableObjectRef> refs = new ArrayList<>();
	
			to_LineNumbers = new RtTableObject("LineNumbers", columns, refs, false);
		}
	
		return to_LineNumbers;
	}
}
