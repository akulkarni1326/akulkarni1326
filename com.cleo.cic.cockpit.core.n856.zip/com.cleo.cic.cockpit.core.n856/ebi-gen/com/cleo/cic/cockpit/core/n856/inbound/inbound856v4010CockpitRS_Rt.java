/**
* @generated
*/
package com.cleo.cic.cockpit.core.n856.inbound;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.lib.schema.NullSchema;

@SuppressWarnings("all")
public class inbound856v4010CockpitRS_Rt extends AbstractReactor<RtEdiDerivedMessageSchema,NullSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EdiEnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.DateTime v_currentDateTime;
	private com.extol.ebi.ruleset.lang.core.Object v_inboundMessage;
	private com.extol.ebi.ruleset.lang.core.Number v_lineItemCounter;
	private com.extol.ebi.ruleset.lang.core.String v_lineItemCounterString;
	private com.extol.ebi.ruleset.lang.core.Number v_currentDateTimeMillis;
	private com.extol.ebi.ruleset.lang.core.String v_currentDateTimeMillisString;
	private com.extol.ebi.ruleset.lang.core.String v_ParentMessageId = asString("NA");
	private com.extol.ebi.ruleset.lang.core.String v_MessageId = asString("NA");
	private com.cleo.cic.cockpit.core.cockpitRDO glb = addToContextMap(new com.cleo.cic.cockpit.core.cockpitRDO());
	private com.extol.ebi.ruleset.lang.core.String v_ShippedDate;
	private com.extol.ebi.ruleset.lang.core.String v_NumberOfLineItems;
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getSourceSchema() {
		return new com.cleo.cic.cockpit.core.n856.n856v4010CockpitEDI_Rt();
	}
	
	public SchemaProvider<NullSchema> getTargetSchema() {
		return null;
	}
	
	public Connector getSourceConnector() {
		return new X12Connector();
	}

	public Connector getTargetConnector() {
		return null;
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();

		createCompositeRule(1, "", new Block() { public void body() {
		
		
			createCompositeRule(2, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime action = new com.extol.ebi.reactor.lib.actions.datetime.GetCurrentDateTime();
					createSimpleRule(3, "new GetCurrentDateTime().execute() => #[this.v_currentDateTime]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute();
					inbound856v4010CockpitRS_Rt.this.v_currentDateTime = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds action = new com.extol.ebi.reactor.lib.actions.datetime.GetMilliseconds();
					createSimpleRule(4, "new GetMilliseconds().execute(this.v_currentDateTime) => #[this.v_currentDateTimeMillis]", action);
					final com.extol.ebi.ruleset.lang.core.DateTime var0 = inbound856v4010CockpitRS_Rt.this.v_currentDateTime;
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.v_currentDateTimeMillis = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(5, "new Move().execute(this.v_currentDateTimeMillis) => #[this.v_currentDateTimeMillisString]", action);
					final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.v_currentDateTimeMillis);
					final SourceNode result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.v_currentDateTimeMillisString = extractString(result);
				}
			}}).run();
			createCompositeRule(6, "", new Block() { public void body() {
			
			
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(7, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BSN.BSN396) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BSN").get("BSN396");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(7, "new Move().execute(source.Area1.BSN.BSN396) => #[this.v_ParentMessageId]", action);
						final SourceNode var0 = source.get("Area1").get("BSN").get("BSN396");
						final SourceNode result = action.execute(var0);
						inbound856v4010CockpitRS_Rt.this.v_ParentMessageId = extractString(result);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(8, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BSN.BSN396) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BSN").get("BSN396");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(8, "new Move().execute(source.Area1.BSN.BSN396) => #[this.v_MessageId]", action);
						final SourceNode var0 = source.get("Area1").get("BSN").get("BSN396");
						final SourceNode result = action.execute(var0);
						inbound856v4010CockpitRS_Rt.this.v_MessageId = extractString(result);
					}
				}
				createCompositeRule(9, "for source.Area2.sgHL", new Block() { public void body() {
					final SourceNode s0_Area2 = source.get("Area2");
					if (exists(s0_Area2)) {
					for (final SourceNode s1_cur_sgHL : s0_Area2.getIterable("sgHL")) {
				
				
					createCompositeRule(10, "for source.Area2.sgHL.current.HL", new Block() { public void body() {
						final SourceNode s2_HL = s1_cur_sgHL.get("HL");
						if (exists(s2_HL)) {
					
					
						{
							com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
							createSimpleRule(11, "new Add().execute(this.v_lineItemCounter, 1, 0) => #[this.v_lineItemCounter]", action);
							final com.extol.ebi.ruleset.lang.core.Number var0 = inbound856v4010CockpitRS_Rt.this.v_lineItemCounter;
							final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
							final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(0);
							final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
							inbound856v4010CockpitRS_Rt.this.v_lineItemCounter = result;
						}
					}}}).run();
					createCompositeRule(12, "for source.Area2.sgHL.current.DTM", new Block() { public void body() {
						for (final SourceNode s2_cur_DTM : s1_cur_sgHL.getIterable("DTM")) {
					
					
						{
							boolean conditionResult;
							{
								com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized condition = new com.extol.ebi.reactor.lib.actions.string.StringEqualsNormalized();
								createRuleCondition(13, "new StringEqualsNormalized().execute(source.Area2.sgHL.current.DTM.current.DTM374, \"011\") => #[]", condition);
								final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s2_cur_DTM.get("DTM374"));
								final com.extol.ebi.ruleset.lang.core.String var1 = asString("011");
								final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
								
								conditionResult = result.asJavaBoolean().booleanValue();
							}
							if (conditionResult) {
								com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
								createSimpleRule(13, "new Move().execute(source.Area2.sgHL.current.DTM.current.DTM373) => #[this.v_ShippedDate]", action);
								final SourceNode var0 = s2_cur_DTM.get("DTM373");
								final SourceNode result = action.execute(var0);
								inbound856v4010CockpitRS_Rt.this.v_ShippedDate = extractString(result);
							}
						}
					}}}).run();
				}}}}).run();
				createCompositeRule(14, "for source.Area3.CTT", new Block() { public void body() {
					final SourceNode s0_Area3 = source.get("Area3");
					if (exists(s0_Area3)) {
					final SourceNode s1_CTT = s0_Area3.get("CTT");
					if (exists(s1_CTT)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(15, "new Move().execute(source.Area3.CTT.CTT354) => #[this.v_NumberOfLineItems]", action);
						final SourceNode var0 = s1_CTT.get("CTT354");
						final SourceNode result = action.execute(var0);
						inbound856v4010CockpitRS_Rt.this.v_NumberOfLineItems = extractString(result);
					}
				}}}}).run();
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(16, "new Move().execute(this.v_lineItemCounter) => #[this.v_lineItemCounterString]", action);
					final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.v_lineItemCounter);
					final SourceNode result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.v_lineItemCounterString = extractString(result);
				}
			}}).run();
			createCompositeRule(17, "", new Block() { public void body() {
			
			
				{
					com.cleo.b2biaas.clarify.InboundCreateMessageHeader action = new com.cleo.b2biaas.clarify.InboundCreateMessageHeader();
					createSimpleRule(18, "new com.cleo.b2biaas.clarify.InboundCreateMessageHeader().execute(this.glb.tradingPartnerId, this.glb.tpName, \"856\", this.v_ParentMessageId, this.v_MessageId, this.v_currentDateTimeMillisString, \"true\", \"USD\", this.glb.ownerId, this.env.Functional_Group_Code, this.env.Functional_Group_Control_Number, this.env.Message_Control_Number) => #[this.v_inboundMessage]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = inbound856v4010CockpitRS_Rt.this.glb.tradingPartnerId;
					final com.extol.ebi.ruleset.lang.core.String var1 = inbound856v4010CockpitRS_Rt.this.glb.tpName;
					final com.extol.ebi.ruleset.lang.core.String var2 = asString("856");
					final com.extol.ebi.ruleset.lang.core.String var3 = inbound856v4010CockpitRS_Rt.this.v_ParentMessageId;
					final com.extol.ebi.ruleset.lang.core.String var4 = inbound856v4010CockpitRS_Rt.this.v_MessageId;
					final com.extol.ebi.ruleset.lang.core.String var5 = inbound856v4010CockpitRS_Rt.this.v_currentDateTimeMillisString;
					final com.extol.ebi.ruleset.lang.core.String var6 = asString("true");
					final com.extol.ebi.ruleset.lang.core.String var7 = asString("USD");
					final com.extol.ebi.ruleset.lang.core.String var8 = inbound856v4010CockpitRS_Rt.this.glb.ownerId;
					final com.extol.ebi.ruleset.lang.core.String var9 = inbound856v4010CockpitRS_Rt.this.env.Functional_Group_Code;
					final com.extol.ebi.ruleset.lang.core.String var10 = inbound856v4010CockpitRS_Rt.this.env.Functional_Group_Control_Number;
					final com.extol.ebi.ruleset.lang.core.String var11 = inbound856v4010CockpitRS_Rt.this.env.Message_Control_Number;
					final com.extol.ebi.ruleset.lang.core.Object result = action.execute(var0, var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11);
					inbound856v4010CockpitRS_Rt.this.v_inboundMessage = result;
				}
				{
					com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader action = new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader();
					createSimpleRule(19, "new com.cleo.b2biaas.clarify.InboundAddKeyToMessageHeader().execute(this.v_inboundMessage, \"logOfMessageId\", this.env.Log_of_Message_Id) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = inbound856v4010CockpitRS_Rt.this.v_inboundMessage;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("logOfMessageId");
					final com.extol.ebi.ruleset.lang.core.String var2 = inbound856v4010CockpitRS_Rt.this.env.Log_of_Message_Id;
					action.execute(var0, var1, var2);
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(20, "new IsNotNullOrWhiteSpaces().execute(source.Area1.BSN.BSN396) => #[]", condition);
						final SourceNode var0 = source.get("Area1").get("BSN").get("BSN396");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(20, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Shipment Identification\",\"\", source.Area1.BSN.BSN396) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound856v4010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Shipment Identification");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
						final com.extol.ebi.ruleset.lang.core.String var3 = extractString(source.get("Area1").get("BSN").get("BSN396"));
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(21, "new IsNotNullOrWhiteSpaces().execute(this.v_ShippedDate) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.v_ShippedDate);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(21, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Shipped Date\",\"{d}\", this.v_ShippedDate) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound856v4010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Shipped Date");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("{d}");
						final com.extol.ebi.ruleset.lang.core.String var3 = inbound856v4010CockpitRS_Rt.this.v_ShippedDate;
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(22, "new IsNotNullOrWhiteSpaces().execute(source.Area2.sgHL.current.PRF.PRF324) => #[]", condition);
						final SourceNode var0 = source.get("Area2").get("sgHL").get("PRF").get("PRF324");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(22, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Purchase Order Number\",\"\",source.Area2.sgHL.current.PRF.PRF324) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound856v4010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Purchase Order Number");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
						final com.extol.ebi.ruleset.lang.core.String var3 = extractString(source.get("Area2").get("sgHL").get("PRF").get("PRF324"));
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces condition = new com.extol.ebi.reactor.lib.actions.conditions.IsNotNullOrWhiteSpaces();
						createRuleCondition(23, "new IsNotNullOrWhiteSpaces().execute(this.v_NumberOfLineItems) => #[]", condition);
						final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.v_NumberOfLineItems);
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2 action = new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2();
						createSimpleRule(23, "new com.cleo.b2biaas.clarify.InboundAddMessageDetailsV2().execute(this.v_inboundMessage, \"Number of Line Items\", \"\",this.v_NumberOfLineItems) => #[]", action);
						final com.extol.ebi.ruleset.lang.core.Object var0 = inbound856v4010CockpitRS_Rt.this.v_inboundMessage;
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("Number of Line Items");
						final com.extol.ebi.ruleset.lang.core.String var2 = asString("");
						final com.extol.ebi.ruleset.lang.core.String var3 = inbound856v4010CockpitRS_Rt.this.v_NumberOfLineItems;
						action.execute(var0, var1, var2, var3);
					}
				}
				{
					com.cleo.b2biaas.clarify.InboundCloseMessage action = new com.cleo.b2biaas.clarify.InboundCloseMessage();
					createSimpleRule(24, "new com.cleo.b2biaas.clarify.InboundCloseMessage().execute(this.v_inboundMessage) => #[]", action);
					final com.extol.ebi.ruleset.lang.core.Object var0 = inbound856v4010CockpitRS_Rt.this.v_inboundMessage;
					action.execute(var0);
				}
			}}).run();
			createCompositeRule(25, "", new Block() { public void body() {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(26, "new Move().execute(this.glb.User_Reference_1) => #[this.env.User_Reference_1]", action);
					final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.glb.User_Reference_1);
					final SourceNode result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.env.User_Reference_1 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(27, "new Move().execute(this.glb.User_Reference_2) => #[this.env.User_Reference_2]", action);
					final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.glb.User_Reference_2);
					final SourceNode result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.env.User_Reference_2 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(28, "new Move().execute(this.glb.User_Reference_3) => #[this.env.User_Reference_3]", action);
					final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.glb.User_Reference_3);
					final SourceNode result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.env.User_Reference_3 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(29, "new Move().execute(this.glb.User_Reference_4) => #[this.env.User_Reference_4]", action);
					final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.glb.User_Reference_4);
					final SourceNode result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.env.User_Reference_4 = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(30, "new Move().execute(this.glb.User_Reference_5) => #[this.env.User_Reference_5]", action);
					final SourceNode var0 = toValueNode(inbound856v4010CockpitRS_Rt.this.glb.User_Reference_5);
					final SourceNode result = action.execute(var0);
					inbound856v4010CockpitRS_Rt.this.env.User_Reference_5 = extractString(result);
				}
			}}).run();
		}}).run();
	}

}
