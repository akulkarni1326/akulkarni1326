package com.cleo.b2bcloud.core.acknowledgment;

import com.cleo.catalyst.lib.Variable;
import com.extol.ebi.bps.lang.BpsCallable;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.sqlaccess.SqlAccess;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.database.lib.datasource.RtDataSource;
import com.extol.ebi.reactor.database.lib.schema.RtColumnTypes;
import com.extol.ebi.reactor.lib.AbstractAction;
import com.extol.ebi.reactor.lib.ValueNode;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;
import com.extol.ebi.sqlaccess.lib.BpsSqlAccessParameter;
import com.extol.ebi.sqlaccess.lib.Direction;
import com.extol.ebi.sqlaccess.lib.MultipleRecordsAction;
import com.extol.ebi.sqlaccess.lib.NoRecordsAction;
import com.extol.ebi.sqlaccess.lib.PreparedSqlAccess;
import com.extol.ebi.sqlaccess.lib.Retry;
import com.extol.ebi.sqlaccess.lib.SqlAccessHelper;
import com.extol.ebi.sqlaccess.lib.SqlAccessParameter;
import com.extol.ebi.sqlaccess.lib.TimeUnit;
import com.extol.ebi.sqlaccess.lib.Timeout;
import com.extol.ebi.sqlaccess.lib.V2SqlAccessTask;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("all")
public class InboundAcknowledgmentSQL implements SqlAccess {
  public void execute(final com.extol.ebi.ruleset.lang.core.String ReceiverID, final com.extol.ebi.ruleset.lang.core.String GroupCntlNo, final com.extol.ebi.ruleset.lang.core.String MessageCntlNo, final com.extol.ebi.ruleset.lang.core.String RefferenceNo, final com.extol.ebi.ruleset.lang.core.String TRADING_PARTNER_ID, final com.extol.ebi.ruleset.lang.core.String UUID) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class BpsTask extends V2SqlAccessTask implements BpsCallable {
    @OverrideOpName(value = "bps1://SQLAccess")
    public boolean execute(final com.extol.ebi.bps.lang.String ReceiverID, final com.extol.ebi.bps.lang.String GroupCntlNo, final com.extol.ebi.bps.lang.String MessageCntlNo, final com.extol.ebi.bps.lang.String RefferenceNo, final com.extol.ebi.bps.lang.String TRADING_PARTNER_ID, final com.extol.ebi.bps.lang.String UUID) {
      throw new UnsupportedOperationException("execute is not implemented");
    }
    
    public boolean execute_v2(final Variable<String> ReceiverID, final Variable<String> GroupCntlNo, final Variable<String> MessageCntlNo, final Variable<String> RefferenceNo, final Variable<String> TRADING_PARTNER_ID, final Variable<String> UUID) {
      PreparedSqlAccess sqlAccess = buildSqlAccess(ReceiverID, GroupCntlNo, MessageCntlNo);
      List<ValueNode> valueNodes = sqlAccess.performAction();
      
      RefferenceNo.setValue(valueNodes == null ? null : extractValue(valueNodes.get(0), java.lang.String.class));
      TRADING_PARTNER_ID.setValue(valueNodes == null ? null : extractValue(valueNodes.get(1), java.lang.String.class));
      UUID.setValue(valueNodes == null ? null : extractValue(valueNodes.get(2), java.lang.String.class));
      
      return true;
    }
    
    private static PreparedSqlAccess buildSqlAccess(final Variable<String> ReceiverID, final Variable<String> GroupCntlNo, final Variable<String> MessageCntlNo) {
      RtDataSource dataSource = new com.cleo.b2bcloud.core.systemchecks.ClarifyDatabaseDS_Rt();
      String statement = "select \"USER_REFERENCE_1\",\"TRADING_PARTNER_ID\",\"DATA_UUID\" from \"EBI\".\"LOG_OF_MESSAGE\" where \"RECEIVER_ID\"=${ReceiverID} and \"GROUP_CONTROL_REFERENCE\"=${GroupCntlNo} and \"MESSAGE_CONTROL_REFERENCE\"=${MessageCntlNo} and \"ACK_STATUS\"=\'5386\'";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      parameters.add(new BpsSqlAccessParameter("ReceiverID", ReceiverID, RtColumnTypes.VARCHAR, Direction.IN));
      parameters.add(new BpsSqlAccessParameter("GroupCntlNo", GroupCntlNo, RtColumnTypes.VARCHAR, Direction.IN));
      parameters.add(new BpsSqlAccessParameter("MessageCntlNo", MessageCntlNo, RtColumnTypes.VARCHAR, Direction.IN));
      parameters.add(new BpsSqlAccessParameter("RefferenceNo", RtColumnTypes.VARCHAR));
      parameters.add(new BpsSqlAccessParameter("TRADING_PARTNER_ID", RtColumnTypes.VARCHAR));
      parameters.add(new BpsSqlAccessParameter("UUID", RtColumnTypes.VARCHAR));
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
  
  public static class RulesetAction implements RulesetCallable, SqlAccess {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public com.extol.ebi.ruleset.lang.core.String RefferenceNo;
      
      @TupleIndex(value = 1)
      public com.extol.ebi.ruleset.lang.core.String TRADING_PARTNER_ID;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.String UUID;
    }
    
    public InboundAcknowledgmentSQL.RulesetAction.ResultTuple execute(final com.extol.ebi.ruleset.lang.core.String ReceiverID, final com.extol.ebi.ruleset.lang.core.String GroupCntlNo, final com.extol.ebi.ruleset.lang.core.String MessageCntlNo) {
      return null;
    }
  }
  
  public static class RulesetActionV2 extends AbstractAction implements RulesetCallable, SqlAccess {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public com.extol.ebi.ruleset.lang.core.String RefferenceNo;
      
      @TupleIndex(value = 1)
      public com.extol.ebi.ruleset.lang.core.String TRADING_PARTNER_ID;
      
      @TupleIndex(value = 2)
      public com.extol.ebi.ruleset.lang.core.String UUID;
    }
    
    public InboundAcknowledgmentSQL.RulesetActionV2.ResultTuple execute(final com.extol.ebi.ruleset.lang.core.String ReceiverID, final com.extol.ebi.ruleset.lang.core.String GroupCntlNo, final com.extol.ebi.ruleset.lang.core.String MessageCntlNo) {
      PreparedSqlAccess sqlAccess = buildSqlAccess(ReceiverID, GroupCntlNo, MessageCntlNo);
      List<ValueNode> valueNodes = sqlAccess.performAction();
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.RefferenceNo = (valueNodes == null ? null : valueNodes.get(0).extractString());
      resultTuple.TRADING_PARTNER_ID = (valueNodes == null ? null : valueNodes.get(1).extractString());
      resultTuple.UUID = (valueNodes == null ? null : valueNodes.get(2).extractString());
      
      return resultTuple;
    }
    
    private static PreparedSqlAccess buildSqlAccess(final com.extol.ebi.ruleset.lang.core.String ReceiverID, final com.extol.ebi.ruleset.lang.core.String GroupCntlNo, final com.extol.ebi.ruleset.lang.core.String MessageCntlNo) {
      RtDataSource dataSource = new com.cleo.b2bcloud.core.systemchecks.ClarifyDatabaseDS_Rt();
      String statement = "select \"USER_REFERENCE_1\",\"TRADING_PARTNER_ID\",\"DATA_UUID\" from \"EBI\".\"LOG_OF_MESSAGE\" where \"RECEIVER_ID\"=${ReceiverID} and \"GROUP_CONTROL_REFERENCE\"=${GroupCntlNo} and \"MESSAGE_CONTROL_REFERENCE\"=${MessageCntlNo} and \"ACK_STATUS\"=\'5386\'";
      
      SqlAccessHelper helper = new SqlAccessHelper();
      helper.isCallable = false;
      helper.multipleRecordsAction = MultipleRecordsAction.Fail;
      helper.noRecordsAction = NoRecordsAction.ReturnNull;
      helper.timeout = new Timeout(0, TimeUnit.Seconds);
      helper.retry = new Retry(0, 0, TimeUnit.Seconds);
      
      ArrayList<SqlAccessParameter> parameters = new ArrayList<SqlAccessParameter>();
      parameters.add(new SqlAccessParameter("ReceiverID", ReceiverID, RtColumnTypes.VARCHAR, Direction.IN));
      parameters.add(new SqlAccessParameter("GroupCntlNo", GroupCntlNo, RtColumnTypes.VARCHAR, Direction.IN));
      parameters.add(new SqlAccessParameter("MessageCntlNo", MessageCntlNo, RtColumnTypes.VARCHAR, Direction.IN));
      parameters.add(new SqlAccessParameter("RefferenceNo", RtColumnTypes.VARCHAR));
      parameters.add(new SqlAccessParameter("TRADING_PARTNER_ID", RtColumnTypes.VARCHAR));
      parameters.add(new SqlAccessParameter("UUID", RtColumnTypes.VARCHAR));
      helper.parameters = parameters;
      
      return new PreparedSqlAccess(dataSource, statement, helper); 
    }
  }
}
