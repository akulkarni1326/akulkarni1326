/**
* @generated
*/
package com.otterproducts.core.edi.outbound.n810;

import com.cleo.catalyst.lib.AbstractCatalyst;
import com.cleo.catalyst.lib.CatalyticProviderFactory;
import com.cleo.catalyst.lib.Functions.Function0;
import com.cleo.catalyst.lib.StepsBlockBuilder;
import com.cleo.catalyst.lib.Variable;
import com.cleo.common.lang.annotations.ParameterType;
import com.extol.ebi.bps.lib.tasks.misc.SetExitStatus;
import com.extol.ebi.bps.lib.tasks.misc.SetRouteFieldValues;
import com.extol.ebi.bps.lib.tasks.transformation.ExecuteTransformation;
import com.extol.ebi.bps.lib.types.Route;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.transformationsettings.TransformationSettings;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@SuppressWarnings("all")
public class BaseOutbound810RouteBPS_Rt extends AbstractCatalyst {
	private final Variable<Ruleset> f_ruleset;
	private final Variable<String> f_tpIdValue;
	private final Variable<String> f_partnerName;
	private final Variable<Ruleset> f_cockpitRS;
	private final Variable<String> f_ReprocessParms;
	private final Variable<String> f_docType;
	
	public BaseOutbound810RouteBPS_Rt(CatalyticProviderFactory cpf) {
		super(cpf);
		f_ruleset = variable(Ruleset.class, null);
		f_tpIdValue = variable(String.class, null);
		f_partnerName = variable(String.class, null);
		f_cockpitRS = variable(Ruleset.class, null);
		f_ReprocessParms = variable(String.class, null);
		f_docType = variable(String.class, null);
	}
	
	public boolean execute(@ParameterType(Route.class) Variable<Route> p_route, @ParameterType(StorageNode.class) Variable<StorageNode> p_context, @ParameterType(StorageNode.class) Variable<StorageNode> p_inputDataFragment) {
		final Variable<StorageNode> v_target = variable(StorageNode.class, null);
		final Variable<StorageNode> v_targetContext = variable(StorageNode.class, null);
		final Variable<StorageNode> v_sourceContext = variable(StorageNode.class, null);

		StepsBlockBuilder builder = this.getBuilder();

		builder.addStep(null, "Set Route Field Values", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Route Field Values");
					SetRouteFieldValues task = new SetRouteFieldValues();
					setupTask(task);
					return task.execute(p_route);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Execute Transformation - Single Output", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Execute Transformation - Single Output");
					ExecuteTransformation task = new ExecuteTransformation();
					setupTask(task);
					return task.execute(p_inputDataFragment, v_target, literalTypeFromString(TransformationSettings.class, "com.cleo.b2bcloud.core.DefaultTransformationSettingsTS"), f_ruleset, null, p_context, v_targetContext);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "com.cleo.cic.cockpit.core.outbound.outboundCockpitReferenceBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.outbound.outboundCockpitReferenceBPS");
					return getInvokeDynamicTask("com.cleo.cic.cockpit.core.outbound.outboundCockpitReferenceBPS", "bps1://BusinessProcessScript").execute(p_context, v_targetContext, v_target, f_partnerName, f_tpIdValue, f_cockpitRS, f_ReprocessParms);
				} finally { _endTask();}
			}
		}, "next", "Failure");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, true));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		builder.addStep("Failure", "com.cleo.cic.cockpit.core.outbound.outboundErrorCockpitBPS", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("com.cleo.cic.cockpit.core.outbound.outboundErrorCockpitBPS");
					return getInvokeDynamicTask("com.cleo.cic.cockpit.core.outbound.outboundErrorCockpitBPS", "bps1://BusinessProcessScript").execute(v_sourceContext, v_targetContext, f_partnerName, f_tpIdValue, p_inputDataFragment, f_docType, f_ReprocessParms);
				} finally { _endTask();}
			}
		}, "next", "end");
		
		builder.addStep(null, "Set Exit Status", new Function0<Boolean>() {
		
			public Boolean apply() {
				try { _startTask("Set Exit Status");
					SetExitStatus task = new SetExitStatus();
					setupTask(task);
					return task.execute(variable(Boolean.class, false));
				} finally { _endTask();}
			}
		}, "end", "end");
		
		return builder.createRunner().run();
	}
	
	public List<String> getFieldNames() {
		return Arrays.asList("f_ruleset", "f_tpIdValue", "f_partnerName", "f_cockpitRS", "f_ReprocessParms", "f_docType");
	}
	
	public void initialize(final Map<String, Object> map) {
		_setFieldWithMap(f_ruleset, "f_ruleset", map);
		_setFieldWithMap(f_tpIdValue, "f_tpIdValue", map);
		_setFieldWithMap(f_partnerName, "f_partnerName", map);
		_setFieldWithMap(f_cockpitRS, "f_cockpitRS", map);
		_setFieldWithMap(f_ReprocessParms, "f_ReprocessParms", map);
		_setFieldWithMap(f_docType, "f_docType", map);
	}
}
