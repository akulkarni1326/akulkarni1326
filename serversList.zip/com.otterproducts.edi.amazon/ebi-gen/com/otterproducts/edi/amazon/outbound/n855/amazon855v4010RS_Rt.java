/**
* @generated
*/
package com.otterproducts.edi.amazon.outbound.n855;

import com.extol.ebi.reactor.lib.schema.SchemaProvider;
import com.extol.ebi.reactor.lib.connectors.Connector;
import com.extol.ebi.reactor.lib.*;
import com.extol.ebi.reactor.edi.lib.connectors.*;
import com.extol.ebi.reactor.edi.lib.schema.*;
import com.extol.ebi.reactor.pojo.lib.*;
import com.extol.ebi.reactor.pojo.lib.connectors.*;

@SuppressWarnings("all")
public class amazon855v4010RS_Rt extends AbstractReactor<RtPojoSchema,RtEdiDerivedMessageSchema> {
	
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext sys = new com.extol.ebi.ruleset.lang.core.reactor.contexts.SystemContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext glb = new com.extol.ebi.ruleset.lang.core.reactor.contexts.BaseGlobalContext();
	private com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext env = addToContextMap(new com.extol.ebi.ruleset.lang.core.reactor.contexts.EnvironmentContext());
	private com.extol.ebi.ruleset.lang.core.String v_date;
	private com.extol.ebi.ruleset.lang.core.DateTime v_BAK04;
	private com.extol.ebi.ruleset.lang.core.String v_UOM;
	private com.extol.ebi.ruleset.lang.core.Number v_count;
	private com.extol.ebi.ruleset.lang.core.Number v_CTT02;
	private com.extol.ebi.ruleset.lang.core.Number v_Qty;
	private com.extol.ebi.ruleset.lang.core.String v_reasonCode;
	private com.extol.ebi.ruleset.lang.core.String v_OrderQty;
	
	public SchemaProvider<RtPojoSchema> getSourceSchema() {
		return new com.otterproducts.core.system.n855.PurchaseOrderAcknowledgementMessageOBJ_Rt();
	}
	
	public SchemaProvider<RtEdiDerivedMessageSchema> getTargetSchema() {
		return new com.otterproducts.core.edi.schemas.n855v4010EDI_Rt();
	}
	
	public Connector getSourceConnector() {
		return new XMLObjectConnector();
	}

	public Connector getTargetConnector() {
		return new X12Connector();
	}

	public void run() {
		final SourceNode source = getDataSource().getRoot();
		final TargetNode target = getDataWriter().getRoot();

		createCompositeRule(1, "initNew target.Area1.BAK", new Block() { public void body() {
		
			final TargetNode t0_Area1 = target.getLast(at("Area1"));
			final TargetNode t1_BAK = t0_Area1.getLast(at("BAK"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(2, "new Move().execute(\"00\") => #[target.Area1.BAK.BAK353]", action);
				final SourceNode var0 = toValueNode(asString("00"));
				final SourceNode result = action.execute(var0);
				t1_BAK.set(at("BAK353"), result);
			}
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(3, "new Move().execute(\"AD\") => #[target.Area1.BAK.BAK587]", action);
				final SourceNode var0 = toValueNode(asString("AD"));
				final SourceNode result = action.execute(var0);
				t1_BAK.set(at("BAK587"), result);
			}
			createCompositeRule(4, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.PurchaseOrderNumber", new Block() { public void body() {
				final SourceNode s0_purchaseOrderAcknowledgementMessage = source.get("purchaseOrderAcknowledgementMessage");
				if (exists(s0_purchaseOrderAcknowledgementMessage)) {
				final SourceNode s1_CustomerOrder = s0_purchaseOrderAcknowledgementMessage.get("CustomerOrder");
				if (exists(s1_CustomerOrder)) {
				final SourceNode s2_PurchaseOrderNumber = s1_CustomerOrder.get("PurchaseOrderNumber");
				if (exists(s2_PurchaseOrderNumber)) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(5, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.PurchaseOrderNumber) => #[target.Area1.BAK.BAK324, this.env.User_Reference_1]", action);
					final SourceNode var0 = s2_PurchaseOrderNumber;
					final SourceNode result = action.execute(var0);
					t1_BAK.set(at("BAK324"), result);
					amazon855v4010RS_Rt.this.env.User_Reference_1 = extractString(result);
				}
			}}}}}).run();
			createCompositeRule(6, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.OrderDate", new Block() { public void body() {
				final SourceNode s0_purchaseOrderAcknowledgementMessage = source.get("purchaseOrderAcknowledgementMessage");
				if (exists(s0_purchaseOrderAcknowledgementMessage)) {
				final SourceNode s1_CustomerOrder = s0_purchaseOrderAcknowledgementMessage.get("CustomerOrder");
				if (exists(s1_CustomerOrder)) {
				final SourceNode s2_OrderDate = s1_CustomerOrder.get("OrderDate");
				if (exists(s2_OrderDate)) {
			
			
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(7, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.OrderDate) => #[this.v_date]", action);
					final SourceNode var0 = s2_OrderDate;
					final SourceNode result = action.execute(var0);
					amazon855v4010RS_Rt.this.v_date = extractString(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.string.Substring action = new com.extol.ebi.reactor.lib.actions.string.Substring();
					createSimpleRule(8, "new Substring().execute(this.v_date, 0, 10) => #[this.v_date]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = amazon855v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(0);
					final com.extol.ebi.ruleset.lang.core.Number var2 = asNumber(10);
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1, var2);
					amazon855v4010RS_Rt.this.v_date = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.string.ExtractDigits action = new com.extol.ebi.reactor.lib.actions.string.ExtractDigits();
					createSimpleRule(9, "new ExtractDigits().execute(this.v_date) => #[this.v_date]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = amazon855v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
					amazon855v4010RS_Rt.this.v_date = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString action = new com.extol.ebi.reactor.lib.actions.datetime.CreateDateTimeFromString();
					createSimpleRule(10, "new CreateDateTimeFromString().execute(this.v_date, \"yyyyMMdd\") => #[this.v_BAK04]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = amazon855v4010RS_Rt.this.v_date;
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("yyyyMMdd");
					final com.extol.ebi.ruleset.lang.core.DateTime result = action.execute(var0, var1);
					amazon855v4010RS_Rt.this.v_BAK04 = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(11, "new Move().execute(this.v_BAK04) => #[target.Area1.BAK.BAK373]", action);
					final SourceNode var0 = toValueNode(amazon855v4010RS_Rt.this.v_BAK04);
					final SourceNode result = action.execute(var0);
					t1_BAK.set(at("BAK373"), result);
				}
			}}}}}).run();
		}}).run();
		createCompositeRule(12, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine initNew target.Area2.sgPO1", new Block() { public void body() {
			final SourceNode s0_purchaseOrderAcknowledgementMessage = source.get("purchaseOrderAcknowledgementMessage");
			if (exists(s0_purchaseOrderAcknowledgementMessage)) {
			final SourceNode s1_CustomerOrder = s0_purchaseOrderAcknowledgementMessage.get("CustomerOrder");
			if (exists(s1_CustomerOrder)) {
			final SourceNode s2_CustomerOrderLines = s1_CustomerOrder.get("CustomerOrderLines");
			if (exists(s2_CustomerOrderLines)) {
			for (final SourceNode s3_cur_CustomerOrderLine : s2_CustomerOrderLines.getIterable("CustomerOrderLine")) {
		
			final TargetNode t0_Area2 = target.getLast(at("Area2"));
			final TargetNode t1_cur_sgPO1 = t0_Area2.create(at("sgPO1"));
		
			createCompositeRule(13, "initNew target.Area2.sgPO1.current.PO1", new Block() { public void body() {
			
				final TargetNode t2_PO1 = t1_cur_sgPO1.getLast(at("PO1"));
			
				createCompositeRule(14, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.Product.ProductId", new Block() { public void body() {
					final SourceNode s4_Product = s3_cur_CustomerOrderLine.get("Product");
					if (exists(s4_Product)) {
					final SourceNode s5_ProductId = s4_Product.get("ProductId");
					if (exists(s5_ProductId)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(15, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.Product.ProductId) => #[target.Area2.sgPO1.current.PO1.PO1234]", action);
						final SourceNode var0 = s5_ProductId;
						final SourceNode result = action.execute(var0);
						t2_PO1.set(at("PO1234"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(16, "new Move().execute(\"VN\") => #[target.Area2.sgPO1.current.PO1.PO1235]", action);
						final SourceNode var0 = toValueNode(asString("VN"));
						final SourceNode result = action.execute(var0);
						t2_PO1.set(at("PO1235"), result);
					}
				}}}}).run();
				createCompositeRule(17, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(17, "new StringEquals().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement, \"EACH\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_CustomerOrderLine.get("ProductQuantityUnitOfMeasurement"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("EACH");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(18, "new Move().execute(\"EA\") => #[target.Area2.sgPO1.current.PO1.PO1355]", action);
						final SourceNode var0 = toValueNode(asString("EA"));
						final SourceNode result = action.execute(var0);
						t2_PO1.set(at("PO1355"), result);
					}
				}}).run();
				{
					com.otterproducts.edi.amazon.outbound.n855.SelectxrefQtySQL.RulesetActionV2 action = new com.otterproducts.edi.amazon.outbound.n855.SelectxrefQtySQL.RulesetActionV2();
					createSimpleRule(19, "new com.otterproducts.edi.amazon.outbound.n855.SelectxrefQtySQL$RulesetActionV2().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.PurchaseOrderNumber, source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.Product.ProductId) => #[this.v_OrderQty]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s1_CustomerOrder.get("PurchaseOrderNumber"));
					final com.extol.ebi.ruleset.lang.core.String var1 = extractString(s3_cur_CustomerOrderLine.get("Product").get("ProductId"));
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0, var1);
					amazon855v4010RS_Rt.this.v_OrderQty = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(20, "new Move().execute(this.v_OrderQty) => #[target.Area2.sgPO1.current.PO1.PO1330, this.v_Qty]", action);
					final SourceNode var0 = toValueNode(amazon855v4010RS_Rt.this.v_OrderQty);
					final SourceNode result = action.execute(var0);
					t2_PO1.set(at("PO1330"), result);
					amazon855v4010RS_Rt.this.v_Qty = extractNumber(result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(21, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount) => #[target.Area2.sgPO1.current.PO1.PO1212]", action);
					final SourceNode var0 = s3_cur_CustomerOrderLine.get("ProductUnitPriceAmount");
					final SourceNode result = action.execute(var0);
					t2_PO1.set(at("PO1212"), result);
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(22, "new Move().execute(\"CT\") => #[target.Area2.sgPO1.current.PO1.PO1639]", action);
					final SourceNode var0 = toValueNode(asString("CT"));
					final SourceNode result = action.execute(var0);
					t2_PO1.set(at("PO1639"), result);
				}
			}}).run();
			createCompositeRule(23, "initNew target.Area2.sgPO1.current.CTP", new Block() { public void body() {
			
				final TargetNode t2_cur_CTP = t1_cur_sgPO1.create(at("CTP"));
			
				createCompositeRule(24, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount", new Block() { public void body() {
					final SourceNode s4_ProductUnitPriceAmount = s3_cur_CustomerOrderLine.get("ProductUnitPriceAmount");
					if (exists(s4_ProductUnitPriceAmount)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(25, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductUnitPriceAmount) => #[target.Area2.sgPO1.current.CTP.current.CTP212]", action);
						final SourceNode var0 = s4_ProductUnitPriceAmount;
						final SourceNode result = action.execute(var0);
						t2_cur_CTP.set(at("CTP212"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(26, "new Move().execute(\"ACT\") => #[target.Area2.sgPO1.current.CTP.current.CTP236]", action);
						final SourceNode var0 = toValueNode(asString("ACT"));
						final SourceNode result = action.execute(var0);
						t2_cur_CTP.set(at("CTP236"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(27, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.OrderedQuantity) => #[target.Area2.sgPO1.current.CTP.current.CTP380]", action);
						final SourceNode var0 = s3_cur_CustomerOrderLine.get("OrderedQuantity");
						final SourceNode result = action.execute(var0);
						t2_cur_CTP.set(at("CTP380"), result);
					}
					createCompositeRule(28, "", new ConditionedBlock() {
					public boolean condition() {
						com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
						createRuleCondition(28, "new StringEquals().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement, \"EACH\") => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_CustomerOrderLine.get("ProductQuantityUnitOfMeasurement"));
						final com.extol.ebi.ruleset.lang.core.String var1 = asString("EACH");
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
						
						return result.asJavaBoolean().booleanValue();
					}
					public void body() {
					
					
						{
							com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
							createSimpleRule(29, "new Move().execute(\"EA\") => #[target.Area2.sgPO1.current.CTP.current.CTPC001.C00101]", action);
							final SourceNode var0 = toValueNode(asString("EA"));
							final SourceNode result = action.execute(var0);
							t2_cur_CTP.set(at("CTPC001", "C00101"), result);
						}
					}}).run();
				}}}).run();
			}}).run();
			createCompositeRule(30, "initNew target.Area2.sgPO1.current.sgACK.current.ACK", new Block() { public void body() {
			
				final TargetNode t2_cur_sgACK = t1_cur_sgPO1.getLast(at("sgACK"));
				final TargetNode t3_ACK = t2_cur_sgACK.getLast(at("ACK"));
			
				createCompositeRule(31, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ReasonCode", new Block() { public void body() {
					final SourceNode s4_ReasonCode = s3_cur_CustomerOrderLine.get("ReasonCode");
					if (exists(s4_ReasonCode)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.RawMove action = new com.extol.ebi.reactor.lib.actions.general.RawMove();
						createSimpleRule(32, "new RawMove().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ReasonCode) => #[this.v_reasonCode]", action);
						final SourceNode var0 = s4_ReasonCode;
						final SourceNode result = action.execute(var0);
						amazon855v4010RS_Rt.this.v_reasonCode = extractString(result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(33, "new Move().execute(this.v_reasonCode) => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK668]", action);
						final SourceNode var0 = toValueNode(amazon855v4010RS_Rt.this.v_reasonCode);
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK668"), result);
					}
				}}}).run();
				{
					boolean conditionResult;
					{
						com.extol.ebi.reactor.lib.actions.string.IsStringEmpty condition = new com.extol.ebi.reactor.lib.actions.string.IsStringEmpty();
						createRuleCondition(34, "new IsStringEmpty().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ReasonCode) => #[]", condition);
						final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_CustomerOrderLine.get("ReasonCode"));
						final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0);
						
						conditionResult = result.asJavaBoolean().booleanValue();
					}
					if (conditionResult) {
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(34, "new Move().execute(\"AC\") => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK668]", action);
						final SourceNode var0 = toValueNode(asString("AC"));
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK668"), result);
					}
				}
				{
					com.extol.ebi.reactor.lib.actions.string.Trim action = new com.extol.ebi.reactor.lib.actions.string.Trim();
					createSimpleRule(35, "new Trim().execute(this.v_OrderQty) => #[this.v_OrderQty]", action);
					final com.extol.ebi.ruleset.lang.core.String var0 = amazon855v4010RS_Rt.this.v_OrderQty;
					final com.extol.ebi.ruleset.lang.core.String result = action.execute(var0);
					amazon855v4010RS_Rt.this.v_OrderQty = result;
				}
				{
					com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
					createSimpleRule(36, "new Move().execute(this.v_OrderQty) => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK380]", action);
					final SourceNode var0 = toValueNode(amazon855v4010RS_Rt.this.v_OrderQty);
					final SourceNode result = action.execute(var0);
					t3_ACK.set(at("ACK380"), result);
				}
				createCompositeRule(37, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.bool.BooleanEquals condition = new com.extol.ebi.reactor.lib.actions.bool.BooleanEquals();
					createRuleCondition(37, "new BooleanEquals().execute(source.purchaseOrderAcknowledgementMessage.OrderAcknowledgements.CustomerOrderLineAcknowledgement.current.IsQuantityChanged, false) => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.Boolean var0 = extractBoolean(s0_purchaseOrderAcknowledgementMessage.get("OrderAcknowledgements").get("CustomerOrderLineAcknowledgement").get("IsQuantityChanged"));
					final com.extol.ebi.ruleset.lang.core.Boolean var1 = asBoolean(false);
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
				}}).run();
				createCompositeRule(38, "", new ConditionedBlock() {
				public boolean condition() {
					com.extol.ebi.reactor.lib.actions.string.StringEquals condition = new com.extol.ebi.reactor.lib.actions.string.StringEquals();
					createRuleCondition(38, "new StringEquals().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.ProductQuantityUnitOfMeasurement, \"EACH\") => #[]", condition);
					final com.extol.ebi.ruleset.lang.core.String var0 = extractString(s3_cur_CustomerOrderLine.get("ProductQuantityUnitOfMeasurement"));
					final com.extol.ebi.ruleset.lang.core.String var1 = asString("EACH");
					final com.extol.ebi.ruleset.lang.core.Boolean result = condition.execute(var0, var1);
					
					return result.asJavaBoolean().booleanValue();
				}
				public void body() {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(39, "new Move().execute(\"EA\") => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK355]", action);
						final SourceNode var0 = toValueNode(asString("EA"));
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK355"), result);
					}
				}}).run();
				createCompositeRule(40, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate", new Block() { public void body() {
					final SourceNode s4_PromisedShipDate = s3_cur_CustomerOrderLine.get("PromisedShipDate");
					if (exists(s4_PromisedShipDate)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(41, "new Move().execute(\"068\") => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK374]", action);
						final SourceNode var0 = toValueNode(asString("068"));
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK374"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(42, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate) => #[target.Area2.sgPO1.current.sgACK.current.ACK.ACK373]", action);
						final SourceNode var0 = s4_PromisedShipDate;
						final SourceNode result = action.execute(var0);
						t3_ACK.set(at("ACK373"), result);
					}
				}}}).run();
			}}).run();
			createCompositeRule(43, "initNew target.Area2.sgPO1.current.sgACK.current.DTM", new Block() { public void body() {
			
				final TargetNode t2_cur_sgACK = t1_cur_sgPO1.getLast(at("sgACK"));
				final TargetNode t3_DTM = t2_cur_sgACK.getLast(at("DTM"));
			
				createCompositeRule(44, "for source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate", new Block() { public void body() {
					final SourceNode s4_PromisedShipDate = s3_cur_CustomerOrderLine.get("PromisedShipDate");
					if (exists(s4_PromisedShipDate)) {
				
				
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(45, "new Move().execute(\"067\") => #[target.Area2.sgPO1.current.sgACK.current.DTM.DTM374]", action);
						final SourceNode var0 = toValueNode(asString("067"));
						final SourceNode result = action.execute(var0);
						t3_DTM.set(at("DTM374"), result);
					}
					{
						com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
						createSimpleRule(46, "new Move().execute(source.purchaseOrderAcknowledgementMessage.CustomerOrder.CustomerOrderLines.CustomerOrderLine.current.PromisedShipDate) => #[target.Area2.sgPO1.current.sgACK.current.DTM.DTM373]", action);
						final SourceNode var0 = s4_PromisedShipDate;
						final SourceNode result = action.execute(var0);
						t3_DTM.set(at("DTM373"), result);
					}
				}}}).run();
				{
					com.extol.ebi.reactor.lib.actions.numeric.Add action = new com.extol.ebi.reactor.lib.actions.numeric.Add();
					createSimpleRule(47, "new Add().execute(this.v_count, 1, null) => #[this.v_count]", action);
					final com.extol.ebi.ruleset.lang.core.Number var0 = amazon855v4010RS_Rt.this.v_count;
					final com.extol.ebi.ruleset.lang.core.Number var1 = asNumber(1);
					final com.extol.ebi.ruleset.lang.core.Number var2 = null;
					final com.extol.ebi.ruleset.lang.core.Number result = action.execute(var0, var1, var2);
					amazon855v4010RS_Rt.this.v_count = result;
				}
			}}).run();
		}}}}}}).run();
		createCompositeRule(48, "initNew target.Area3.sgCTT.CTT", new Block() { public void body() {
		
			final TargetNode t0_Area3 = target.getLast(at("Area3"));
			final TargetNode t1_sgCTT = t0_Area3.getLast(at("sgCTT"));
			final TargetNode t2_CTT = t1_sgCTT.getLast(at("CTT"));
		
			{
				com.extol.ebi.reactor.lib.actions.general.Move action = new com.extol.ebi.reactor.lib.actions.general.Move();
				createSimpleRule(49, "new Move().execute(this.v_count) => #[target.Area3.sgCTT.CTT.CTT354]", action);
				final SourceNode var0 = toValueNode(amazon855v4010RS_Rt.this.v_count);
				final SourceNode result = action.execute(var0);
				t2_CTT.set(at("CTT354"), result);
			}
		}}).run();
	}

}
