package com.otterproducts.core.edi.outbound.n810;

import com.extol.ebi.bps.lang.RouteParameter;
import com.extol.ebi.bps.lib.templates.OutboundTemplate;
import com.extol.ebi.bps.lib.types.Route;
import com.extol.ebi.bps.lib.types.Ruleset;
import com.extol.ebi.lang.bps.OverrideOpName;
import com.extol.ebi.lang.storage.StorageNode;
import com.extol.ebi.lang.tuples.Tuple;
import com.extol.ebi.lang.tuples.TupleIndex;
import com.extol.ebi.reactor.server.actions.AbstractBusinessProcessAction;
import com.extol.ebi.ruleset.lang.core.RulesetCallable;

@SuppressWarnings("all")
public class BaseOutbound810RouteBPS extends OutboundTemplate {
  @RouteParameter
  public Ruleset ruleset;
  
  @RouteParameter
  public com.extol.ebi.bps.lang.String tpIdValue;
  
  @RouteParameter
  public com.extol.ebi.bps.lang.String partnerName;
  
  @RouteParameter
  public Ruleset cockpitRS;
  
  @RouteParameter
  public com.extol.ebi.bps.lang.String ReprocessParms;
  
  @RouteParameter
  public com.extol.ebi.bps.lang.String docType;
  
  @OverrideOpName(value = "bps1://BusinessProcessScript")
  public OutboundTemplate.ResultTuple execute(final Route route, final StorageNode context, final StorageNode inputDataFragment) {
    throw new UnsupportedOperationException("execute is not implemented");
  }
  
  public static class RulesetAction extends AbstractBusinessProcessAction implements RulesetCallable {
    public static class ResultTuple implements Tuple {
      @TupleIndex(value = 0)
      public com.extol.ebi.ruleset.lang.core.Object route;
      
      @TupleIndex(value = 1)
      public StorageNode context;
      
      @TupleIndex(value = 2)
      public StorageNode inputDataFragment;
      
      @TupleIndex(value = 3)
      public com.extol.ebi.ruleset.lang.core.Boolean _exit_PassStatus;
    }
    
    public BaseOutbound810RouteBPS.RulesetAction.ResultTuple execute(final com.extol.ebi.ruleset.lang.core.Object route, final StorageNode context, final StorageNode inputDataFragment) {
      Object[] _bps_parameters = new Object[3];
      _bps_parameters[0] = toBpsObject(route);
      _bps_parameters[1] = context;
      _bps_parameters[2] = inputDataFragment;
      
      boolean _exit_PassStatus = launchScript("com.otterproducts.core.edi", "com.otterproducts.core.edi.outbound.n810.BaseOutbound810RouteBPS", _bps_parameters);
      
      ResultTuple resultTuple = new ResultTuple();
      resultTuple.route = asObject(_bps_parameters[0]);
      resultTuple.context = asStorageNode(_bps_parameters[1]);
      resultTuple.inputDataFragment = asStorageNode(_bps_parameters[2]);
      resultTuple._exit_PassStatus = asBoolean(_exit_PassStatus);
      return resultTuple;
    }
  }
}
